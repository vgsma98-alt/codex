<?php
/**
 * Fallback template for the Madaq Restaurant theme.
 *
 * WordPress requires index.php in every classic theme. The restaurant home
 * page is rendered by front-page.php; this template keeps all other requests
 * valid and intentionally reuses the same complete presentation.
 */

require get_template_directory() . '/front-page.php';

