(() => {
  const root = document.querySelector('[data-madaq-slider]');
  if (!root) return;
  const slides = [...root.querySelectorAll('[data-slide]')];
  const dots = [...root.querySelectorAll('[data-slide-to]')];
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let current = 0;
  let timer;

  const show = (next) => {
    current = (next + slides.length) % slides.length;
    slides.forEach((slide, index) => {
      const active = index === current;
      slide.classList.toggle('is-active', active);
      slide.setAttribute('aria-hidden', active ? 'false' : 'true');
    });
    dots.forEach((dot, index) => dot.classList.toggle('is-active', index === current));
  };
  const start = () => {
    if (reducedMotion) return;
    window.clearInterval(timer);
    timer = window.setInterval(() => show(current + 1), 6500);
  };

  root.querySelector('[data-slide-prev]')?.addEventListener('click', () => { show(current - 1); start(); });
  root.querySelector('[data-slide-next]')?.addEventListener('click', () => { show(current + 1); start(); });
  dots.forEach((dot, index) => dot.addEventListener('click', () => { show(index); start(); }));
  root.addEventListener('mouseenter', () => window.clearInterval(timer));
  root.addEventListener('mouseleave', start);
  root.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft') show(current - 1);
    if (event.key === 'ArrowRight') show(current + 1);
  });
  start();
})();
