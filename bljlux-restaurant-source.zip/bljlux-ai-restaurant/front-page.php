<?php
if (!defined('ABSPATH')) {
    exit;
}
require get_template_directory() . '/front-page-v2.php';
return;

$restaurant_name = madaq_business_value('site_title', get_bloginfo('name'));
$phone = madaq_business_value('phone', '+212 5 22 00 00 00');
$email = madaq_business_value('email', 'reservation@madaq.ma');
$address = madaq_business_value('address', 'الدار البيضاء، المغرب');
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="shell nav">
        <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
            <span class="brand-mark">م</span>
            <span><?php echo esc_html($restaurant_name); ?></span>
        </a>
        <nav class="nav-links" aria-label="التنقل الرئيسي">
            <a href="#story">حكايتنا</a>
            <a href="#menu">قائمة الطعام</a>
            <a href="#experience">التجربة</a>
            <a class="button ghost" href="#contact">احجز طاولتك</a>
        </nav>
    </div>
</header>

<main>
    <section class="hero">
        <div class="shell hero-content">
            <div class="eyebrow">نكهات مغربية بروح معاصرة</div>
            <h1>مذاقٌ يحكي<br>حكاية المغرب</h1>
            <p>نأخذك في رحلة بين وصفات الدار الأصيلة ولمسات الطهاة المبتكرة، داخل فضاء دافئ صُمّم للّقاءات التي لا تُنسى.</p>
            <div class="hero-actions">
                <a class="button" href="#contact">احجز طاولتك</a>
                <a class="button ghost" href="#menu">اكتشف القائمة</a>
            </div>
        </div>
        <div class="shell hero-note">مفتوح يوميًا • 12:00 — 23:30</div>
    </section>

    <section id="story" class="section">
        <div class="shell story-grid">
            <div>
                <div class="section-kicker">من مطبخ الدار إلى مائدتك</div>
                <h2 class="section-title">تراث نتقنه،<br>وتفاصيل نجددها</h2>
                <p class="section-lead">في <?php echo esc_html($restaurant_name); ?> نختار منتجات الموسم بعناية، ونحضّر التوابل يوميًا، ونمنح كل طبق الوقت الذي يستحقه. النتيجة تجربة كريمة، صادقة وأنيقة دون تكلّف.</p>
            </div>
            <div class="story-card">
                <div class="story-quote">
                    <strong>“</strong>
                    <p>الضيافة عندنا تبدأ قبل وصول الطبق، وتبقى في الذاكرة بعد آخر رشفة شاي.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="menu" class="section menu-section">
        <div class="shell">
            <div class="menu-heading">
                <div>
                    <div class="section-kicker">مختارات الشيف</div>
                    <h2 class="section-title">أطباق تحبّ المشاركة</h2>
                </div>
                <p class="section-lead">قائمة موسمية تجمع بين الكلاسيكيات المغربية ومقادير محلية منتقاة.</p>
            </div>
            <div class="menu-grid">
                <article class="dish"><span class="dish-tag">من الفرن</span><div class="dish-top"><h3>طاجين الدجاج البلدي</h3><span class="price">145 د.م</span></div><p>ليمون مصيّر، زيتون أخضر، زعفران وخضر موسمية.</p></article>
                <article class="dish"><span class="dish-tag">طبق الدار</span><div class="dish-top"><h3>كسكس سبع خضاري</h3><span class="price">130 د.م</span></div><p>سميد مفوّر يدويًا، خضر السوق ومرق عطري خفيف.</p></article>
                <article class="dish"><span class="dish-tag">مشاوي</span><div class="dish-top"><h3>ضلعة مطهوة ببطء</h3><span class="price">195 د.م</span></div><p>تتبيلة رأس الحانوت، بطاطس محمّرة وصلصة البرقوق.</p></article>
                <article class="dish"><span class="dish-tag">نباتي</span><div class="dish-top"><h3>بسطيلة الخضر</h3><span class="price">105 د.م</span></div><p>ورقة رقيقة، خضر مشوية، لوز وأعشاب عطرية.</p></article>
                <article class="dish"><span class="dish-tag">تحلية</span><div class="dish-top"><h3>جوهرة زهر البرتقال</h3><span class="price">65 د.م</span></div><p>كريمة خفيفة، لوز مقرمش وفواكه موسمية.</p></article>
                <article class="dish"><span class="dish-tag">شاي</span><div class="dish-top"><h3>طقوس أتاي</h3><span class="price">45 د.م</span></div><p>شاي أخضر، نعناع طازج وتشكيلة حلويات مغربية.</p></article>
            </div>
        </div>
    </section>

    <section id="experience" class="section experience">
        <div class="shell experience-grid">
            <div>
                <div class="section-kicker">أكثر من وجبة</div>
                <h2 class="section-title">مساءٌ له إيقاعه الخاص</h2>
                <p class="section-lead">إضاءة هادئة، موسيقى منتقاة وخدمة تعرف متى تقترب ومتى تترك للحظة مساحتها.</p>
            </div>
            <div class="feature-list">
                <div class="feature"><strong>منتجات يومية</strong><span>نتعامل مع منتجين محليين ونبني قائمتنا حول أفضل ما يمنحه الموسم.</span></div>
                <div class="feature"><strong>موائد للمناسبات</strong><span>قوائم خاصة لأعياد الميلاد، عشاء العمل واللقاءات العائلية.</span></div>
                <div class="feature"><strong>خيارات مرنة</strong><span>أطباق نباتية وخيارات تراعي احتياجات الضيوف الغذائية عند الحجز.</span></div>
            </div>
        </div>
    </section>

    <section id="contact" class="section">
        <div class="shell contact-card">
            <div class="contact-copy">
                <h2>مائدتك تنتظرك</h2>
                <p>اتصل بنا أو راسلنا لحجز طاولة. للمجموعات الكبيرة، يسعد فريقنا بإعداد قائمة تناسب مناسبتك.</p>
                <a class="button light" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>">اتصل للحجز</a>
            </div>
            <div class="contact-info">
                <div class="contact-line"><small>الهاتف</small><strong><?php echo esc_html($phone); ?></strong></div>
                <div class="contact-line"><small>البريد</small><strong><?php echo esc_html($email); ?></strong></div>
                <div class="contact-line"><small>العنوان</small><strong><?php echo esc_html($address); ?></strong></div>
                <div class="contact-line"><small>ساعات العمل</small><strong>يوميًا، 12:00 — 23:30</strong></div>
            </div>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="shell footer-inner">
        <span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($restaurant_name); ?></span>
        <span>نكهات مغربية • ضيافة من القلب</span>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
