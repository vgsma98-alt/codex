<?php

if (!defined('ABSPATH')) {
    exit;
}

function madaq_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('style', 'script', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'madaq_setup');

function madaq_assets() {
    wp_enqueue_style('madaq-style', get_stylesheet_uri(), array(), '1.5.0');
    wp_enqueue_script('madaq-slider', get_template_directory_uri() . '/assets/slider.js', array(), '1.5.0', true);
}
add_action('wp_enqueue_scripts', 'madaq_assets');

function madaq_business_value($field, $fallback = '') {
    if (shortcode_exists('aia_business')) {
        $value = trim(wp_strip_all_tags(do_shortcode('[aia_business field="' . esc_attr($field) . '"]')));
        if ($value !== '') {
            return $value;
        }
    }
    return $fallback;
}
