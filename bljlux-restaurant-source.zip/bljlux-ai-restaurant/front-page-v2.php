<?php
if (!defined('ABSPATH')) {
    exit;
}

$requested_lang = isset($_GET['lang']) ? sanitize_key(wp_unslash($_GET['lang'])) : '';
$is_fr = $requested_lang !== 'ar';
$page_lang = $is_fr ? '?lang=fr' : '';
$restaurant_name = madaq_business_value('site_title', get_bloginfo('name'));
$phone = madaq_business_value('phone', '+212 5 22 00 00 00');
$email = madaq_business_value('email', 'reservation@madaq.ma');
$address = madaq_business_value('address', $is_fr ? 'Casablanca, Maroc' : 'الدار البيضاء، المغرب');
$whatsapp_number = preg_replace('/\D+/', '', $phone);
if (strpos($whatsapp_number, '0') === 0) {
    $whatsapp_number = '212' . substr($whatsapp_number, 1);
}

$copy = $is_fr ? array(
    'story_nav' => 'Notre histoire', 'menu_nav' => 'La carte', 'experience_nav' => 'L’expérience',
    'book' => 'Réserver une table', 'eyebrow' => 'Saveurs marocaines, esprit contemporain',
    'hero_title' => 'Le Maroc<br>se raconte à table',
    'hero_text' => 'Un voyage entre recettes de maison et gestes contemporains, dans un cadre chaleureux pensé pour les moments qui comptent.',
    'discover' => 'Découvrir la carte', 'open' => 'Ouvert tous les jours • 12h00 — 23h30',
    'story_kicker' => 'De notre cuisine à votre table', 'story_title' => 'Un héritage maîtrisé,<br>des détails réinventés',
    'story_text' => "Chez {$restaurant_name}, nous choisissons les produits de saison, préparons nos épices chaque jour et accordons à chaque plat le temps qu’il mérite.",
    'quote' => 'Chez nous, l’hospitalité commence avant le premier plat et reste en mémoire après le dernier thé.',
    'menu_kicker' => 'La sélection du chef', 'menu_title' => 'Des plats faits pour être partagés',
    'menu_text' => 'Une carte de saison qui marie les classiques marocains à des produits locaux soigneusement choisis.',
    'reserve_dish' => 'Réserver ce plat', 'more_than' => 'Bien plus qu’un repas',
    'experience_title' => 'Une soirée à son propre rythme',
    'experience_text' => 'Lumière douce, musique choisie et service attentif composent une expérience naturelle et élégante.',
    'feature_1' => 'Produits du jour', 'feature_1_text' => 'Notre carte suit le meilleur de la saison et les arrivages de producteurs locaux.',
    'feature_2' => 'Tables pour vos occasions', 'feature_2_text' => 'Menus dédiés aux anniversaires, dîners professionnels et réunions de famille.',
    'feature_3' => 'Choix flexibles', 'feature_3_text' => 'Options végétariennes et adaptation aux besoins alimentaires signalés à la réservation.',
    'table_waits' => 'Votre table vous attend',
    'contact_text' => 'Appelez-nous ou réservez directement sur WhatsApp. Pour les groupes, notre équipe prépare un menu adapté à votre occasion.',
    'call' => 'Appeler', 'whatsapp' => 'Réserver sur WhatsApp', 'phone' => 'Téléphone', 'email' => 'E-mail',
    'address' => 'Adresse', 'hours' => 'Horaires', 'hours_value' => 'Tous les jours, 12h00 — 23h30',
    'footer' => 'Saveurs marocaines • Hospitalité du cœur', 'lang_label' => 'العربية', 'lang_url' => add_query_arg('lang', 'ar', home_url('/')),
) : array(
    'story_nav' => 'حكايتنا', 'menu_nav' => 'قائمة الطعام', 'experience_nav' => 'التجربة',
    'book' => 'احجز طاولتك', 'eyebrow' => 'نكهات مغربية بروح معاصرة',
    'hero_title' => 'مذاقٌ يحكي<br>حكاية المغرب',
    'hero_text' => 'نأخذك في رحلة بين وصفات الدار الأصيلة ولمسات الطهاة المبتكرة، داخل فضاء دافئ صُمّم للّقاءات التي لا تُنسى.',
    'discover' => 'اكتشف القائمة', 'open' => 'مفتوح يوميًا • 12:00 — 23:30',
    'story_kicker' => 'من مطبخ الدار إلى مائدتك', 'story_title' => 'تراث نتقنه،<br>وتفاصيل نجددها',
    'story_text' => "في {$restaurant_name} نختار منتجات الموسم بعناية، ونحضّر التوابل يوميًا، ونمنح كل طبق الوقت الذي يستحقه.",
    'quote' => 'الضيافة عندنا تبدأ قبل وصول الطبق، وتبقى في الذاكرة بعد آخر رشفة شاي.',
    'menu_kicker' => 'مختارات الشيف', 'menu_title' => 'أطباق تحبّ المشاركة',
    'menu_text' => 'قائمة موسمية تجمع بين الكلاسيكيات المغربية ومقادير محلية منتقاة.',
    'reserve_dish' => 'احجز هذا الطبق', 'more_than' => 'أكثر من وجبة',
    'experience_title' => 'مساءٌ له إيقاعه الخاص',
    'experience_text' => 'إضاءة هادئة، موسيقى منتقاة وخدمة تعرف متى تقترب ومتى تترك للحظة مساحتها.',
    'feature_1' => 'منتجات يومية', 'feature_1_text' => 'نتعامل مع منتجين محليين ونبني قائمتنا حول أفضل ما يمنحه الموسم.',
    'feature_2' => 'موائد للمناسبات', 'feature_2_text' => 'قوائم خاصة لأعياد الميلاد، عشاء العمل واللقاءات العائلية.',
    'feature_3' => 'خيارات مرنة', 'feature_3_text' => 'أطباق نباتية وخيارات تراعي احتياجات الضيوف الغذائية عند الحجز.',
    'table_waits' => 'مائدتك تنتظرك',
    'contact_text' => 'اتصل بنا أو احجز مباشرة عبر واتساب. للمجموعات الكبيرة، يسعد فريقنا بإعداد قائمة تناسب مناسبتك.',
    'call' => 'اتصل للحجز', 'whatsapp' => 'احجز عبر واتساب', 'phone' => 'الهاتف', 'email' => 'البريد',
    'address' => 'العنوان', 'hours' => 'ساعات العمل', 'hours_value' => 'يوميًا، 12:00 — 23:30',
    'footer' => 'نكهات مغربية • ضيافة من القلب', 'lang_label' => 'Français', 'lang_url' => add_query_arg('lang', 'fr', home_url('/')),
);

$menu = $is_fr ? array(
    array('id' => 'tagine_chicken', 'tag' => 'Du tajine', 'name' => 'Tajine de poulet fermier', 'price' => '145 MAD', 'description' => 'Citron confit, olives vertes, safran et légumes de saison.', 'image' => 'dish-tagine.png'),
    array('id' => 'seven_vegetable_couscous', 'tag' => 'Maison', 'name' => 'Couscous aux sept légumes', 'price' => '130 MAD', 'description' => 'Semoule roulée à la main, légumes du marché et bouillon parfumé.', 'image' => 'dish-couscous.png'),
    array('id' => 'lamb_ribs', 'tag' => 'Grillades', 'name' => 'Côtes d’agneau confites', 'price' => '195 MAD', 'description' => 'Ras el-hanout, pommes rôties et jus délicat aux prunes.', 'image' => 'dish-ribs.png'),
    array('id' => 'vegetable_pastilla', 'tag' => 'Végétarien', 'name' => 'Pastilla de légumes', 'price' => '105 MAD', 'description' => 'Feuille croustillante, légumes rôtis, amandes et herbes fraîches.', 'image' => 'dish-pastilla.png'),
    array('id' => 'orange_blossom_dessert', 'tag' => 'Dessert', 'name' => 'Joyau à la fleur d’oranger', 'price' => '65 MAD', 'description' => 'Crème légère, tuile aux amandes et fruits de saison.', 'image' => 'dish-dessert.png'),
    array('id' => 'mint_tea', 'tag' => 'Thé', 'name' => 'Rituel de l’atay', 'price' => '45 MAD', 'description' => 'Thé vert, menthe fraîche et assortiment de pâtisseries marocaines.', 'image' => 'dish-tea.png'),
) : array(
    array('id' => 'tagine_chicken', 'tag' => 'من الفرن', 'name' => 'طاجين الدجاج البلدي', 'price' => '145 د.م', 'description' => 'ليمون مصيّر، زيتون أخضر، زعفران وخضر موسمية.', 'image' => 'dish-tagine.png'),
    array('id' => 'seven_vegetable_couscous', 'tag' => 'طبق الدار', 'name' => 'كسكس سبع خضاري', 'price' => '130 د.م', 'description' => 'سميد مفوّر يدويًا، خضر السوق ومرق عطري خفيف.', 'image' => 'dish-couscous.png'),
    array('id' => 'lamb_ribs', 'tag' => 'مشاوي', 'name' => 'ضلعة مطهوة ببطء', 'price' => '195 د.م', 'description' => 'تتبيلة رأس الحانوت، بطاطس محمّرة وصلصة البرقوق.', 'image' => 'dish-ribs.png'),
    array('id' => 'vegetable_pastilla', 'tag' => 'نباتي', 'name' => 'بسطيلة الخضر', 'price' => '105 د.م', 'description' => 'ورقة رقيقة، خضر مشوية، لوز وأعشاب عطرية.', 'image' => 'dish-pastilla.png'),
    array('id' => 'orange_blossom_dessert', 'tag' => 'تحلية', 'name' => 'جوهرة زهر البرتقال', 'price' => '65 د.م', 'description' => 'كريمة خفيفة، لوز مقرمش وفواكه موسمية.', 'image' => 'dish-dessert.png'),
    array('id' => 'mint_tea', 'tag' => 'شاي', 'name' => 'طقوس أتاي', 'price' => '45 د.م', 'description' => 'شاي أخضر، نعناع طازج وتشكيلة حلويات مغربية.', 'image' => 'dish-tea.png'),
);

$hero_slides = $is_fr ? array(
    array('id' => 'tagine', 'kicker' => 'La signature de la maison', 'title' => 'Le tajine qui<br>réunit la table', 'text' => 'Poulet fermier, citron confit et safran : un classique marocain servi avec précision.', 'image' => 'dish-tagine.png', 'dish' => 'Tajine de poulet fermier'),
    array('id' => 'couscous', 'kicker' => 'Un héritage vivant', 'title' => 'Sept légumes,<br>une seule histoire', 'text' => 'Une semoule légère, des légumes du marché et un bouillon lentement parfumé.', 'image' => 'dish-couscous.png', 'dish' => 'Couscous aux sept légumes'),
    array('id' => 'lamb', 'kicker' => 'Lentement confites', 'title' => 'Des saveurs<br>intensément marocaines', 'text' => 'Côtes d’agneau, ras el-hanout et jus aux prunes dans une assiette généreuse et contemporaine.', 'image' => 'dish-ribs.png', 'dish' => 'Côtes d’agneau confites'),
) : array(
    array('id' => 'tagine', 'kicker' => 'توقيع مطبخنا', 'title' => 'طاجين يجمع<br>أحباب المائدة', 'text' => 'دجاج بلدي، ليمون مصيّر وزعفران؛ طبق مغربي أصيل نقدّمه بعناية معاصرة.', 'image' => 'dish-tagine.png', 'dish' => 'طاجين الدجاج البلدي'),
    array('id' => 'couscous', 'kicker' => 'تراث حيّ', 'title' => 'سبع خضاري،<br>وحكاية واحدة', 'text' => 'سميد خفيف، خضر السوق ومرق عطري يُحضّر على مهل.', 'image' => 'dish-couscous.png', 'dish' => 'كسكس سبع خضاري'),
    array('id' => 'lamb', 'kicker' => 'طهي بطيء', 'title' => 'نكهات مغربية<br>بعمق استثنائي', 'text' => 'ضلعة طرية، رأس الحانوت وصلصة البرقوق في طبق يجمع الكرم والأناقة.', 'image' => 'dish-ribs.png', 'dish' => 'ضلعة مطهوة ببطء'),
);

$dynamic_content = get_option('aia_site_content', array());
$dynamic_prices = get_option('aia_menu_prices', array());
foreach ($menu as &$dish) {
    $saved = isset($dynamic_content['menu'][$dish['id']]) ? $dynamic_content['menu'][$dish['id']] : array();
    $suffix = $is_fr ? '_fr' : '_ar';
    if (!empty($saved['name' . $suffix])) $dish['name'] = $saved['name' . $suffix];
    if (!empty($saved['description' . $suffix])) $dish['description'] = $saved['description' . $suffix];
    if (!empty($saved['tag' . $suffix])) $dish['tag'] = $saved['tag' . $suffix];
    if (isset($dynamic_prices[$dish['id']])) $dish['price'] = $dynamic_prices[$dish['id']] . ($is_fr ? ' MAD' : ' د.م');
    if (!empty($saved['image_url'])) $dish['image_url'] = $saved['image_url'];
}
unset($dish);
foreach ($hero_slides as &$slide) {
    $saved = isset($dynamic_content['slides'][$slide['id']]) ? $dynamic_content['slides'][$slide['id']] : array();
    $suffix = $is_fr ? '_fr' : '_ar';
    foreach (array('kicker', 'title', 'text', 'dish') as $field) {
        if (!empty($saved[$field . $suffix])) $slide[$field] = $saved[$field . $suffix];
    }
    if (!empty($saved['image_url'])) $slide['image_url'] = $saved['image_url'];
}
unset($slide);

function madaq_whatsapp_url($number, $message) {
    return 'https://wa.me/' . rawurlencode($number) . '?text=' . rawurlencode($message);
}

$general_message = $is_fr
    ? "Bonjour, je souhaite réserver une table chez {$restaurant_name}."
    : "مرحبًا، أريد حجز طاولة في {$restaurant_name}.";
?><!doctype html>
<html lang="<?php echo $is_fr ? 'fr' : 'ar'; ?>" dir="<?php echo $is_fr ? 'ltr' : 'rtl'; ?>">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class($is_fr ? 'madaq-fr' : 'madaq-ar'); ?>>
<?php wp_body_open(); ?>
<header class="site-header"><div class="shell nav">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><img class="brand-logo" src="<?php echo esc_url(get_template_directory_uri() . '/assets/bljlux-emblem.png'); ?>" alt="BLJLUX"><span class="brand-name"><?php echo esc_html($restaurant_name); ?></span></a>
    <nav class="nav-links" aria-label="Navigation">
        <a href="#story"><?php echo esc_html($copy['story_nav']); ?></a><a href="#menu"><?php echo esc_html($copy['menu_nav']); ?></a><a href="#experience"><?php echo esc_html($copy['experience_nav']); ?></a><a href="<?php echo esc_url(home_url('/contact/' . $page_lang)); ?>"><?php echo esc_html($is_fr ? 'Contact' : 'التواصل'); ?></a><a href="<?php echo esc_url(home_url('/reservation/' . $page_lang)); ?>"><?php echo esc_html($is_fr ? 'Réserver' : 'الحجز'); ?></a>
        <a class="lang-switch" href="<?php echo esc_url($copy['lang_url']); ?>"><?php echo esc_html($copy['lang_label']); ?></a>
        <a class="button ghost" href="<?php echo esc_url(home_url('/reservation/' . $page_lang)); ?>"><?php echo esc_html($copy['book']); ?></a>
    </nav>
</div></header>
<main>
    <section class="hero-slider" data-madaq-slider aria-label="<?php echo esc_attr($is_fr ? 'Plats signature' : 'أطباقنا المميزة'); ?>">
        <div class="hero-slides">
            <?php foreach ($hero_slides as $index => $slide) : $slide_message = $is_fr ? "Bonjour, je souhaite réserver le plat « {$slide['dish']} » chez {$restaurant_name}." : "مرحبًا، أريد حجز طبق « {$slide['dish']} » في {$restaurant_name}."; ?>
                <article class="hero-slide<?php echo $index === 0 ? ' is-active' : ''; ?>" data-slide="<?php echo esc_attr($index); ?>" aria-hidden="<?php echo $index === 0 ? 'false' : 'true'; ?>" style="--slide-image:url('<?php echo esc_url(!empty($slide['image_url']) ? $slide['image_url'] : get_template_directory_uri() . '/assets/' . $slide['image']); ?>')">
                    <div class="hero-slide-shade"></div>
                    <div class="shell hero-slide-content">
                        <div class="eyebrow"><?php echo esc_html($slide['kicker']); ?></div>
                        <h1><?php echo wp_kses_post($slide['title']); ?></h1>
                        <p><?php echo esc_html($slide['text']); ?></p>
                        <div class="hero-actions"><a class="button" href="<?php echo esc_url(madaq_whatsapp_url($whatsapp_number, $slide_message)); ?>" target="_blank" rel="noopener"><?php echo esc_html($copy['reserve_dish']); ?></a><a class="button ghost" href="#menu"><?php echo esc_html($copy['discover']); ?></a></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <div class="shell slider-ui"><div class="slider-dots" role="tablist" aria-label="Slides"><?php foreach ($hero_slides as $index => $slide) : ?><button class="slider-dot<?php echo $index === 0 ? ' is-active' : ''; ?>" type="button" data-slide-to="<?php echo esc_attr($index); ?>" aria-label="<?php echo esc_attr($slide['dish']); ?>"></button><?php endforeach; ?></div><div class="slider-arrows"><button type="button" class="slider-arrow" data-slide-prev aria-label="Previous">‹</button><button type="button" class="slider-arrow" data-slide-next aria-label="Next">›</button></div></div>
        <div class="shell hero-note"><?php echo esc_html($copy['open']); ?></div>
    </section>
    <section id="story" class="section"><div class="shell story-grid"><div><div class="section-kicker"><?php echo esc_html($copy['story_kicker']); ?></div><h2 class="section-title"><?php echo wp_kses_post($copy['story_title']); ?></h2><p class="section-lead"><?php echo esc_html($copy['story_text']); ?></p></div><div class="story-card"><div class="story-quote"><strong>“</strong><p><?php echo esc_html($copy['quote']); ?></p></div></div></div></section>
    <section id="menu" class="section menu-section"><div class="shell"><div class="menu-heading"><div><div class="section-kicker"><?php echo esc_html($copy['menu_kicker']); ?></div><h2 class="section-title"><?php echo esc_html($copy['menu_title']); ?></h2></div><p class="section-lead"><?php echo esc_html($copy['menu_text']); ?></p></div><div class="menu-grid">
        <?php foreach ($menu as $dish) : $dish_message = $is_fr ? "Bonjour, je souhaite réserver le plat « {$dish['name']} » chez {$restaurant_name}." : "مرحبًا، أريد حجز طبق « {$dish['name']} » في {$restaurant_name}."; ?>
            <article class="dish"><img class="dish-image" src="<?php echo esc_url(!empty($dish['image_url']) ? $dish['image_url'] : get_template_directory_uri() . '/assets/' . $dish['image']); ?>" alt="<?php echo esc_attr($dish['name']); ?>" loading="lazy"><div class="dish-body"><span class="dish-tag"><?php echo esc_html($dish['tag']); ?></span><div class="dish-top"><h3><?php echo esc_html($dish['name']); ?></h3><span class="price"><?php echo esc_html($dish['price']); ?></span></div><p><?php echo esc_html($dish['description']); ?></p><a class="dish-book" href="<?php echo esc_url(madaq_whatsapp_url($whatsapp_number, $dish_message)); ?>" target="_blank" rel="noopener"><span aria-hidden="true">◉</span><?php echo esc_html($copy['reserve_dish']); ?></a></div></article>
        <?php endforeach; ?>
    </div></div></section>
    <section id="experience" class="section experience"><div class="shell experience-grid"><div><div class="section-kicker"><?php echo esc_html($copy['more_than']); ?></div><h2 class="section-title"><?php echo esc_html($copy['experience_title']); ?></h2><p class="section-lead"><?php echo esc_html($copy['experience_text']); ?></p></div><div class="feature-list"><div class="feature"><strong><?php echo esc_html($copy['feature_1']); ?></strong><span><?php echo esc_html($copy['feature_1_text']); ?></span></div><div class="feature"><strong><?php echo esc_html($copy['feature_2']); ?></strong><span><?php echo esc_html($copy['feature_2_text']); ?></span></div><div class="feature"><strong><?php echo esc_html($copy['feature_3']); ?></strong><span><?php echo esc_html($copy['feature_3_text']); ?></span></div></div></div></section>
    <section id="contact" class="section"><div class="shell contact-card"><div class="contact-copy"><h2><?php echo esc_html($copy['table_waits']); ?></h2><p><?php echo esc_html($copy['contact_text']); ?></p><div class="contact-actions"><a class="button light" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>"><?php echo esc_html($copy['call']); ?></a><a class="button whatsapp" href="<?php echo esc_url(madaq_whatsapp_url($whatsapp_number, $general_message)); ?>" target="_blank" rel="noopener"><?php echo esc_html($copy['whatsapp']); ?></a></div></div><div class="contact-info"><div class="contact-line"><small><?php echo esc_html($copy['phone']); ?></small><strong><?php echo esc_html($phone); ?></strong></div><div class="contact-line"><small><?php echo esc_html($copy['email']); ?></small><strong><?php echo esc_html($email); ?></strong></div><div class="contact-line"><small><?php echo esc_html($copy['address']); ?></small><strong><?php echo esc_html($address); ?></strong></div><div class="contact-line"><small><?php echo esc_html($copy['hours']); ?></small><strong><?php echo esc_html($copy['hours_value']); ?></strong></div></div></div></section>
</main>
<footer class="site-footer"><div class="shell footer-inner"><span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($restaurant_name); ?></span><span><?php echo esc_html($copy['footer']); ?></span></div></footer>
<?php wp_footer(); ?>
</body></html>
