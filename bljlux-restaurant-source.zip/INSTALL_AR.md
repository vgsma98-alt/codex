# دليل تثبيت BLJLUX ووكيل Telegram

هذا الدليل يثبت موقع WordPress ووكيل Telegram من الملفات المرفقة. لا تضع كلمات المرور أو مفاتيح API داخل Git أو داخل ملفات الموقع العامة.

## 1. تثبيت موقع WordPress

1. سجّل الدخول إلى لوحة WordPress.
2. افتح **إضافات ← أضف إضافة ← رفع إضافة**.
3. ارفع ملف الإضافة الموجود داخل مجلد `wordpress-plugin` بعد ضغطه بصيغة ZIP.
4. فعّل الإضافة.
5. افتح **المظهر ← قوالب ← أضف جديد ← رفع قالب**.
6. ارفع مجلد `wordpress-theme/bljlux-ai-restaurant` بصيغة ZIP.
7. فعّل قالب **BLJLUX AI Restaurant**.

## 2. إعداد سر اتصال WordPress

من إعدادات الإضافة أنشئ سرًا عشوائيًا طويلًا، ثم احتفظ به لاستخدامه في الوكيل. يجب أن يكون طوله 32 محرفًا على الأقل.

## 3. إعداد متغيرات الوكيل في Easypanel

أنشئ خدمة Node.js أو Docker Compose، ثم أضف المتغيرات التالية:

```env
TELEGRAM_BOT_TOKEN=توكن_BotFather
TELEGRAM_WEBHOOK_SECRET=قيمة_عشوائية_طويلة
AI_API_KEY=مفتاح_Gemini
AI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai
AI_MODEL=gemini-2.5-flash-lite
ADMIN_API_KEY=مفتاح_إدارة_داخلي_عشوائي
PUBLIC_BASE_URL=https://رابط-الوكيل
```

لا تضع مسافات قبل أو بعد علامة `=`. قيمة `TELEGRAM_WEBHOOK_SECRET` تُنشأ عشوائيًا وليست من BotFather.

## 4. تشغيل الوكيل

1. ارفع محتويات مجلد `server` أو استخدم ملف `compose.yaml`.
2. شغّل الخدمة وانتظر حتى يعرض Easypanel حالة التشغيل.
3. اختبر الرابط:

```text
https://رابط-الوكيل/health
```

يجب أن تكون النتيجة:

```json
{"ok":true}
```

## 5. ربط الموقع بالوكيل

أرسل طلب POST إلى:

```text
https://رابط-الوكيل/admin/sites
```

باستخدام ترويسة:

```text
Authorization: Bearer ADMIN_API_KEY
```

والبيانات التالية بصيغة JSON:

```json
{
  "chatId": 521774876,
  "name": "BLJLUX",
  "siteUrl": "https://رابط-موقع-WordPress",
  "secret": "سر-إضافة-WordPress"
}
```

## 6. ضبط Webhook Telegram

أرسل طلب POST إلى:

```text
https://رابط-الوكيل/admin/telegram/webhook
```

بنفس ترويسة `Authorization`. بعد ذلك أرسل `/start` إلى البوت.

## 7. اختبار التعديل

أرسل إلى البوت مثلًا:

```text
غيّر سعر طاجين الدجاج البلدي إلى 150 درهم
```

سيعرض الوكيل ملخصًا، ثم اضغط **تنفيذ**.

لتغيير صورة، أرسل الصورة كمرفق Telegram مع وصف مثل:

```text
اجعل هذه صورة السلايدر الأول
```

## 8. ملاحظات مهمة

- لا تحذف ملفات WordPress القديمة قبل أخذ نسخة احتياطية.
- استخدم HTTPS لرابط الموقع والوكيل.
- غيّر كلمات المرور التجريبية قبل تسليم الموقع لعميل.
- إذا لم تصل رسائل نموذج الحجز إلى البريد، اربط WordPress بخدمة SMTP.
