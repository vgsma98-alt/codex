<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('aia_shared_secret');
delete_option('aia_business_profile');

global $wpdb;
$table = $wpdb->prefix . 'aia_change_log';
$wpdb->query("DROP TABLE IF EXISTS {$table}");
