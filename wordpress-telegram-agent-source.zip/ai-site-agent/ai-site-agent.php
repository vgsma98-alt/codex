<?php
/**
 * Plugin Name: AI Site Agent
 * Description: Secure, auditable REST commands for the company Telegram website agent.
 * Version: 0.2.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Your Company
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class AIA_Site_Agent {
    const VERSION = '0.2.0';
    const SECRET_OPTION = 'aia_shared_secret';
    const PROFILE_OPTION = 'aia_business_profile';
    const MENU_OPTION = 'aia_menu_prices';
    const CONTENT_OPTION = 'aia_site_content';

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
        add_action('admin_menu', array(__CLASS__, 'register_settings_page'));
        add_action('admin_post_aia_regenerate_secret', array(__CLASS__, 'regenerate_secret'));
        add_shortcode('aia_business', array(__CLASS__, 'business_shortcode'));
        add_shortcode('aia_menu_price', array(__CLASS__, 'menu_price_shortcode'));
    }

    public static function activate() {
        global $wpdb;
        $table = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            action varchar(50) NOT NULL,
            target_id bigint(20) unsigned NULL,
            before_state longtext NOT NULL,
            after_state longtext NOT NULL,
            requested_by varchar(191) NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY action (action),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        if (!get_option(self::SECRET_OPTION)) {
            update_option(self::SECRET_OPTION, wp_generate_password(48, false, false), false);
        }
        if (!get_option(self::PROFILE_OPTION)) {
            update_option(self::PROFILE_OPTION, array(
                'phone' => '',
                'email' => get_option('admin_email'),
                'address' => '',
            ), false);
        }
        if (!get_option(self::MENU_OPTION)) {
            update_option(self::MENU_OPTION, self::default_menu_prices(), false);
        }
    }

    private static function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'aia_change_log';
    }

    public static function register_routes() {
        register_rest_route('ai-site-agent/v1', '/commands', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'execute_command'),
            'permission_callback' => array(__CLASS__, 'verify_signature'),
        ));

        register_rest_route('ai-site-agent/v1', '/capabilities', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'capabilities'),
            'permission_callback' => array(__CLASS__, 'verify_signature'),
        ));

        register_rest_route('ai-site-agent/v1', '/context', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'site_context'),
            'permission_callback' => array(__CLASS__, 'verify_signature'),
        ));
    }

    public static function verify_signature(WP_REST_Request $request) {
        $timestamp = $request->get_header('x-aia-timestamp');
        $nonce = $request->get_header('x-aia-nonce');
        $signature = $request->get_header('x-aia-signature');
        if (!$timestamp || !$nonce || !$signature || !ctype_digit((string) $timestamp)) {
            return new WP_Error('aia_missing_signature', 'Missing request signature.', array('status' => 401));
        }

        if (abs(time() - (int) $timestamp) > 300) {
            return new WP_Error('aia_expired_signature', 'Request signature has expired.', array('status' => 401));
        }

        $secret = get_option(self::SECRET_OPTION);
        $signed_payload = implode("\n", array(
            $timestamp,
            $nonce,
            $request->get_method(),
            $request->get_route(),
            $request->get_body(),
        ));
        $expected = hash_hmac('sha256', $signed_payload, $secret);
        if (!hash_equals($expected, $signature)) {
            return new WP_Error('aia_invalid_signature', 'Invalid request signature.', array('status' => 401));
        }

        $replay_key = 'aia_seen_' . md5($signature);
        if (get_transient($replay_key)) {
            return new WP_Error('aia_replayed_request', 'This request was already received.', array('status' => 409));
        }
        set_transient($replay_key, '1', 5 * MINUTE_IN_SECONDS);
        return true;
    }

    public static function capabilities() {
        return rest_ensure_response(array(
            'version' => self::VERSION,
            'actions' => array('update_site_info', 'update_menu_item', 'update_slider_item', 'update_post', 'replace_text', 'create_post', 'undo'),
            'post_types' => array('post', 'page'),
        ));
    }

    public static function site_context() {
        $items = get_posts(array(
            'post_type' => array('page', 'post'),
            'post_status' => array('publish', 'draft', 'pending', 'private'),
            'numberposts' => 100,
            'orderby' => 'modified',
            'order' => 'DESC',
        ));
        $content = array_map(function ($post) {
            return array(
                'id' => $post->ID,
                'type' => $post->post_type,
                'title' => get_the_title($post),
                'slug' => $post->post_name,
                'status' => $post->post_status,
            );
        }, $items);

        $catalog = self::menu_catalog();
        $prices = self::menu_prices();
        $site_content = self::site_content_values();
        $menu = array();
        foreach ($catalog as $id => $labels) {
            $saved = isset($site_content['menu'][$id]) ? $site_content['menu'][$id] : array();
            $menu[] = array_merge(array('id' => $id, 'name_ar' => $labels['ar'], 'name_fr' => $labels['fr'], 'price' => $prices[$id]), $saved);
        }

        return rest_ensure_response(array(
            'site_title' => get_option('blogname'),
            'tagline' => get_option('blogdescription'),
            'content' => $content,
            'menu' => $menu,
            'slides' => self::slider_context($site_content),
        ));
    }

    public static function execute_command(WP_REST_Request $request) {
        $payload = $request->get_json_params();
        $action = isset($payload['action']) ? sanitize_key($payload['action']) : '';
        $arguments = isset($payload['arguments']) && is_array($payload['arguments'])
            ? $payload['arguments']
            : array();
        $requested_by = isset($payload['requested_by'])
            ? sanitize_text_field($payload['requested_by'])
            : 'unknown';

        switch ($action) {
            case 'update_site_info':
                return self::update_site_info($arguments, $requested_by);
            case 'update_menu_item':
                return self::update_menu_item($arguments, $requested_by);
            case 'update_slider_item':
                return self::update_slider_item($arguments, $requested_by);
            case 'update_post':
                return self::update_post($arguments, $requested_by);
            case 'replace_text':
                return self::replace_text($arguments, $requested_by);
            case 'create_post':
                return self::create_post($arguments, $requested_by);
            case 'undo':
                return self::undo($arguments, $requested_by);
            default:
                return new WP_Error('aia_unsupported_action', 'Unsupported action.', array('status' => 400));
        }
    }

    private static function update_site_info($arguments, $requested_by) {
        $allowed = array('site_title', 'tagline', 'phone', 'email', 'address');
        $provided = array_intersect($allowed, array_keys($arguments));
        if (!$provided) {
            return new WP_Error('aia_empty_update', 'No supported fields were provided.', array('status' => 400));
        }

        $profile = get_option(self::PROFILE_OPTION, array());
        $before = array(
            'site_title' => get_option('blogname'),
            'tagline' => get_option('blogdescription'),
            'profile' => $profile,
        );

        $validated_email = null;
        if (array_key_exists('email', $arguments)) {
            $validated_email = sanitize_email($arguments['email']);
            if (!$validated_email) {
                return new WP_Error('aia_invalid_email', 'The email address is invalid.', array('status' => 400));
            }
        }

        if (array_key_exists('site_title', $arguments)) {
            update_option('blogname', sanitize_text_field($arguments['site_title']));
        }
        if (array_key_exists('tagline', $arguments)) {
            update_option('blogdescription', sanitize_text_field($arguments['tagline']));
        }
        if (array_key_exists('phone', $arguments)) {
            $profile['phone'] = sanitize_text_field($arguments['phone']);
        }
        if (array_key_exists('email', $arguments)) {
            $profile['email'] = $validated_email;
        }
        if (array_key_exists('address', $arguments)) {
            $profile['address'] = sanitize_textarea_field($arguments['address']);
        }
        update_option(self::PROFILE_OPTION, $profile, false);

        $after = array(
            'site_title' => get_option('blogname'),
            'tagline' => get_option('blogdescription'),
            'profile' => $profile,
        );
        $action_id = self::log_change('update_site_info', null, $before, $after, $requested_by);

        return rest_ensure_response(array(
            'ok' => true,
            'message' => 'تم تحديث معلومات الموقع.',
            'action_id' => $action_id,
            'url' => home_url('/'),
        ));
    }

    private static function menu_catalog() {
        return array(
            'tagine_chicken' => array('ar' => 'طاجين الدجاج البلدي', 'fr' => 'Tajine de poulet fermier'),
            'seven_vegetable_couscous' => array('ar' => 'كسكس سبع خضاري', 'fr' => 'Couscous aux sept légumes'),
            'lamb_ribs' => array('ar' => 'ضلعة مطهوة ببطء', 'fr' => 'Côtes d’agneau confites'),
            'vegetable_pastilla' => array('ar' => 'بسطيلة الخضر', 'fr' => 'Pastilla de légumes'),
            'orange_blossom_dessert' => array('ar' => 'جوهرة زهر البرتقال', 'fr' => 'Joyau à la fleur d’oranger'),
            'mint_tea' => array('ar' => 'طقوس أتاي', 'fr' => 'Rituel de l’atay'),
        );
    }

    private static function default_menu_prices() {
        return array(
            'tagine_chicken' => 145,
            'seven_vegetable_couscous' => 130,
            'lamb_ribs' => 195,
            'vegetable_pastilla' => 105,
            'orange_blossom_dessert' => 65,
            'mint_tea' => 45,
        );
    }

    private static function menu_prices() {
        $stored = get_option(self::MENU_OPTION, array());
        return array_merge(self::default_menu_prices(), is_array($stored) ? $stored : array());
    }

    private static function site_content_values() {
        $content = get_option(self::CONTENT_OPTION, array());
        if (!is_array($content)) {
            $content = array();
        }
        $content['menu'] = isset($content['menu']) && is_array($content['menu']) ? $content['menu'] : array();
        $content['slides'] = isset($content['slides']) && is_array($content['slides']) ? $content['slides'] : array();
        return $content;
    }

    private static function slider_context($content) {
        $defaults = array(
            'tagine' => array('dish_ar' => 'طاجين الدجاج البلدي', 'dish_fr' => 'Tajine de poulet fermier'),
            'couscous' => array('dish_ar' => 'كسكس سبع خضاري', 'dish_fr' => 'Couscous aux sept légumes'),
            'lamb' => array('dish_ar' => 'ضلعة مطهوة ببطء', 'dish_fr' => 'Côtes d’agneau confites'),
        );
        $slides = array();
        foreach ($defaults as $id => $values) {
            $slides[] = array_merge(array('id' => $id), $values, isset($content['slides'][$id]) ? $content['slides'][$id] : array());
        }
        return $slides;
    }

    private static function save_image($image) {
        if (!is_array($image) || empty($image['data_base64'])) {
            return new WP_Error('aia_invalid_image', 'Image data is missing.', array('status' => 400));
        }
        $bytes = base64_decode((string) $image['data_base64'], true);
        if ($bytes === false || strlen($bytes) < 100 || strlen($bytes) > 5 * 1024 * 1024) {
            return new WP_Error('aia_invalid_image', 'Image size is invalid.', array('status' => 400));
        }
        $mime = function_exists('finfo_buffer') ? finfo_buffer(finfo_open(FILEINFO_MIME_TYPE), $bytes) : '';
        $extensions = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
        if (!isset($extensions[$mime])) {
            return new WP_Error('aia_invalid_image_type', 'Only JPEG, PNG and WebP images are supported.', array('status' => 400));
        }
        $upload = wp_upload_bits('aia-' . wp_generate_uuid4() . '.' . $extensions[$mime], null, $bytes);
        if (!empty($upload['error'])) {
            return new WP_Error('aia_image_upload_failed', $upload['error'], array('status' => 500));
        }
        return esc_url_raw($upload['url']);
    }

    private static function update_menu_item($arguments, $requested_by) {
        $item_id = isset($arguments['item_id']) ? sanitize_key($arguments['item_id']) : '';
        $catalog = self::menu_catalog();
        if (!isset($catalog[$item_id])) {
            return new WP_Error('aia_menu_item_not_found', 'Menu item not found.', array('status' => 404));
        }
        $prices = self::menu_prices();
        $content = self::site_content_values();
        $before = array('item_id' => $item_id, 'price' => $prices[$item_id], 'content' => isset($content['menu'][$item_id]) ? $content['menu'][$item_id] : array());
        $allowed_text = array('name_ar', 'name_fr', 'description_ar', 'description_fr', 'tag_ar', 'tag_fr');
        $changed = false;
        if (array_key_exists('price', $arguments)) {
            if (!is_numeric($arguments['price'])) {
                return new WP_Error('aia_invalid_price', 'Price must be numeric.', array('status' => 400));
            }
            $price = round((float) $arguments['price'], 2);
            if ($price < 0 || $price > 100000) {
                return new WP_Error('aia_invalid_price', 'Price is outside the allowed range.', array('status' => 400));
            }
            $prices[$item_id] = $price;
            update_option(self::MENU_OPTION, $prices, false);
            $changed = true;
        }
        foreach ($allowed_text as $field) {
            if (array_key_exists($field, $arguments)) {
                $content['menu'][$item_id][$field] = sanitize_text_field($arguments[$field]);
                $changed = true;
            }
        }
        if (!empty($arguments['image'])) {
            $image_url = self::save_image($arguments['image']);
            if (is_wp_error($image_url)) return $image_url;
            $content['menu'][$item_id]['image_url'] = $image_url;
            $changed = true;
        }
        if (!$changed) {
            return new WP_Error('aia_empty_menu_update', 'No supported menu fields were provided.', array('status' => 400));
        }
        update_option(self::CONTENT_OPTION, $content, false);
        $after = array('item_id' => $item_id, 'price' => $prices[$item_id], 'content' => $content['menu'][$item_id]);
        $action_id = self::log_change('update_menu_item', null, $before, $after, $requested_by);

        return rest_ensure_response(array(
            'ok' => true,
            'message' => 'تم تحديث سعر الوجبة بنجاح.',
            'action_id' => $action_id,
            'url' => home_url('/'),
        ));
    }

    private static function update_slider_item($arguments, $requested_by) {
        $slide_id = isset($arguments['slide_id']) ? sanitize_key($arguments['slide_id']) : '';
        if (!in_array($slide_id, array('tagine', 'couscous', 'lamb'), true)) {
            return new WP_Error('aia_slide_not_found', 'Slider item not found.', array('status' => 404));
        }
        $content = self::site_content_values();
        $before = array('slide_id' => $slide_id, 'content' => isset($content['slides'][$slide_id]) ? $content['slides'][$slide_id] : array());
        $allowed_text = array('kicker_ar', 'kicker_fr', 'title_ar', 'title_fr', 'text_ar', 'text_fr', 'dish_ar', 'dish_fr');
        $changed = false;
        foreach ($allowed_text as $field) {
            if (array_key_exists($field, $arguments)) {
                $content['slides'][$slide_id][$field] = sanitize_text_field($arguments[$field]);
                $changed = true;
            }
        }
        if (!empty($arguments['image'])) {
            $image_url = self::save_image($arguments['image']);
            if (is_wp_error($image_url)) return $image_url;
            $content['slides'][$slide_id]['image_url'] = $image_url;
            $changed = true;
        }
        if (!$changed) {
            return new WP_Error('aia_empty_slider_update', 'No supported slider fields were provided.', array('status' => 400));
        }
        update_option(self::CONTENT_OPTION, $content, false);
        $after = array('slide_id' => $slide_id, 'content' => $content['slides'][$slide_id]);
        $action_id = self::log_change('update_slider_item', null, $before, $after, $requested_by);
        return rest_ensure_response(array('ok' => true, 'message' => 'تم تحديث السلايدر بنجاح.', 'action_id' => $action_id, 'url' => home_url('/')));
    }

    private static function find_post($arguments) {
        if (!empty($arguments['post_id'])) {
            $post = get_post(absint($arguments['post_id']));
        } elseif (!empty($arguments['slug'])) {
            $posts = get_posts(array(
                'name' => sanitize_title($arguments['slug']),
                'post_type' => array('post', 'page'),
                'post_status' => array('publish', 'draft', 'pending', 'private'),
                'numberposts' => 1,
            ));
            $post = $posts ? $posts[0] : null;
        } else {
            $post = null;
        }

        if (!$post || !in_array($post->post_type, array('post', 'page'), true)) {
            return new WP_Error('aia_post_not_found', 'Page or post not found.', array('status' => 404));
        }
        return $post;
    }

    private static function post_snapshot($post) {
        return array(
            'post_title' => $post->post_title,
            'post_content' => $post->post_content,
            'post_excerpt' => $post->post_excerpt,
            'post_status' => $post->post_status,
            'post_type' => $post->post_type,
        );
    }

    private static function update_post($arguments, $requested_by) {
        $post = self::find_post($arguments);
        if (is_wp_error($post)) {
            return $post;
        }

        $update = array('ID' => $post->ID);
        if (array_key_exists('title', $arguments)) {
            $update['post_title'] = sanitize_text_field($arguments['title']);
        }
        if (array_key_exists('content', $arguments)) {
            $update['post_content'] = wp_kses_post($arguments['content']);
        }
        if (array_key_exists('excerpt', $arguments)) {
            $update['post_excerpt'] = sanitize_textarea_field($arguments['excerpt']);
        }
        if (array_key_exists('status', $arguments)) {
            if (!in_array($arguments['status'], array('draft', 'publish'), true)) {
                return new WP_Error('aia_invalid_status', 'Invalid post status.', array('status' => 400));
            }
            $update['post_status'] = $arguments['status'];
        }
        if (count($update) === 1) {
            return new WP_Error('aia_empty_update', 'No supported post fields were provided.', array('status' => 400));
        }

        $before = self::post_snapshot($post);
        $result = wp_update_post(wp_slash($update), true);
        if (is_wp_error($result)) {
            return $result;
        }
        $updated = get_post($post->ID);
        $action_id = self::log_change(
            'update_post',
            $post->ID,
            $before,
            self::post_snapshot($updated),
            $requested_by
        );

        return rest_ensure_response(array(
            'ok' => true,
            'message' => 'تم تحديث المحتوى.',
            'action_id' => $action_id,
            'url' => get_permalink($post->ID),
        ));
    }

    private static function replace_text($arguments, $requested_by) {
        if (empty($arguments['post_id']) || !isset($arguments['old_text']) || !isset($arguments['new_text'])) {
            return new WP_Error('aia_missing_replacement', 'Post ID, old text and new text are required.', array('status' => 400));
        }
        $post = self::find_post(array('post_id' => $arguments['post_id']));
        if (is_wp_error($post)) {
            return $post;
        }

        $old_text = wp_kses_post($arguments['old_text']);
        $new_text = wp_kses_post($arguments['new_text']);
        if ($old_text === '') {
            return new WP_Error('aia_empty_old_text', 'Old text cannot be empty.', array('status' => 400));
        }
        $matches = substr_count($post->post_content, $old_text);
        if ($matches !== 1) {
            return new WP_Error(
                'aia_ambiguous_replacement',
                $matches === 0 ? 'The old text was not found.' : 'The old text occurs more than once.',
                array('status' => 409)
            );
        }

        $before = self::post_snapshot($post);
        $updated_content = str_replace($old_text, $new_text, $post->post_content);
        $result = wp_update_post(wp_slash(array(
            'ID' => $post->ID,
            'post_content' => $updated_content,
        )), true);
        if (is_wp_error($result)) {
            return $result;
        }
        $updated = get_post($post->ID);
        $action_id = self::log_change(
            'replace_text',
            $post->ID,
            $before,
            self::post_snapshot($updated),
            $requested_by
        );

        return rest_ensure_response(array(
            'ok' => true,
            'message' => 'تم استبدال النص.',
            'action_id' => $action_id,
            'url' => get_permalink($post->ID),
        ));
    }

    private static function create_post($arguments, $requested_by) {
        $post_type = isset($arguments['post_type']) ? sanitize_key($arguments['post_type']) : 'post';
        if (!in_array($post_type, array('post', 'page'), true)) {
            return new WP_Error('aia_invalid_post_type', 'Invalid post type.', array('status' => 400));
        }
        if (empty($arguments['title']) || !isset($arguments['content'])) {
            return new WP_Error('aia_missing_content', 'Title and content are required.', array('status' => 400));
        }

        $status = isset($arguments['status']) ? $arguments['status'] : 'draft';
        if (!in_array($status, array('draft', 'publish'), true)) {
            return new WP_Error('aia_invalid_status', 'Invalid post status.', array('status' => 400));
        }

        $post_id = wp_insert_post(wp_slash(array(
            'post_type' => $post_type,
            'post_title' => sanitize_text_field($arguments['title']),
            'post_content' => wp_kses_post($arguments['content']),
            'post_excerpt' => isset($arguments['excerpt'])
                ? sanitize_textarea_field($arguments['excerpt'])
                : '',
            'post_status' => $status,
        )), true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }

        $created = get_post($post_id);
        $action_id = self::log_change(
            'create_post',
            $post_id,
            array('exists' => false),
            self::post_snapshot($created),
            $requested_by
        );

        return rest_ensure_response(array(
            'ok' => true,
            'message' => $status === 'publish' ? 'تم إنشاء المحتوى ونشره.' : 'تم إنشاء مسودة.',
            'action_id' => $action_id,
            'url' => get_permalink($post_id),
        ));
    }

    private static function undo($arguments, $requested_by) {
        global $wpdb;
        $table = self::table_name();
        if (!empty($arguments['action_id'])) {
            $row = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d AND action != 'undo'",
                absint($arguments['action_id'])
            ));
        } else {
            $row = $wpdb->get_row("SELECT * FROM {$table} WHERE action != 'undo' ORDER BY id DESC LIMIT 1");
        }
        if (!$row) {
            return new WP_Error('aia_change_not_found', 'No change was found to undo.', array('status' => 404));
        }

        $undo_marker = '%"source_action_id":' . (int) $row->id . '%';
        $already_undone = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE action = 'undo' AND before_state LIKE %s LIMIT 1",
            $undo_marker
        ));
        if ($already_undone) {
            return new WP_Error('aia_already_undone', 'This change was already undone.', array('status' => 409));
        }

        $before = json_decode($row->before_state, true);
        if ($row->action === 'update_site_info') {
            update_option('blogname', $before['site_title']);
            update_option('blogdescription', $before['tagline']);
            update_option(self::PROFILE_OPTION, $before['profile'], false);
        } elseif ($row->action === 'update_menu_item') {
            $prices = self::menu_prices();
            $prices[$before['item_id']] = $before['price'];
            update_option(self::MENU_OPTION, $prices, false);
            $content = self::site_content_values();
            if (!empty($before['content'])) {
                $content['menu'][$before['item_id']] = $before['content'];
            } else {
                unset($content['menu'][$before['item_id']]);
            }
            update_option(self::CONTENT_OPTION, $content, false);
        } elseif ($row->action === 'update_slider_item') {
            $content = self::site_content_values();
            if (!empty($before['content'])) {
                $content['slides'][$before['slide_id']] = $before['content'];
            } else {
                unset($content['slides'][$before['slide_id']]);
            }
            update_option(self::CONTENT_OPTION, $content, false);
        } elseif (in_array($row->action, array('update_post', 'replace_text'), true)) {
            $before['ID'] = (int) $row->target_id;
            $result = wp_update_post(wp_slash($before), true);
            if (is_wp_error($result)) {
                return $result;
            }
        } elseif ($row->action === 'create_post') {
            $result = wp_trash_post((int) $row->target_id);
            if (!$result) {
                return new WP_Error('aia_undo_failed', 'Unable to move the created content to trash.', array('status' => 500));
            }
        } else {
            return new WP_Error('aia_undo_unsupported', 'This change cannot be undone.', array('status' => 400));
        }

        $undo_id = self::log_change(
            'undo',
            $row->target_id ? (int) $row->target_id : null,
            array('source_action_id' => (int) $row->id),
            array('restored' => true),
            $requested_by
        );
        return rest_ensure_response(array(
            'ok' => true,
            'message' => 'تم التراجع عن التعديل.',
            'action_id' => $undo_id,
            'url' => $row->target_id ? get_permalink((int) $row->target_id) : home_url('/'),
        ));
    }

    private static function log_change($action, $target_id, $before, $after, $requested_by) {
        global $wpdb;
        $wpdb->insert(
            self::table_name(),
            array(
                'action' => $action,
                'target_id' => $target_id,
                'before_state' => wp_json_encode($before),
                'after_state' => wp_json_encode($after),
                'requested_by' => $requested_by,
                'created_at' => current_time('mysql', true),
            ),
            array('%s', '%d', '%s', '%s', '%s', '%s')
        );
        return (int) $wpdb->insert_id;
    }

    public static function business_shortcode($attributes) {
        $attributes = shortcode_atts(array('field' => 'phone'), $attributes, 'aia_business');
        $field = sanitize_key($attributes['field']);
        $profile = get_option(self::PROFILE_OPTION, array());
        $allowed = array(
            'phone' => isset($profile['phone']) ? $profile['phone'] : '',
            'email' => isset($profile['email']) ? $profile['email'] : '',
            'address' => isset($profile['address']) ? $profile['address'] : '',
            'site_title' => get_option('blogname'),
            'tagline' => get_option('blogdescription'),
        );
        return isset($allowed[$field]) ? esc_html($allowed[$field]) : '';
    }

    public static function menu_price_shortcode($attributes) {
        $attributes = shortcode_atts(array('item' => ''), $attributes, 'aia_menu_price');
        $item_id = sanitize_key($attributes['item']);
        $prices = self::menu_prices();
        return isset($prices[$item_id]) ? esc_html((string) $prices[$item_id]) : '';
    }

    public static function register_settings_page() {
        add_options_page(
            'AI Site Agent',
            'AI Site Agent',
            'manage_options',
            'ai-site-agent',
            array(__CLASS__, 'render_settings_page')
        );
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $secret = get_option(self::SECRET_OPTION);
        ?>
        <div class="wrap">
            <h1>AI Site Agent</h1>
            <p>انسخ مفتاح الربط إلى إعداد الموقع في الخادم المركزي. احتفظ به بسرية.</p>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">رابط الموقع</th>
                    <td><code><?php echo esc_html(home_url('/')); ?></code></td>
                </tr>
                <tr>
                    <th scope="row">مفتاح الربط</th>
                    <td><input type="text" class="regular-text code" readonly value="<?php echo esc_attr($secret); ?>" onclick="this.select();"></td>
                </tr>
            </table>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="aia_regenerate_secret">
                <?php wp_nonce_field('aia_regenerate_secret'); ?>
                <?php submit_button('إنشاء مفتاح جديد', 'secondary'); ?>
            </form>
            <p><strong>تنبيه:</strong> إنشاء مفتاح جديد يوقف الخادم عن الاتصال إلى أن تُحدّث المفتاح لديه.</p>
        </div>
        <?php
    }

    public static function regenerate_secret() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized.');
        }
        check_admin_referer('aia_regenerate_secret');
        update_option(self::SECRET_OPTION, wp_generate_password(48, false, false), false);
        wp_safe_redirect(admin_url('options-general.php?page=ai-site-agent&updated=1'));
        exit;
    }
}

register_activation_hook(__FILE__, array('AIA_Site_Agent', 'activate'));
AIA_Site_Agent::init();
