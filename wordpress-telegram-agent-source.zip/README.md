# وكيل تعديل WordPress عبر Telegram

هذه نسخة أولية عملية لخدمة متعددة المواقع. يستقبل الخادم رسالة العميل من Telegram، ويحوّلها عبر نموذج ذكاء اصطناعي إلى أمر محدود، ثم يعرض الأمر للتأكيد. بعد التأكيد يرسله بتوقيع HMAC إلى إضافة WordPress، التي تنفذه وتسجل الحالة السابقة حتى يمكن التراجع عنه.

## ما تدعمه النسخة الحالية

- تعديل اسم الموقع، الوصف، الهاتف، البريد والعنوان.
- تعديل صفحة أو مقال بواسطة المعرّف أو `slug`.
- استبدال جملة واحدة داخل صفحة مع رفض التنفيذ إذا لم تكن المطابقة دقيقة وفريدة.
- إنشاء صفحة أو مقال كمسودة أو نشره عند طلب ذلك صراحة.
- التراجع عن آخر عملية أو عملية محددة.
- ربط كل محادثة Telegram بموقع واحد.
- مفتاح مستقل وتوقيع مستقل لكل موقع.
- منع إعادة إرسال الطلب الموقع خلال مدة صلاحيته.
- تأكيد التعديل من زر داخل Telegram قبل التنفيذ.

لا تسمح النسخة الحالية بتثبيت إضافات، تعديل ملفات PHP، تشغيل SQL، إدارة المستخدمين أو تنفيذ أوامر نظام.

## هيكل المشروع

- `server/`: خادم Node.js دون حزم خارجية، ويحتاج Node.js 20 أو أحدث.
- `wordpress-plugin/ai-site-agent/`: إضافة WordPress.
- `compose.yaml`: تشغيل الخادم داخل Docker على VPS.
- `deploy/easypanel-compose.yaml`: نشر inline داخل Easypanel دون مستودع خارجي.
- `deploy/easypanel-compose-compact.yaml`: نسخة مضغوطة أسهل للصق في محرر Easypanel.
- `.env.example`: جميع متغيرات التشغيل المطلوبة.

## 1. إنشاء بوت Telegram

1. افتح محادثة مع `@BotFather` في Telegram.
2. نفّذ `/newbot` واحفظ الرمز الذي يمنحه لك.
3. لا تشارك الرمز ولا تضعه في Git.

## 2. إعداد الخادم

انسخ `.env.example` إلى `.env`، ثم أدخل القيم الحقيقية. يمكن إنشاء أسرار قوية بهذا الأمر:

```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

يجب أن يشير `PUBLIC_BASE_URL` إلى نطاق HTTPS يصل إلى الخادم. في الإنتاج، ضع Caddy أو Nginx أمام المنفذ 3000.

للتشغيل مباشرة:

```powershell
cd server
node --env-file=../.env src/server.js
```

أو باستخدام Docker على الخادم:

```bash
docker compose up -d --build
```

لتحديث ملف النشر الخاص بـEasypanel بعد تعديل كود الخادم:

```powershell
cd server
npm run build:easypanel
```

أنشئ Compose Service في Easypanel، الصق محتوى `deploy/easypanel-compose.yaml` في المصدر
inline، ثم ضع متغيرات `deploy/easypanel.env.example` في قسم Environment دون حفظ القيم
الحقيقية داخل Git. وجّه نطاق الخدمة إلى internal service باسم `agent` والمنفذ `3000`.

اختبار الصحة:

```bash
curl https://agent.example.com/health
```

## 3. تثبيت إضافة WordPress

ثبّت الملف الجاهز `dist/ai-site-agent-0.1.0.zip` من **إضافات ← أضف إضافة ← رفع إضافة**. فعّل الإضافة، ثم افتح **الإعدادات ← AI Site Agent** وانسخ:

- رابط الموقع.
- مفتاح الربط.

استخدم الحقول الديناميكية داخل Gutenberg بهذه الصيغ حتى يتغير المحتوى في كل مواضعه مرة واحدة:

```text
[aia_business field="phone"]
[aia_business field="email"]
[aia_business field="address"]
[aia_business field="site_title"]
[aia_business field="tagline"]
```

## 4. معرفة رقم محادثة العميل

شغّل الخادم وسجل Webhook أولًا، ثم يرسل العميل `/start` إلى البوت. إذا لم يكن مربوطًا، سيرد البوت برقم المحادثة المطلوب. وإذا كان مربوطًا، يعرض اسم الموقع المرتبط.

تسجيل Webhook:

```bash
curl -X POST https://agent.example.com/admin/telegram/webhook \
  -H "Authorization: Bearer ADMIN_API_KEY"
```

## 5. ربط العميل بموقعه

استخدم رقم المحادثة، رابط WordPress ومفتاح الإضافة:

```bash
curl -X POST https://agent.example.com/admin/sites \
  -H "Authorization: Bearer ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "chatId": "123456789",
    "name": "موقع العميل",
    "siteUrl": "https://client.example.com",
    "secret": "WORDPRESS_PLUGIN_SECRET"
  }'
```

إعادة إرسال الطلب بنفس `chatId` تحدّث بيانات الربط الموجودة.

## 6. تجربة كاملة

أرسل إلى البوت:

```text
غيّر رقم الهاتف إلى +212600000000
```

سيعرض البوت وصف العملية وزري التنفيذ والإلغاء. بعد التنفيذ، يمكن إرسال:

```text
تراجع عن آخر تعديل
```

## مزود الذكاء الاصطناعي

الخادم يستخدم واجهة Chat Completions المتوافقة مع OpenAI. الإعداد الافتراضي في `.env.example` مخصص لواجهة Gemini المتوافقة، ويمكن تغيير `AI_BASE_URL` و`AI_MODEL` إلى مزود آخر يدعم `response_format: {"type":"json_object"}`.

استخدم حساب API مدفوعًا في الإنتاج. الطبقات المجانية قد تستخدم البيانات لتحسين الخدمة أو تفرض حدودًا غير مناسبة للزبناء.

## الاختبارات

```powershell
cd server
npm test
```

اختبارات Node لا تحتاج إلى تنزيل أي حزم. فحص PHP يتطلب وجود PHP محليًا أو بيئة WordPress/Docker، وهو غير متوفر تلقائيًا على Windows الحالي.

## قبل إطلاق الخدمة تجاريًا

النسخة الحالية مناسبة للتجربة المغلقة. قبل ربط عملاء فعليين أضف PostgreSQL بدل ملف JSON، نسخًا احتياطية مشفرة، مراقبة للأخطاء، سياسة حذف للسجلات، وحساب إدارة بواجهة داخلية. لا تضع ملف البيانات أو `.env` داخل مجلد عام يخدمه الويب.
