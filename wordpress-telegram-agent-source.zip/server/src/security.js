import { createHmac, timingSafeEqual } from "node:crypto";

export function signWordPressRequest(secret, timestamp, nonce, method, route, rawBody) {
  return createHmac("sha256", secret)
    .update(`${timestamp}\n${nonce}\n${method}\n${route}\n${rawBody}`)
    .digest("hex");
}

export function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && timingSafeEqual(a, b);
}
