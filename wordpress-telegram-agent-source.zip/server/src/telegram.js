export class TelegramClient {
  constructor(token) {
    this.baseUrl = `https://api.telegram.org/bot${token}`;
    this.fileBaseUrl = `https://api.telegram.org/file/bot${token}`;
  }

  async call(method, payload) {
    const response = await fetch(`${this.baseUrl}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(`Telegram ${method} failed: ${JSON.stringify(data)}`);
    }
    return data.result;
  }

  sendMessage(chatId, text, extra = {}) {
    return this.call("sendMessage", { chat_id: chatId, text, ...extra });
  }

  answerCallbackQuery(callbackQueryId, text) {
    return this.call("answerCallbackQuery", {
      callback_query_id: callbackQueryId,
      text,
    });
  }

  setWebhook(url, secretToken) {
    return this.call("setWebhook", { url, secret_token: secretToken });
  }

  async downloadPhoto(photoSizes, maxBytes = 5 * 1024 * 1024) {
    const candidates = Array.isArray(photoSizes) ? [...photoSizes].reverse() : [{ file_id: photoSizes }];
    let tooLarge = false;
    for (const candidate of candidates) {
      const file = await this.call("getFile", { file_id: candidate.file_id });
      const response = await fetch(`${this.fileBaseUrl}/${file.file_path}`);
      if (!response.ok) throw new Error(`Telegram file download failed (${response.status})`);
      const bytes = Buffer.from(await response.arrayBuffer());
      if (bytes.length > maxBytes) { tooLarge = true; continue; }
      const path = String(file.file_path || "image.jpg");
      const extension = path.split(".").pop().toLowerCase();
      const mimeType = extension === "png" ? "image/png" : extension === "webp" ? "image/webp" : "image/jpeg";
      return { filename: `telegram-${Date.now()}.${extension}`, mime_type: mimeType, data_base64: bytes.toString("base64") };
    }
    if (tooLarge) throw new Error("الصورة أكبر من 5 ميغابايت حتى بعد اختيار نسخة مضغوطة من Telegram");
    throw new Error("تعذر تنزيل الصورة من Telegram");
  }
}
