export class WhatsAppClient {
  constructor(token, phoneNumberId, apiVersion = "v20.0") {
    this.token = token;
    this.phoneNumberId = phoneNumberId;
    this.baseUrl = `https://graph.facebook.com/${apiVersion}`;
  }

  async call(path, payload, method = "POST") {
    const response = await fetch(`${this.baseUrl}/${path}`, {
      method,
      headers: { authorization: `Bearer ${this.token}`, "content-type": "application/json" },
      ...(payload ? { body: JSON.stringify(payload) } : {}),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(`WhatsApp API failed: ${JSON.stringify(data)}`);
    return data;
  }

  sendText(to, text) {
    return this.call(`${this.phoneNumberId}/messages`, {
      messaging_product: "whatsapp", to, type: "text", text: { preview_url: false, body: text },
    });
  }

  sendConfirmation(to, text, id) {
    return this.call(`${this.phoneNumberId}/messages`, {
      messaging_product: "whatsapp", to, type: "interactive",
      interactive: {
        type: "button", body: { text },
        action: { buttons: [
          { type: "reply", reply: { id: `confirm:${id}`, title: "✅ تنفيذ" } },
          { type: "reply", reply: { id: `cancel:${id}`, title: "❌ إلغاء" } },
        ] },
      },
    });
  }

  async downloadMedia(mediaId, maxBytes = 5 * 1024 * 1024) {
    const info = await this.call(mediaId, null, "GET");
    const response = await fetch(info.url, { headers: { authorization: `Bearer ${this.token}` } });
    if (!response.ok) throw new Error(`WhatsApp media download failed (${response.status})`);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > maxBytes) throw new Error("الصورة أكبر من 5 ميغابايت");
    const mime = String(info.mime_type || "image/jpeg").split(";")[0];
    const ext = mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "jpg";
    return { filename: `whatsapp-${Date.now()}.${ext}`, mime_type: mime, data_base64: bytes.toString("base64") };
  }
}
