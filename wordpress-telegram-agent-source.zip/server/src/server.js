import { createServer } from "node:http";
import { URL } from "node:url";
import { loadConfig } from "./config.js";
import { JsonStore } from "./store.js";
import { TelegramClient } from "./telegram.js";
import { planCommand } from "./ai.js";
import { safeEqual } from "./security.js";
import { executeWordPressCommand, getWordPressContext } from "./wordpress.js";

const config = loadConfig();
const store = new JsonStore(config.dataFile);
const telegram = new TelegramClient(config.telegramToken);

function json(response, status, body) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}

async function readBody(request, limit = 1_000_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw new Error("Request body is too large");
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString("utf8");
  return raw ? JSON.parse(raw) : {};
}

function confirmationKeyboard(id) {
  return {
    inline_keyboard: [[
      { text: "✅ تنفيذ", callback_data: `confirm:${id}` },
      { text: "❌ إلغاء", callback_data: `cancel:${id}` },
    ]],
  };
}

async function handleMessage(message) {
  const chatId = message.chat?.id;
  const photo = Array.isArray(message.photo) && message.photo.length ? message.photo.at(-1) : null;
  const text = (message.text || message.caption || "").trim();
  if (!chatId) return;
  if (config.fixedChatId && String(chatId) !== String(config.fixedChatId)) return;
  if (photo && !text) {
    await telegram.sendMessage(chatId, config.vertical === "car_rental" ? "أرسل الصورة مع وصف يحدد السيارة أو شريحة السلايدر المراد تغييرها." : "أرسل الصورة مع وصف يحدد مكانها، مثل: اجعل هذه صورة طاجين الدجاج أو صورة الشريحة الأولى.");
    return;
  }
  if (!text) return;

  if (text === "/start" || text === "/help") {
    const linkedSite = await store.getSiteByChatId(chatId);
    const linkingNote = linkedSite
      ? `\n\nالموقع المرتبط: ${linkedSite.name}`
      : `\n\nهذا الحساب غير مربوط بموقع بعد. أرسل هذا الرقم لمسؤول الخدمة: ${chatId}`;
    await telegram.sendMessage(
      chatId,
      `أرسل التعديل المطلوب بلغة واضحة. سأعرض عليك ما سأفعله قبل التنفيذ.\n\nمثال: ${config.vertical === "car_rental" ? "غيّر ثمن Berline Confort إلى 420 درهم لليوم" : "غيّر رقم الهاتف إلى +212600000000"}${linkingNote}`,
    );
    return;
  }

  const site = await store.getSiteByChatId(chatId);
  if (!site) {
    await telegram.sendMessage(
      chatId,
      `هذا الحساب غير مربوط بموقع بعد. أرسل هذا الرقم لمسؤول الخدمة: ${chatId}`,
    );
    return;
  }

  await telegram.sendMessage(chatId, "أحلل الطلب…");
  const siteContext = await getWordPressContext(site);
  const plan = await planCommand(config, photo ? `${text}\n[توجد صورة مرفقة مع الطلب]` : text, siteContext);
  if (plan.error) {
    await telegram.sendMessage(chatId, plan.error);
    return;
  }

  // Image replacement requires an actual Telegram photo. Do not create a
  // confirmation that will inevitably fail with an empty image payload.
  const imageWords = /صورة|صور|صوره|السلايدر|الشريحة|image|photo|slider|diapositive/i;
  const imageFields = plan.arguments && plan.arguments.image;
  const textFields = [
    "kicker_ar", "kicker_fr", "title_ar", "title_fr", "text_ar", "text_fr", "dish_ar", "dish_fr",
    "name_ar", "name_fr", "description_ar", "description_fr", "tag_ar", "tag_fr", "price",
    "name", "description", "title", "kicker", "badge", "category", "gear", "seats", "bags", "label", "vehicle",
  ];
  const hasTextChange = textFields.some((field) => Object.prototype.hasOwnProperty.call(plan.arguments || {}, field));
  if (!photo && imageWords.test(text) && !imageFields && !hasTextChange) {
    await telegram.sendMessage(
      chatId,
      config.vertical === "car_rental" ? "لتغيير صورة سيارة أو السلايدر، أرسل الصورة الجديدة كمرفق مع اسم السيارة أو الشريحة. لا يمكن استبدال الصورة من وصف نصي فقط." : "لتغيير صورة الوجبة أو السلايدر، أرسل الصورة الجديدة كمرفق مع وصف واضح لمكانها، مثل: «اجعل هذه صورة السلايدر الأول». لا يمكن استبدال الصورة من وصف نصي فقط.",
    );
    return;
  }

  if (photo) {
    if (!["update_menu_item", "update_slider_item"].includes(plan.action)) {
      await telegram.sendMessage(chatId, config.vertical === "car_rental" ? "تعذر تحديد السيارة أو شريحة السلايدر. اكتب اسمها بوضوح مع الصورة." : "تعذر تحديد الوجبة أو شريحة السلايدر التي ستُستبدل صورتها. اكتب اسمها بوضوح في وصف الصورة.");
      return;
    }
    plan.arguments.image = await telegram.downloadPhoto(message.photo);
  }

  const pending = await store.createPending(chatId, site.id, plan);
  await telegram.sendMessage(
    chatId,
    `الموقع: ${site.name}\nالتعديل المقترح: ${plan.summary_ar}\n\nاضغط «تنفيذ» لتأكيد التعديل.`,
    { reply_markup: confirmationKeyboard(pending.id) },
  );
}

async function handleCallback(callback) {
  const chatId = callback.message?.chat?.id;
  if (config.fixedChatId && String(chatId) !== String(config.fixedChatId)) return;
  const [operation, pendingId] = String(callback.data || "").split(":", 2);
  if (!chatId || !pendingId || !["confirm", "cancel"].includes(operation)) return;

  if (operation === "cancel") {
    const item = await store.consumePending(pendingId, chatId, "cancelled");
    await telegram.answerCallbackQuery(callback.id, item ? "تم الإلغاء" : "انتهت صلاحية الطلب");
    if (item) await telegram.sendMessage(chatId, "تم إلغاء التعديل.");
    return;
  }

  const item = await store.consumePending(pendingId, chatId, "executing");
  if (!item) {
    await telegram.answerCallbackQuery(callback.id, "تم تنفيذ الطلب أو إلغاؤه سابقًا");
    return;
  }

  await telegram.answerCallbackQuery(callback.id, "جارٍ التنفيذ…");
  const site = await store.getSiteByChatId(chatId);
  if (!site || site.id !== item.siteId) throw new Error("The linked site was not found");
  let result;
  try {
    result = await executeWordPressCommand(site, item.plan);
    await store.setPendingStatus(item.id, "completed");
  } catch (error) {
    await store.setPendingStatus(item.id, "failed");
    throw error;
  }
  const details = [result.message || "تم التعديل بنجاح."];
  if (result.url) details.push(result.url);
  if (result.action_id) details.push(`رقم العملية: ${result.action_id}`);
  await telegram.sendMessage(chatId, details.join("\n"));
}

async function handleTelegramUpdate(update) {
  if (update.callback_query) return handleCallback(update.callback_query);
  if (update.message) return handleMessage(update.message);
}

async function requestHandler(request, response) {
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);

  if (request.method === "GET" && url.pathname === "/health") {
    return json(response, 200, { ok: true });
  }

  if (request.method === "POST" && url.pathname === "/telegram/webhook") {
    const suppliedSecret = request.headers["x-telegram-bot-api-secret-token"] || "";
    if (!safeEqual(suppliedSecret, config.telegramWebhookSecret)) {
      return json(response, 401, { error: "Invalid webhook secret" });
    }
    const update = await readBody(request);
    json(response, 200, { ok: true });
    handleTelegramUpdate(update).catch(async (error) => {
      console.error("Telegram update failed", error);
      const chatId = update.message?.chat?.id || update.callback_query?.message?.chat?.id;
      if (chatId) {
        await telegram.sendMessage(chatId, "تعذر تنفيذ الطلب. حاول مرة أخرى أو تواصل مع الدعم.")
          .catch((telegramError) => console.error("Failed to send error message", telegramError));
      }
    });
    return;
  }

  if (request.method === "POST" && url.pathname === "/admin/sites") {
    const authorization = request.headers.authorization || "";
    if (!safeEqual(authorization, `Bearer ${config.adminApiKey}`)) {
      return json(response, 401, { error: "Unauthorized" });
    }
    if (config.fixedChatId) return json(response, 403, { error: "This agent is bound to one site" });
    const body = await readBody(request);
    if (!body.chatId || !body.name || !body.siteUrl || !body.secret) {
      return json(response, 400, { error: "chatId, name, siteUrl and secret are required" });
    }
    let parsedUrl;
    try {
      parsedUrl = new URL(body.siteUrl);
    } catch {
      return json(response, 400, { error: "siteUrl must be a valid URL" });
    }
    if (parsedUrl.protocol !== "https:" && parsedUrl.hostname !== "localhost") {
      return json(response, 400, { error: "siteUrl must use HTTPS" });
    }
    if (String(body.secret).length < 32) {
      return json(response, 400, { error: "secret must contain at least 32 characters" });
    }
    const site = await store.upsertSite(body);
    return json(response, 201, { site });
  }

  if (request.method === "POST" && url.pathname === "/admin/telegram/webhook") {
    const authorization = request.headers.authorization || "";
    if (!safeEqual(authorization, `Bearer ${config.adminApiKey}`)) {
      return json(response, 401, { error: "Unauthorized" });
    }
    const result = await telegram.setWebhook(
      `${config.publicBaseUrl}/telegram/webhook`,
      config.telegramWebhookSecret,
    );
    return json(response, 200, { ok: result });
  }

  return json(response, 404, { error: "Not found" });
}

await store.init();
if (config.fixedChatId || config.fixedSiteUrl || config.fixedSiteSecret) {
  if (!config.fixedChatId || !config.fixedSiteUrl || !config.fixedSiteSecret) throw new Error("All fixed-site variables are required together");
  await store.upsertSite({ chatId: config.fixedChatId, name: "Atlas Drive Maroc", siteUrl: config.fixedSiteUrl, secret: config.fixedSiteSecret });
}
const server = createServer((request, response) => {
  requestHandler(request, response).catch((error) => {
    console.error(error);
    if (!response.headersSent) json(response, 500, { error: "Internal server error" });
    else response.end();
  });
});

server.listen(config.port, "0.0.0.0", () => {
  console.log(`AI Site Agent listening on port ${config.port}`);
  if (config.fixedChatId) {
    const register = async (attempt = 1) => {
      try {
        await telegram.setWebhook(`${config.publicBaseUrl}/telegram/webhook`, config.telegramWebhookSecret);
        console.log('Telegram webhook registered for fixed-site agent');
      } catch (error) {
        console.error(`Webhook registration attempt ${attempt} failed`, error.message);
        if (attempt < 12) setTimeout(() => register(attempt + 1), 10000);
      }
    };
    register();
  }
});
