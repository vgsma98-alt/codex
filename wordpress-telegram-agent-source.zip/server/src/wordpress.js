import { signWordPressRequest } from "./security.js";
import { randomUUID } from "node:crypto";

export async function executeWordPressCommand(site, plan) {
  const rawBody = JSON.stringify({
    action: plan.action,
    arguments: plan.arguments,
    requested_by: `telegram:${site.chatId}`,
  });
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = randomUUID();
  const route = "/ai-site-agent/v1/commands";
  const signature = signWordPressRequest(site.secret, timestamp, nonce, "POST", route, rawBody);

  const response = await fetch(`${site.siteUrl}/wp-json${route}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-aia-timestamp": timestamp,
      "x-aia-nonce": nonce,
      "x-aia-signature": signature,
    },
    body: rawBody,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data?.message || `WordPress returned HTTP ${response.status}`);
  }
  return data;
}

export async function getWordPressContext(site) {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = randomUUID();
  const route = "/ai-site-agent/v1/context";
  const signature = signWordPressRequest(site.secret, timestamp, nonce, "GET", route, "");
  const response = await fetch(`${site.siteUrl}/wp-json${route}`, {
    headers: {
      "x-aia-timestamp": timestamp,
      "x-aia-nonce": nonce,
      "x-aia-signature": signature,
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data?.message || `WordPress returned HTTP ${response.status}`);
  }
  return data;
}
