const ALLOWED_ACTIONS = [
  "update_site_info",
  "update_menu_item",
  "update_slider_item",
  "update_post",
  "replace_text",
  "create_post",
  "undo",
];

const SYSTEM_PROMPT = `You convert an Arabic or French website-edit request into one safe WordPress command.
Return JSON only with this shape:
{
  "action": "update_site_info|update_menu_item|update_slider_item|update_post|replace_text|create_post|undo",
  "summary_ar": "short Arabic description of the exact proposed change",
  "arguments": {}
}

Arguments:
- update_site_info: { "site_title"?, "tagline"?, "phone"?, "email"?, "address"? }
- update_menu_item: { "item_id": string, "name_ar"?, "name_fr"?, "price"?: number, "description_ar"?, "description_fr"?, "tag_ar"?, "tag_fr"? }
- update_slider_item: { "slide_id": string, "kicker_ar"?, "kicker_fr"?, "title_ar"?, "title_fr"?, "text_ar"?, "text_fr"?, "dish_ar"?, "dish_fr"? }
- update_post: { "post_id": integer, "title"?, "content"?, "excerpt"?, "status"?: "draft"|"publish" }
- replace_text: { "post_id": integer, "old_text": string, "new_text": string }
- create_post: { "post_type": "post"|"page", "title": string, "content": string, "excerpt"?, "status": "draft"|"publish" }
- undo: { "action_id"?: integer }

Rules:
- Select post_id only from the supplied site context.
- Select item_id and slide_id only from the supplied site context. Use update_menu_item for meal names, descriptions, categories, prices or meal images. Use update_slider_item for slider text or slider images.
- If the request says that an attached image should replace a meal or slider image, select the correct menu or slider action and target; the image payload is added after planning.
- Use replace_text for a small edit inside existing page content. old_text must be supplied or unambiguous in the user request.
- Only use update_post.content when the user explicitly supplies or requests replacement of the complete page content.
- Preserve the user's supplied text and facts. Do not add claims, prices, or contact details.
- Use draft unless the user explicitly asks to publish.
- Refuse unsupported operations by returning {"error":"Arabic explanation"}.
- Never return code, SQL, PHP, plugin installation, user-management, or file-editing actions.`;

const CAR_RENTAL_PROMPT = `You convert an Arabic or French request to edit a French car-rental WordPress site into ONE safe command. Return JSON only:
{"action":"update_site_info|update_menu_item|update_slider_item|update_post|replace_text|create_post|undo","summary_ar":"brief precise Arabic summary","arguments":{}}
Fields:
- update_site_info: site_title, tagline, phone, email, address, whatsapp (only fields explicitly requested).
- update_menu_item: item_id from context, then name, description, price (numeric MAD/day), badge, category, gear, seats, bags, image (only when user attached a photo).
- update_slider_item: slide_id from context, then kicker, title, description, label, vehicle, image (only when user attached a photo).
- update_post: post_id from context, title, content, excerpt, status draft|publish.
- replace_text: post_id from context, old_text, new_text.
- create_post: post_type post|page, title, content, excerpt, status draft|publish.
- undo: action_id optional.
For an attached image, select the specified vehicle or slide and its action; image bytes are added by the server after planning.
Choose IDs ONLY from supplied site context. Never use restaurant dish/menu terminology or invent cars, prices, contact details, or claims. Keep existing facts unless the user requests a change. Use draft for a new post unless explicitly asked to publish. Refuse unsupported, ambiguous, destructive or security-related operations with {"error":"brief Arabic explanation"}. Never return code, SQL, PHP, file edits, plugins, or user-management operations.`;

function extractJson(text) {
  const cleaned = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  return JSON.parse(cleaned);
}

function validatePlan(plan) {
  if (!plan || typeof plan !== "object") throw new Error("AI returned an invalid response");
  if (plan.error) return { error: String(plan.error) };
  if (!ALLOWED_ACTIONS.includes(plan.action)) throw new Error("AI returned an unsupported action");
  if (!plan.summary_ar || typeof plan.summary_ar !== "string") {
    throw new Error("AI response is missing an Arabic summary");
  }
  if (!plan.arguments || typeof plan.arguments !== "object" || Array.isArray(plan.arguments)) {
    throw new Error("AI response has invalid arguments");
  }
  if (["update_post", "replace_text"].includes(plan.action) && !plan.arguments.post_id) {
    return { error: "حدد الصفحة أو المقال المراد تعديله بالاسم أو الرابط." };
  }
  if (plan.action === "update_menu_item" && !plan.arguments.item_id) {
          return { error: "حدد العنصر المراد تعديله." };
  }
  if (plan.action === "update_slider_item" && !plan.arguments.slide_id) {
          return { error: "حدد شريحة السلايدر المراد تعديلها." };
  }
  return plan;
}

export async function planCommand(config, userText, siteContext) {
  const response = await fetch(`${config.aiBaseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      authorization: `Bearer ${config.aiApiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: config.aiModel,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: config.vertical === "car_rental" ? CAR_RENTAL_PROMPT : SYSTEM_PROMPT },
        {
          role: "user",
          content: `Site context: ${JSON.stringify(siteContext)}\nRequest: ${userText}`,
        },
      ],
    }),
  });

  const body = await response.json();
  if (!response.ok) throw new Error(`AI provider failed: ${JSON.stringify(body)}`);
  const content = body.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI provider returned no content");
  return validatePlan(extractJson(content));
}

export { validatePlan };
