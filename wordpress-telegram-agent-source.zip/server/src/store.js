import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { randomUUID } from "node:crypto";

const EMPTY_STORE = { sites: [], pending: [] };

export class JsonStore {
  constructor(filePath) {
    this.filePath = resolve(filePath);
    this.queue = Promise.resolve();
  }

  async init() {
    await mkdir(dirname(this.filePath), { recursive: true });
    try {
      await readFile(this.filePath, "utf8");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      await this.#write(EMPTY_STORE);
    }
  }

  async #read() {
    return JSON.parse(await readFile(this.filePath, "utf8"));
  }

  async #write(data) {
    const temp = `${this.filePath}.tmp`;
    await writeFile(temp, `${JSON.stringify(data, null, 2)}\n`, "utf8");
    await rename(temp, this.filePath);
  }

  async #mutate(fn) {
    const operation = this.queue.then(async () => {
      const data = await this.#read();
      const result = await fn(data);
      await this.#write(data);
      return result;
    });
    this.queue = operation.catch(() => {});
    return operation;
  }

  async getSiteByChatId(chatId) {
    const data = await this.#read();
    return data.sites.find((site) => String(site.chatId) === String(chatId)) || null;
  }

  async upsertSite(site) {
    return this.#mutate((data) => {
      const normalized = {
        id: site.id || randomUUID(),
        chatId: String(site.chatId),
        name: String(site.name),
        siteUrl: String(site.siteUrl).replace(/\/$/, ""),
        secret: String(site.secret),
      };
      const index = data.sites.findIndex((item) => item.chatId === normalized.chatId);
      if (index >= 0) {
        normalized.id = data.sites[index].id;
        data.sites[index] = normalized;
      } else {
        data.sites.push(normalized);
      }
      return { ...normalized, secret: undefined };
    });
  }

  async createPending(chatId, siteId, plan) {
    return this.#mutate((data) => {
      const item = {
        id: randomUUID(),
        chatId: String(chatId),
        siteId,
        plan,
        status: "pending",
        createdAt: new Date().toISOString(),
      };
      data.pending.push(item);
      data.pending = data.pending.slice(-500);
      return item;
    });
  }

  async consumePending(id, chatId, nextStatus) {
    return this.#mutate((data) => {
      const item = data.pending.find(
        (candidate) => candidate.id === id && candidate.chatId === String(chatId),
      );
      if (!item || item.status !== "pending") return null;
      item.status = nextStatus;
      item.resolvedAt = new Date().toISOString();
      if (nextStatus === "cancelled" && item.plan?.arguments?.image) delete item.plan.arguments.image;
      return item;
    });
  }

  async setPendingStatus(id, status) {
    return this.#mutate((data) => {
      const item = data.pending.find((candidate) => candidate.id === id);
      if (!item) return null;
      item.status = status;
      item.updatedAt = new Date().toISOString();
      if (["completed", "failed", "cancelled"].includes(status) && item.plan?.arguments?.image) {
        delete item.plan.arguments.image;
      }
      return item;
    });
  }
}
