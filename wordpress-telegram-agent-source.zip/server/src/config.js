function required(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export function loadConfig() {
  const port = Number.parseInt(process.env.PORT || "3000", 10);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("PORT must be a valid TCP port");
  }

  return {
    port,
    telegramToken: required("TELEGRAM_BOT_TOKEN"),
    telegramWebhookSecret: required("TELEGRAM_WEBHOOK_SECRET"),
    aiApiKey: required("AI_API_KEY"),
    aiBaseUrl: (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
    aiModel: process.env.AI_MODEL || "gpt-4.1-mini",
    adminApiKey: required("ADMIN_API_KEY"),
    publicBaseUrl: required("PUBLIC_BASE_URL").replace(/\/$/, ""),
    dataFile: process.env.DATA_FILE || "./data/store.json",
    vertical: process.env.AGENT_VERTICAL === "car_rental" ? "car_rental" : "restaurant",
    fixedChatId: process.env.TELEGRAM_ALLOWED_CHAT_ID || "",
    fixedSiteUrl: process.env.WORDPRESS_SITE_URL || "",
    fixedSiteSecret: process.env.WORDPRESS_SITE_SECRET || "",
  };
}
