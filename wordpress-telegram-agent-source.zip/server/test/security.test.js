import test from "node:test";
import assert from "node:assert/strict";
import { signWordPressRequest, safeEqual } from "../src/security.js";

test("WordPress request signature is deterministic", () => {
  const signature = signWordPressRequest(
    "secret",
    "1700000000",
    "request-nonce",
    "POST",
    "/ai-site-agent/v1/commands",
    '{"action":"test"}',
  );
  assert.equal(signature, "a9b3105376131d6f07ba045969292fcbb2b7ab0694cc00f42efe6f7a3fccc569");
});

test("safeEqual compares secrets without accepting partial values", () => {
  assert.equal(safeEqual("same", "same"), true);
  assert.equal(safeEqual("same", "sam"), false);
  assert.equal(safeEqual("same", "different"), false);
});
