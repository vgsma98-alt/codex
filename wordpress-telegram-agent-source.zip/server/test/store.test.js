import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { JsonStore } from "../src/store.js";

test("stores sites and consumes a pending action once", async () => {
  const directory = await mkdtemp(join(tmpdir(), "aia-store-"));
  try {
    const file = join(directory, "store.json");
    const store = new JsonStore(file);
    await store.init();
    const saved = await store.upsertSite({
      chatId: "42",
      name: "Test",
      siteUrl: "https://example.com/",
      secret: "a".repeat(48),
    });
    assert.equal(saved.siteUrl, "https://example.com");
    assert.equal(saved.secret, undefined);

    const site = await store.getSiteByChatId(42);
    const pending = await store.createPending(42, site.id, {
      action: "undo",
      summary_ar: "تراجع",
      arguments: {},
    });
    assert.ok(await store.consumePending(pending.id, 42, "executing"));
    assert.equal(await store.consumePending(pending.id, 42, "executing"), null);

    const persisted = JSON.parse(await readFile(file, "utf8"));
    assert.equal(persisted.sites.length, 1);
  } finally {
    await rm(directory, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
  }
});
