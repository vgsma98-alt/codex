import test from "node:test";
import assert from "node:assert/strict";
import { validatePlan } from "../src/ai.js";

test("accepts an allowed structured command", () => {
  const plan = validatePlan({
    action: "update_site_info",
    summary_ar: "تغيير رقم الهاتف",
    arguments: { phone: "+212600000000" },
  });
  assert.equal(plan.action, "update_site_info");
});

test("requires a target for post updates", () => {
  const plan = validatePlan({
    action: "update_post",
    summary_ar: "تغيير العنوان",
    arguments: { title: "عنوان جديد" },
  });
  assert.match(plan.error, /حدد الصفحة/);
});

test("rejects actions outside the allowlist", () => {
  assert.throws(() => validatePlan({
    action: "install_plugin",
    summary_ar: "تثبيت إضافة",
    arguments: {},
  }), /unsupported action/);
});

test("accepts a precise text replacement", () => {
  const plan = validatePlan({
    action: "replace_text",
    summary_ar: "استبدال جملة في الصفحة الرئيسية",
    arguments: { post_id: 2, old_text: "قديم", new_text: "جديد" },
  });
  assert.equal(plan.arguments.post_id, 2);
});

test("accepts a menu price update", () => {
  const plan = validatePlan({
    action: "update_menu_item",
    summary_ar: "تغيير سعر طاجين الدجاج إلى 160 درهم",
    arguments: { item_id: "tagine_chicken", price: 160 },
  });
  assert.equal(plan.arguments.item_id, "tagine_chicken");
});

test("requires a slider target", () => {
  const plan = validatePlan({ action: "update_slider_item", summary_ar: "تغيير صورة السلايدر", arguments: {} });
  assert.match(plan.error, /شريحة/);
});
