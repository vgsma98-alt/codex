import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { signWordPressRequest } from '../src/security.js';

const root = 'https://n8n-atlas-drive-wp.aafmlp.easypanel.host';
const credentials = await readFile('.credentials/atlas-drive-wp-admin.txt', 'utf8');
const password = credentials.match(/^Password:\s*(.+)$/m)?.[1]?.trim();
if (!password) throw new Error('WordPress credentials are unavailable');
const cookies = new Map();
async function adminRequest(path, options = {}, depth = 0) {
  if (depth > 8) throw new Error('Too many redirects');
  const headers = new Headers(options.headers || {});
  if (cookies.size) headers.set('cookie', [...cookies].map(([name, value]) => `${name}=${value}`).join('; '));
  const response = await fetch(new URL(path, root), { ...options, headers, redirect: 'manual' });
  for (const line of response.headers.getSetCookie?.() || []) {
    const [pair] = line.split(';');
    const at = pair.indexOf('=');
    if (at > 0) cookies.set(pair.slice(0, at), pair.slice(at + 1));
  }
  const location = response.headers.get('location');
  if (location && [301, 302, 303, 307, 308].includes(response.status)) {
    const method = response.status === 303 || (response.status === 302 && options.method === 'POST') ? 'GET' : options.method || 'GET';
    return adminRequest(new URL(location, new URL(path, root)), { method, body: method === 'GET' ? undefined : options.body }, depth + 1);
  }
  return response;
}
await adminRequest('/wp-login.php');
await adminRequest('/wp-login.php', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ log: 'atlasadmin', pwd: password, 'wp-submit': 'Log In', redirect_to: root + '/wp-admin/', testcookie: '1' }) });
const html = await (await adminRequest('/wp-admin/options-general.php?page=atlas-telegram-agent')).text();
const secret = html.match(/Shared secret:<\/strong>\s*<code>([^<]+)<\/code>/)?.[1];
if (!secret) throw new Error('Live Atlas agent secret is unavailable');
const bytes = await readFile('wordpress-theme/atlas-drive/assets/cars-optimized/berline.jpg');

async function signed(method, route, payload) {
  const body = payload ? JSON.stringify(payload) : '';
  const timestamp = String(Math.floor(Date.now() / 1000));
  const nonce = randomUUID();
  const signature = signWordPressRequest(secret, timestamp, nonce, method, route, body);
  const response = await fetch(root + '/wp-json' + route, {
    method,
    headers: {
      'content-type': 'application/json',
      'x-aia-timestamp': timestamp,
      'x-aia-nonce': nonce,
      'x-aia-signature': signature,
    },
    body: method === 'POST' ? body : undefined,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`${response.status}: ${data.message || 'WordPress error'}`);
  return data;
}

const original = await signed('GET', '/ai-site-agent/v1/context');
const before = original.menu.find((item) => item.id === 'berline')?.image_url;
if (!before) throw new Error('Original vehicle image is missing');
const result = await signed('POST', '/ai-site-agent/v1/commands', {
  action: 'update_menu_item',
  arguments: {
    item_id: 'berline',
    image: { filename: 'berline.jpg', mime_type: 'image/jpeg', data_base64: bytes.toString('base64') },
  },
  requested_by: 'bridge-image-check',
});
try {
  const changed = await signed('GET', '/ai-site-agent/v1/context');
  const after = changed.menu.find((item) => item.id === 'berline')?.image_url;
  if (!after || after === before || !after.includes('/uploads/')) throw new Error('Uploaded image was not published in context');
  const imageResponse = await fetch(after);
  if (!imageResponse.ok || !(imageResponse.headers.get('content-type') || '').startsWith('image/')) throw new Error('Uploaded image URL is unavailable');
  console.log('Atlas image bridge verified: uploaded image published and reachable.');
} finally {
  await signed('POST', '/ai-site-agent/v1/commands', {
    action: 'undo', arguments: { action_id: result.action_id }, requested_by: 'bridge-image-check',
  });
}
