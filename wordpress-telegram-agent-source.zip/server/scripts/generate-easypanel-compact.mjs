import { gzipSync } from "node:zlib";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const serverDirectory = resolve(scriptDirectory, "..");
const outputDirectory = resolve(serverDirectory, "..", "deploy");
const outputFile = resolve(outputDirectory, "easypanel-compose-compact.yaml");
const sourceFiles = [
  "ai.js",
  "config.js",
  "security.js",
  "server.js",
  "store.js",
  "telegram.js",
  "wordpress.js",
];

const bundle = { "package.json": '{"type":"module"}\n' };
for (const fileName of sourceFiles) {
  bundle[fileName] = await readFile(resolve(serverDirectory, "src", fileName), "utf8");
}
const compressedBundle = gzipSync(Buffer.from(JSON.stringify(bundle))).toString("base64");
const bootstrap = [
  "const z=require('node:zlib'),f=require('node:fs');",
  "const b=JSON.parse(z.gunzipSync(Buffer.from(process.env.APP_BUNDLE,'base64')));",
  "f.mkdirSync('/app',{recursive:true});",
  "for(const [n,c] of Object.entries(b))f.writeFileSync('/app/'+n,c);",
  "import('/app/server.js').catch(e=>{console.error(e);process.exit(1)});",
].join("");

const compose = `services:
  agent:
    image: node:24-alpine
    restart: unless-stopped
    working_dir: /app
    command: ["node", "-e", "${bootstrap}"]
    environment:
      NODE_ENV: production
      PORT: "3000"
      DATA_FILE: /data/store.json
      APP_BUNDLE: "${compressedBundle}"
      TELEGRAM_BOT_TOKEN: \${TELEGRAM_BOT_TOKEN}
      TELEGRAM_WEBHOOK_SECRET: \${TELEGRAM_WEBHOOK_SECRET}
      AI_API_KEY: \${AI_API_KEY}
      AI_BASE_URL: \${AI_BASE_URL}
      AI_MODEL: \${AI_MODEL}
      ADMIN_API_KEY: \${ADMIN_API_KEY}
      PUBLIC_BASE_URL: \${PUBLIC_BASE_URL}
    volumes:
      - agent_data:/data
    expose:
      - "3000"
    networks:
      easypanel:
        aliases:
          - n8n_wp-agent_agent
    healthcheck:
      test: ["CMD", "node", "-e", "fetch('http://127.0.0.1:3000/health').then(r=>{if(!r.ok)process.exit(1)}).catch(()=>process.exit(1))"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s

volumes:
  agent_data:

networks:
  easypanel:
    external: true
    name: easypanel
`;

await mkdir(outputDirectory, { recursive: true });
await writeFile(outputFile, compose, "utf8");
console.log(`Generated ${outputFile}`);
