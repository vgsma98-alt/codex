import { readFile } from "node:fs/promises";
import path from "node:path";

const [baseUrl, username, credentialsFile, themeZip, themeSlug] = process.argv.slice(2);
if (![baseUrl, username, credentialsFile, themeZip, themeSlug].every(Boolean)) {
  console.error("Usage: node deploy-wordpress-theme.mjs BASE_URL USERNAME CREDENTIALS_FILE THEME_ZIP THEME_SLUG");
  process.exit(2);
}

const root = baseUrl.replace(/\/$/, "");
const credentials = await readFile(credentialsFile, "utf8");
const password = credentials.match(/^Password:\s*(.+)$/m)?.[1]?.trim();
if (!password) throw new Error("Password was not found in the credentials file");

function decodeHtml(value) {
  return value.replaceAll("&#038;", "&").replaceAll("&amp;", "&").replaceAll("&#039;", "'").replaceAll("&quot;", '"');
}

function field(html, name) {
  const patterns = [
    new RegExp(`<input[^>]*name=["']${name}["'][^>]*value=["']([^"']*)["']`, "i"),
    new RegExp(`<input[^>]*value=["']([^"']*)["'][^>]*name=["']${name}["']`, "i"),
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match) return decodeHtml(match[1]);
  }
  return "";
}

class Session {
  constructor() { this.cookies = new Map(); }
  update(headers) {
    const values = typeof headers.getSetCookie === "function" ? headers.getSetCookie() : [headers.get("set-cookie")].filter(Boolean);
    for (const value of values) {
      const pair = value.split(";", 1)[0];
      const index = pair.indexOf("=");
      if (index > 0) this.cookies.set(pair.slice(0, index), pair.slice(index + 1));
    }
  }
  header() { return [...this.cookies].map(([key, value]) => `${key}=${value}`).join("; "); }
  async request(target, options = {}, redirects = 0) {
    const url = new URL(target, root);
    const headers = new Headers(options.headers || {});
    if (this.cookies.size) headers.set("cookie", this.header());
    const response = await fetch(url, { ...options, headers, redirect: "manual" });
    this.update(response.headers);
    const location = response.headers.get("location");
    if ([301, 302, 303, 307, 308].includes(response.status) && location) {
      if (redirects > 8) throw new Error("Too many redirects");
      const method = response.status === 303 || (response.status === 302 && options.method === "POST") ? "GET" : (options.method || "GET");
      return this.request(new URL(location, url), { method, body: method === "GET" ? undefined : options.body }, redirects + 1);
    }
    return response;
  }
}

const session = new Session();
await session.request("/wp-login.php");
const login = await session.request("/wp-login.php", {
  method: "POST",
  headers: { "content-type": "application/x-www-form-urlencoded" },
  body: new URLSearchParams({ log: username, pwd: password, "wp-submit": "Log In", redirect_to: `${root}/wp-admin/`, testcookie: "1" }),
});
const loginHtml = await login.text();
if (!login.url.includes("/wp-admin/") || !loginHtml.includes("wp-admin-bar")) throw new Error("WordPress login failed");

const uploadPage = "/wp-admin/theme-install.php?browse=featured";
const page = await session.request(uploadPage);
const nonce = field(await page.text(), "_wpnonce");
if (!nonce) throw new Error("Theme upload nonce was not found");

const bytes = await readFile(themeZip);
const form = new FormData();
form.append("_wpnonce", nonce);
form.append("_wp_http_referer", uploadPage);
form.append("themezip", new Blob([bytes], { type: "application/zip" }), path.basename(themeZip));
form.append("install-theme-submit", "Install Now");
const upload = await session.request("/wp-admin/update.php?action=upload-theme", { method: "POST", body: form });
const uploadHtml = await upload.text();
const links = [...uploadHtml.matchAll(/href=["']([^"']+)["']/gi)].map((match) => decodeHtml(match[1]));
const activation = links.find((href) => href.includes("action=activate") && href.includes(themeSlug));
if (!activation) {
  const detail = uploadHtml.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(-900);
  throw new Error(`Theme activation link was not found: ${detail}`);
}
await session.request(new URL(activation, `${root}/wp-admin/`));

const publicPage = await fetch(root);
const publicHtml = await publicPage.text();
if (!publicPage.ok || !publicHtml.includes(`/themes/${themeSlug}/style.css`)) throw new Error("Theme did not become active");
console.log(`Theme ${themeSlug} installed, activated, and verified`);

