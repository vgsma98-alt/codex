import { readFile, writeFile } from 'node:fs/promises';
const yaml=await readFile(new URL('../../deploy/easypanel-compose-compact-v2.yaml',import.meta.url),'utf8');
const bundle=yaml.match(/APP_BUNDLE: "([^"]+)"/)?.[1];
if(!bundle)throw new Error('Bundle missing');
await writeFile(new URL('../../deploy/atlas-bundle.txt',import.meta.url),bundle,'utf8');
console.log(`Bundle bytes: ${bundle.length}`);
