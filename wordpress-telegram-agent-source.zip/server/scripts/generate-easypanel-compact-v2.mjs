import { readFile, writeFile } from "node:fs/promises";
import { gzipSync } from "node:zlib";

const sourceFiles = [
  "ai.js",
  "config.js",
  "security.js",
  "server.js",
  "store.js",
  "telegram.js",
  "wordpress.js",
];

const bundle = {};
for (const fileName of sourceFiles) {
  bundle[fileName] = await readFile(new URL(`../src/${fileName}`, import.meta.url), "utf8");
}

const encoded = gzipSync(Buffer.from(JSON.stringify(bundle))).toString("base64");
const templateUrl = new URL("../../deploy/easypanel-compose-compact.yaml", import.meta.url);
const outputUrl = new URL("../../deploy/easypanel-compose-compact-v2.yaml", import.meta.url);
const template = await readFile(templateUrl, "utf8");
const compose = template.replace(/APP_BUNDLE: "[^"]*"/, `APP_BUNDLE: "${encoded}"`);
if (compose === template) throw new Error("APP_BUNDLE field not found in compact template");

await writeFile(outputUrl, compose, "utf8");
console.log(`Generated ${outputUrl.pathname}`);

