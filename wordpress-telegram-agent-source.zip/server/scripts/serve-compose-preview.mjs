import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const requestedFile = process.argv[2] || "easypanel-compose.yaml";
const composeFile = resolve(scriptDirectory, "..", "..", "deploy", requestedFile);
const port = Number.parseInt(process.env.COMPOSE_PREVIEW_PORT || "31987", 10);

createServer(async (request, response) => {
  if (request.url !== "/compose") {
    response.writeHead(404).end("Not found");
    return;
  }
  try {
    const content = await readFile(composeFile, "utf8");
    response.writeHead(200, {
      "content-type": "text/plain; charset=utf-8",
      "cache-control": "no-store",
    });
    response.end(content);
  } catch (error) {
    response.writeHead(500).end(error.message);
  }
}).listen(port, "0.0.0.0", () => {
  console.log(`Compose preview: http://0.0.0.0:${port}/compose`);
});
