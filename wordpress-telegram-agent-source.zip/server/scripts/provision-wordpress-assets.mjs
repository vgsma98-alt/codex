import { createHmac, randomBytes, randomUUID } from "node:crypto";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";

const [baseUrl, username, initialPassword, pluginZip, themeZip, credentialsDir] = process.argv.slice(2);
if (![baseUrl, username, initialPassword, pluginZip, themeZip, credentialsDir].every(Boolean)) {
  console.error("Usage: node provision-wordpress-assets.mjs BASE_URL USERNAME PASSWORD PLUGIN_ZIP THEME_ZIP CREDENTIALS_DIR");
  process.exit(2);
}

const root = baseUrl.replace(/\/$/, "");

function decodeHtml(value) {
  return value
    .replaceAll("&#038;", "&")
    .replaceAll("&amp;", "&")
    .replaceAll("&#039;", "'")
    .replaceAll("&quot;", '"');
}

function field(html, name) {
  const patterns = [
    new RegExp(`<input[^>]*name=["']${name}["'][^>]*value=["']([^"']*)["']`, "i"),
    new RegExp(`<input[^>]*value=["']([^"']*)["'][^>]*name=["']${name}["']`, "i"),
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match) return decodeHtml(match[1]);
  }
  return "";
}

class WordPressSession {
  constructor() {
    this.cookies = new Map();
  }

  updateCookies(headers) {
    const values = typeof headers.getSetCookie === "function"
      ? headers.getSetCookie()
      : [headers.get("set-cookie")].filter(Boolean);
    for (const value of values) {
      const pair = value.split(";", 1)[0];
      const index = pair.indexOf("=");
      if (index > 0) this.cookies.set(pair.slice(0, index), pair.slice(index + 1));
    }
  }

  cookieHeader() {
    return [...this.cookies.entries()].map(([key, value]) => `${key}=${value}`).join("; ");
  }

  async request(target, options = {}, redirects = 0) {
    const url = new URL(target, root);
    const headers = new Headers(options.headers || {});
    if (this.cookies.size) headers.set("cookie", this.cookieHeader());
    const response = await fetch(url, { ...options, headers, redirect: "manual" });
    this.updateCookies(response.headers);
    if ([301, 302, 303, 307, 308].includes(response.status) && response.headers.get("location")) {
      if (redirects > 8) throw new Error("Too many redirects");
      const nextMethod = response.status === 303 || (response.status === 302 && options.method === "POST") ? "GET" : options.method;
      return this.request(new URL(response.headers.get("location"), url), {
        method: nextMethod || "GET",
        headers: nextMethod === "GET" ? {} : headers,
        body: nextMethod === "GET" ? undefined : options.body,
      }, redirects + 1);
    }
    return response;
  }

  async login(password) {
    await this.request("/wp-login.php");
    const body = new URLSearchParams({
      log: username,
      pwd: password,
      "wp-submit": "Log In",
      redirect_to: `${root}/wp-admin/`,
      testcookie: "1",
    });
    const response = await this.request("/wp-login.php", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    });
    const html = await response.text();
    if (!response.url.includes("/wp-admin/") || !html.includes("wp-admin-bar")) {
      throw new Error("WordPress login failed");
    }
  }
}

async function uploadAndActivate(session, kind, archivePath) {
  const isPlugin = kind === "plugin";
  const uploadPage = isPlugin ? "/wp-admin/plugin-install.php?tab=upload" : "/wp-admin/theme-install.php?browse=featured";
  const uploadAction = isPlugin ? "upload-plugin" : "upload-theme";
  const fileField = isPlugin ? "pluginzip" : "themezip";
  const submitField = isPlugin ? "install-plugin-submit" : "install-theme-submit";
  const page = await session.request(uploadPage);
  const pageHtml = await page.text();
  const nonce = field(pageHtml, "_wpnonce");
  if (!nonce) throw new Error(`Unable to find ${kind} upload nonce`);

  const bytes = await readFile(archivePath);
  const form = new FormData();
  form.append("_wpnonce", nonce);
  form.append("_wp_http_referer", uploadPage);
  form.append(fileField, new Blob([bytes], { type: "application/zip" }), path.basename(archivePath));
  form.append(submitField, isPlugin ? "Install Now" : "Install Now");

  const upload = await session.request(`/wp-admin/update.php?action=${uploadAction}`, { method: "POST", body: form });
  const uploadHtml = await upload.text();
  if (!/successfully|بنجاح|installed/i.test(uploadHtml)) {
    const detail = uploadHtml.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 1200);
    throw new Error(`${kind} upload did not report success (${upload.status}): ${detail}`);
  }

  const links = [...uploadHtml.matchAll(/href=["']([^"']+)["']/gi)].map((match) => decodeHtml(match[1]));
  const activation = links.find((href) => href.includes("action=activate"));
  if (!activation) throw new Error(`Unable to find ${kind} activation link`);
  const activated = await session.request(new URL(activation, `${root}/wp-admin/`));
  await activated.text();
  if (activated.status >= 400) {
    throw new Error(`${kind} activation failed`);
  }
}

function findLink(html, predicate) {
  const links = [...html.matchAll(/href=["']([^"']+)["']/gi)].map((match) => decodeHtml(match[1]));
  return links.find(predicate);
}

async function ensurePlugin(session, archivePath) {
  let response = await session.request("/wp-admin/plugins.php");
  let html = await response.text();
  const pluginMarker = "ai-site-agent%2Fai-site-agent.php";

  if (!html.includes(pluginMarker)) {
    await uploadAndActivate(session, "plugin", archivePath);
    response = await session.request("/wp-admin/plugins.php");
    html = await response.text();
  }

  if (!html.includes(`action=deactivate&amp;plugin=${pluginMarker}`) && !html.includes(`action=deactivate&plugin=${pluginMarker}`)) {
    const activation = findLink(html, (href) => href.includes("action=activate") && href.includes(pluginMarker));
    if (!activation) throw new Error("Unable to find AI Site Agent activation link");
    const activationResponse = await session.request(new URL(activation, `${root}/wp-admin/`));
    const activationHtml = await activationResponse.text();
    response = await session.request("/wp-admin/plugins.php");
    html = await response.text();
    if (activationResponse.status >= 400) {
      const detail = activationHtml.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 800);
      throw new Error(`AI Site Agent activation returned ${activationResponse.status}: ${detail}`);
    }
  }

  if (!html.includes(`action=deactivate&amp;plugin=${pluginMarker}`) && !html.includes(`action=deactivate&plugin=${pluginMarker}`)) {
    throw new Error("AI Site Agent is not active after activation request");
  }
  console.log("plugin: installed and active");
}

async function restaurantThemeIsActive() {
  const response = await fetch(root);
  const html = await response.text();
  return response.ok && html.includes("/themes/madaq-restaurant/style.css");
}

async function ensureTheme(session, archivePath) {
  if (await restaurantThemeIsActive()) {
    console.log("theme: already active");
    return;
  }

  let response = await session.request("/wp-admin/themes.php");
  let html = await response.text();
  if (!html.includes('data-slug="madaq-restaurant"')) {
    await uploadAndActivate(session, "theme", archivePath);
  } else {
    const activation = findLink(html, (href) => href.includes("action=activate") && href.includes("madaq-restaurant"));
    if (!activation) throw new Error("Unable to find Madaq Restaurant activation link");
    await session.request(new URL(activation, `${root}/wp-admin/`));
  }

  if (!(await restaurantThemeIsActive())) {
    throw new Error("Madaq Restaurant theme is not active after activation request");
  }
  console.log("theme: installed and active");
}

async function readAgentSecret(session) {
  const response = await session.request("/wp-admin/options-general.php?page=ai-site-agent");
  const html = await response.text();
  const match = html.match(/<input[^>]*class=["'][^"']*regular-text code[^"']*["'][^>]*value=["']([^"']+)["']/i)
    || html.match(/<input[^>]*value=["']([^"']+)["'][^>]*class=["'][^"']*regular-text code/i);
  if (!match) throw new Error("Unable to read AI Site Agent secret");
  return decodeHtml(match[1]);
}

async function updateBusinessProfile(secret) {
  const route = "/ai-site-agent/v1/commands";
  const body = JSON.stringify({
    action: "update_site_info",
    arguments: {
      site_title: "مطعم مذاق المغرب",
      tagline: "نكهات مغربية بروح معاصرة",
      phone: "+212 5 22 00 00 00",
      email: "reservation@madaq.ma",
      address: "الدار البيضاء، المغرب",
    },
    requested_by: "provisioning:local",
  });
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = randomUUID();
  const signature = createHmac("sha256", secret)
    .update([timestamp, nonce, "POST", route, body].join("\n"))
    .digest("hex");
  const response = await fetch(`${root}/wp-json${route}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-aia-timestamp": timestamp,
      "x-aia-nonce": nonce,
      "x-aia-signature": signature,
    },
    body,
  });
  if (!response.ok) throw new Error(`Business profile update failed (${response.status}): ${await response.text()}`);
  console.log("business profile: configured");
}

async function changePassword(session) {
  const profile = await session.request("/wp-admin/profile.php");
  const html = await profile.text();
  const userId = field(html, "user_id");
  const nonce = field(html, "_wpnonce");
  if (!userId || !nonce) throw new Error("Unable to read profile form");
  const finalPassword = randomBytes(24).toString("base64url") + "!Aa7";
  const body = new URLSearchParams({
    _wpnonce: nonce,
    _wp_http_referer: "/wp-admin/profile.php",
    from: "profile",
    checkuser_id: userId,
    user_id: userId,
    action: "update",
    nickname: username,
    display_name: username,
    email: "admin@example.com",
    pass1: finalPassword,
    pass2: finalPassword,
    submit: "Update Profile",
  });
  const updated = await session.request("/wp-admin/profile.php", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  const result = await updated.text();
  if (!/Profile updated|تم تحديث الملف الشخصي|updated/i.test(result)) {
    throw new Error("WordPress password update did not report success");
  }
  const verify = new WordPressSession();
  await verify.login(finalPassword);
  await mkdir(credentialsDir, { recursive: true });
  await writeFile(path.join(credentialsDir, "restaurant-wp-admin-final.txt"),
    `Site: ${root}\nUsername: ${username}\nEmail: admin@example.com\nPassword: ${finalPassword}\n`,
    { flag: "wx", mode: 0o600 });
  console.log("admin password: strengthened and verified");
}

const session = new WordPressSession();
await session.login(initialPassword);
await ensurePlugin(session, pluginZip);
await ensureTheme(session, themeZip);
const agentSecret = await readAgentSecret(session);
await mkdir(credentialsDir, { recursive: true });
await writeFile(path.join(credentialsDir, "restaurant-site-agent-secret.txt"),
  `Site: ${root}\nSecret: ${agentSecret}\n`, { flag: "wx", mode: 0o600 });
await updateBusinessProfile(agentSecret);
await changePassword(session);
console.log("WordPress restaurant site provisioning complete");
