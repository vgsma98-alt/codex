import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { signWordPressRequest } from '../src/security.js';

const root='https://n8n-atlas-drive-wp.aafmlp.easypanel.host';
const credentials=await readFile('.credentials/atlas-drive-wp-admin.txt','utf8');
const password=credentials.match(/^Password:\s*(.+)$/m)?.[1]?.trim();
if(!password)throw new Error('WordPress credentials unavailable');
const cookies=new Map();
async function request(path,options={},depth=0){
  if(depth>8)throw new Error('Too many redirects');
  const headers=new Headers(options.headers||{});
  if(cookies.size)headers.set('cookie',[...cookies].map(([k,v])=>`${k}=${v}`).join('; '));
  const response=await fetch(new URL(path,root),{...options,headers,redirect:'manual'});
  for(const line of response.headers.getSetCookie?.()||[]){const [pair]=line.split(';');const at=pair.indexOf('=');if(at>0)cookies.set(pair.slice(0,at),pair.slice(at+1));}
  const location=response.headers.get('location');
  if(location && [301,302,303,307,308].includes(response.status)){
    const method=response.status===303 || (response.status===302 && options.method==='POST')?'GET':options.method||'GET';
    return request(new URL(location,new URL(path,root)),{method,body:method==='GET'?undefined:options.body},depth+1);
  }
  return response;
}
await request('/wp-login.php');
const login=await request('/wp-login.php',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({log:'atlasadmin',pwd:password,'wp-submit':'Log In',redirect_to:`${root}/wp-admin/`,testcookie:'1'})});
if(!(await login.text()).includes('wp-admin-bar'))throw new Error('WordPress login failed');
const admin=await request('/wp-admin/options-general.php?page=atlas-telegram-agent');
const html=await admin.text();
const secret=html.match(/Shared secret:<\/strong>\s*<code>([^<]+)<\/code>/)?.[1];
if(!secret)throw new Error('Atlas agent secret unavailable');

async function signed(route,method,body=''){
  const timestamp=String(Math.floor(Date.now()/1000));
  const nonce=randomUUID();
  const signature=signWordPressRequest(secret,timestamp,nonce,method,route,body);
  const response=await fetch(`${root}/wp-json${route}`,{method,headers:{'content-type':'application/json','x-aia-timestamp':timestamp,'x-aia-nonce':nonce,'x-aia-signature':signature},body:method==='GET'?undefined:body});
  return {status:response.status,data:await response.json()};
}
const denied=await fetch(`${root}/wp-json/ai-site-agent/v1/context`);
if(denied.status!==401)throw new Error(`Unsigned context was not denied: ${denied.status}`);
const context=await signed('/ai-site-agent/v1/context','GET');
if(context.status!==200 || context.data.menu?.length!==9 || context.data.slides?.length!==3)throw new Error(`Unexpected signed context: ${context.status}`);
const car=context.data.menu.find(item=>item.id==='berline');
if(!car)throw new Error('Berline missing from context');
const change=await signed('/ai-site-agent/v1/commands','POST',JSON.stringify({action:'update_menu_item',arguments:{item_id:'berline',price:Number(car.price)},requested_by:'bridge-check'}));
if(change.status!==200 || !change.data.action_id)throw new Error(`Signed update failed: ${change.status} ${JSON.stringify(change.data)}`);
const undo=await signed('/ai-site-agent/v1/commands','POST',JSON.stringify({action:'undo',arguments:{action_id:change.data.action_id},requested_by:'bridge-check'}));
if(undo.status!==200 || !undo.data.ok)throw new Error(`Undo failed: ${undo.status} ${JSON.stringify(undo.data)}`);
console.log('Atlas bridge verified: unsigned request denied; 9 cars, 3 slides; signed update and undo succeeded.');
