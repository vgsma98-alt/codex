import { readFile } from "node:fs/promises";
import path from "node:path";

const [baseUrl, username, credentialsFile, pluginZip, pluginSlug] = process.argv.slice(2);
if (![baseUrl, username, credentialsFile, pluginZip, pluginSlug].every(Boolean)) {
  console.error("Usage: node deploy-wordpress-plugin-update.mjs BASE_URL USERNAME CREDENTIALS_FILE PLUGIN_ZIP PLUGIN_SLUG");
  process.exit(2);
}
const root = baseUrl.replace(/\/$/, "");
const credentials = await readFile(credentialsFile, "utf8");
const password = credentials.match(/^Password:\s*(.+)$/m)?.[1]?.trim();
if (!password) throw new Error("Password was not found in the credentials file");

function decode(value = "") {
  return value.replaceAll("&#038;", "&").replaceAll("&amp;", "&").replaceAll("&#039;", "'").replaceAll("&quot;", '"');
}
function field(html, name) {
  return decode(html.match(new RegExp(`<input[^>]*name=["']${name}["'][^>]*value=["']([^"']*)`, "i"))?.[1]
    || html.match(new RegExp(`<input[^>]*value=["']([^"']*)["'][^>]*name=["']${name}["']`, "i"))?.[1]);
}
class Session {
  constructor() { this.cookies = new Map(); }
  update(headers) {
    const values = typeof headers.getSetCookie === "function" ? headers.getSetCookie() : [headers.get("set-cookie")].filter(Boolean);
    for (const value of values) { const pair = value.split(";", 1)[0]; const i = pair.indexOf("="); if (i > 0) this.cookies.set(pair.slice(0, i), pair.slice(i + 1)); }
  }
  header() { return [...this.cookies].map(([k, v]) => `${k}=${v}`).join("; "); }
  async request(target, options = {}, redirects = 0) {
    const url = new URL(target, root); const headers = new Headers(options.headers || {}); if (this.cookies.size) headers.set("cookie", this.header());
    const response = await fetch(url, { ...options, headers, redirect: "manual" }); this.update(response.headers);
    const location = response.headers.get("location");
    if ([301,302,303,307,308].includes(response.status) && location) {
      if (redirects > 8) throw new Error("Too many redirects");
      const method = response.status === 303 || (response.status === 302 && options.method === "POST") ? "GET" : (options.method || "GET");
      return this.request(new URL(location, url), { method, body: method === "GET" ? undefined : options.body }, redirects + 1);
    }
    return response;
  }
}

const session = new Session();
await session.request("/wp-login.php");
const login = await session.request("/wp-login.php", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ log: username, pwd: password, "wp-submit": "Log In", redirect_to: `${root}/wp-admin/`, testcookie: "1" }) });
if (!login.url.includes("/wp-admin/") || !(await login.text()).includes("wp-admin-bar")) throw new Error("WordPress login failed");

const page = await session.request("/wp-admin/plugin-install.php?tab=upload");
const nonce = field(await page.text(), "_wpnonce");
if (!nonce) throw new Error("Plugin upload nonce was not found");
const form = new FormData();
form.append("_wpnonce", nonce); form.append("_wp_http_referer", "/wp-admin/plugin-install.php?tab=upload");
form.append("pluginzip", new Blob([await readFile(pluginZip)], { type: "application/zip" }), path.basename(pluginZip));
form.append("install-plugin-submit", "Install Now");
const upload = await session.request("/wp-admin/update.php?action=upload-plugin", { method: "POST", body: form });
let html = await upload.text();

if (/already installed|déjà installée|موجودة بالفعل/i.test(html)) {
  const replacement = [...html.matchAll(/<form[\s\S]*?<\/form>/gi)].map((match) => match[0]).find((candidate) => /overwrite|replace-current|remplacer/i.test(candidate));
  const replacementLink = [...html.matchAll(/href=["']([^"']+)["']/gi)].map((match) => decode(match[1])).find((href) => /overwrite=update-plugin|overwrite-plugin/i.test(href));
  if (!replacement && !replacementLink) {
    const detail = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(-1800);
    throw new Error(`Plugin replacement form was not found: ${detail}`);
  }
  if (replacementLink) {
    const replaced = await session.request(replacementLink);
    html = await replaced.text();
  } else {
    const action = decode(replacement.match(/action=["']([^"']+)["']/i)?.[1] || "/wp-admin/update.php?action=upload-plugin");
    const body = new URLSearchParams();
    for (const input of replacement.matchAll(/<input[^>]*>/gi)) {
      const tag = input[0]; const name = decode(tag.match(/name=["']([^"']+)["']/i)?.[1]); if (!name) continue;
      body.append(name, decode(tag.match(/value=["']([^"']*)["']/i)?.[1] || ""));
    }
    const replaced = await session.request(action, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body });
    html = await replaced.text();
  }
}

const activation = [...html.matchAll(/href=["']([^"']+)["']/gi)]
  .map((match) => decode(match[1]))
  .find((href) => href.includes("action=activate") && href.includes(pluginSlug));
if (activation) await session.request(new URL(activation, `${root}/wp-admin/`));

const plugins = await session.request("/wp-admin/plugins.php");
const pluginsHtml = await plugins.text();
if (!pluginsHtml.includes(`${pluginSlug}%2F${pluginSlug}.php`) || !pluginsHtml.includes(`action=deactivate&amp;plugin=${pluginSlug}%2F${pluginSlug}.php`)) {
  throw new Error("Updated plugin is not active");
}
console.log(`Plugin ${pluginSlug} updated and active`);
