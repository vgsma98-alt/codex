import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const serverDirectory = resolve(scriptDirectory, "..");
const outputDirectory = resolve(serverDirectory, "..", "deploy");
const outputFile = resolve(outputDirectory, "easypanel-compose.yaml");

const sourceFiles = [
  "ai.js",
  "config.js",
  "security.js",
  "server.js",
  "store.js",
  "telegram.js",
  "wordpress.js",
];

function configName(fileName) {
  return fileName.replace(/\W/g, "_");
}

function indentBlock(content, spaces) {
  const indentation = " ".repeat(spaces);
  // Docker Compose uses $$ for a literal dollar sign. This keeps JavaScript
  // template literals from being interpreted as Compose variables.
  return content
    .replace(/\$/g, "$$$$")
    .split("\n")
    .map((line) => `${indentation}${line}`)
    .join("\n");
}

const configMounts = sourceFiles
  .map((fileName) => [
    `      - source: ${configName(fileName)}`,
    `        target: /app/${fileName}`,
  ].join("\n"))
  .join("\n");

const configDefinitions = [];
for (const fileName of sourceFiles) {
  const content = await readFile(resolve(serverDirectory, "src", fileName), "utf8");
  configDefinitions.push([
    `  ${configName(fileName)}:`,
    "    content: |",
    indentBlock(content.replace(/\s+$/, ""), 6),
  ].join("\n"));
}

const compose = `services:
  agent:
    image: node:24-alpine
    restart: unless-stopped
    working_dir: /app
    command: ["node", "/app/server.js"]
    environment:
      NODE_ENV: production
      PORT: "3000"
      DATA_FILE: /data/store.json
      TELEGRAM_BOT_TOKEN: \${TELEGRAM_BOT_TOKEN}
      TELEGRAM_WEBHOOK_SECRET: \${TELEGRAM_WEBHOOK_SECRET}
      AI_API_KEY: \${AI_API_KEY}
      AI_BASE_URL: \${AI_BASE_URL}
      AI_MODEL: \${AI_MODEL}
      ADMIN_API_KEY: \${ADMIN_API_KEY}
      PUBLIC_BASE_URL: \${PUBLIC_BASE_URL}
    configs:
${configMounts}
    volumes:
      - agent_data:/data
    expose:
      - "3000"
    networks:
      easypanel:
        aliases:
          - n8n_wp-agent_agent
    healthcheck:
      test: ["CMD", "node", "-e", "fetch('http://127.0.0.1:3000/health').then(r=>{if(!r.ok)process.exit(1)}).catch(()=>process.exit(1))"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s

volumes:
  agent_data:

networks:
  easypanel:
    external: true
    name: easypanel

configs:
${configDefinitions.join("\n")}
`;

await mkdir(outputDirectory, { recursive: true });
await writeFile(outputFile, compose, "utf8");
console.log(`Generated ${outputFile}`);
