<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Source {
    private static $index=null;
    private static $immediate_attempts=0;
    public static function init() {
        add_action('save_post',[__CLASS__,'saved'],20,3);
        add_action('riwaq_source_product',[__CLASS__,'queued'],10,2);
        add_filter('cron_schedules',function($s){$s['riwaq_five_minutes']=['interval'=>300,'display'=>'Riwaq every five minutes'];return $s;});
        add_action('riwaq_source_refresh',[__CLASS__,'cron']);
        add_action('admin_menu',function(){add_submenu_page('riwaq','جلب بيانات المنتجات','جلب بيانات المنتجات','manage_options','riwaq-source',[__CLASS__,'page']);});
        add_action('admin_post_riwaq_source',[__CLASS__,'action']);
        add_action('init',function(){if(get_option('riwaq_source_auto',0)&&!wp_next_scheduled('riwaq_source_refresh')){wp_schedule_event(time()+300,'riwaq_five_minutes','riwaq_source_refresh');}});
    }
    public static function saved($post_id,$post,$update) {
        if(!get_option('riwaq_source_auto',0)||!in_array($post->post_type,['post','page'],true)||wp_is_post_revision($post_id)||wp_is_post_autosave($post_id)||!current_user_can('edit_post',$post_id)||in_array($post->post_status,['trash','auto-draft'],true)){return;}
        if(!preg_match_all('/\[amazon\b([^\]]*)\]/i',$post->post_content,$matches)){return;}
        foreach($matches[1] as $match){$atts=shortcode_parse_atts($match);if(!is_array($atts)){continue;}foreach(explode(',',$atts['box']??$atts['link']??$atts['fields']??'') as $asin){self::ensure($asin,Riwaq_Catalog::settings()['market']);}}
    }
    private static function schedule_product($asin,$market,$delay=10) {
        $args=[$asin,$market];if(!wp_next_scheduled('riwaq_source_product',$args)){wp_schedule_single_event(time()+$delay,'riwaq_source_product',$args);}
    }
    public static function queued($asin,$market) {
        if(!get_option('riwaq_source_auto',0)||self::find($asin,$market)){return;}
        self::ensure($asin,$market);
    }
    public static function ensure($asin,$market) {
        $asin=strtoupper(trim((string)$asin));if(!get_option('riwaq_source_auto',0)||!preg_match('/^[A-Z0-9]{10}$/',$asin)||!isset(Riwaq_Catalog::markets()[$market])||self::find($asin,$market)){return;}
        $failures=(array)get_option('riwaq_source_errors',[]);$error=$failures[$market.'|'.$asin]??[];
        if(!self::retry_due($error)){self::schedule_product($asin,$market,($error['code']??'')==='identity'||in_array((int)($error['status']??0),[404,410],true)?7*DAY_IN_SECONDS:HOUR_IN_SECONDS);return;}
        if(self::$immediate_attempts>=1){self::schedule_product($asin,$market);return;}
        self::$immediate_attempts++;$result=self::import($asin,$market);
        if(is_wp_error($result)){self::schedule_product($asin,$market,in_array($result->get_error_data(),[404,410],true)||$result->get_error_code()==='identity'?7*DAY_IN_SECONDS:HOUR_IN_SECONDS);}
    }
    public static function parse($html,$asin,$market) {
        if(!class_exists('DOMDocument')){return new WP_Error('dom','امتداد DOM غير متاح.');}
        if(preg_match('/<title[^>]*>\s*(?:Amazon\s+)?(?:Robot Check|CAPTCHA)/i',$html)||stripos($html,'/errors/validateCaptcha')!==false){return new WP_Error('blocked','أمازون طلبت تحققًا؛ لم تُستورد بيانات.');}
        $d=new DOMDocument();$previous=libxml_use_internal_errors(true);
        try{$loaded=$d->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET);}finally{libxml_clear_errors();libxml_use_internal_errors($previous);}
        if(!$loaded){return new WP_Error('html','تعذر قراءة الصفحة.');}$x=new DOMXPath($d);
        $node=function($id)use($x){return $x->query('//*[@id="'.$id.'"]')->item(0);};
        $id=$node('ASIN');$title=$node('productTitle');
        $identity=$id?strtoupper(trim($id->getAttribute('value'))):'';
        if($identity===''){$apex=$node('apex_desktop');$canonical=$x->query('//link[@rel="canonical"]')->item(0);$href=$canonical?$canonical->getAttribute('href'):'';$host=strtolower((string)wp_parse_url($href,PHP_URL_HOST));if($apex&&strtoupper($apex->getAttribute('data-csa-c-asin'))===$asin&&in_array($host,['amazon.fr','www.amazon.fr'],true)&&preg_match('#/dp/'.preg_quote($asin,'#').'(?:[/?]|$)#i',$href)){$identity=$asin;}}
        if($identity!==$asin||!$title||trim($title->textContent)===''){return new WP_Error('identity','الصفحة لا تؤكد ASIN المطلوب؛ لم تُستورد بيانات.');}
        $image=$node('landingImage');$url=$image?($image->getAttribute('data-old-hires')?:$image->getAttribute('src')):'';
        $host=strtolower((string)wp_parse_url($url,PHP_URL_HOST));
        if(!preg_match('/(?:^|\.)(?:media-amazon\.com|ssl-images-amazon\.com)$/',$host)){$url='';}
        $rating=$node('acrPopover');$ratingText=$rating?($rating->getAttribute('title')?:$rating->textContent):'';
        $score='';if(preg_match('/([0-5](?:[.,]\d+)?)\s+(?:sur|out of|von|de)\s+5/iu',$ratingText,$m)){$score=str_replace(',','.',$m[1]);}
        $reviews=$node('acrCustomerReviewText');$count=0;
        if($reviews&&preg_match('/[0-9][0-9\s\x{00a0}\x{202f}.,]*/u',$reviews->textContent,$m)){$count=(int)preg_replace('/\D/','',$m[0]);}
        $features=[];foreach($x->query('//*[@id="feature-bullets"]//li//span[contains(concat(" ",normalize-space(@class)," ")," a-list-item ")]') as $n){$text=sanitize_text_field($n->textContent);if($text!==''&&strlen($text)<1500){$features[]=$text;}if(count($features)>=6){break;}}
        $data=Riwaq_Catalog::clean(['asin'=>$asin,'market'=>$market,'image'=>$url,'rating'=>$score,'rating_label'=>Riwaq_Catalog::markets()[$market],'review_count'=>$count,'features'=>implode("\n",$features)]);
        if(!$data['image']){return new WP_Error('image','الصورة الأساسية غير متاحة؛ لم تُستورد الصفحة.');}
        $price='';$price_from=false;
        if($market==='FR'){
            foreach(['corePriceDisplay_desktop_feature_div','corePrice_feature_div','apex_desktop','desktop_buybox','dynamic-aod-ingress-box'] as $root){
                $nodes=$x->query('//*[@id="'.$root.'"]//span[contains(concat(" ",normalize-space(@class)," ")," a-price ") and not(contains(concat(" ",normalize-space(@class)," ")," a-text-price "))]//span[contains(concat(" ",normalize-space(@class)," ")," a-offscreen ")]');
                foreach($nodes as $n){$text=trim(preg_replace('/[\s\x{00a0}\x{202f}]+/u','',$n->textContent));if(preg_match('/^(\d{1,9}),([0-9]{2})€$/u',$text,$m)&&((float)($m[1].'.'.$m[2]))>0){$price=$m[1].'.'.$m[2];$price_from=$root==='dynamic-aod-ingress-box';break 2;}}
            }
        }
        return ['title'=>sanitize_text_field($title->textContent),'data'=>$data,'has_rating'=>$score!=='','has_review_count'=>$reviews!==null,'price'=>$price,'price_from'=>$price_from,'currency'=>$market==='FR'?'EUR':''];
    }
    public static function fetch($asin,$market) {
        $asin=strtoupper(trim((string)$asin));
        if(!preg_match('/^[A-Z0-9]{10}$/',$asin)||!isset(Riwaq_Catalog::markets()[$market])){return new WP_Error('input','ASIN أو متجر غير صالح.');}
        $url='https://www.'.Riwaq_Catalog::markets()[$market].'/dp/'.$asin.'/';
        $r=wp_safe_remote_get($url,['timeout'=>15,'redirection'=>3,'limit_response_size'=>2000000]);
        if(is_wp_error($r)){return $r;}$status=wp_remote_retrieve_response_code($r);
        if($status!==200){return new WP_Error('http','أمازون أعادت HTTP '.$status.'.',$status);}
        return self::parse(wp_remote_retrieve_body($r),$asin,$market);
    }
    public static function find($asin,$market) {
        if(self::$index===null){self::$index=[];foreach(get_posts(['post_type'=>'riwaq_product','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>-1,'fields'=>'ids']) as $id){$d=(array)get_post_meta($id,'_riwaq_data',true);self::$index[($d['market']??'').'|'.($d['asin']??'')]=$id;}}
        return self::$index[$market.'|'.$asin]??0;
    }
    public static function import($asin,$market,$html=null) {
        if($html!==null && (!current_user_can('manage_options')||!is_string($html)||strlen($html)>2000000)){return new WP_Error('snapshot','استيراد نسخة الصفحة يتطلب صلاحيات المدير وبيانات صالحة.');}
        $key=$market.'|'.$asin;$lock='riwaq_fetch_'.md5($key);$at=get_option($lock,0);
        if($at&&time()-(int)$at>120){delete_option($lock);}if(!add_option($lock,time(),'','no')){return new WP_Error('busy','الجلب قيد التنفيذ.');}
        try{
            $parsed=$html===null?self::fetch($asin,$market):self::parse($html,$asin,$market);$errors=(array)get_option('riwaq_source_errors',[]);
            if(is_wp_error($parsed)){$errors[$key]=['at'=>time(),'message'=>$parsed->get_error_message(),'code'=>$parsed->get_error_code(),'status'=>is_int($parsed->get_error_data())?$parsed->get_error_data():0];update_option('riwaq_source_errors',array_slice($errors,-1000,null,true),false);return $parsed;}
            $id=self::find($asin,$market);$created=false;
            if($id){
                $source=(array)get_post_meta($id,'_riwaq_source',true);
                if(!empty($source['paused'])){return new WP_Error('manual','تم إيقاف التحديث بعد تعديل المنتج يدويًا.');}
                $data=Riwaq_Catalog::clean((array)get_post_meta($id,'_riwaq_data',true));
                // Existing manually maintained products must explicitly opt into this source.
                if(!$source&&empty(get_post_meta($id,'_riwaq_seed',true))){return new WP_Error('manual','منتج يدوي؛ لا يستبدله الجلب التلقائي.');}
                $data=array_merge($data,array_intersect_key($parsed['data'],array_flip(['image','rating','rating_label','review_count','features'])));
            }else{$data=$parsed['data'];$id=wp_insert_post(wp_slash(['post_type'=>'riwaq_product','post_status'=>'publish','post_title'=>$parsed['title']]),true);if(is_wp_error($id)||!$id){return new WP_Error('save','تعذر إنشاء المنتج.');}$created=true;}
            update_post_meta($id,'_riwaq_data',wp_slash($data));
            if(get_post_meta($id,'_riwaq_data',true)!==$data){if($created){wp_delete_post($id,true);}return new WP_Error('save','تعذر حفظ بيانات المنتج.');}
            update_post_meta($id,'_riwaq_source',['kind'=>'amazon_page','checked'=>time(),'has_rating'=>$parsed['has_rating'],'has_review_count'=>$parsed['has_review_count'],'price'=>$parsed['price'],'price_from'=>$parsed['price_from'],'currency'=>$parsed['currency'],'paused'=>0]);
            if(self::$index!==null){self::$index[$key]=$id;}
            unset($errors[$key]);update_option('riwaq_source_errors',$errors,false);return ['id'=>$id,'asin'=>$asin,'image'=>!empty($data['image']),'rating'=>$data['rating'],'reviews'=>$data['review_count'],'status'=>get_post_status($id)];
        }finally{delete_option($lock);}
    }
    public static function candidates() {
        $market=Riwaq_Catalog::settings()['market'];$found=[];
        foreach(Riwaq_Compatibility::scan() as $row){if(get_post_status($row['post'])!=='publish'){continue;}preg_match_all('/\b(?:box|link|fields)\s*=\s*["\x27]([^"\x27]+)["\x27]/i',$row['code'],$m);foreach($m[1] as $value){foreach(explode(',',$value) as $asin){$asin=strtoupper(trim($asin));if(preg_match('/^[A-Z0-9]{10}$/',$asin)){$found[$asin]=['asin'=>$asin,'market'=>$market,'checked'=>0];}}}}
        foreach($found as &$item){$id=self::find($item['asin'],$market);if($id){$source=(array)get_post_meta($id,'_riwaq_source',true);if(!$source||!empty($source['paused'])){$item['skip']=true;}else{$item['checked']=(int)($source['checked']??0);}}}unset($item);
        $errors=(array)get_option('riwaq_source_errors',[]);
        $found=array_values(array_filter($found,function($v)use($errors){return empty($v['skip'])&&time()-$v['checked']>DAY_IN_SECONDS&&self::retry_due($errors[$v['market'].'|'.$v['asin']]??[]);}));
        usort($found,fn($a,$b)=>$a['checked']<=>$b['checked']);return $found;
    }
    public static function retry_due($error){
        $permanent=($error['code']??'')==='identity'||in_array((int)($error['status']??0),[404,410],true)||str_contains($error['message']??'','HTTP 404')||str_contains($error['message']??'','لا تؤكد ASIN');
        return time()-(int)($error['at']??0)>($permanent?7*DAY_IN_SECONDS:HOUR_IN_SECONDS);
    }
    public static function cron() {if(!get_option('riwaq_source_auto',0)){return;}$start=microtime(true);foreach(array_slice(self::candidates(),0,3) as $item){if(microtime(true)-$start>12){break;}self::import($item['asin'],$item['market']);}}
    public static function action() {
        if(!current_user_can('manage_options')){wp_die('غير مصرح','',['response'=>403]);}check_admin_referer('riwaq_source');
        if(isset($_POST['save_auto'])){update_option('riwaq_source_auto',empty($_POST['auto'])?0:1);if(empty($_POST['auto'])){wp_clear_scheduled_hook('riwaq_source_refresh');}$message='حُفظ خيار التحديث.';}
        else{$results=[];foreach(array_slice(self::candidates(),0,1) as $item){$r=self::import($item['asin'],$item['market']);$results[]=$item['asin'].': '.(is_wp_error($r)?$r->get_error_message():'تم الجلب');}$message=$results?implode('؛ ',$results):'لا توجد منتجات مستحقة الآن.';}
        set_transient('riwaq_source_notice_'.get_current_user_id(),$message,120);wp_safe_redirect(admin_url('admin.php?page=riwaq-source'));exit;
    }
    public static function page() {
        if(!current_user_can('manage_options')){return;}echo '<div class="wrap rw-admin" dir="rtl"><h1>جلب بيانات صفحات أمازون</h1><section class="rw-panel"><p>يقرأ صفحات المنتجات العامة دون API: العنوان والصورة والتقييم وعدد التقييمات ومميزات المنتج. يجلب سعر العرض الظاهر لمنتجات Amazon.fr عند توفره؛ يعود إلى عبارة السعر الحالي عند غيابه أو قدمه. قد تحجب أمازون الطلبات أو تغيّر بنية الصفحة. لا يجري تجاوز أي تحقق. قد تختلف بيانات التقييم بين المتاجر.</p><p>الجلب ينشئ منتجًا منشورًا عند نجاح التحقق من ASIN والصورة. يجمع أكواد المقالات المنشورة فقط، ويترك المنتجات اليدوية والمسودات الموجودة دون استبدال. التحديث الدوري يجلب حتى 3 منتجات كل 5 دقائق، ضمن مهلة زمنية قصيرة، ويعيد مراجعة المنتجات بعد 24 ساعة عبر WP-Cron.</p>';
        $notice=get_transient('riwaq_source_notice_'.get_current_user_id());if($notice){delete_transient('riwaq_source_notice_'.get_current_user_id());echo '<p role="status">'.esc_html($notice).'</p>';}
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="riwaq_source">';wp_nonce_field('riwaq_source');echo '<label><input name="auto" type="checkbox" value="1" '.checked(get_option('riwaq_source_auto',0),1,false).'> تفعيل الجلب والتحديث الدوري</label>';submit_button('حفظ التحديث الدوري','secondary','save_auto');submit_button('جلب المنتج التالي الآن');echo '</form>';
        $errors=(array)get_option('riwaq_source_errors',[]);if($errors){echo '<h2>آخر حالات فشل الجلب</h2><ul>';foreach(array_slice($errors,-10,null,true) as $key=>$error){echo '<li>'.esc_html($key.' — '.($error['message']??'')).'</li>';}echo '</ul>';}
        $job=(array)get_option('riwaq_bulk_job',[]);if($job){echo '<h2>نتيجة الفحص الشامل للموقع</h2><p>'.esc_html('مقالات: '.absint($job['posts']??0).'؛ منتجات مختلفة: '.absint($job['total_products']??0).'؛ فُحص: '.absint($job['index']??0).' من '.count((array)($job['queue']??[])).'؛ جُلب بنجاح: '.(absint($job['ready']??0)+absint($job['success']??0)).'؛ فشل الجلب: '.count((array)($job['failures']??[]))).'</p><p>الروابط القديمة التي تعيد 404 أو تتحول إلى ASIN مختلف تحتاج مراجعة؛ لا نستبدلها تلقائيًا بمنتج آخر.</p>';}
        echo '<p>تظهر التقييمات المجلوبة مع تاريخ القراءة. إذا مضى 7 أيام دون تحديث تختفي التقييمات وعددها. تعديل بيانات المنتج يدويًا يوقف تحديثه التلقائي حتى لا يستبدل عملك. الإيقاف لا يحذف البيانات المجلوبة.</p></section></div>';
    }
}
