<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Render {
    public static function register() {
        add_shortcode('riwaq', [__CLASS__, 'shortcode']);
        wp_register_style('riwaq', RIWAQ_URL . 'assets/frontend.css', [], RIWAQ_VERSION);
        wp_register_script('riwaq-track', RIWAQ_URL . 'assets/tracking.js', [], RIWAQ_VERSION, true);
        wp_register_script('riwaq-markets', RIWAQ_URL . 'assets/markets.js', [], RIWAQ_VERSION, true);
        wp_register_script('riwaq-editor', RIWAQ_URL . 'block/editor.js', ['wp-blocks','wp-element','wp-components','wp-block-editor','wp-server-side-render'], RIWAQ_VERSION, true);
        register_block_type(RIWAQ_PATH . 'block', ['render_callback'=>function ($a) { return self::shortcode($a); }]);
        // A small stylesheet loaded in the head also supports widgets and template shortcodes.
        add_action('wp_enqueue_scripts', function () { wp_enqueue_style('riwaq'); });
    }
    public static function shortcode($atts) {
        $a = shortcode_atts(['ids'=>'','collection'=>'','category'=>'','layout'=>'box','columns'=>3,'limit'=>20,'order'=>'manual','orderby'=>'','direction'=>'ASC','title'=>'','field'=>'','label'=>'','search'=>'','min_price'=>'','max_price'=>'','currency'=>'','prime'=>'','available'=>'','style'=>'','language'=>'','button_text'=>'','button'=>'','description_items'=>6,'product_title'=>'','description'=>'','image'=>'','rows'=>'','highlight'=>0,'template'=>'','select'=>'','rating'=>'','star_rating'=>'','reviews'=>''], $atts, 'riwaq');
        if ($a['collection']) {
            $c = get_post(absint($a['collection']));
            if (!$c || $c->post_type !== 'riwaq_collection' || $c->post_status !== 'publish' || $c->post_password !== '') { return ''; }
            $data = (array)get_post_meta($c->ID, '_riwaq_collection', true);
            $a = array_merge($a, array_intersect_key($data, array_flip(['ids','layout','columns'])), ['title'=>$c->post_title]);
            $table = (array)get_post_meta($c->ID,'_riwaq_table',true);
            $a['rows'] = $table['rows'] ?? $a['rows']; $a['highlight'] = $table['highlight'] ?? $a['highlight'];
        }
        $layout = in_array($a['layout'], ['box','grid','list','table','link','field'], true) ? $a['layout'] : 'box';
        $ids = Riwaq_Catalog::ids($a['ids']);
        if (!$ids && ($a['category'] || $a['search'])) {
            // Filter/sort the whole matching catalog before applying the display limit.
            $q = ['post_type'=>'riwaq_product','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','orderby'=>['menu_order'=>'ASC','ID'=>'DESC']];
            if ($a['category']) { $q['tax_query'] = [['taxonomy'=>'riwaq_category','field'=>'slug','terms'=>sanitize_title($a['category'])]]; }
            $ids = get_posts($q);
        }
        $products = array_values(array_filter(array_map(['Riwaq_Catalog','product'], $ids)));
        $products = self::filter_sort($products, $a);
        if (!$products) { return ''; }
        $s = Riwaq_Catalog::settings();
        $a['language'] = in_array($a['language'], ['ar','fr','en'],true) ? $a['language'] : $s['language'];
        $a['style'] = in_array($a['style'], ['clean','dark','compact'],true) ? $a['style'] : $s['style'];
        foreach ($products as &$p) {
            if ($a['product_title']) { $p['title'] = sanitize_text_field($a['product_title']); }
            if ($a['description']) { $p['features'] = sanitize_textarea_field($a['description']); }
            if ($a['image']) {
                $images = array_filter(explode("\n",$p['images']));
                $p['image'] = ctype_digit((string)$a['image']) ? ($images[max(0,(int)$a['image']-1)] ?? $p['image']) : esc_url_raw($a['image'],['https']);
            }
            if ($a['rating'] !== '' && is_numeric($a['rating'])) { $p['rating'] = (string)max(0,min(5,(float)$a['rating'])); $p['source_checked']=0; $p['rating_label']=Riwaq_Display::text('editor',$a['language']); }
        }
        unset($p);
        if ($s['tracking']) {
            wp_enqueue_script('riwaq-track');
            wp_localize_script('riwaq-track', 'riwaqTracking', ['url'=>admin_url('admin-ajax.php')]);
        }
        if ($layout === 'field') {
            $p = $products[0];
            if ($a['field'] === 'price') { return esc_html(Riwaq_Catalog::price($p)); }
            if ($a['field'] === 'button') { return self::link($p,Riwaq_Display::button($p,$a)); }
            if ($a['field'] === 'image') { return self::link($p,self::picture($p),'image',true); }
            if ($a['field'] === 'url') { return esc_url(Riwaq_Catalog::url($p)); }
            if ($a['field'] === 'rating') { return self::rating($p,$a); }
            return in_array($a['field'], ['title','asin','currency','features','review_count'], true) ? esc_html($p[$a['field']]) : '';
        }
        if ($layout === 'link') { return self::link($products[0], $a['label'] ?: $products[0]['title'], 'text'); }
        $cols = max(1,min(4,absint($a['columns'])));
        $html = '<section dir="'.($a['language']==='ar'?'rtl':'ltr').'" lang="'.esc_attr($a['language']).'" class="riwaq riwaq--'.esc_attr($layout).' riwaq--'.esc_attr($a['style']).'" style="--riwaq-accent:'.esc_attr($s['color']).';--riwaq-info:'.esc_attr($s['info_color']).';--riwaq-cols:'.$cols.'" aria-label="'.esc_attr($a['title'] ?: Riwaq_Display::text('comparison',$a['language'])).'">';
        if ($a['title']) { $html .= '<h2 class="riwaq__heading">'.esc_html($a['title']).'</h2>'; }
        if ($layout === 'table') { $html .= self::table($products,$a); }
        else {
            $html .= '<div class="riwaq__items">';
            foreach ($products as $i=>$p) {
                $card = self::card($p, $layout === 'list' ? $i + 1 : 0, $a);
                if ($a['template']) {
                    // PHP templates must live in the active theme, never in uploaded CSV/JSON.
                    $name = sanitize_file_name($a['template']);
                    $path = $name === $a['template'] && preg_match('/^[a-zA-Z0-9_-]+$/',$name) ? locate_template('riwaq/'.$name.'.php') : '';
                    if ($path) { ob_start(); $product=$p; $attributes=$a; $default_html=$card; include $path; $card=ob_get_clean(); }
                }
                $html .= apply_filters('riwaq_card_html',$card,$p,$a);
            }
            $html .= '</div>';
        }
        $html .= '</section>';
        return apply_filters('riwaq_output_html',$html,$products,$a);
    }
    public static function link($p, $label, $element = 'button', $html = false) {
        $url = Riwaq_Catalog::url($p);
        if (!$url) { return '<span class="riwaq__unavailable">'.esc_html(Riwaq_Display::text('unavailable')).'</span>'; }
        $s = Riwaq_Catalog::settings();
        $attrs = '';
        if ($s['market_selector']) {
            wp_enqueue_script('riwaq-markets');
            wp_localize_script('riwaq-markets','riwaqMarkets',['url'=>admin_url('admin-ajax.php')]);
            $attrs .= ' data-riwaq-market-links="'.esc_attr(wp_json_encode(Riwaq_Display::maps($p))).'" data-riwaq-original-market="'.esc_attr($p['market']).'"';
        }
        if ($s['tracking']) {
            $token = hash_hmac('sha256', $p['id'].'|'.$element, wp_salt('nonce'));
            $attrs .= ' data-riwaq-id="'.absint($p['id']).'" data-riwaq-element="'.esc_attr($element).'" data-riwaq-token="'.esc_attr($token).'"';
        }
        return '<a class="riwaq__'.esc_attr($element).'" href="'.esc_url($url).'" rel="sponsored nofollow noopener"'.($element==='image' ? ' aria-label="'.esc_attr($p['title']).'"' : '').($s['new_tab'] ? ' target="_blank"' : '').$attrs.'>'.($html ? $label : esc_html($label)).'</a>';
    }
    private static function picture($p) {
        if (!$p['image']) { return '<span class="riwaq__placeholder" aria-hidden="true">◇</span>'; }
        return '<img src="'.esc_url($p['image']).'" alt="'.esc_attr($p['title']).'" loading="lazy" decoding="async" width="240" height="240">';
    }
    private static function price($p, $a = []) {
        $lang = $a['language'] ?? '';
        $price = Riwaq_Catalog::price($p);
        $h = '<div class="riwaq__price-data" data-market="'.esc_attr($p['market']).'">';
        if ($price === '') { return $h.'<p class="riwaq__price-note">'.esc_html(Riwaq_Display::text('current',$lang)).'</p></div>'; }
        $h .= '<div class="riwaq__price"><span class="riwaq__price-amount">'.esc_html(number_format_i18n((float)$p['price'],2)).'</span><span class="riwaq__price-currency">'.esc_html($p['currency']==='EUR'?'€':$p['currency']).'</span></div>';
        if ($p['list_price'] !== '' && (float)$p['list_price'] > (float)$p['price']) {
            $percent = round((1-(float)$p['price']/(float)$p['list_price'])*100);
            $h .= '<div class="riwaq__discount"><del>'.esc_html(number_format_i18n((float)$p['list_price'],2).' '.$p['currency']).'</del> · '.esc_html(Riwaq_Display::text('saved',$lang).' '.$percent.'%').'</div>';
        }
        if(!empty($p['source_price'])){return $h.'<small class="riwaq__updated">'.esc_html(Riwaq_Display::text('change',$lang)).'</small></div>';}
        return $h.'<small class="riwaq__updated">'.esc_html(Riwaq_Display::text('manual',$lang)).' · '.esc_html(wp_date(get_option('date_format'), $p['verified'])).'<br>'.esc_html(Riwaq_Display::text('change',$lang)).'</small></div>';
    }
    private static function card($p, $rank, $a) {
        $h = '<article class="riwaq__card" data-riwaq-product="'.absint($p['id']).'">';
        if ($rank) { $h .= '<span class="riwaq__rank">'.(int)$rank.'</span>'; }
        $h .= '<div class="riwaq__visual">'.self::link($p,self::picture($p),'image',true).'</div><div class="riwaq__body">';
        if ($p['badge']) { $h .= '<span class="riwaq__badge">'.esc_html($p['badge']).'</span>'; }
        $h .= '<h3 class="riwaq__title">'.self::link($p,$p['title'],'title').'</h3>';
        $h .= self::rating($p,$a);
        $features = $p['market']==='FR' ? [] : array_slice(array_filter(array_map('trim', explode("\n", $p['features']))),0,max(0,min(10,absint($a['description_items']))));
        if ($features) { $h .= '<ul class="riwaq__features">'; foreach ($features as $f) { $h .= '<li>'.esc_html($f).'</li>'; } $h .= '</ul>'; }
        $h .= '</div><div class="riwaq__buy">'.self::price($p,$a);
        if ($p['prime'] || $p['availability'] !== 'unknown') {
            $h .= '<small class="riwaq__facts" data-market="'.esc_attr($p['market']).'">'.esc_html(($p['prime'] ? Riwaq_Display::text('prime',$a['language']).' · ' : '').($p['availability']==='unknown'?'':Riwaq_Display::text($p['availability']==='available'?'available':'out',$a['language']))).'</small>';
        }
        if ($a['button'] !== 'none') { $h .= self::link($p,Riwaq_Display::button($p,$a)); }
        if ($p['detail_url']) { $h .= '<a class="riwaq__detail" href="'.esc_url($p['detail_url']).'">'.esc_html(Riwaq_Display::text('details',$a['language'])).'</a>'; }
        $h .= self::selector($p,$a).($p['market']==='FR'?'':'<small class="riwaq__market">Amazon · '.esc_html($p['market']).'</small>').'</div></article>';
        return $h;
    }
    private static function table($products,$a) {
        $keys = [];
        foreach ($products as $p) { $keys = array_unique(array_merge($keys,array_keys(Riwaq_Catalog::specs($p['specs'])))); }
        if ($a['rows']) { $keys = array_slice(array_values(array_filter(array_map('trim',explode("\n",$a['rows'])))),0,30); }
        $lang = $a['language'];
        $h = '<div class="riwaq__scroll" tabindex="0" role="region" aria-label="'.esc_attr(Riwaq_Display::text('scroll',$lang)).'"><table class="riwaq__table"><caption class="screen-reader-text">'.esc_html(Riwaq_Display::text('comparison',$lang)).'</caption><colgroup><col>';
        foreach ($products as $p) { $h .= '<col'.(absint($a['highlight'])===$p['id']?' class="riwaq__highlight"':'').'>'; }
        $h .= '</colgroup><thead><tr><th scope="col">'.esc_html(Riwaq_Display::text('product',$lang)).'</th>';
        foreach ($products as $p) {
            $h .= '<th scope="col" data-riwaq-product="'.absint($p['id']).'"><div class="riwaq__table-image">'.self::link($p,self::picture($p),'image',true).'</div>'.($p['badge'] ? '<span class="riwaq__badge">'.esc_html($p['badge']).'</span>' : '').'<div>'.self::link($p,$p['title'],'title').'</div></th>';
        }
        $h .= '</tr></thead><tbody><tr><th scope="row">'.esc_html(Riwaq_Display::text('price',$lang)).'</th>';
        foreach ($products as $p) { $h .= '<td data-riwaq-product="'.absint($p['id']).'">'.self::price($p,$a).'</td>'; }
        $h .= '</tr>';
        if ($a['star_rating'] !== 'none') {
            $h .= '<tr><th scope="row">'.esc_html(Riwaq_Display::text('rating',$lang)).'</th>';
            foreach ($products as $p) { $h .= '<td>'.(self::rating($p,$a) ?: '—').'</td>'; }
            $h .= '</tr>';
        }
        foreach (array_slice($keys,0,30) as $key) {
            $h .= '<tr><th scope="row">'.esc_html($key).'</th>';
            foreach ($products as $p) { $spec = Riwaq_Catalog::specs($p['specs']); $h .= '<td>'.esc_html($spec[$key] ?? '—').'</td>'; }
            $h .= '</tr>';
        }
        $h .= '<tr><th scope="row">'.esc_html(Riwaq_Display::text('purchase',$lang)).'</th>';
        foreach ($products as $p) { $h .= '<td data-riwaq-product="'.absint($p['id']).'">'.($a['button']==='none'?'':self::link($p,Riwaq_Display::button($p,$a))).self::selector($p,$a).'</td>'; }
        return $h.'</tr></tbody></table></div>';
    }
    private static function rating($p,$a) {
        if ($p['rating'] === '' || ($a['star_rating']??'')==='none') { return ''; }
        $label = $p['rating_label'] ?: Riwaq_Display::text('rating',$a['language']??'');
        if ($label==='تقييم المحرر') { $label=Riwaq_Display::text('editor',$a['language']??''); }
        $h='<div class="riwaq__rating" aria-label="'.esc_attr($label.' '.$p['rating'].' / 5').'"><span class="riwaq__stars" aria-hidden="true">';
        for ($i=1;$i<=5;$i++) { $h.='<span class="'.($i<=(float)$p['rating']?'is-filled':'').'">★</span>'; }
        $h.='</span> <strong>'.esc_html($p['rating']).'/5</strong>';
        if($p['market']!=='FR' || !preg_match('/^(?:www\.)?amazon\.fr$/i',$label)){$h.='<small>'.esc_html($label).'</small>';}
        if ($p['review_count'] && ($a['reviews']??'')!=='none') {
            $count_label=!empty($p['source_checked']) ? (($a['language']??'')==='fr'?'évaluations Amazon':(($a['language']??'')==='ar'?'تقييمات أمازون':'Amazon ratings')) : Riwaq_Display::text('review_count',$a['language']??'');
            $h.='<span class="riwaq__review-count"><strong>'.esc_html(number_format_i18n($p['review_count'])).'</strong><span>'.esc_html($count_label).'</span></span>';
        }
        if($p['market']!=='FR' && !empty($p['source_checked'])){$h.='<small>'.esc_html((($a['language']??'')==='fr'?'Consulté le ': (($a['language']??'')==='ar'?'آخر جلب: ':'Fetched: ')).wp_date(get_option('date_format'),$p['source_checked'])).'</small>';}
        return $h.'</div>';
    }
    private static function selector($p,$a) {
        if (!Riwaq_Catalog::settings()['market_selector'] || count(Riwaq_Display::maps($p))<2) { return ''; }
        $h='<label class="riwaq__store-label">'.esc_html(Riwaq_Display::text('choose',$a['language'])).'<select class="riwaq__store" data-product="'.absint($p['id']).'">';
        foreach (Riwaq_Display::maps($p) as $market=>$url) { $h.='<option value="'.esc_attr($market).'" '.selected($p['market'],$market,false).'>'.esc_html($market).'</option>'; }
        return $h.'</select></label>';
    }
    public static function filter_sort($products,$a) {
        $products=array_values(array_filter($products,function ($p) use ($a) {
            if ($a['search']) {
                $text=$p['title'].' '.$p['keywords'].' '.$p['features'];
                $found=function_exists('mb_stripos') ? mb_stripos($text,(string)$a['search']) : stripos($text,(string)$a['search']);
                if ($found===false) { return false; }
            }
            if ($a['currency'] && strtoupper($a['currency'])!==$p['currency']) { return false; }
            if ($a['prime']==='1' && !$p['prime']) { return false; }
            if ($a['available']==='1' && $p['availability']!=='available') { return false; }
            if ($a['order']==='release' && !$p['release_date']) { return false; }
            if ($a['min_price']!=='' || $a['max_price']!=='') {
                if (Riwaq_Catalog::price($p)==='') { return false; }
                if ($a['min_price']!=='' && (float)$p['price']<(float)$a['min_price']) { return false; }
                if ($a['max_price']!=='' && (float)$p['price']>(float)$a['max_price']) { return false; }
            }
            return true;
        }));
        $sort=$a['orderby'] ?: ($a['order']==='newest'?'published':($a['order']==='release'?'release_date':''));
        if (in_array($sort,['price','title','rating','rank','published','release_date','amount_saved','percentage_saved'],true)) {
            $value=function($p) use($sort) {
                if ($sort==='price') { return Riwaq_Catalog::price($p)==='' ? null : (float)$p['price']; }
                if (in_array($sort,['amount_saved','percentage_saved'],true)) { return Riwaq_Catalog::price($p)!=='' && (float)$p['list_price']>(float)$p['price'] ? ($sort==='amount_saved'?(float)$p['list_price']-(float)$p['price']:(1-(float)$p['price']/(float)$p['list_price'])*100) : null; }
                return in_array($sort,['rating','rank'],true) ? ($p[$sort]===''?null:(float)$p[$sort]) : $p[$sort];
            };
            $desc=strtoupper($a['direction'])==='DESC' || in_array($a['order'],['newest','release'],true);
            usort($products,function($x,$y) use($value,$desc) { $vx=$value($x);$vy=$value($y);if($vx===null){return $vy===null?0:1;}if($vy===null){return -1;}return ($vx<=>$vy)*($desc?-1:1); });
        }
        if ($a['select'] && preg_match('/^(\d+)(?:-(\d+))?$/',(string)$a['select'],$m)) {
            $start=max(1,(int)$m[1]); $end=max($start,(int)($m[2]??$start)); $products=array_slice($products,$start-1,$end-$start+1);
        }
        return array_slice($products,0,max(1,min(20,absint($a['limit']))));
    }
}
