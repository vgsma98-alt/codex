<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Backup {
    public static function init() {
        add_action('admin_menu',function(){add_submenu_page('riwaq','نسخة كتالوج كاملة','نسخة كتالوج كاملة','manage_options','riwaq-backup',[__CLASS__,'page']);});
        add_action('admin_post_riwaq_backup',[__CLASS__,'download']);
        add_action('admin_post_riwaq_restore',[__CLASS__,'upload']);
    }
    private static function guard($action) {
        if (!current_user_can('manage_options')) { wp_die('غير مصرح','',['response'=>403]); }
        check_admin_referer($action);
    }
    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap rw-admin" dir="rtl"><h1>نسخة كتالوج كاملة</h1><section class="rw-panel"><p>ينقل JSON منتجات رواق وفئاتها ومجموعاتها وصفوف المقارنة وروابط جداول AAWP. لا يحتوي على مفاتيح API أو نقرات أو إعدادات عامة. الاستعادة تنشئ مسودات جديدة وتعاد مطابقة معرّفات المنتجات داخل مجموعات المقارنة؛ لا تُستبدل البيانات الموجودة.</p>';
        $notice=get_transient('riwaq_restore_'.get_current_user_id());
        if($notice){delete_transient('riwaq_restore_'.get_current_user_id());echo '<p role="status">'.esc_html($notice).'</p>';}
        foreach (['riwaq_backup'=>'تنزيل نسخة JSON','riwaq_restore'=>'استعادة إلى مسودات جديدة'] as $action=>$label) {
            echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post" enctype="multipart/form-data"><input type="hidden" name="action" value="'.esc_attr($action).'">';wp_nonce_field($action);
            if($action==='riwaq_restore'){echo '<label for="rw-json">ملف JSON، حتى 5 ميغابايت و500 منتج و100 مجموعة</label><input id="rw-json" type="file" name="backup" accept=".json,application/json" required>';}
            submit_button($label,$action==='riwaq_backup'?'secondary':'primary');echo '</form>';
        }
        echo '<p>هذه نسخة كتالوج رواق؛ ليست مستوردًا لملفات AAWP ولا نسخة احتياطية لووردبريس. يُلغى التحقق من الأسعار عند الاستعادة حتى تراجعها.</p></section></div>';
    }
    public static function snapshot() {
        $out=['format'=>'riwaq-catalog','version'=>2,'products'=>[],'collections'=>[]];
        foreach(get_posts(['post_type'=>'riwaq_product','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC']) as $post){
            $cats=wp_get_object_terms($post->ID,'riwaq_category',['fields'=>'names']);
            $out['products'][]=['id'=>$post->ID,'title'=>$post->post_title,'data'=>Riwaq_Catalog::clean((array)get_post_meta($post->ID,'_riwaq_data',true)),'categories'=>is_wp_error($cats)?[]:$cats];
        }
        foreach(get_posts(['post_type'=>'riwaq_collection','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC']) as $post){
            $out['collections'][]=['title'=>$post->post_title,'data'=>(array)get_post_meta($post->ID,'_riwaq_collection',true),'table'=>(array)get_post_meta($post->ID,'_riwaq_table',true)];
        }
        return $out;
    }
    public static function download() {
        self::guard('riwaq_backup');nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="riwaq-catalog.json"');
        echo wp_json_encode(self::snapshot(),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);exit;
    }
    public static function validate($r) {
        if(!is_array($r) || ($r['format']??'')!=='riwaq-catalog' || ($r['version']??0)!==2 || !isset($r['products'],$r['collections']) || !is_array($r['products']) || !is_array($r['collections']) || count($r['products'])>500 || count($r['collections'])>100){return new WP_Error('format','ملف غير صالح أو يتجاوز حدود الاستعادة.');}
        $seen=[];
        foreach($r['products'] as $p){
            if(!is_array($p) || !isset($p['id'],$p['title'],$p['data'],$p['categories']) || !is_scalar($p['id']) || !absint($p['id']) || isset($seen[absint($p['id'])]) || !is_string($p['title']) || trim($p['title'])==='' || !is_array($p['data']) || !is_array($p['categories']) || count($p['categories'])>30){return new WP_Error('format','منتج غير صالح في الملف.');}
            foreach($p['categories'] as $cat){if(!is_string($cat)){return new WP_Error('format','فئة غير صالحة.');}}
            $seen[absint($p['id'])]=true;
        }
        foreach($r['collections'] as $c){
            if(!is_array($c) || !isset($c['title'],$c['data'],$c['table']) || !is_string($c['title']) || !is_array($c['data']) || !is_array($c['table']) || !is_string($c['data']['ids']??'')){return new WP_Error('format','مجموعة غير صالحة.');}
            foreach(Riwaq_Catalog::ids($c['data']['ids']) as $id){if(!isset($seen[$id])){return new WP_Error('format','مجموعة تشير إلى منتج غير موجود في النسخة.');}}
        }
        return true;
    }
    public static function restore($r) {
        $valid=self::validate($r);if(is_wp_error($valid)){return $valid;}
        $lock=get_option('riwaq_restore_lock',0);if($lock && time()-(int)$lock>300){delete_option('riwaq_restore_lock');}
        if(!add_option('riwaq_restore_lock',time(),'','no')){return new WP_Error('locked','استعادة أخرى قيد التنفيذ.');}
        $map=[];$created=[];
        try{
            foreach($r['products'] as $p){
                $d=Riwaq_Catalog::clean($p['data']);$d['verified']=0;
                $id=wp_insert_post(wp_slash(['post_type'=>'riwaq_product','post_title'=>sanitize_text_field($p['title']),'post_status'=>'draft','menu_order'=>$d['rank']]),true);
                if(is_wp_error($id)||!$id){throw new RuntimeException('تعذر إنشاء منتج.');}$created[]=$id;
                if(!update_post_meta($id,'_riwaq_data',wp_slash($d))){throw new RuntimeException('تعذر حفظ بيانات منتج.');}
                $terms=[];foreach($p['categories'] as $cat){$cat=sanitize_text_field($cat);$term=term_exists($cat,'riwaq_category');if(!$term){$term=wp_insert_term($cat,'riwaq_category');}if(is_wp_error($term)){throw new RuntimeException('تعذر حفظ فئة.');}$terms[]=(int)(is_array($term)?$term['term_id']:$term);}
                $assigned=wp_set_object_terms($id,$terms,'riwaq_category');if(is_wp_error($assigned)){throw new RuntimeException('تعذر ربط فئات المنتج.');}
                $map[absint($p['id'])]=$id;
            }
            foreach($r['collections'] as $c){
                $d=$c['data'];$ids=[];foreach(Riwaq_Catalog::ids($d['ids']??'') as $old){$ids[]=$map[$old];}
                $id=wp_insert_post(wp_slash(['post_type'=>'riwaq_collection','post_title'=>sanitize_text_field($c['title']),'post_status'=>'draft']),true);
                if(is_wp_error($id)||!$id){throw new RuntimeException('تعذر إنشاء مجموعة.');}$created[]=$id;
                $layout=in_array($d['layout']??'',['table','grid','box','list'],true)?$d['layout']:'table';
                if(!update_post_meta($id,'_riwaq_collection',['ids'=>implode(',',$ids),'layout'=>$layout,'columns'=>max(1,min(4,absint($d['columns']??3)))])){throw new RuntimeException('تعذر حفظ مجموعة.');}
                $table=$c['table'];$rows=isset($table['rows'])&&is_string($table['rows'])?sanitize_textarea_field($table['rows']):'';
                if(!update_post_meta($id,'_riwaq_table',wp_slash(['rows'=>$rows,'highlight'=>$map[absint($table['highlight']??0)]??0,'alias'=>absint($table['alias']??0)]))){throw new RuntimeException('تعذر حفظ صفوف المقارنة.');}
            }
        }catch(Throwable $error){foreach(array_reverse($created) as $id){wp_delete_post($id,true);}delete_option('riwaq_restore_lock');return new WP_Error('restore',$error->getMessage().' تم التراجع عن المنتجات والمجموعات الجديدة.');}
        delete_option('riwaq_restore_lock');return ['products'=>count($map),'collections'=>count($r['collections']),'ids'=>$map];
    }
    public static function upload() {
        self::guard('riwaq_restore');$f=$_FILES['backup']??null;
        if(!$f || !is_string($f['tmp_name']??null) || !is_string($f['name']??null) || ($f['error']??1)!==UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name']) || $f['size']>5*1024*1024 || strtolower(pathinfo($f['name'],PATHINFO_EXTENSION))!=='json'){$message='اختر ملف JSON صالحًا حتى 5 ميغابايت.';}
        else{$r=self::restore(json_decode(file_get_contents($f['tmp_name']),true));$message=is_wp_error($r)?$r->get_error_message():'تم إنشاء '.$r['products'].' منتج و'.$r['collections'].' مجموعة كمسودات جديدة.';}
        set_transient('riwaq_restore_'.get_current_user_id(),$message,120);wp_safe_redirect(admin_url('admin.php?page=riwaq-backup'));exit;
    }
}
