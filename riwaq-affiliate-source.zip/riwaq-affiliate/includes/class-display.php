<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Display {
    public static function init() {
        add_action('add_meta_boxes', function () {
            add_meta_box('riwaq-extended', 'التقييمات والعروض والمتاجر البديلة', [__CLASS__,'product_box'], 'riwaq_product', 'normal');
            add_meta_box('riwaq-table-options', 'صفوف المقارنة والتخصيص', [__CLASS__,'collection_box'], 'riwaq_collection', 'normal');
        });
        add_action('admin_menu', function () { add_submenu_page('riwaq','خيارات العرض والتوافق','خيارات العرض والتوافق','manage_options','riwaq-display',[__CLASS__,'page']); });
        add_action('admin_post_riwaq_display_save', [__CLASS__,'save_settings']);
        add_action('save_post_riwaq_collection', [__CLASS__,'save_collection'], 20, 2);
        add_action('wp_ajax_riwaq_visitor_market', [__CLASS__,'visitor_market']);
        add_action('wp_ajax_nopriv_riwaq_visitor_market', [__CLASS__,'visitor_market']);
    }
    public static function text($key, $language = '') {
        $lang = $language ?: Riwaq_Catalog::settings()['language'];
        $labels = [
            'ar'=>['buy'=>'عرض على أمازون','disclosure'=>'قد نحصل على عمولة عند الشراء عبر الروابط في هذه الصفحة.','product'=>'المنتج','price'=>'السعر','rating'=>'التقييم المدخل يدويًا','purchase'=>'رابط الشراء','current'=>'تحقق من السعر الحالي في المتجر','manual'=>'سعر مدخل يدويًا','change'=>'السعر والتوفر قد يتغيران؛ السعر المعتمد في المتجر.','unavailable'=>'الرابط غير متاح','details'=>'قراءة المراجعة','available'=>'متوفر — إدخال يدوي','out'=>'غير متوفر — إدخال يدوي','prime'=>'Prime — إدخال يدوي','choose'=>'اختر متجر الشراء','comparison'=>'مقارنة المنتجات','scroll'=>'جدول مقارنة قابل للتمرير','saved'=>'وفر','editor'=>'تقييم المحرر','review_count'=>'عدد مراجعات مدخل يدويًا','selected'=>'منتج مختار','fallback_help'=>'اطّلع على معلومات المنتج والسعر والتوفر مباشرةً على أمازون.'],
            'fr'=>['buy'=>'Voir sur Amazon','disclosure'=>'Nous pouvons recevoir une commission sur les achats via ces liens.','product'=>'Produit','price'=>'Prix','rating'=>'Note saisie manuellement','purchase'=>'Acheter','current'=>'Consultez le prix actuel en boutique','manual'=>'Prix saisi manuellement','change'=>'Prix et disponibilité susceptibles de changer. Le prix en boutique fait foi.','unavailable'=>'Lien indisponible','details'=>'Lire le test','available'=>'Disponible — saisie manuelle','out'=>'Indisponible — saisie manuelle','prime'=>'Prime — saisie manuelle','choose'=>'Choisir la boutique','comparison'=>'Comparaison des produits','scroll'=>'Tableau de comparaison défilant','saved'=>'Économisez','editor'=>'Note de la rédaction','review_count'=>'nombre d’avis saisi manuellement','selected'=>'Produit sélectionné','fallback_help'=>'Consultez les informations, le prix et la disponibilité directement sur Amazon.'],
            'en'=>['buy'=>'View on Amazon','disclosure'=>'We may earn a commission from purchases through these links.','product'=>'Product','price'=>'Price','rating'=>'Manually entered rating','purchase'=>'Buy','current'=>'Check the current store price','manual'=>'Manually entered price','change'=>'Prices and availability may change. The store price applies.','unavailable'=>'Link unavailable','details'=>'Read the review','available'=>'Available — manual entry','out'=>'Unavailable — manual entry','prime'=>'Prime — manual entry','choose'=>'Choose a store','comparison'=>'Product comparison','scroll'=>'Scrollable comparison table','saved'=>'Save','editor'=>'Editor rating','review_count'=>'manually entered review count','selected'=>'Selected product','fallback_help'=>'See product information, price and availability directly on Amazon.']
        ];
        $labels = apply_filters('riwaq_translations', $labels);
        return $labels[$lang][$key] ?? $labels['en'][$key] ?? $key;
    }
    public static function button($p, $a = []) {
        $s = Riwaq_Catalog::settings();
        return ($a['button_text'] ?? '') ?: ($p['button_text'] ?: ($s['button'] === 'عرض على أمازون' ? self::text('buy', $a['language'] ?? '') : $s['button']));
    }
    public static function maps($p) {
        $out = [$p['market']=>Riwaq_Catalog::url($p)];
        foreach (explode("\n", $p['alternates']) as $line) {
            $v = explode(':', $line, 3);
            if (count($v) >= 2 && isset(Riwaq_Catalog::markets()[$v[0]]) && preg_match('/^[A-Z0-9]{10}$/', $v[1])) {
                $alt = $p; $alt['market'] = $v[0]; $alt['asin'] = $v[1]; $alt['tag'] = $v[2] ?? '';
                $out[$v[0]] = Riwaq_Catalog::url($alt);
            }
        }
        return array_filter($out);
    }
    public static function visitor_market() {
        $market = apply_filters('riwaq_visitor_market', '');
        // Trust a country header only when the site owner explicitly trusts their proxy.
        if (!$market && defined('RIWAQ_TRUST_COUNTRY_HEADER') && RIWAQ_TRUST_COUNTRY_HEADER === true) {
            $country = sanitize_key($_SERVER['HTTP_CF_IPCOUNTRY'] ?? '');
            $market = strtoupper($country === 'gb' ? 'uk' : $country);
        }
        nocache_headers();
        wp_send_json_success(['market'=>isset(Riwaq_Catalog::markets()[$market]) ? $market : '']);
    }
    public static function product_box($post) {
        $d = wp_parse_args((array)get_post_meta($post->ID,'_riwaq_data',true), Riwaq_Catalog::defaults());
        echo '<div class="rw-editor" dir="rtl"><div class="rw-fields">';
        foreach (['list_price'=>['السعر السابق اليدوي','text'],'rating'=>['التقييم 0–5 (يدوي)','number'],'rating_label'=>['مصدر التقييم / وصفه','text'],'review_count'=>['عدد المراجعات اليدوي','number'],'release_date'=>['تاريخ إصدار المنتج المدخل يدويًا','date'],'detail_url'=>['رابط مراجعتك التفصيلية','url'],'button_text'=>['نص زر خاص بالمنتج','text'],'keywords'=>['كلمات بحث / اسم قائمة AAWP القديمة','text']] as $key=>$field) {
            echo '<div><label for="rw-extra-'.esc_attr($key).'">'.esc_html($field[0]).'</label><input id="rw-extra-'.esc_attr($key).'" type="'.esc_attr($field[1]).'" name="riwaq['.esc_attr($key).']" value="'.esc_attr($d[$key]).'" '.($key==='rating'?'min="0" max="5" step="0.1"':($key==='review_count'?'min="0" max="99999999"':'')).'></div>';
        }
        echo '<div><label for="rw-availability">التوفر اليدوي</label><select id="rw-availability" name="riwaq[availability]">';
        foreach (['unknown'=>'غير محدد','available'=>'متوفر','unavailable'=>'غير متوفر'] as $key=>$label) { echo '<option value="'.esc_attr($key).'" '.selected($d['availability'],$key,false).'>'.esc_html($label).'</option>'; }
        echo '</select></div><div><label for="rw-prime">Prime (تحقق يدوي)</label><input type="hidden" name="riwaq[prime]" value="0"><input id="rw-prime" type="checkbox" name="riwaq[prime]" value="1" '.checked($d['prime'],1,false).'></div></div>';
        foreach (['alternates'=>'المتاجر البديلة — متجر:ASIN:معرّف الشريك، سطر لكل متجر، مثل FR:B000000001:yourtag-21','images'=>'صور إضافية HTTPS، رابط في كل سطر (حتى 5)'] as $key=>$label) { echo '<label for="rw-extra-'.esc_attr($key).'">'.esc_html($label).'</label><textarea dir="ltr" rows="4" id="rw-extra-'.esc_attr($key).'" name="riwaq['.esc_attr($key).']">'.esc_textarea($d[$key]).'</textarea>'; }
        echo '<p>التقييمات وPrime وعدد المراجعات والتوفر لا تُجلب من أمازون. أدخل مصدرًا واضحًا للتقييم. عند اختيار متجر بديل تختفي الأسعار اليدوية للمتجر الأصلي.</p></div>';
    }
    public static function collection_box($post) {
        $d = (array)get_post_meta($post->ID,'_riwaq_table',true);
        echo '<div class="rw-editor" dir="rtl"><label for="rw-table-rows">ترتيب صفوف المواصفات (اسم الخاصية في كل سطر؛ اتركه فارغًا لعرض الكل)</label><textarea id="rw-table-rows" rows="5" name="riwaq_table[rows]">'.esc_textarea($d['rows']??'').'</textarea><label for="rw-highlight">معرّف المنتج المميز في المقارنة</label><input id="rw-highlight" type="number" min="0" name="riwaq_table[highlight]" value="'.absint($d['highlight']??0).'"><label for="rw-alias">معرّف جدول AAWP السابق، إن وجد</label><input id="rw-alias" type="number" min="0" name="riwaq_table[alias]" value="'.absint($d['alias']??0).'"><p>الربط يربط أكواد [aawp table="ID"] بهذه المجموعة عند تفعيل التوافق؛ لا يقرأ قاعدة بيانات AAWP.</p></div>';
    }
    public static function save_collection($id, $post) {
        if (wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('manage_options') || !isset($_POST['riwaq_nonce'],$_POST['riwaq_table']) || !is_string($_POST['riwaq_nonce']) || !is_array($_POST['riwaq_table']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['riwaq_nonce'])),'riwaq_save')) { return; }
        $r = wp_unslash($_POST['riwaq_table']);
        $rows = isset($r['rows']) && is_string($r['rows']) ? sanitize_textarea_field($r['rows']) : '';
        update_post_meta($id,'_riwaq_table',wp_slash(['rows'=>$rows,'highlight'=>absint($r['highlight']??0),'alias'=>absint($r['alias']??0)]));
    }
    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        $s=Riwaq_Catalog::settings();
        echo '<div class="wrap rw-admin" dir="rtl"><header class="rw-header"><div><h1>خيارات العرض والتوافق</h1><p>تخصيص رواق 2.0 دون الاتصال بـ Amazon API.</p></div></header><form class="rw-panel" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="riwaq_display_save">'; wp_nonce_field('riwaq_display_save');
        foreach (['language'=>['لغة العرض',['auto'=>'تلقائي حسب لغة الموقع','ar'=>'العربية','fr'=>'Français','en'=>'English']],'style'=>['التصميم الافتراضي',['clean'=>'نظيف','dark'=>'داكن','compact'=>'مضغوط']]] as $key=>$field) {
            echo '<label for="rw-display-'.esc_attr($key).'">'.esc_html($field[0]).'</label><select id="rw-display-'.esc_attr($key).'" name="'.esc_attr($key).'">';
            foreach ($field[1] as $value=>$label) { echo '<option value="'.esc_attr($value).'" '.selected($key==='language'?$s['language_mode']:$s[$key],$value,false).'>'.esc_html($label).'</option>'; }
            echo '</select>';
        }
        echo '<label for="rw-info-color">لون معلومات المنتج والإطار المحيط به</label><input type="color" id="rw-info-color" name="info_color" value="'.esc_attr($s['info_color']).'"><p>يُطبّق على عنوان المنتج والسعر والتقييمات وإطار البطاقة.</p>';
        foreach (['market_selector'=>'إظهار اختيار متجر الزائر وتفعيل ربط الموقع الجغرافي عند توفير مصدر موثوق'] as $key=>$label) { echo '<label><input type="checkbox" name="'.esc_attr($key).'" value="1" '.checked($s[$key],1,false).'> '.esc_html($label).'</label>'; }
        echo '<p>تدعم رواق أكواد [amazon] و[aawp] الموجودة تلقائيًا. المنتجات غير المضافة تعرض رابطًا مباشرًا بحسب ASIN وعنوان القسم إن توفر. اختيار المتجر لا يخمّن ASIN بين البلدان.</p>'; submit_button('حفظ خيارات العرض'); echo '</form></div>';
    }
    public static function save_settings() {
        if (!current_user_can('manage_options')) { wp_die('غير مصرح','',['response'=>403]); }
        check_admin_referer('riwaq_display_save'); $s=Riwaq_Catalog::settings();
        $s['language']=in_array($_POST['language']??'', ['auto','ar','fr','en'],true)?$_POST['language']:'auto';
        $s['info_color']=isset($_POST['info_color'])&&is_string($_POST['info_color'])?(sanitize_hex_color(wp_unslash($_POST['info_color']))?:'#087f70'):'#087f70';unset($s['language_mode']);
        $s['style']=in_array($_POST['style']??'', ['clean','dark','compact'],true)?$_POST['style']:'clean';
        $s['compatibility']=1;$s['compatibility_replace']=1;$s['market_selector']=empty($_POST['market_selector'])?0:1;
        update_option('riwaq_settings',$s);
        wp_safe_redirect(admin_url('admin.php?page=riwaq-display')); exit;
    }
}
