<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Admin {
    public static function init() {
        add_action('admin_menu', [__CLASS__,'menu']);
        add_action('admin_init', [__CLASS__,'settings']);
        add_action('add_meta_boxes', [__CLASS__,'boxes']);
        add_action('save_post', [__CLASS__,'save'], 10, 2);
        add_action('admin_enqueue_scripts', [__CLASS__,'assets']);
        add_filter('manage_riwaq_product_posts_columns', function ($cols) { $cols['riwaq_id']=riwaq_admin_text('معرّف / كود الإدراج','ID / Code court','ID / Shortcode'); $cols['riwaq_asin']=riwaq_admin_text('ASIN / المتجر','ASIN / Boutique','ASIN / Store'); return $cols; });
        add_action('current_screen',[__CLASS__,'translate_screen']);
        add_action('manage_riwaq_product_posts_custom_column', function ($col,$id) {
            if ($col === 'riwaq_id') { echo '<code>'.esc_html('[riwaq ids="'.$id.'"]').'</code>'; }
            if ($col === 'riwaq_asin') { $d=(array)get_post_meta($id,'_riwaq_data',true); echo esc_html(($d['asin']??'').' / '.($d['market']??'')); }
        },10,2);
    }
    public static function menu() {
        $name=riwaq_admin_text('رواق أفلييت','Affiliation Riwaq','Riwaq Affiliate');
        add_menu_page($name,$name,'manage_options','riwaq',[__CLASS__,'dashboard'],'dashicons-cart',26);
        add_submenu_page('riwaq',riwaq_admin_text('لوحة التحكم','Tableau de bord','Dashboard'),riwaq_admin_text('لوحة التحكم','Tableau de bord','Dashboard'),'manage_options','riwaq',[__CLASS__,'dashboard']);
        add_submenu_page('riwaq',riwaq_admin_text('الاستيراد والتصدير','Importer et exporter','Import and export'),riwaq_admin_text('الاستيراد والتصدير','Importer et exporter','Import and export'),'manage_options','riwaq-transfer',['Riwaq_Transfer','page']);
        add_submenu_page('riwaq',riwaq_admin_text('الإعدادات','Réglages','Settings'),riwaq_admin_text('الإعدادات','Réglages','Settings'),'manage_options','riwaq-settings',[__CLASS__,'settings_page']);
    }
    public static function translate_screen($screen){
        if(riwaq_admin_language()!=='fr'||(!$screen||(strpos((string)$screen->id,'riwaq')===false&&strpos((string)($screen->post_type??''),'riwaq')===false))){return;}
        ob_start(function($html){return strtr($html,self::french_map());});
    }
    public static function french_map(){return ['dir="rtl"'=>'dir="ltr"','منتجات رواق'=>'Produits Riwaq','المقارنات والقوائم'=>'Comparaisons et listes','لوحة التحكم'=>'Tableau de bord','الاستيراد والتصدير'=>'Importer et exporter','الإعدادات'=>'Réglages','نسخة كتالوج كاملة'=>'Sauvegarde complète du catalogue','جلب بيانات المنتجات'=>'Récupérer les données produits','خيارات العرض والتوافق'=>'Affichage et compatibilité','معرّف / كود الإدراج'=>'ID / Code court','ASIN / المتجر'=>'ASIN / Boutique','لغة العرض'=>'Langue d’affichage','تلقائي حسب لغة الموقع'=>'Automatique selon la langue du site','التصميم الافتراضي'=>'Style par défaut','نظيف'=>'Épuré','داكن'=>'Sombre','مضغوط'=>'Compact','لون معلومات المنتج والإطار المحيط به'=>'Couleur des informations produit et de la bordure','يُطبّق على عنوان المنتج والسعر والتقييمات وإطار البطاقة.'=>'Appliquée au titre, au prix, aux évaluations et à la bordure de la carte.','حفظ خيارات العرض'=>'Enregistrer les options d’affichage','إظهار اختيار متجر الزائر وتفعيل ربط الموقع الجغرافي عند توفير مصدر موثوق'=>'Afficher le choix de la boutique du visiteur','تفعيل أكواد [amazon] و[aawp] الأساسية'=>'Compatibilité avec les codes [amazon] et [aawp]','إضافة منتج'=>'Ajouter un produit','بحث المنتجات'=>'Rechercher des produits','المنتجات المنشورة'=>'Produits publiés','بانتظار المراجعة'=>'En attente de révision','إعدادات رواق'=>'Réglages Riwaq','حفظ الإعدادات'=>'Enregistrer les réglages','بيانات المنتج'=>'Données du produit','متجر المنتج'=>'Boutique du produit','آخر مراجعة'=>'Dernière vérification','كود الإدراج'=>'Code court'];}
    public static function assets() {
        $screen = get_current_screen();
        if (!$screen || (strpos($screen->id,'riwaq') === false && strpos($screen->post_type??'','riwaq') === false)) { return; }
        wp_enqueue_style('riwaq-admin', RIWAQ_URL.'assets/admin.css',[],RIWAQ_VERSION);
        wp_enqueue_script('riwaq-admin',RIWAQ_URL.'assets/admin.js',['jquery'],RIWAQ_VERSION,true);
        if ($screen->post_type === 'riwaq_product') { wp_enqueue_media(); }
    }
    public static function settings() {
        register_setting('riwaq','riwaq_settings',['type'=>'array','sanitize_callback'=>[__CLASS__,'sanitize_settings'],'default'=>[]]);
    }
    public static function sanitize_settings($raw) {
        $r = is_array($raw) ? $raw : [];
        $s = Riwaq_Catalog::settings();
        foreach (['tag','button','disclosure'] as $k) { $s[$k]=isset($r[$k]) && is_scalar($r[$k]) ? sanitize_text_field($r[$k]) : ''; }
        $s['tag']=preg_replace('/[^a-zA-Z0-9_-]/','',$s['tag']);
        $s['market']=isset($r['market']) && is_string($r['market']) && isset(Riwaq_Catalog::markets()[$r['market']]) ? $r['market'] : 'US';
        $s['color']=isset($r['color']) && is_string($r['color']) ? (sanitize_hex_color($r['color']) ?: '#087f70') : '#087f70';
        $s['language']=in_array($r['language']??'', ['auto','ar','fr','en'],true)?$r['language']:$s['language_mode'];unset($s['language_mode']);
        if(isset($r['info_color'])){$s['info_color']=is_string($r['info_color'])?(sanitize_hex_color($r['info_color'])?:'#087f70'):'#087f70';}
        $s['price_days']=max(1,min(30,absint($r['price_days']??7)));
        $s['tracking']=empty($r['tracking'])?0:1;
        $s['new_tab']=empty($r['new_tab'])?0:1;
        $s['button']=$s['button']?:'عرض على أمازون';
        $s['disclosure']=$s['disclosure']?:'قد نحصل على عمولة عند الشراء عبر الروابط في هذه الصفحة.';
        return $s;
    }
    private static function header($title,$subtitle) {
        echo '<div class="wrap rw-admin" dir="rtl"><header class="rw-header"><div><span class="rw-eyebrow">RIWAQ / رواق أفلييت</span><h1>'.esc_html($title).'</h1><p>'.esc_html($subtitle).'</p></div><span class="rw-version">'.esc_html(RIWAQ_VERSION).' · دون Amazon API</span></header>';
    }
    public static function dashboard() {
        if (!current_user_can('manage_options')) { return; }
        self::header('مساحة منتجاتك. فرص أكثر.','حوّل اختياراتك إلى بطاقات جميلة ومقارنات تساعد القارئ على الاختيار.');
        $counts=wp_count_posts('riwaq_product'); $collections=wp_count_posts('riwaq_collection');
        echo '<div class="rw-stats">';
        foreach (['المنتجات المنشورة'=>(int)$counts->publish,'بانتظار المراجعة'=>(int)$counts->draft,'المقارنات والقوائم'=>(int)$collections->publish,'نقرات آخر 30 يومًا'=>Riwaq_Tracking::total()] as $label=>$value) { echo '<div class="rw-stat"><span>'.esc_html($label).'</span><strong>'.esc_html(number_format_i18n($value)).'</strong></div>'; }
        echo '</div><div class="rw-columns"><section class="rw-panel"><h2>ابدأ بمنتج يستحق التوصية</h2><p>أضف عنوان المنتج ورمزه وصورته ومميزاته، ثم انشره لتتمكن من عرضه في مقالاتك.</p><div class="rw-actions"><a class="button button-primary" href="'.esc_url(admin_url('post-new.php?post_type=riwaq_product')).'">+ إضافة منتج</a><a class="button" href="'.esc_url(admin_url('admin.php?page=riwaq-transfer')).'">استيراد CSV</a><a class="button" href="'.esc_url(admin_url('post-new.php?post_type=riwaq_collection')).'">إنشاء مقارنة</a></div><hr><h2>مولّد كود الإدراج</h2><label for="rw-gen-ids">معرّفات المنتجات (تجدها في صفحة المنتجات)</label><input id="rw-gen-ids" type="text" placeholder="12,34,56" dir="ltr"><label for="rw-gen-layout">طريقة العرض</label><select id="rw-gen-layout"><option value="box">بطاقات أفقية</option><option value="grid">شبكة منتجات</option><option value="list">قائمة مرقمة</option><option value="table">جدول مقارنة</option><option value="link">رابط نصي</option></select><label for="rw-gen-code">انسخ إلى كتلة Shortcode في مقالك</label><input id="rw-gen-code" type="text" readonly dir="ltr" value="[riwaq ids=&quot;12,34&quot; layout=&quot;box&quot;]"><button class="button" type="button" id="rw-copy">نسخ الكود</button><span id="rw-copy-status" role="status"></span></section><section class="rw-panel rw-guide"><span class="rw-eyebrow">دليل سريع</span><h2>من الكتالوج إلى المقال</h2><ol><li><strong>اضبط المتجر ومعرّف الشريك</strong><p>معرّف الشريك الافتراضي يطبّق على منتجات متجره فقط.</p></li><li><strong>أضف المنتجات وانشرها</strong><p>يمكن الاستيراد دفعة واحدة؛ تبقى المنتجات المستوردة مسودات حتى تراجعها.</p></li><li><strong>اختر الشكل المناسب</strong><p>استخدم كتلة «منتجات رواق» أو انسخ كود الإدراج.</p></li></ol><a href="'.esc_url(admin_url('admin.php?page=riwaq-settings')).'">فتح الإعدادات ←</a><p class="rw-note">البيانات والأسعار والترتيبات في هذه النسخة يدوية. ترتيب القائمة لا يمثل ترتيب مبيعات أمازون.</p></section></div>';
        echo '<section class="rw-panel"><h2>المنتجات الأكثر نقرًا · آخر 30 يومًا</h2><p>إحصاءات تقريبية للنقرات، وليست مبيعات أو زوارًا فريدين. التتبع اختياري ويعمل دون ملفات تعريف ارتباط أو حفظ عناوين IP.</p>';
        $rows=Riwaq_Tracking::report();
        if (!$rows) { echo '<p class="rw-empty">لا توجد نقرات مسجلة. فعّل التتبع من الإعدادات إذا رغبت في قياس التفاعل.</p>'; }
        else { echo '<table class="widefat striped"><thead><tr><th>المنتج</th><th>موضع النقر</th><th>النقرات</th></tr></thead><tbody>'; foreach ($rows as $r) { echo '<tr><td>'.esc_html(get_the_title($r->product_id) ?: 'منتج محذوف').'</td><td>'.esc_html($r->element).'</td><td>'.esc_html($r->clicks).'</td></tr>'; } echo '</tbody></table>'; }
        echo '</section></div>';
    }
    public static function settings_page() {
        if (!current_user_can('manage_options')) { return; }
        self::header('إعدادات رواق','اضبط الروابط والمظهر وطريقة عرض الأسعار.');
        settings_errors(); $s=Riwaq_Catalog::settings();
        echo '<form action="options.php" method="post" class="rw-panel">'; settings_fields('riwaq');
        echo '<table class="form-table"><tbody><tr><th><label for="rw-market">المتجر الافتراضي</label></th><td><select id="rw-market" name="riwaq_settings[market]">';
        foreach (Riwaq_Catalog::markets() as $code=>$domain) { echo '<option value="'.esc_attr($code).'" '.selected($s['market'],$code,false).'>'.esc_html($code.' — '.$domain).'</option>'; }
        echo '</select></td></tr>';
        foreach (['tag'=>['معرّف الشريك الافتراضي','text'],'button'=>['نص زر الشراء','text'],'disclosure'=>['إفصاح روابط العمولة','text'],'color'=>['لون الأزرار','color'],'price_days'=>['إخفاء السعر بعد (أيام)','number']] as $key=>$field) {
            echo '<tr><th><label for="rw-'.esc_attr($key).'">'.esc_html($field[0]).'</label></th><td><input id="rw-'.esc_attr($key).'" name="riwaq_settings['.esc_attr($key).']" type="'.esc_attr($field[1]).'" value="'.esc_attr($s[$key]).'" '.($field[1]==='number'?'min="1" max="30"':'').' class="regular-text"></td></tr>';
        }
        foreach (['new_tab'=>'فتح روابط الشراء في تبويب جديد','tracking'=>'تفعيل عدّ النقرات المجمّع (دون IP أو Cookies)'] as $key=>$label) { echo '<tr><th>'.esc_html($label).'</th><td><label><input name="riwaq_settings['.esc_attr($key).']" type="checkbox" value="1" '.checked($s[$key],1,false).'> مفعّل</label></td></tr>'; }
        echo '</tbody></table><p>الأسعار يدوية، ويُعرض تاريخ مراجعتها. حذف الإضافة يحتفظ بمنتجاتك وإعداداتك. تُحذف إحصاءات النقرات التي يتجاوز عمرها 90 يومًا تلقائيًا.</p>'; submit_button('حفظ الإعدادات'); echo '</form></div>';
    }
    public static function boxes() {
        add_meta_box('riwaq-details','بيانات المنتج',[__CLASS__,'product_box'],'riwaq_product','normal','high');
        add_meta_box('riwaq-collection','بناء المقارنة أو القائمة',[__CLASS__,'collection_box'],'riwaq_collection','normal','high');
    }
    public static function product_box($post) {
        $d=wp_parse_args((array)get_post_meta($post->ID,'_riwaq_data',true),Riwaq_Catalog::defaults());
        wp_nonce_field('riwaq_save','riwaq_nonce');
        echo '<div class="rw-editor" dir="rtl"><p>أدخل بيانات تملك حق استخدامها. الحقول اختيارية، لكن رابط الشراء يحتاج ASIN صالحًا من 10 أحرف وأرقام.</p><div class="rw-fields">';
        $fields=['asin'=>'ASIN','tag'=>'معرّف الشريك لهذا المنتج (اختياري)','image'=>'رابط الصورة HTTPS','price'=>'السعر اليدوي (مثل 49.99)','currency'=>'رمز العملة (USD / SAR / AED)','badge'=>'شارة مخصصة (مثل اختيار المحرر)','rank'=>'ترتيب يدوي داخل الفئة (الأقل أولًا)'];
        foreach ($fields as $k=>$label) {
            echo '<div><label for="rw-'.esc_attr($k).'">'.esc_html($label).'</label><input id="rw-'.esc_attr($k).'" name="riwaq['.esc_attr($k).']" type="'.($k==='rank'?'number':'text').'" value="'.esc_attr($d[$k]).'" '.($k==='rank'?'min="0" max="999999"':'').'>';
            if ($k==='image') { echo '<button type="button" class="button" id="rw-media">اختر من مكتبة الوسائط</button>'; }
            echo '</div>';
        }
        echo '<div><label for="rw-product-market">متجر المنتج</label><select id="rw-product-market" name="riwaq[market]">';
        foreach (Riwaq_Catalog::markets() as $code=>$domain) { echo '<option value="'.esc_attr($code).'" '.selected($d['market'],$code,false).'>'.esc_html($code.' — '.$domain).'</option>'; }
        echo '</select></div></div><div class="rw-fields">';
        foreach (['features'=>'المميزات (ميزة في كل سطر)','specs'=>'المواصفات للمقارنة (مثل: الوزن: 250 غرام)'] as $k=>$label) { echo '<div><label for="rw-'.esc_attr($k).'">'.esc_html($label).'</label><textarea rows="6" id="rw-'.esc_attr($k).'" name="riwaq['.esc_attr($k).']">'.esc_textarea($d[$k]).'</textarea></div>'; }
        echo '</div><p><label><input type="checkbox" name="riwaq_verify" value="1"> راجعت السعر الآن (يعيد ضبط تاريخ مراجعة السعر)</label></p><p>آخر مراجعة: '.esc_html($d['verified'] ? wp_date('Y-m-d H:i',(int)$d['verified']) : 'لم تتم المراجعة').'</p><p>كود الإدراج: <code dir="ltr">'.esc_html('[riwaq ids="'.$post->ID.'"]').'</code></p></div>';
    }
    public static function collection_box($post) {
        wp_nonce_field('riwaq_save','riwaq_nonce');
        $d=wp_parse_args((array)get_post_meta($post->ID,'_riwaq_collection',true),['ids'=>'','layout'=>'table','columns'=>3]);
        $products=get_posts(['post_type'=>'riwaq_product','post_status'=>'publish','posts_per_page'=>200,'orderby'=>'title','order'=>'ASC']);
        echo '<div class="rw-editor" dir="rtl"><p>اختر منتجات أو أدخل معرّفاتها بالترتيب المطلوب. تُجمع صفوف جدول المقارنة من مواصفات المنتجات.</p><label for="rw-collection-ids">معرّفات المنتجات بالترتيب (20 منتجًا كحد أقصى)</label><input id="rw-collection-ids" name="riwaq_collection[ids]" value="'.esc_attr($d['ids']).'" dir="ltr"><div class="rw-picker">';
        foreach ($products as $p) { echo '<button class="button rw-add-product" type="button" data-id="'.absint($p->ID).'">+ '.esc_html($p->post_title).' (#'.absint($p->ID).')</button> '; }
        if (!$products) { echo '<p>أضف منتجات وانشرها أولًا.</p>'; }
        echo '</div><label for="rw-collection-layout">طريقة العرض</label><select id="rw-collection-layout" name="riwaq_collection[layout]">';
        foreach (['table'=>'جدول مقارنة','grid'=>'شبكة','box'=>'بطاقات أفقية','list'=>'قائمة مرقمة'] as $key=>$label) { echo '<option value="'.esc_attr($key).'" '.selected($d['layout'],$key,false).'>'.esc_html($label).'</option>'; }
        echo '</select><label for="rw-columns">أعمدة الشبكة</label><input id="rw-columns" type="number" name="riwaq_collection[columns]" min="1" max="4" value="'.absint($d['columns']).'"><p>بعد نشر المجموعة، استخدم: <code dir="ltr">'.esc_html('[riwaq collection="'.$post->ID.'"]').'</code></p></div>';
    }
    public static function save($id,$post) {
        if (!in_array($post->post_type,['riwaq_product','riwaq_collection'],true) || wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
        if (!current_user_can('manage_options') || !current_user_can('edit_post',$id) || !isset($_POST['riwaq_nonce']) || !is_string($_POST['riwaq_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['riwaq_nonce'])),'riwaq_save')) { return; }
        if ($post->post_type==='riwaq_product' && isset($_POST['riwaq']) && is_array($_POST['riwaq'])) {
            $old=(array)get_post_meta($id,'_riwaq_data',true);
            $d=Riwaq_Catalog::clean(wp_unslash($_POST['riwaq']));
            $source=(array)get_post_meta($id,'_riwaq_source',true);
            if(($source['kind']??'')==='amazon_page'){
                foreach(['image','rating','rating_label','review_count','features'] as $key){if(($old[$key]??'')!==$d[$key]){$source['paused']=1;update_post_meta($id,'_riwaq_source',$source);break;}}
            }
            $changed=($old['price']??'')!==$d['price'] || ($old['currency']??'')!==$d['currency'] || ($old['asin']??'')!==$d['asin'] || ($old['market']??'')!==$d['market'];
            $d['verified']=!empty($_POST['riwaq_verify']) ? time() : ($changed ? 0 : absint($old['verified']??0));
            update_post_meta($id,'_riwaq_data',wp_slash($d));
            // Remove this callback around wp_update_post to avoid recursive saves.
            remove_action('save_post',[__CLASS__,'save'],10);
            wp_update_post(['ID'=>$id,'menu_order'=>$d['rank']]);
            add_action('save_post',[__CLASS__,'save'],10,2);
        }
        if ($post->post_type==='riwaq_collection' && isset($_POST['riwaq_collection']) && is_array($_POST['riwaq_collection'])) {
            $r=wp_unslash($_POST['riwaq_collection']);
            $ids=isset($r['ids']) && is_scalar($r['ids']) ? implode(',',Riwaq_Catalog::ids($r['ids'])) : '';
            $layout=in_array($r['layout']??'', ['table','grid','box','list'],true)?$r['layout']:'table';
            update_post_meta($id,'_riwaq_collection',['ids'=>$ids,'layout'=>$layout,'columns'=>max(1,min(4,absint($r['columns']??3)))]);
        }
    }
}
