<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Compatibility {
    private static $lookup_index=null;
    public static function clear_lookup(){self::$lookup_index=null;}
    public static function init() {
        add_action('save_post_riwaq_product',[__CLASS__,'clear_lookup']);
        foreach(['added_post_meta','updated_post_meta','deleted_post_meta'] as $hook){add_action($hook,function($meta_id,$object_id,$key){if($key==='_riwaq_data'){self::clear_lookup();}},10,3);}
        add_action('wp_loaded', [__CLASS__,'register_legacy'], PHP_INT_MAX);
    }
    public static function register_legacy() {
            add_shortcode('amazon',[__CLASS__,'amazon']);
            add_shortcode('aawp',[__CLASS__,'aawp']);
    }
    public static function menus() {
        add_action('admin_menu',function () { add_submenu_page('riwaq','فحص استبدال AAWP','فحص استبدال AAWP','manage_options','riwaq-migration',[__CLASS__,'page']); });
        add_action('admin_post_riwaq_seed',[__CLASS__,'seed_action']);
    }
    public static function lookup($asin) {
        $asin=strtoupper(trim((string)$asin));
        if (!preg_match('/^[A-Z0-9]{10}$/',$asin)) { return 0; }
        if(self::$lookup_index===null){
            self::$lookup_index=[];
            foreach(get_posts(['post_type'=>'riwaq_product','post_status'=>'publish','posts_per_page'=>-1]) as $post){
                if($post->post_password!==''){continue;}
                $p=Riwaq_Catalog::clean((array)get_post_meta($post->ID,'_riwaq_data',true));
                if($p['asin']!==''&&!isset(self::$lookup_index[$p['asin']][$p['market']])){self::$lookup_index[$p['asin']][$p['market']]=$post->ID;}
            }
        }
        $matches=self::$lookup_index[$asin]??[];
        return $matches[Riwaq_Catalog::settings()['market']]??($matches?reset($matches):0);
    }
    public static function amazon($atts,$content=null) {
        $r=is_array($atts)?$atts:[];
        if (isset($r['table'])) { return self::aawp($r); }
        $a=['ids'=>'','layout'=>'box','limit'=>$r['items']??20,'columns'=>$r['grid']??3];
        $source=$r['box']??$r['link']??$r['fields']??'';
        if ($source) { foreach(array_slice(explode(',',$source),0,20) as $asin){Riwaq_Source::ensure($asin,Riwaq_Catalog::settings()['market']);} }
        if ($source) { $a['ids']=implode(',',array_filter(array_map([__CLASS__,'lookup'],explode(',',$source)))); }
        if (!$source && isset($r['bestseller'])) { $a['search']=$r['bestseller']; $a['layout']='list'; $a['orderby']='rank'; }
        if (!$source && isset($r['new'])) { $a['category']=sanitize_title($r['new']); $a['layout']='list'; $a['order']='release'; }
        if (isset($r['link'])) { $a['layout']='link'; $a['label']=$r['title']??($content?wp_strip_all_tags($content):''); }
        elseif (isset($r['fields'])) {
            $a['layout']='field';
            $fields=['price'=>'price','title'=>'title','button'=>'button','image'=>'image','url'=>'url','rating'=>'rating','reviews'=>'review_count','description'=>'features'];
            $a['field']=$fields[$r['value']??'title']??'';
        } elseif (!empty($r['grid'])) { $a['layout']='grid'; }
        elseif (isset($r['template']) && in_array($r['template'],['table','list','vertical','horizontal'],true)) { $a['layout']=['vertical'=>'grid','horizontal'=>'box','list'=>'list','table'=>'table'][$r['template']]; }
        foreach (['orderby','select','button','button_text','description_items','star_rating','reviews','rating','image'] as $key) { if (isset($r[$key]) && is_scalar($r[$key])) { $a[$key]=$r[$key]; } }
        if (isset($r['order'])) { $a['direction']=$r['order']; }
        if (isset($r['title']) && !isset($r['link'])) { $a['product_title']=$r['title']; }
        if (isset($r['description'])) { $a['description']=$r['description']; }
        if (isset($r['style']) && in_array($r['style'],['clean','dark','compact'],true)) { $a['style']=$r['style']; }
        if (isset($r['filterby'],$r['filter']) && $r['filterby']==='title') { $a['search']=$r['filter']; }
        if (isset($r['filterby'],$r['filter']) && $r['filterby']==='price' && is_numeric($r['filter'])) {
            $compare=$r['filter_compare']??'equal';
            if ($compare==='equal') { $a['min_price']=$r['filter'];$a['max_price']=$r['filter']; }
            if ($compare==='less') { $a['max_price']=(string)((float)$r['filter']-.01); }
            if ($compare==='more') { $a['min_price']=(string)((float)$r['filter']+.01); }
        }
        if ($source && !$a['ids']) { return self::fallback($source,$r,$content); }
        $html=Riwaq_Render::shortcode($a);
        if($source && !isset($r['link']) && !isset($r['fields'])){
            foreach(explode(',',$source) as $asin){if(!self::lookup($asin)){$html.=self::fallback($asin,$r,$content);}}
        }
        return $html;
    }
    public static function fallback($source,$r,$content=null) {
        $s=Riwaq_Catalog::settings();$out='';$seen=[];
        foreach(array_slice(explode(',',(string)$source),0,20) as $asin){
            $asin=strtoupper(trim($asin));if(!preg_match('/^[A-Z0-9]{10}$/',$asin)||isset($seen[$asin])){continue;}$seen[$asin]=true;
            $p=Riwaq_Catalog::clean(['asin'=>$asin,'market'=>$s['market']]);$p['id']=0;
            $title=isset($r['title'])&&is_scalar($r['title'])?sanitize_text_field($r['title']):'';
            if(!$title && !isset($r['link']) && !isset($r['fields'])){
                $post=get_post();
                if($post && preg_match('/\[amazon\b[^\]]*'.preg_quote($asin,'/').'[^\]]*\]/i',$post->post_content,$m,PREG_OFFSET_CAPTURE)){
                    $before=substr($post->post_content,0,$m[0][1]);preg_match_all('/<h[1-6]\b[^>]*>(.*?)<\/h[1-6]>/is',$before,$headings);
                    if($headings[1]){$title=sanitize_text_field(wp_strip_all_tags(end($headings[1])));}
                }
            }
            $p['title']=$title?:'Amazon · '.$asin;
            $url=Riwaq_Catalog::url($p);
            if(isset($r['fields'])){
                $value=$r['value']??'title';
                if($value==='url'){$out.=esc_url($url);}elseif($value==='button'){$out.=self::fallback_link($p,Riwaq_Display::button($p));}
                // Unknown data remains empty: no invented price, rating, image or title field.
                continue;
            }
            if(isset($r['link'])){$out.=self::fallback_link($p,$title?:($content?wp_strip_all_tags($content):Riwaq_Display::text('buy')));continue;}
            $lang=$s['language'];$label=isset($r['button_text'])&&is_scalar($r['button_text'])?sanitize_text_field($r['button_text']):Riwaq_Display::button($p);
            $icon='<span class="riwaq__fallback-icon" aria-hidden="true"><svg viewBox="0 0 48 48" focusable="false"><path d="M12 15.5 24 9l12 6.5v17L24 39l-12-6.5z"/><path d="m12 15.5 12 6.7 12-6.7M24 22.2V39"/></svg></span>';
            $out.='<section class="riwaq riwaq--box riwaq--'.esc_attr($s['style']).' riwaq--fallback" style="--riwaq-info:'.esc_attr($s['info_color']).';--riwaq-accent:'.esc_attr($s['color']).'" lang="'.esc_attr($lang).'" dir="'.($lang==='ar'?'rtl':'ltr').'"><article class="riwaq__card"><div class="riwaq__fallback-visual">'.$icon.'</div><div class="riwaq__body"><span class="riwaq__fallback-kicker">'.esc_html(Riwaq_Display::text('selected',$lang)).'</span><h3 class="riwaq__title">'.esc_html($p['title']).'</h3><p class="riwaq__fallback-help">'.esc_html(Riwaq_Display::text('fallback_help',$lang)).'</p></div><div class="riwaq__buy">'.(($r['button']??'')==='none'?'':self::fallback_link($p,$label)).'</div></article></section>';
        }
        return $out?:($content?esc_html(wp_strip_all_tags($content)):'');
    }
    private static function fallback_link($p,$label){
        $s=Riwaq_Catalog::settings();return '<a class="riwaq__button" href="'.esc_url(Riwaq_Catalog::url($p)).'" rel="sponsored nofollow noopener"'.($s['new_tab']?' target="_blank"':'').'>'.esc_html($label).'</a>';
    }
    public static function aawp($atts) {
        if (!is_array($atts) || empty($atts['table'])) { return ''; }
        $alias=absint($atts['table']);
        $ids=get_posts(['post_type'=>'riwaq_collection','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids']);
        foreach ($ids as $id) { $d=(array)get_post_meta($id,'_riwaq_table',true);if(absint($d['alias']??0)===$alias){return Riwaq_Render::shortcode(['collection'=>$id]);} }
        return '';
    }
    public static function scan() {
        $out=[]; $page=1;
        do {
            $posts=get_posts(['post_type'=>['post','page'],'post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>200,'paged'=>$page++,'orderby'=>'ID','order'=>'ASC']);
            foreach ($posts as $p) {
                if (!preg_match_all('/\[(amazon|aawp)\b([^\]]*)\]/i',$p->post_content,$matches,PREG_SET_ORDER)) { continue; }
                foreach ($matches as $m) {
                    $a=shortcode_parse_atts($m[2]);$a=is_array($a)?$a:[];$missing=[];
                    $supported=['box','link','fields','value','bestseller','new','table','grid','items','orderby','order','select','button','button_text','description_items','star_rating','reviews','rating','image','title','description','style','template','filterby','filter','filter_compare'];
                    $unknown=array_diff(array_filter(array_keys($a),'is_string'),$supported);
                    foreach (explode(',',$a['box']??$a['link']??$a['fields']??'') as $asin) { if (trim($asin) && !self::lookup($asin)) { $missing[]=trim($asin); } }
                    $status=$missing?'منتجات غير مربوطة: '.implode(', ',$missing):'الكود الأساسي مدعوم؛ راجع العرض';
                    if (isset($a['bestseller'],$a['new']) || isset($a['bestseller']) || isset($a['new'])) { $status='قائمة تحتاج كلمات بحث/فئة وترتيبًا أو تاريخ إصدار يدويًا'; }
                    if (isset($a['table'])) { $status='جدول يحتاج ربط معرّفه بمجموعة رواق'; }
                    if ($unknown) { $status.='؛ خصائص غير مدعومة: '.implode(', ',$unknown); }
                    $out[]=['post'=>$p->ID,'title'=>$p->post_title,'code'=>$m[0],'status'=>$status];
                }
            }
        } while(count($posts)===200);
        return $out;
    }
    public static function seed() {
        $asins=[];
        foreach(self::scan() as $row){
            preg_match('/\[(amazon|aawp)\b([^\]]*)\]/i',$row['code'],$m);
            $a=shortcode_parse_atts($m[2]??'');$a=is_array($a)?$a:[];
            foreach(explode(',',$a['box']??$a['link']??$a['fields']??'') as $asin){$asin=strtoupper(trim($asin));if(preg_match('/^[A-Z0-9]{10}$/',$asin)){$asins[$asin]=true;}}
        }
        $market=Riwaq_Catalog::settings()['market'];$existing=[];
        foreach(get_posts(['post_type'=>'riwaq_product','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>-1,'fields'=>'ids']) as $id){$d=Riwaq_Catalog::clean(get_post_meta($id,'_riwaq_data',true));if($d['market']===$market){$existing[$d['asin']]=true;}}
        $created=0;$failed=0;$remaining=0;
        foreach(array_keys($asins) as $asin){
            if(isset($existing[$asin])){continue;}
            if($created+$failed>=500){$remaining++;continue;}
            $id=wp_insert_post(['post_type'=>'riwaq_product','post_title'=>'Amazon '.$asin,'post_status'=>'draft'],true);
            if(is_wp_error($id)||!$id){$failed++;continue;}
            $d=Riwaq_Catalog::clean(['asin'=>$asin,'market'=>$market]);
            if(!update_post_meta($id,'_riwaq_data',wp_slash($d))){wp_delete_post($id,true);$failed++;continue;}
            $created++;
        }
        return ['created'=>$created,'failed'=>$failed,'remaining'=>$remaining];
    }
    public static function seed_action(){
        if(!current_user_can('manage_options')){wp_die('غير مصرح','',['response'=>403]);}check_admin_referer('riwaq_seed');
        $r=self::seed();set_transient('riwaq_seed_'.get_current_user_id(),'مسودات جديدة: '.$r['created'].'؛ فشل: '.$r['failed'].'؛ متبقي للدفعة التالية: '.$r['remaining'],120);
        wp_safe_redirect(admin_url('admin.php?page=riwaq-migration'));exit;
    }
    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap rw-admin" dir="rtl"><h1>فحص استبدال AAWP</h1><section class="rw-panel"><p>هذا الفحص يقرأ محتوى المقالات والصفحات دون تعديلها. أضف المنتجات بحسب ASIN، واضبط متجرها، واربط معرّفات الجداول بمجموعات رواق. راجع كل كود قبل تعطيل AAWP.</p>';
        echo '<form method="post">';wp_nonce_field('riwaq_scan');submit_button('فحص أكواد الموقع','secondary');echo '</form>';
        $notice=get_transient('riwaq_seed_'.get_current_user_id());if($notice){delete_transient('riwaq_seed_'.get_current_user_id());echo '<p role="status">'.esc_html($notice).'</p>';}
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="riwaq_seed">';wp_nonce_field('riwaq_seed');
        echo '<p>اختر المتجر الصحيح في الإعدادات أولًا. تجهيز ASIN ينشئ مسودات بعناوين مؤقتة دون أسعار أو صور، ويتجاهل المنتجات الموجودة لنفس المتجر. حتى 500 منتج في الدفعة. أكمل البيانات وانشر المنتجات قبل الانتقال.</p>';submit_button('تجهيز مسودات المنتجات من أكواد المقالات','secondary');echo '</form>';
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            check_admin_referer('riwaq_scan');$rows=self::scan();
            echo '<p>تم العثور على '.count($rows).' كود.</p><table class="widefat striped"><thead><tr><th>المقال</th><th>الكود</th><th>الإجراء المطلوب</th></tr></thead><tbody>';
            foreach($rows as $r){echo '<tr><td><a href="'.esc_url(get_edit_post_link($r['post'])).'">'.esc_html($r['title']).'</a></td><td><code dir="ltr">'.esc_html($r['code']).'</code></td><td>'.esc_html($r['status']).'</td></tr>';}
            echo '</tbody></table>';
        }
        echo '<p>الفحص لا يستورد كتالوج AAWP تلقائيًا ولا يدّعي دعم كل خاصية من خصائصه. استيراد CSV أو نقل يدوي مطلوب للصور والعناوين والمواصفات. لا يوجد اشتراك أو تفعيل ترخيص في رواق.</p></section></div>';
    }
}
