<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Widget extends WP_Widget {
    public function __construct() { parent::__construct('riwaq_products','منتجات رواق',['description'=>'منتجات أو مقارنة محفوظة في الشريط الجانبي.']); }
    public function widget($args,$instance) {
        $a=wp_parse_args($instance,['title'=>'','ids'=>'','collection'=>'','layout'=>'grid']);
        $a['columns']=1;
        $html=Riwaq_Render::shortcode($a);
        if (!$html) { return; }
        echo $args['before_widget'].$html.$args['after_widget'];
    }
    public function form($instance) {
        $i=wp_parse_args($instance,['title'=>'','ids'=>'','collection'=>'','layout'=>'grid']);
        foreach (['title'=>'العنوان','ids'=>'معرّفات المنتجات، مفصولة بفاصلة','collection'=>'معرّف مجموعة (له الأولوية)'] as $key=>$label) { echo '<p><label for="'.esc_attr($this->get_field_id($key)).'">'.esc_html($label).'</label><input class="widefat" id="'.esc_attr($this->get_field_id($key)).'" name="'.esc_attr($this->get_field_name($key)).'" value="'.esc_attr($i[$key]).'"></p>'; }
        echo '<p><label for="'.esc_attr($this->get_field_id('layout')).'">طريقة العرض</label><select class="widefat" id="'.esc_attr($this->get_field_id('layout')).'" name="'.esc_attr($this->get_field_name('layout')).'">';
        foreach (['grid'=>'بطاقات عمودية','list'=>'قائمة','box'=>'بطاقات أفقية','table'=>'جدول'] as $value=>$label) { echo '<option value="'.esc_attr($value).'" '.selected($i['layout'],$value,false).'>'.esc_html($label).'</option>'; }
        echo '</select></p>';
    }
    public function update($new,$old) {
        return ['title'=>sanitize_text_field($new['title']??''),'ids'=>implode(',',Riwaq_Catalog::ids($new['ids']??'')),'collection'=>(string)absint($new['collection']??0),'layout'=>in_array($new['layout']??'',['grid','list','box','table'],true)?$new['layout']:'grid'];
    }
}
