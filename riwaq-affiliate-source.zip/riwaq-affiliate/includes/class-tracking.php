<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Tracking {
    public static function init() {
        add_action('wp_ajax_riwaq_click',[__CLASS__,'click']);
        add_action('wp_ajax_nopriv_riwaq_click',[__CLASS__,'click']);
        add_action('riwaq_prune',[__CLASS__,'prune']);
        add_action('admin_init',function () { if (current_user_can('manage_options') && get_option('riwaq_db_version')!=='1') { self::install(); } });
    }
    public static function install() {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $table=$wpdb->prefix.'riwaq_clicks'; $collate=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            product_id bigint(20) unsigned NOT NULL,
            day date NOT NULL,
            element varchar(12) NOT NULL,
            clicks bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (product_id,day,element),
            KEY day (day)
        ) $collate;");
        update_option('riwaq_db_version','1',false);
        if (!wp_next_scheduled('riwaq_prune')) { wp_schedule_event(time()+3600,'daily','riwaq_prune'); }
    }
    public static function click() {
        if (!Riwaq_Catalog::settings()['tracking']) { wp_send_json_error(null,403); }
        // Respect browser privacy signals; do not record administrators testing their site.
        if (($_SERVER['HTTP_DNT']??'')==='1' || ($_SERVER['HTTP_SEC_GPC']??'')==='1' || current_user_can('manage_options')) { wp_send_json_success(); }
        $id=isset($_POST['id']) && is_scalar($_POST['id']) ? absint($_POST['id']) : 0;
        $element=isset($_POST['element']) && is_string($_POST['element']) ? sanitize_key($_POST['element']) : '';
        $token=isset($_POST['token']) && is_string($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        if (!in_array($element,['button','title','image','text'],true) || !Riwaq_Catalog::product($id) || !hash_equals(hash_hmac('sha256',$id.'|'.$element,wp_salt('nonce')),$token)) { wp_send_json_error(null,400); }
        // Reject explicitly cross-origin browsers. Public signed tokens remain compatible with page caches.
        if (!empty($_SERVER['HTTP_ORIGIN']) && wp_parse_url($_SERVER['HTTP_ORIGIN'],PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST)) { wp_send_json_error(null,403); }
        global $wpdb;
        $ok=$wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->prefix}riwaq_clicks (product_id,day,element,clicks) VALUES (%d,%s,%s,1) ON DUPLICATE KEY UPDATE clicks=clicks+1",$id,gmdate('Y-m-d'),$element));
        if ($ok===false) { wp_send_json_error(null,500); }
        wp_send_json_success();
    }
    public static function total() {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(clicks),0) FROM {$wpdb->prefix}riwaq_clicks WHERE day >= %s",gmdate('Y-m-d',time()-29*DAY_IN_SECONDS)));
    }
    public static function report() {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT product_id,element,SUM(clicks) AS clicks FROM {$wpdb->prefix}riwaq_clicks WHERE day >= %s GROUP BY product_id,element ORDER BY clicks DESC LIMIT 20",gmdate('Y-m-d',time()-29*DAY_IN_SECONDS)));
    }
    public static function prune() {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}riwaq_clicks WHERE day < %s",gmdate('Y-m-d',time()-90*DAY_IN_SECONDS)));
    }
}
