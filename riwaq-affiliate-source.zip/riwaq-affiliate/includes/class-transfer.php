<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Transfer {
    const HEADERS = ['title','asin','market','tag','image','price','currency','features','specs','badge','rank','list_price','rating','rating_label','review_count','prime','availability','release_date','alternates','detail_url','button_text','keywords','images'];
    public static function init() {
        add_action('admin_post_riwaq_import',[__CLASS__,'import']);
        add_action('admin_post_riwaq_export',[__CLASS__,'export']);
    }
    private static function guard($action) {
        if (!current_user_can('manage_options')) { wp_die('غير مصرح.', '', ['response'=>403]); }
        check_admin_referer($action);
    }
    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap rw-admin" dir="rtl"><header class="rw-header"><div><span class="rw-eyebrow">RIWAQ / رواق</span><h1>الاستيراد والتصدير</h1><p>انقل كتالوجك باستخدام ملفات CSV بترميز UTF-8.</p></div></header>';
        $notice=get_transient('riwaq_import_'.get_current_user_id());
        if ($notice) { delete_transient('riwaq_import_'.get_current_user_id()); echo '<div class="notice notice-info"><p>'.esc_html($notice).'</p></div>'; }
        echo '<section class="rw-panel"><h2>استيراد منتجات</h2><p>الحد الأقصى 500 منتج و2 ميغابايت. يُفحص الملف قبل الاستيراد. تُنشأ المنتجات كمسودات، وتُتجاهل المنتجات الموجودة بنفس ASIN والمتجر. الاستيراد الافتراضي لا يعدّل الموجود؛ خيار تحديث المسودات أدناه يسمح بتعبئتها من الملف.</p><p>راجع الأسعار في صفحة كل منتج قبل نشرها. الاستيراد لا يعتبر تحققًا من السعر.</p><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="riwaq_import">';
        wp_nonce_field('riwaq_import');
        echo '<label for="rw-csv">ملف CSV</label><input id="rw-csv" type="file" name="csv" accept=".csv,text/csv" required><p><label><input type="checkbox" name="update_drafts" value="1"> تحديث المسودات المطابقة لنفس ASIN والمتجر ببيانات الملف (لا يغيّر المنتجات المنشورة)</label></p>'; submit_button('فحص واستيراد كمسودات');
        echo '</form><h3>الأعمدة المطلوبة</h3><p><code>title,asin,market</code></p><h3>جميع الأعمدة المدعومة</h3><p><code>'.esc_html(implode(',',self::HEADERS)).'</code></p><p>استخدم فاصلة إنجليزية للفصل بين الأعمدة، وضع النص متعدد الأسطر داخل علامتي اقتباس. المواصفات بصيغة «المفتاح: القيمة» في كل سطر.</p><a class="button" href="'.esc_url(RIWAQ_URL.'sample-products.csv').'" download>تنزيل نموذج CSV</a></section><section class="rw-panel"><h2>تصدير الكتالوج</h2><p>يحتوي الملف على بيانات المنتجات المنشورة والمسودات والخاصة. التصدير مخصص للنقل ولا يتضمن الفئات أو المجموعات أو الإحصاءات أو تواريخ مراجعة السعر.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="riwaq_export">';
        wp_nonce_field('riwaq_export'); submit_button('تنزيل CSV','secondary'); echo '</form></section></div>';
    }
    public static function parse($path) {
        $fh=fopen($path,'r');
        if (!$fh) { return new WP_Error('csv','تعذر قراءة الملف.'); }
        $header=fgetcsv($fh,0,',','"','');
        if (!$header) { fclose($fh); return new WP_Error('csv','الملف فارغ.'); }
        $header[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$header[0]);
        $header=array_map('trim',$header);
        if (count($header)!==count(array_unique($header)) || array_diff(['title','asin','market'],$header)) { fclose($fh); return new WP_Error('csv','رأس الملف يجب أن يتضمن title,asin,market بدون أسماء أعمدة مكررة.'); }
        $rows=[]; $line=1;
        while (($values=fgetcsv($fh,0,',','"',''))!==false) {
            $line++;
            if ($values === [null] || $values === ['']) { continue; }
            if (count($values)!==count($header)) { fclose($fh); return new WP_Error('csv','عدد الأعمدة غير صحيح في السجل '.$line); }
            $r=array_combine($header,$values);
            // Undo spreadsheet formula protection from our own exports.
            foreach ($r as &$value) { if (preg_match('/^\'\s*[=+@\-\t\r]/',$value)) { $value=substr($value,1); } }
            unset($value);
            if (trim($r['title'])==='' || !preg_match('/^[A-Z0-9]{10}$/i',trim($r['asin'])) || !isset(Riwaq_Catalog::markets()[trim($r['market'])])) { fclose($fh); return new WP_Error('csv','عنوان أو ASIN أو متجر غير صالح في السجل '.$line); }
            if (isset($r['price']) && trim($r['price'])!=='' && !preg_match('/^\d{1,9}(\.\d{1,2})?$/',trim($r['price']))) { fclose($fh); return new WP_Error('csv','صيغة السعر غير صحيحة في السجل '.$line); }
            if (isset($r['image']) && trim($r['image'])!=='' && (!wp_http_validate_url(trim($r['image'])) || wp_parse_url(trim($r['image']),PHP_URL_SCHEME)!=='https')) { fclose($fh); return new WP_Error('csv','رابط الصورة يجب أن يكون HTTPS صالحًا في السجل '.$line); }
            $r=array_map('trim',$r);
            $rows[]=['title'=>sanitize_text_field($r['title']),'data'=>Riwaq_Catalog::clean($r)];
            if (count($rows)>500) { fclose($fh); return new WP_Error('csv','الحد الأقصى 500 منتج في الملف.'); }
        }
        fclose($fh);
        return $rows ?: new WP_Error('csv','لا توجد منتجات في الملف.');
    }
    private static function finish($message) {
        set_transient('riwaq_import_'.get_current_user_id(),$message,120);
        wp_safe_redirect(admin_url('admin.php?page=riwaq-transfer')); exit;
    }
    public static function import() {
        self::guard('riwaq_import');
        $file=$_FILES['csv']??null;
        if (!$file || !isset($file['error'],$file['tmp_name'],$file['name'],$file['size']) || !is_string($file['tmp_name']) || !is_string($file['name']) || $file['error']!==UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name']) || $file['size']>2*1024*1024 || strtolower(pathinfo($file['name'],PATHINFO_EXTENSION))!=='csv') { self::finish('اختر ملف CSV صالحًا بحجم لا يتجاوز 2 ميغابايت.'); }
        $rows=self::parse($file['tmp_name']);
        if (is_wp_error($rows)) { self::finish($rows->get_error_message().' لم يتم استيراد أي منتج.'); }
        // Atomic option lock prevents simultaneous imports from creating duplicates.
        $lock=get_option('riwaq_import_lock',0);
        if ($lock && time()-(int)$lock>300) { delete_option('riwaq_import_lock'); }
        if (!add_option('riwaq_import_lock',time(),'','no')) { self::finish('هناك استيراد قيد التنفيذ. حاول لاحقًا.'); }
        $known=[];
        foreach (get_posts(['post_type'=>'riwaq_product','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>-1,'fields'=>'ids']) as $id) {
            $d=(array)get_post_meta($id,'_riwaq_data',true); $known[($d['market']??'').'|'.($d['asin']??'')]=$id;
        }
        $created=0; $skipped=0; $failed=0; $updated=0;
        foreach ($rows as $row) {
            $d=$row['data']; $key=$d['market'].'|'.$d['asin'];
            if (isset($known[$key])) {
                $id=$known[$key];
                if (($_POST['update_drafts']??'')==='1' && get_post_status($id)==='draft') {
                    $d['verified']=0;
                    $saved=wp_update_post(wp_slash(['ID'=>$id,'post_title'=>$row['title'],'menu_order'=>$d['rank']]),true);
                    if(is_wp_error($saved)){$failed++;continue;}
                    update_post_meta($id,'_riwaq_data',wp_slash($d));
                    if(get_post_meta($id,'_riwaq_data',true)===$d){$updated++;}else{$failed++;}
                }else{$skipped++;}
                continue;
            }
            $id=wp_insert_post(wp_slash(['post_type'=>'riwaq_product','post_status'=>'draft','post_title'=>$row['title'],'menu_order'=>$d['rank']]),true);
            if (is_wp_error($id) || !$id) { $failed++; continue; }
            $d['verified']=0;
            if (!update_post_meta($id,'_riwaq_data',wp_slash($d))) { wp_delete_post($id,true); $failed++; continue; }
            $known[$key]=$id; $created++;
        }
        delete_option('riwaq_import_lock');
        self::finish('تم إنشاء '.$created.' مسودة. تم تجاهل '.$skipped.' منتج مكرر. تم تحديث '.$updated.' مسودة. تعذر حفظ '.$failed.' منتج.');
    }
    public static function csv_cell($value) {
        $value=(string)$value;
        return preg_match('/^[\s]*[=+@\-\t\r]/',$value) ? "'".$value : $value;
    }
    public static function export() {
        self::guard('riwaq_export');
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="riwaq-products.csv"');
        $out=fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF"); fputcsv($out,self::HEADERS,',','"','');
        $page=1;
        do {
            $posts=get_posts(['post_type'=>'riwaq_product','post_status'=>['publish','draft','private','pending','future'],'posts_per_page'=>200,'paged'=>$page++,'orderby'=>'ID','order'=>'ASC']);
            foreach ($posts as $post) {
                $d=wp_parse_args((array)get_post_meta($post->ID,'_riwaq_data',true),Riwaq_Catalog::defaults()); $d['title']=$post->post_title;
                $row=[]; foreach (self::HEADERS as $key) { $row[]=self::csv_cell($d[$key]??''); } fputcsv($out,$row,',','"','');
            }
        } while (count($posts)===200);
        fclose($out); exit;
    }
}
