<?php
if (!defined('ABSPATH')) { exit; }

final class Riwaq_Catalog {
    public static function markets() {
        return ['US'=>'amazon.com','UK'=>'amazon.co.uk','DE'=>'amazon.de','FR'=>'amazon.fr','ES'=>'amazon.es','IT'=>'amazon.it','CA'=>'amazon.ca','JP'=>'amazon.co.jp','IN'=>'amazon.in','AU'=>'amazon.com.au','AE'=>'amazon.ae','SA'=>'amazon.sa','EG'=>'amazon.eg','NL'=>'amazon.nl','BR'=>'amazon.com.br','MX'=>'amazon.com.mx','SE'=>'amazon.se','PL'=>'amazon.pl','BE'=>'amazon.com.be','SG'=>'amazon.sg','TR'=>'amazon.com.tr'];
    }
    public static function settings() {
        $s=wp_parse_args(get_option('riwaq_settings', []), ['market'=>'US','tag'=>'','button'=>'عرض على أمازون','disclosure'=>'قد نحصل على عمولة عند الشراء عبر الروابط في هذه الصفحة.','color'=>'#087f70','info_color'=>'#087f70','tracking'=>0,'price_days'=>7,'new_tab'=>1,'language'=>'auto','style'=>'clean','compatibility'=>1,'compatibility_replace'=>1,'market_selector'=>0]);
        $s['language_mode']=$s['language'];
        if($s['language']==='auto'){$code=strtolower(substr((string)get_option('WPLANG','en_US'),0,2));$s['language']=in_array($code,['ar','fr','en'],true)?$code:'en';}
        return $s;
    }
    public static function register() {
        $caps = ['edit_post'=>'manage_options','read_post'=>'manage_options','delete_post'=>'manage_options','edit_posts'=>'manage_options','edit_others_posts'=>'manage_options','publish_posts'=>'manage_options','read_private_posts'=>'manage_options','delete_posts'=>'manage_options','delete_private_posts'=>'manage_options','delete_published_posts'=>'manage_options','delete_others_posts'=>'manage_options','edit_private_posts'=>'manage_options','edit_published_posts'=>'manage_options','create_posts'=>'manage_options'];
        register_post_type('riwaq_product', ['labels'=>['name'=>riwaq_admin_text('منتجات رواق','Produits Riwaq','Riwaq Products'),'singular_name'=>riwaq_admin_text('منتج','Produit','Product'),'add_new_item'=>riwaq_admin_text('إضافة منتج','Ajouter un produit','Add product'),'edit_item'=>riwaq_admin_text('تعديل المنتج','Modifier le produit','Edit product'),'search_items'=>riwaq_admin_text('بحث المنتجات','Rechercher des produits','Search products'),'not_found'=>riwaq_admin_text('لا توجد منتجات','Aucun produit','No products found')], 'public'=>false,'show_ui'=>true,'show_in_menu'=>'riwaq','supports'=>['title'],'capabilities'=>$caps,'map_meta_cap'=>false]);
        register_post_type('riwaq_collection', ['labels'=>['name'=>riwaq_admin_text('المقارنات والقوائم','Comparaisons et listes','Comparisons and lists'),'singular_name'=>riwaq_admin_text('مجموعة','Collection','Collection'),'add_new_item'=>riwaq_admin_text('إنشاء مقارنة أو قائمة','Créer une comparaison ou une liste','Create comparison or list'),'edit_item'=>riwaq_admin_text('تعديل المجموعة','Modifier la collection','Edit collection')], 'public'=>false,'show_ui'=>true,'show_in_menu'=>'riwaq','supports'=>['title'],'capabilities'=>$caps,'map_meta_cap'=>false]);
        register_taxonomy('riwaq_category', 'riwaq_product', ['label'=>'فئات المنتجات','hierarchical'=>true,'public'=>false,'show_ui'=>true,'show_admin_column'=>true,'capabilities'=>['manage_terms'=>'manage_options','edit_terms'=>'manage_options','delete_terms'=>'manage_options','assign_terms'=>'manage_options']]);
    }
    public static function defaults() {
        return ['asin'=>'','market'=>self::settings()['market'],'tag'=>'','image'=>'','price'=>'','currency'=>'USD','features'=>'','specs'=>'','badge'=>'','rank'=>0,'verified'=>0,'list_price'=>'','rating'=>'','rating_label'=>'تقييم المحرر','review_count'=>0,'prime'=>0,'availability'=>'unknown','release_date'=>'','alternates'=>'','detail_url'=>'','button_text'=>'','keywords'=>'','images'=>''];
    }
    public static function clean($raw) {
        $raw = is_array($raw) ? $raw : [];
        $d = self::defaults();
        foreach ($d as $key=>$value) {
            $v = isset($raw[$key]) && is_scalar($raw[$key]) ? (string)$raw[$key] : (string)$value;
            $d[$key] = in_array($key, ['features','specs','alternates','images'], true) ? sanitize_textarea_field($v) : sanitize_text_field($v);
        }
        $d['asin'] = preg_match('/^[A-Z0-9]{10}$/', strtoupper($d['asin'])) ? strtoupper($d['asin']) : '';
        $d['market'] = isset(self::markets()[$d['market']]) ? $d['market'] : self::settings()['market'];
        $d['image'] = esc_url_raw($d['image'], ['https']);
        $d['tag'] = preg_replace('/[^a-zA-Z0-9_-]/', '', $d['tag']);
        $d['price'] = preg_match('/^\d{1,9}(\.\d{1,2})?$/', $d['price']) ? $d['price'] : '';
        $d['currency'] = preg_match('/^[A-Z]{3}$/', strtoupper($d['currency'])) ? strtoupper($d['currency']) : 'USD';
        $d['rank'] = min(999999, absint($d['rank']));
        $d['verified'] = min(time(), absint($d['verified']));
        $d['list_price'] = preg_match('/^\d{1,9}(\.\d{1,2})?$/', $d['list_price']) ? $d['list_price'] : '';
        $d['rating'] = is_numeric($d['rating']) && (float)$d['rating'] >= 0 && (float)$d['rating'] <= 5 ? (string)(float)$d['rating'] : '';
        $d['review_count'] = min(99999999, absint($d['review_count']));
        $d['prime'] = empty($d['prime']) ? 0 : 1;
        $d['availability'] = in_array($d['availability'], ['unknown','available','unavailable'], true) ? $d['availability'] : 'unknown';
        $date = DateTime::createFromFormat('!Y-m-d', $d['release_date']);
        $d['release_date'] = $date && $date->format('Y-m-d') === $d['release_date'] ? $d['release_date'] : '';
        $d['detail_url'] = esc_url_raw($d['detail_url'], ['https','http']);
        $d['images'] = implode("\n", array_slice(array_filter(array_map(function ($u) { return esc_url_raw(trim($u), ['https']); }, explode("\n", $d['images']))), 0, 5));
        $alternates = [];
        foreach (array_slice(explode("\n", $d['alternates']), 0, 30) as $line) {
            $parts = array_map('trim', explode(':', $line, 3));
            if (count($parts) >= 2 && isset(self::markets()[$parts[0]]) && preg_match('/^[A-Z0-9]{10}$/i', $parts[1])) {
                $alternates[$parts[0]] = $parts[0].':'.strtoupper($parts[1]).':'.preg_replace('/[^a-zA-Z0-9_-]/', '', $parts[2] ?? '');
            }
        }
        $d['alternates'] = implode("\n", $alternates);
        return $d;
    }
    public static function product($id) {
        $post = get_post(absint($id));
        if (!$post || $post->post_type !== 'riwaq_product' || $post->post_status !== 'publish' || $post->post_password !== '') { return null; }
        $data=self::clean((array)get_post_meta($post->ID, '_riwaq_data', true));
        $source=(array)get_post_meta($post->ID,'_riwaq_source',true);
        $checked=($source['kind']??'')==='amazon_page' && empty($source['paused']) ? min(time(),absint($source['checked']??0)) : 0;
        if($checked && time()-$checked>7*DAY_IN_SECONDS){$data['rating']='';$data['review_count']=0;}
        $source_price=false;
        if($checked && $data['price']==='' && time()-$checked<DAY_IN_SECONDS && preg_match('/^\d{1,9}\.\d{2}$/',(string)($source['price']??'')) && ($source['currency']??'')==='EUR'){$data['price']=$source['price'];$data['currency']='EUR';$data['verified']=$checked;$source_price=true;}
        return array_merge($data, ['id'=>$post->ID, 'title'=>$post->post_title,'published'=>$post->post_date,'source_checked'=>$checked,'source_price'=>$source_price,'price_from'=>$source_price && !empty($source['price_from'])]);
    }
    public static function url($p) {
        if (empty($p['asin']) || !isset(self::markets()[$p['market']])) { return ''; }
        $s = self::settings();
        // A global tag only applies to its own marketplace.
        $tag = $p['tag'] ?: ($p['market'] === $s['market'] ? $s['tag'] : '');
        $url = 'https://www.' . self::markets()[$p['market']] . '/dp/' . rawurlencode($p['asin']) . '/';
        return $tag ? add_query_arg('tag', $tag, $url) : $url;
    }
    public static function ids($text) {
        return array_slice(array_values(array_unique(array_filter(array_map('absint', explode(',', (string)$text))))), 0, 20);
    }
    public static function specs($text) {
        $out = [];
        foreach (array_slice(explode("\n", $text), 0, 30) as $line) {
            $parts = explode(':', $line, 2);
            if (count($parts) === 2 && trim($parts[0]) !== '') { $out[trim($parts[0])] = trim($parts[1]); }
        }
        return $out;
    }
    public static function price($p) {
        $days = max(1, (int)self::settings()['price_days']);
        if ($p['price'] === '' || !$p['verified'] || time() - (int)$p['verified'] > $days * DAY_IN_SECONDS) { return ''; }
        return number_format_i18n((float)$p['price'], 2) . ' ' . ($p['currency']==='EUR'?'€':$p['currency']);
    }
}
