=== Riwaq Affiliate — رواق أفلييت ===
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 2.5.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Arabic-first affiliate product catalog with responsive cards, lists, comparison tables, Gutenberg block, CSV transfer and optional aggregate click analytics.

== Description ==
Version 2.1 adds optional public Amazon product page fetching for title, image, score, ratings count and features. No Amazon API is used. Fetching can fail or be blocked, and prices are not fetched. Data includes provenance and date; stale fetched ratings hide after 7 days. Manual edits pause source updates.

Version 2 adds manual ratings, offers, alternate stores, sorting/filtering, widgets, JSON catalog backup, and optional legacy AAWP shortcode compatibility with a read-only scanner and draft scaffolding. No Amazon API, subscription, automatic Amazon data or guaranteed full AAWP parity.

Original standalone plugin. Not affiliated with AAWP or Amazon. This release uses manually entered product information; it does not connect to AAWP's paid service.

* Product catalog and categories, administrator-only editing.
* Horizontal cards, responsive grids, numbered lists, comparison tables, text links and individual data fields.
* Saved product collections with selectable products and ordered IDs.
* Gutenberg dynamic block and [riwaq] shortcodes.
* Marketplace-specific Amazon links and partner tags.
* CSV import with complete prevalidation, duplicate skipping and draft-only creation.
* CSV export protected against spreadsheet formula injection.
* Optional aggregate click counts, without visitor IDs, IP storage or cookies.
* Manual price verification date and configurable expiry.
* Arabic UI and RTL-compatible layouts. Arabic, French and English frontend labels.

== Installation ==
Upload riwaq-affiliate.zip through Plugins > Add New > Upload Plugin. Activate, then open رواق أفلييت > الإعدادات. Set a marketplace and partner tag. Add products, verify their data, and publish them. Insert the منتجات رواق block or a shortcode into a post.

== Shortcodes ==
[riwaq ids="12"]
[riwaq ids="12,34,56" layout="grid" columns="3" title="منتجات مختارة"]
[riwaq ids="12,34" layout="table"]
[riwaq ids="12,34" layout="list"]
[riwaq collection="90"]
[riwaq category="headphones" order="newest" limit="5" layout="grid"]
[riwaq category="headphones" order="manual" layout="list"]
[riwaq ids="12" layout="link" label="شاهد المنتج"]
[riwaq ids="12" layout="field" field="price"]

Only published, non-password-protected products and collections appear publicly. Maximum 20 products per shortcode. Explicit IDs preserve input order. Category queries default to manual order (smallest rank first). Newest means catalog publication date, not Amazon release date. A saved collection overrides IDs, layout, columns and title.

Link and field shortcodes do not emit an automatic disclosure; add the appropriate disclosure near them in your article.

== Data and privacy ==
Product metadata and settings remain after deactivation or deletion to prevent accidental data loss. Click aggregates are retained for 90 days while WordPress cron runs. Tracking is disabled by default, skips administrators, and respects browser DNT/GPC signals. It records product ID, UTC day, clicked element and count, never revenue or unique visitors. Public analytics can be inflated by bots; they are advisory, not audit-grade. Image requests go directly to the image host; Amazon is opened only when readers follow a link.

Multisite: activate separately on each site. Network-wide rollout is not tested.

== Limitations ==
No Amazon API, automatic bestsellers/new releases, geolocation routing, license system or remote update service. Optional public product-page import checks ASIN identity and imports images, ratings and rating counts; it cannot guarantee access or availability. Missing data remains empty. Manual prices require editorial verification. Legacy comparison tables require a collection mapped to the original table ID.

== Changelog ==
= 2.5.0 =
* Support amazon table aliases. Improve catalog lookup and refresh batching. French cards omit descriptions, store labels and retrieval dates, and show rating counts in a badge.

= 2.0.0 =
* Expanded manual product catalog, display options, legacy shortcode mapping, draft scaffolding, CSV draft updates and JSON catalog transfer.

= 1.0.0 =
Initial manual catalog release.

