(function () {
  'use strict';
  document.addEventListener('DOMContentLoaded', function () {
    const ids = document.getElementById('rw-gen-ids');
    const layout = document.getElementById('rw-gen-layout');
    const code = document.getElementById('rw-gen-code');
    function update() {
      const clean = ids.value.split(',').map(v => parseInt(v,10)).filter(v => v > 0).slice(0,20).join(',');
      code.value = '[riwaq ids="' + clean + '" layout="' + layout.value + '"]';
    }
    if (ids) { ids.addEventListener('input',update); layout.addEventListener('change',update); }
    document.getElementById('rw-copy')?.addEventListener('click', async function () {
      const status = document.getElementById('rw-copy-status');
      try { await navigator.clipboard.writeText(code.value); status.textContent = ' تم النسخ'; }
      catch (_) { code.select(); status.textContent = ' اضغط Ctrl+C لنسخ الكود'; }
    });
    document.querySelectorAll('.rw-add-product').forEach(button => button.addEventListener('click', function () {
      const input = document.getElementById('rw-collection-ids');
      const values = input.value.split(',').map(v => v.trim()).filter(Boolean);
      if (!values.includes(button.dataset.id) && values.length < 20) { values.push(button.dataset.id); }
      input.value = values.join(',');
    }));
    document.getElementById('rw-media')?.addEventListener('click', function () {
      const frame = wp.media({title:'اختر صورة المنتج',library:{type:'image'},multiple:false});
      frame.on('select', function () { document.getElementById('rw-image').value = frame.state().get('selection').first().toJSON().url; });
      frame.open();
    });
  });
})();
