(function () {
  'use strict';
  if (navigator.doNotTrack === '1' || navigator.globalPrivacyControl) return;
  const recent = new Map();
  document.addEventListener('click', function (event) {
    const link = event.target.closest?.('a[data-riwaq-id]');
    if (!link || !window.riwaqTracking || !event.isTrusted) return;
    const key = link.dataset.riwaqId + ':' + link.dataset.riwaqElement;
    const now = Date.now();
    if (now - (recent.get(key) || 0) < 2000) return;
    recent.set(key, now);
    const body = new URLSearchParams({action:'riwaq_click',id:link.dataset.riwaqId,element:link.dataset.riwaqElement,token:link.dataset.riwaqToken});
    // Direct Amazon links always work, including when JavaScript or analytics is blocked.
    if (!navigator.sendBeacon || !navigator.sendBeacon(riwaqTracking.url, body)) {
      fetch(riwaqTracking.url, {method:'POST',body,credentials:'same-origin',keepalive:true}).catch(function () {});
    }
  });
})();
