(function () {
  'use strict';
  let preference = '';
  function change(id, market) {
    document.querySelectorAll('a[data-riwaq-market-links]').forEach(function (link) {
      const scope = link.closest('[data-riwaq-product]');
      if (!scope || scope.dataset.riwaqProduct !== id) return;
      let map;
      try { map = JSON.parse(link.dataset.riwaqMarketLinks); } catch (_) { return; }
      const target = map[market];
      if (!target) return;
      // Maps are produced server-side from validated ASINs and allowlisted Amazon hosts.
      const url = new URL(target);
      if (url.protocol !== 'https:') return;
      link.href = target;
      document.querySelectorAll('[data-riwaq-product="' + id + '"] [data-market]').forEach(function (price) {
        price.hidden = price.dataset.market !== market;
      });
      document.querySelectorAll('[data-riwaq-product="' + id + '"] .riwaq__market').forEach(e => { e.textContent = 'Amazon · ' + market; });
    });
    document.querySelectorAll('.riwaq__store[data-product="' + id + '"]').forEach(select => {
      if (Array.from(select.options).some(option => option.value === market)) select.value = market;
    });
  }
  function initialize() {
    document.querySelectorAll('.riwaq__store').forEach(function (select) {
      select.addEventListener('change', function () { preference = select.value; change(select.dataset.product, select.value); });
    });
    if (!window.riwaqMarkets) return;
    fetch(riwaqMarkets.url + '?action=riwaq_visitor_market', {credentials:'same-origin',cache:'no-store'})
      .then(r => r.json()).then(function (result) {
        if (preference || !result.success || !result.data.market) return;
        document.querySelectorAll('.riwaq__store').forEach(select => change(select.dataset.product,result.data.market));
      }).catch(function () {});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();
