<?php
/**
 * Plugin Name: Riwaq Affiliate — رواق أفلييت
 * Description: كتالوج منتجات أفلييت، بطاقات وقوائم وجداول مقارنة، استيراد CSV وإحصاءات نقرات اختيارية.
 * Version: 2.5.1
 * Requires at least: 6.5
 * Requires PHP: 8.0
 * Author: Riwaq
 * License: GPL-2.0-or-later
 * Text Domain: riwaq-affiliate
 */
if (!defined('ABSPATH')) { exit; }
define('RIWAQ_VERSION', '2.5.1');
define('RIWAQ_PATH', plugin_dir_path(__FILE__));
define('RIWAQ_URL', plugin_dir_url(__FILE__));
function riwaq_admin_language(){ $code=strtolower(substr((string)get_option('WPLANG','en_US'),0,2)); return in_array($code,['ar','fr','en'],true)?$code:'en'; }
function riwaq_admin_text($ar,$fr,$en){ $lang=riwaq_admin_language(); return $lang==='fr'?$fr:($lang==='ar'?$ar:$en); }
require_once RIWAQ_PATH . 'includes/class-catalog.php';
require_once RIWAQ_PATH . 'includes/class-render.php';
require_once RIWAQ_PATH . 'includes/class-admin.php';
require_once RIWAQ_PATH . 'includes/class-transfer.php';
require_once RIWAQ_PATH . 'includes/class-tracking.php';
require_once RIWAQ_PATH . 'includes/class-display.php';
require_once RIWAQ_PATH . 'includes/class-compatibility.php';
require_once RIWAQ_PATH . 'includes/class-widget.php';
require_once RIWAQ_PATH . 'includes/class-backup.php';
require_once RIWAQ_PATH . 'includes/class-source.php';
add_action('init', ['Riwaq_Catalog', 'register']);
add_action('init', ['Riwaq_Render', 'register']);
Riwaq_Admin::init();
Riwaq_Transfer::init();
Riwaq_Tracking::init();
Riwaq_Display::init();
Riwaq_Compatibility::init();
Riwaq_Backup::init();
Riwaq_Source::init();
add_action('widgets_init', function () { register_widget('Riwaq_Widget'); });
register_activation_hook(__FILE__, ['Riwaq_Tracking', 'install']);
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('riwaq_prune'); wp_clear_scheduled_hook('riwaq_source_refresh'); });
