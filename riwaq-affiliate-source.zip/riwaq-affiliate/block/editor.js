(function (wp) {
  'use strict';
  const el = wp.element.createElement;
  wp.blocks.registerBlockType('riwaq/products', {
    apiVersion: 3,
    title: 'منتجات رواق',
    category: 'widgets',
    icon: 'cart',
    attributes: {
      ids: {type:'string',default:''},
      collection: {type:'string',default:''},
      layout: {type:'string',default:'grid'},
      columns: {type:'number',default:3},
      title: {type:'string',default:''},
      category: {type:'string',default:''},
      search: {type:'string',default:''},
      order: {type:'string',default:'manual'},
      orderby: {type:'string',default:''},
      direction: {type:'string',default:'ASC'},
      limit: {type:'number',default:20},
      language: {type:'string',default:''},
      style: {type:'string',default:''},
      min_price: {type:'string',default:''},
      max_price: {type:'string',default:''},
      currency: {type:'string',default:''}
    },
    supports: {html:false},
    edit: function (props) {
      const a = props.attributes;
      const field = (key, label) => el(wp.components.TextControl, {label, value: a[key], onChange: v => props.setAttributes({[key]: v})});
      return el('div', wp.blockEditor.useBlockProps(),
        el(wp.blockEditor.InspectorControls, {}, el(wp.components.PanelBody, {title:'إعدادات العرض'},
          field('ids', 'معرّفات المنتجات، مفصولة بفاصلة إنجليزية'),
          field('collection', 'معرّف مجموعة محفوظة (له الأولوية)'),
          field('title', 'عنوان القسم'),
          field('category', 'رابط الفئة المختصر (عند عدم تحديد معرّفات)'),
          field('search', 'بحث داخل الكتالوج'),
          el(wp.components.SelectControl, {label:'نوع القائمة',value:a.order||'manual',options:[{label:'اختيارات مرتبة يدويًا',value:'manual'},{label:'أحدث إضافة للكتالوج',value:'newest'},{label:'تاريخ إصدار يدوي',value:'release'}],onChange:v=>props.setAttributes({order:v})}),
          el(wp.components.SelectControl, {label:'فرز المنتجات',value:a.orderby||'',options:[{label:'الترتيب الافتراضي',value:''},{label:'العنوان',value:'title'},{label:'السعر',value:'price'},{label:'التقييم',value:'rating'},{label:'الترتيب اليدوي',value:'rank'},{label:'نسبة الخصم',value:'percentage_saved'}],onChange:v=>props.setAttributes({orderby:v})}),
          el(wp.components.SelectControl, {label:'اتجاه الفرز',value:a.direction||'ASC',options:[{label:'تصاعدي',value:'ASC'},{label:'تنازلي',value:'DESC'}],onChange:v=>props.setAttributes({direction:v})}),
          el(wp.components.SelectControl, {label:'اللغة',value:a.language||'',options:[{label:'لغة الإعدادات',value:''},{label:'العربية',value:'ar'},{label:'Français',value:'fr'},{label:'English',value:'en'}],onChange:v=>props.setAttributes({language:v})}),
          el(wp.components.SelectControl, {label:'التصميم',value:a.style||'',options:[{label:'تصميم الإعدادات',value:''},{label:'نظيف',value:'clean'},{label:'داكن',value:'dark'},{label:'مضغوط',value:'compact'}],onChange:v=>props.setAttributes({style:v})}),
          field('min_price','الحد الأدنى للسعر المراجع'),field('max_price','الحد الأقصى للسعر المراجع'),field('currency','رمز العملة للتصفية (موصى به عند مقارنة الأسعار)'),
          el(wp.components.RangeControl,{label:'عدد المنتجات',min:1,max:20,value:a.limit||20,onChange:v=>props.setAttributes({limit:v})}),
          el(wp.components.SelectControl, {label:'التصميم', value:a.layout, options:[{label:'شبكة',value:'grid'},{label:'بطاقات أفقية',value:'box'},{label:'قائمة',value:'list'},{label:'جدول مقارنة',value:'table'}], onChange:v=>props.setAttributes({layout:v})}),
          el(wp.components.RangeControl,{label:'الأعمدة',min:1,max:4,value:a.columns,onChange:v=>props.setAttributes({columns:v})})
        )),
        a.ids || a.collection || a.category || a.search ? el(wp.serverSideRender.default || wp.serverSideRender, {block:'riwaq/products',attributes:a}) : el(wp.components.Placeholder, {icon:'cart',label:'منتجات رواق'}, 'أضف منتجات وانشرها من قائمة رواق، ثم أدخل معرّفاتها في إعدادات هذه الكتلة.')
      );
    },
    save: function () { return null; }
  });
})(window.wp);
