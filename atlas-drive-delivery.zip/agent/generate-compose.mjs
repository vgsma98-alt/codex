import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const project = process.argv[2] || 'n8n';
const service = process.argv[3] || 'atlas-agent';
if (!/^[a-z0-9][a-z0-9_-]*$/.test(project) || !/^[a-z0-9][a-z0-9_-]*$/.test(service)) {
  throw new Error('Project and service names may contain lowercase letters, numbers, _ and -.');
}
const source = await readFile(join(here, 'agent.mjs'), 'utf8');
// Compose turns $$ into one literal dollar sign. Keep JS template strings and regex intact.
const content = source.replace(/\$/g, () => '$$').trimEnd()
  .split('\n').map((line) => `      ${line}`).join('\n');
const compose = `services:
  agent:
    image: node:24-alpine
    restart: unless-stopped
    command: ["node", "/app/agent.mjs"]
    environment:
      TELEGRAM_BOT_TOKEN: \${TELEGRAM_BOT_TOKEN}
      TELEGRAM_WEBHOOK_SECRET: \${TELEGRAM_WEBHOOK_SECRET}
      TELEGRAM_ALLOWED_CHAT_ID: \${TELEGRAM_ALLOWED_CHAT_ID}
      WORDPRESS_SITE_URL: \${WORDPRESS_SITE_URL}
      WORDPRESS_SITE_SECRET: \${WORDPRESS_SITE_SECRET}
      AI_API_KEY: \${AI_API_KEY}
      AI_BASE_URL: \${AI_BASE_URL}
      AI_MODEL: \${AI_MODEL}
      PUBLIC_BASE_URL: \${PUBLIC_BASE_URL}
    configs:
      - source: atlas_agent_mjs
        target: /app/agent.mjs
    volumes:
      - atlas_agent_data:/data
    expose:
      - "3000"
    networks:
      easypanel:
        aliases:
          - ${project}_${service}_agent
volumes:
  atlas_agent_data:
networks:
  easypanel:
    external: true
    name: easypanel
configs:
  atlas_agent_mjs:
    content: |
${content}
`;
await writeFile(join(here, 'compose.easypanel.yml'), compose);
console.log('Created compose.easypanel.yml');
