import { readFile } from 'node:fs/promises';
import { runInNewContext } from 'node:vm';
import assert from 'node:assert/strict';

const source = await readFile(new URL('./agent.mjs', import.meta.url), 'utf8');
const functions = source.slice(source.indexOf('function normalize'), source.indexOf('async function handle'));
const imagePlan = runInNewContext(`${functions}; imagePlan`);
const context = {
  menu: [
    { id: 'berline', name: 'Berline Confort' },
    { id: 'suv', name: 'SUV Horizon' },
  ],
  slides: [
    { id: 'hero', title: 'La ville à votre rythme.', vehicle: 'berline' },
    { id: 'atlas', title: 'Plus loin, en toute liberté.', vehicle: 'suv' },
  ],
};

assert.equal(imagePlan('غير صورة Berline Confort', context).arguments.item_id, 'berline');
assert.equal(imagePlan('غير صورة السلايدر الثاني', context).arguments.slide_id, 'atlas');
assert.equal(imagePlan('غير صورة غير محددة', context), null);
console.log('Image routing passed');
