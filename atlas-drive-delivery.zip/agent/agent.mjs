import { createServer } from 'node:http';
import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';

const env = process.env;
const token = env.TELEGRAM_BOT_TOKEN;
const allowedChat = String(env.TELEGRAM_ALLOWED_CHAT_ID);
const site = env.WORDPRESS_SITE_URL;
const secret = env.WORDPRESS_SITE_SECRET;
const webhookSecret = env.TELEGRAM_WEBHOOK_SECRET;
const aiBase = env.AI_BASE_URL.replace(/\/$/, '');
const aiModel = env.AI_MODEL;
const aiKey = env.AI_API_KEY;
const telegramApi = `https://api.telegram.org/bot${token}`;
const pendingPath = '/data/pending.json';

await mkdir('/data', { recursive: true });
let pending = {};
try { pending = JSON.parse(await readFile(pendingPath, 'utf8')); } catch {}
const savePending = () => writeFile(pendingPath, JSON.stringify(pending));
const recentPhotos = {};

async function telegram(method, data) {
  const response = await fetch(`${telegramApi}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(data),
  });
  const result = await response.json();
  if (!result.ok) throw Error(`Telegram ${method}: ${result.description}`);
  return result.result;
}

const send = (chatId, message, extra = {}) =>
  telegram('sendMessage', { chat_id: chatId, text: message, ...extra });

async function wordpress(method, route, body) {
  const timestamp = String(Math.floor(Date.now() / 1000));
  const nonce = randomUUID();
  const raw = body ? JSON.stringify(body) : '';
  const signature = createHmac('sha256', secret)
    .update([timestamp, nonce, method, route, raw].join('\n')).digest('hex');
  const response = await fetch(`${site}/wp-json${route}`, {
    method,
    headers: {
      'content-type': 'application/json',
      'x-aia-timestamp': timestamp,
      'x-aia-nonce': nonce,
      'x-aia-signature': signature,
    },
    body: method === 'POST' ? raw : undefined,
  });
  const result = await response.json();
  if (!response.ok) throw Error(result.message || `WordPress ${response.status}`);
  return result;
}

const prompt = 'Convert Arabic or French requests for a French car rental WordPress site into ONE safe JSON command. Return only JSON: {"action":"update_site_info|update_menu_item|update_slider_item|update_post|replace_text|create_post|undo","summary_ar":"precise Arabic summary","arguments":{}}. Site fields: site_title,tagline,phone,email,address,whatsapp. Vehicle action update_menu_item: item_id from context and only explicitly requested name,description,price,badge,category,gear,seats,bags. Slider action update_slider_item: slide_id from context and only explicitly requested kicker,title,description,label,vehicle. For attached photo, select the correct vehicle or slide; server supplies image bytes. Posts: update_post post_id/title/content/excerpt/status, replace_text post_id/old_text/new_text, create_post post_type/title/content/status. Undo: action_id optional. Select IDs only from context. Never invent facts. Refuse ambiguity or unsupported/security actions with {"error":"Arabic explanation"}. Never return code or plugin/user/file actions.';

async function plan(text, context) {
  const response = await fetch(`${aiBase}/chat/completions`, {
    method: 'POST',
    headers: { authorization: `Bearer ${aiKey}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      model: aiModel,
      temperature: 0,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: prompt },
        { role: 'user', content: `Site context: ${JSON.stringify(context)}\nRequest: ${text}` },
      ],
    }),
  });
  const result = await response.json();
  if (!response.ok) throw Error(`AI provider ${response.status}`);
  const command = JSON.parse(result.choices[0].message.content
    .replace(/^```(?:json)?/i, '').replace(/```$/, '').trim());
  if (command.error) return command;
  const actions = ['update_site_info', 'update_menu_item', 'update_slider_item', 'update_post', 'replace_text', 'create_post', 'undo'];
  if (!actions.includes(command.action) || !command.arguments || !command.summary_ar) {
    throw Error('Invalid AI plan');
  }
  return command;
}

async function photoData(photos) {
  for (const photo of [...photos].reverse()) {
    const file = await telegram('getFile', { file_id: photo.file_id });
    const response = await fetch(`https://api.telegram.org/file/bot${token}/${file.file_path}`);
    if (!response.ok) throw Error('تعذر تنزيل الصورة من تيليغرام');
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length <= 5 * 1024 * 1024) {
      return {
        filename: 'telegram-image',
        mime_type: photo.mime_type || 'image/jpeg',
        data_base64: bytes.toString('base64'),
      };
    }
  }
  throw Error('الصورة أكبر من 5 ميغابايت؛ أرسل نسخة أصغر');
}

function normalize(value) {
  return String(value || '').toLocaleLowerCase('fr').normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

function imagePlan(text, context) {
  const normalized = normalize(text);
  const isSlide = /سلايدر|شريح|slider|slide|diapo/i.test(text);
  const entries = isSlide ? context.slides : context.menu;
  if (!Array.isArray(entries)) return null;
  let matches = entries.filter((entry) => [entry.id, entry.name, entry.title, entry.kicker]
    .filter(Boolean).some((value) => {
      const name = normalize(value);
      return name.length > 2 && normalized.includes(name);
    }));
  if (!matches.length && !isSlide) {
    matches = entries.filter((entry) => {
      const first = normalize(entry.name).split(' ')[0];
      return first.length > 3 && normalized.includes(first);
    });
  }
  if (!matches.length && isSlide) {
    const car = (context.menu || []).find((entry) => [entry.id, entry.name]
      .some((value) => value && normalized.includes(normalize(value))));
    if (car) matches = entries.filter((entry) => entry.vehicle === car.id);
  }
  if (!matches.length) {
    let index = -1;
    if (/الأول|الاول|premier|first|(^|[^0-9])1([^0-9]|$)/i.test(text)) index = 0;
    else if (/الثان|deuxieme|deuxième|second|(^|[^0-9])2([^0-9]|$)/i.test(text)) index = 1;
    else if (/الثالث|troisieme|troisième|third|(^|[^0-9])3([^0-9]|$)/i.test(text)) index = 2;
    if (index >= 0 && entries[index]) matches = [entries[index]];
  }
  if (matches.length !== 1) return null;
  const entry = matches[0];
  return {
    action: isSlide ? 'update_slider_item' : 'update_menu_item',
    summary_ar: `تغيير صورة ${isSlide ? 'شريحة السلايدر ' : 'السيارة '}${entry.title || entry.name || entry.id}`,
    arguments: isSlide ? { slide_id: entry.id } : { item_id: entry.id },
  };
}

async function handle(update) {
  const message = update.message;
  const callback = update.callback_query;
  const chatId = String(message?.chat?.id || callback?.message?.chat?.id || '');
  if (chatId !== allowedChat) return;
  if (callback) {
    const [choice, pendingId] = String(callback.data || '').split(':');
    const item = pending[pendingId];
    if (!item || item.chat !== chatId) {
      await telegram('answerCallbackQuery', { callback_query_id: callback.id, text: 'انتهت صلاحية الطلب' });
      return;
    }
    delete pending[pendingId];
    await savePending();
    await telegram('answerCallbackQuery', { callback_query_id: callback.id, text: choice === 'yes' ? 'جار التنفيذ' : 'تم الإلغاء' });
    if (choice !== 'yes') { await send(chatId, 'تم إلغاء التعديل.'); return; }
    try {
      const result = await wordpress('POST', '/ai-site-agent/v1/commands', {
        action: item.plan.action,
        arguments: item.plan.arguments,
        requested_by: `telegram:${chatId}`,
      });
      await send(chatId, `${result.message || 'تم تنفيذ التعديل بنجاح.'}\n${result.url || site}\nرقم العملية: ${result.action_id}`);
    } catch (error) {
      console.error('WP command failed', error.message);
      await send(chatId, `تعذر تنفيذ التعديل: ${error.message}`);
    }
    return;
  }
  if (!message) return;
  const text = String(message.text || message.caption || '').trim();
  const attached = message.photo?.length ? message.photo
    : message.document && /^image\//.test(message.document.mime_type || '') ? [message.document] : null;
  if (text === '/start' || text === '/help') {
    await send(chatId, 'مرحباً بك في وكيل Atlas Drive Maroc. أرسل التعديل المطلوب، مثل: غيّر سعر Berline Confort إلى 420 درهماً. ولتغيير صورة سيارة أو السلايدر أرسل الصورة مع وصف يحدد العنصر. سأطلب تأكيدك قبل التنفيذ.');
    return;
  }
  if (attached && !text) {
    recentPhotos[chatId] = { media: attached, at: Date.now() };
    await send(chatId, 'وصلت الصورة. أرسل الآن اسم السيارة أو رقم شريحة السلايدر المراد تغييرها خلال عشر دقائق.');
    return;
  }
  if (!text) return;
  let media = attached;
  if (!media && recentPhotos[chatId] && Date.now() - recentPhotos[chatId].at < 600000) {
    media = recentPhotos[chatId].media;
    delete recentPhotos[chatId];
  }
  if (!media && /صورة|صور|photo|image/i.test(text)) {
    await send(chatId, 'أرفق الصورة الجديدة مع اسم السيارة أو رقم شريحة السلايدر.');
    return;
  }
  await send(chatId, media ? 'أجهّز الصورة والتعديل…' : 'أحلل الطلب…');
  try {
    const context = await wordpress('GET', '/ai-site-agent/v1/context');
    let command;
    if (media) {
      command = imagePlan(text, context);
      if (!command) {
        await send(chatId, 'لم أتمكن من تحديد العنصر. أرسل الصورة مع اسم السيارة كما يظهر في الموقع، أو اكتب السلايدر الأول/الثاني/الثالث.');
        return;
      }
      command.arguments.image = await photoData(media);
    } else {
      command = await plan(text, context);
      if (command.error) { await send(chatId, command.error); return; }
    }
    const pendingId = randomUUID();
    pending[pendingId] = { chat: chatId, plan: command };
    await savePending();
    await send(chatId, `الموقع: Atlas Drive Maroc\nالتعديل المقترح: ${command.summary_ar}\n\nاضغط «تنفيذ» للتأكيد.`, {
      reply_markup: { inline_keyboard: [[
        { text: '✅ تنفيذ', callback_data: `yes:${pendingId}` },
        { text: '❌ إلغاء', callback_data: `no:${pendingId}` },
      ]] },
    });
  } catch (error) {
    console.error('Update failed', error.message);
    await send(chatId, media ? `تعذر تجهيز الصورة: ${error.message}` : 'تعذر تحليل الطلب أو الاتصال بالموقع. حاول مرة أخرى.');
  }
}

const server = createServer(async (request, response) => {
  if (request.url === '/health') {
    response.writeHead(200, { 'content-type': 'application/json' });
    response.end('{"ok":true}');
    return;
  }
  if (request.url !== '/telegram/webhook' || request.method !== 'POST') {
    response.writeHead(404); response.end(); return;
  }
  const supplied = Buffer.from(String(request.headers['x-telegram-bot-api-secret-token'] || ''));
  const expected = Buffer.from(webhookSecret);
  if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
    response.writeHead(401); response.end(); return;
  }
  let raw = '';
  for await (const part of request) {
    raw += part;
    if (raw.length > 1000000) { response.writeHead(413); response.end(); return; }
  }
  response.writeHead(200); response.end('ok');
  try { await handle(JSON.parse(raw)); }
  catch (error) { console.error('Telegram update failed', error.message); }
});

server.listen(3000, '0.0.0.0', async () => {
  console.log('Atlas agent listening');
  try {
    await telegram('setWebhook', {
      url: `${env.PUBLIC_BASE_URL}/telegram/webhook`,
      secret_token: webhookSecret,
    });
    console.log('Telegram webhook registered');
  } catch (error) { console.error('Webhook failed', error.message); }
});
