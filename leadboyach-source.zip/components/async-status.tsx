'use client';

import { MailSearch, Sparkles } from 'lucide-react';

import { Spinner } from '@/components/ui/spinner';
import { t } from '@/lib/i18n';

export function ResultsLoadingIndicator() {
  return (
    <div
      role="status"
      aria-label={t('search.waiting')}
      className="relative mx-auto my-3 grid size-16 place-items-center"
    >
      <span className="absolute inset-0 rounded-full bg-indigo-100/70 motion-safe:animate-ping" />
      <span className="absolute inset-1 rounded-full border border-indigo-100 bg-white shadow-[0_10px_30px_rgba(16,185,129,0.18)]" />
      <Spinner
        aria-hidden="true"
        className="absolute size-12 text-indigo-600 [animation-duration:1.15s]"
      />
      <Sparkles className="relative size-5 text-indigo-600 motion-safe:animate-pulse" aria-hidden="true" />
      <span className="sr-only">{t('search.waiting')}</span>
    </div>
  );
}

export function EmailLookupIndicator() {
  return (
    <span
      role="status"
      aria-label={t('common.searching')}
      title={t('common.searching')}
      className="relative inline-flex size-8 items-center justify-center rounded-full border border-amber-100 bg-amber-50 text-amber-600 shadow-sm"
    >
      <Spinner aria-hidden="true" className="size-5 [animation-duration:1.1s]" />
      <MailSearch className="absolute size-2.5 text-amber-700 motion-safe:animate-pulse" aria-hidden="true" />
      <span className="sr-only">{t('common.searching')}</span>
    </span>
  );
}
