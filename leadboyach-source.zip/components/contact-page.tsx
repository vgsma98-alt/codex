'use client';

import { useState } from 'react';
import type { SyntheticEvent } from 'react';
import { ArrowLeft, CheckCircle2, Clock3, Mail, MapPin, MessageSquareText, Phone, Send, ShieldCheck } from 'lucide-react';
import { ChayobLogo } from '@/components/chayob-logo';
import { LanguageSwitcher } from '@/components/language-switcher';
import { Button } from '@/components/ui/button';
import { t, useI18n } from '@/lib/i18n';

export function ContactPage() {
  const { direction, language } = useI18n();
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  async function submit(event: SyntheticEvent<HTMLFormElement, SubmitEvent>) {
    event.preventDefault();
    setState('sending');
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const body = Object.fromEntries(form.entries());
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, language }),
      });
      if (!response.ok) throw new Error('send_failed');
      formElement.reset();
      setState('sent');
    } catch {
      setState('error');
    }
  }

  return (
    <main dir={direction} className="min-h-screen bg-[#f4fbf7] text-slate-950">
      <header className="border-b border-emerald-950/10 bg-[#032e25] text-white">
        <div className="mx-auto flex h-20 max-w-[1240px] items-center justify-between px-5 sm:px-8">
          <button onClick={() => window.location.assign('/landing')} aria-label={t('landing.home')}><ChayobLogo inverse /></button>
          <div className="flex items-center gap-3"><LanguageSwitcher className="border-white/15 bg-white/10 text-white" /><Button variant="ghost" className="hidden text-white hover:bg-white/10 hover:text-white sm:inline-flex" onClick={() => window.location.assign('/landing')}><ArrowLeft className="size-4 rtl:rotate-180" />{t('contact.back')}</Button></div>
        </div>
      </header>

      <section className="relative overflow-hidden px-5 py-16 sm:px-8 lg:py-24">
        <div className="absolute inset-x-0 top-0 h-96 bg-[radial-gradient(circle_at_top_right,rgba(74,222,128,.22),transparent_48%)]" />
        <div className="relative mx-auto max-w-[1240px]">
          <div className="max-w-3xl"><p className="text-sm font-black uppercase tracking-[.18em] text-emerald-600">{t('contact.eyebrow')}</p><h1 className="mt-4 text-4xl font-black leading-tight sm:text-6xl">{t('contact.title')}</h1><p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">{t('contact.description')}</p></div>

          <div className="mt-12 grid gap-6 lg:grid-cols-[.9fr_1.1fr]">
            <aside className="space-y-5">
              <div className="overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#04392e] to-[#07956d] p-7 text-white shadow-2xl shadow-emerald-900/20 sm:p-9">
                <p className="text-2xl font-black">{t('contact.detailsTitle')}</p><p className="mt-3 leading-7 text-emerald-50/80">{t('contact.detailsText')}</p>
                <div className="mt-8 space-y-4">
                  <ContactItem icon={Mail} label={t('contact.email')} value="contact@leadboyach.com" href="mailto:contact@leadboyach.com" />
                  <ContactItem icon={Phone} label={t('contact.phone')} value="+212 680 095 434" href="tel:+212680095434" />
                  <ContactItem icon={MapPin} label={t('contact.address')} value={t('contact.addressValue')} href="https://maps.app.goo.gl/eExDFDzk9D6Vvkrt6" />
                  <ContactItem icon={Clock3} label={t('contact.hours')} value={t('contact.hoursValue')} />
                </div>
                <div className="mt-8 flex items-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-sm text-emerald-50"><ShieldCheck className="size-5 shrink-0" />{t('contact.privacy')}</div>
              </div>
              <a href="https://maps.app.goo.gl/eExDFDzk9D6Vvkrt6" target="_blank" rel="noreferrer" className="block overflow-hidden rounded-[2rem] border border-emerald-950/10 bg-white p-2 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg">
                <iframe title={t('contact.mapTitle')} className="pointer-events-none h-72 w-full rounded-[1.55rem] border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=Rue+Bahmad+Belvedere+Casablanca+Morocco&output=embed" />
                <span className="flex items-center justify-between gap-3 px-4 py-3 text-sm font-black text-emerald-800"><span>{t('contact.openMap')}</span><MapPin className="size-4" /></span>
              </a>
            </aside>

            <section className="rounded-[2rem] border border-emerald-950/10 bg-white p-6 shadow-xl shadow-emerald-950/5 sm:p-9">
              <div className="flex items-start gap-4"><span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-emerald-50 text-emerald-700"><MessageSquareText className="size-6" /></span><div><h2 className="text-2xl font-black">{t('contact.formTitle')}</h2><p className="mt-1 text-sm leading-6 text-slate-500">{t('contact.formText')}</p></div></div>
              {state === 'sent' ? <div className="mt-8 rounded-2xl border border-emerald-200 bg-emerald-50 p-6 text-center"><CheckCircle2 className="mx-auto size-10 text-emerald-600" /><p className="mt-3 text-lg font-black text-emerald-950">{t('contact.successTitle')}</p><p className="mt-2 text-sm text-emerald-800">{t('contact.successText')}</p><Button className="mt-5 bg-emerald-700 hover:bg-emerald-800" onClick={() => setState('idle')}>{t('contact.sendAnother')}</Button></div> :
              <form className="mt-8 grid gap-5 sm:grid-cols-2" onSubmit={submit}>
                <label className="grid gap-2 text-sm font-bold">{t('contact.name')}<input required minLength={2} maxLength={100} name="name" autoComplete="name" className="h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder={t('contact.namePlaceholder')} /></label>
                <label className="grid gap-2 text-sm font-bold">{t('contact.email')}<input required type="email" maxLength={254} name="email" autoComplete="email" dir="ltr" className="h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 text-start outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder="name@company.com" /></label>
                <label className="grid gap-2 text-sm font-bold">{t('contact.phone')}<input name="phone" maxLength={32} autoComplete="tel" dir="ltr" className="h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 text-start outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder="+212 6..." /></label>
                <label className="grid gap-2 text-sm font-bold">{t('contact.company')}<input name="company" maxLength={120} autoComplete="organization" className="h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder={t('contact.companyPlaceholder')} /></label>
                <label className="grid gap-2 text-sm font-bold sm:col-span-2">{t('contact.subject')}<input required minLength={2} maxLength={160} name="subject" className="h-12 rounded-xl border border-slate-200 bg-slate-50 px-4 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder={t('contact.subjectPlaceholder')} /></label>
                <label className="grid gap-2 text-sm font-bold sm:col-span-2">{t('contact.message')}<textarea required minLength={10} maxLength={4000} name="message" rows={7} className="resize-none rounded-xl border border-slate-200 bg-slate-50 p-4 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100" placeholder={t('contact.messagePlaceholder')} /></label>
                <label className="hidden" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off" /></label>
                {state === 'error' && <p role="alert" className="sm:col-span-2 rounded-xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700">{t('contact.error')}</p>}
                <Button disabled={state === 'sending'} size="lg" className="h-13 rounded-xl bg-emerald-600 font-black hover:bg-emerald-700 sm:col-span-2">{state === 'sending' ? t('contact.sending') : t('contact.send')}<Send className="size-4 rtl:rotate-180" /></Button>
              </form>}
              <a href="https://wa.me/212680095434" target="_blank" rel="noopener noreferrer" className="mt-4 flex min-h-12 w-full items-center justify-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-center text-sm font-bold text-emerald-800 transition hover:border-emerald-400 hover:bg-emerald-100 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-200">
                <svg viewBox="0 0 24 24" className="size-5 shrink-0 text-[#25D366]" fill="currentColor" aria-hidden="true"><path d="M20.52 3.48A11.88 11.88 0 0012.04 0C5.5 0 .18 5.32.18 11.86c0 2.09.55 4.13 1.59 5.93L.08 24l6.35-1.67a11.85 11.85 0 005.61 1.43h.01c6.54 0 11.86-5.32 11.86-11.86 0-3.17-1.23-6.15-3.39-8.42zM12.05 21.75a9.84 9.84 0 01-5.01-1.37l-.36-.21-3.77.99 1-3.67-.24-.38a9.83 9.83 0 01-1.5-5.25c0-5.43 4.43-9.85 9.88-9.85a9.8 9.8 0 016.97 2.89 9.8 9.8 0 012.89 6.99c0 5.43-4.43 9.86-9.86 9.86zm5.41-7.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.65-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.35.44-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.21-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.03 1.01-1.03 2.47s1.06 2.87 1.21 3.07c.15.2 2.09 3.19 5.06 4.47.71.31 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.09 1.75-.71 2-1.4.24-.69.24-1.28.17-1.4-.07-.13-.27-.2-.57-.35z" /></svg>
                {t('contact.whatsapp')}
              </a>
            </section>
          </div>
        </div>
      </section>
      <footer className="border-t border-emerald-950/10 bg-white px-5 py-8"><div className="mx-auto flex max-w-[1240px] flex-col items-center justify-between gap-4 sm:flex-row"><button type="button" aria-label={t('landing.home')} onClick={() => window.location.assign('/landing')}><ChayobLogo /></button><p className="text-sm text-slate-500">{t('landing.footer')}</p></div></footer>
    </main>
  );
}

function ContactItem({ icon: Icon, label, value, href }: { icon: typeof Mail; label: string; value: string; href?: string }) {
  const content = <><span className="grid size-11 shrink-0 place-items-center rounded-xl bg-white/10"><Icon className="size-5" /></span><span><span className="block text-xs font-bold uppercase tracking-wide text-emerald-100/70">{label}</span><span className="mt-1 block font-bold" dir={href?.startsWith('tel:') || href?.startsWith('mailto:') ? 'ltr' : undefined}>{value}</span></span></>;
  return href ? <a href={href} target={href.startsWith('https:') ? '_blank' : undefined} rel={href.startsWith('https:') ? 'noreferrer' : undefined} className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[.06] p-3 transition hover:bg-white/10">{content}</a> : <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[.06] p-3">{content}</div>;
}
