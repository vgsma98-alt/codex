'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  Building2,
  CircleDollarSign,
  Filter,
  GripVertical,
  Mail,
  Phone,
  Plus,
  Search,
  Settings2,
  Sparkles,
} from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { Lead, PipelineStage } from '@/lib/database.types';
import { supabase } from '@/lib/supabase';
import { formatNumber, t, useI18n } from '@/lib/i18n';
import { leadQualityLabel } from '@/lib/lead-quality';

function money(value: number) {
  return formatNumber(value, { style: 'currency', currency: 'MAD', maximumFractionDigits: 0 });
}

function available(value?: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(
    normalized &&
      !['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined'].includes(normalized),
  );
}

function percentage(part: number, total: number) {
  return total > 0 ? Math.round((part / total) * 100) : 0;
}

function isStalled(lead: Lead) {
  if (!lead.pipeline_updated_at) return false;
  return Date.now() - new Date(lead.pipeline_updated_at).getTime() >= 14 * 86_400_000;
}

function compactLeadName(value?: string | null) {
  const fullName = value?.trim() || t('common.clientUnnamed');
  const words = fullName
    .split(/\s+/)
    .filter((word) => word.replace(/[-–—|,;:/]+/g, '').length > 0);
  return words.length > 7 ? `${words.slice(0, 7).join(' ')}…` : fullName;
}

function stageLabel(stage: PipelineStage) {
  const key = `pipeline.stage.${stage.slug}`;
  const translated = t(key);
  return translated === key ? stage.name : translated;
}

function upsertLead(current: Lead[], incoming: Lead) {
  const existing = current.find((lead) => lead.id === incoming.id);
  if (existing && existing.pipeline_version > incoming.pipeline_version) return current;
  return existing
    ? current.map((lead) => (lead.id === incoming.id ? incoming : lead))
    : [incoming, ...current];
}

export function PipelineBoard({ userId }: { userId: string }) {
  useI18n();
  const [stages, setStages] = useState<PipelineStage[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [quality, setQuality] = useState('all');
  const [minimumScore, setMinimumScore] = useState('all');
  const [draggedLeadId, setDraggedLeadId] = useState<string | null>(null);
  const [touchLeadId, setTouchLeadId] = useState<string | null>(null);
  const [busyLeadIds, setBusyLeadIds] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showStageManager, setShowStageManager] = useState(false);
  const [newStageName, setNewStageName] = useState('');
  const [addingStage, setAddingStage] = useState(false);

  const loadPipeline = useCallback(async () => {
    setLoading(true);
    const [stageResult, leadResult] = await Promise.all([
      supabase.from('Pipeline_Stages').select('*').eq('user_id', userId).order('position', { ascending: true }),
      supabase.from('Leads').select('*').eq('User_id', userId).order('LeadScore', { ascending: false }),
    ]);

    const loadError = stageResult.error || leadResult.error;
    if (loadError) setError(loadError.message);
    else {
      setStages(stageResult.data ?? []);
      setLeads(leadResult.data ?? []);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    const timer = window.setTimeout(() => void loadPipeline(), 0);
    return () => window.clearTimeout(timer);
  }, [loadPipeline]);

  useEffect(() => {
    const channel = supabase
      .channel(`pipeline-${userId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'Leads', filter: `User_id=eq.${userId}` },
        (payload) => {
          if (payload.eventType === 'DELETE') {
            const deleted = payload.old as Pick<Lead, 'id'>;
            setLeads((current) => current.filter((lead) => lead.id !== deleted.id));
          } else {
            setLeads((current) => upsertLead(current, payload.new as Lead));
          }
        },
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'Pipeline_Stages', filter: `user_id=eq.${userId}` },
        () => void loadPipeline(),
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [loadPipeline, userId]);

  const qualities = useMemo(
    () =>
      [...new Set(leads.map((lead) => lead.LeadQuality?.trim()).filter((item): item is string => Boolean(item)))].sort(
        (a, b) => a.localeCompare(b),
      ),
    [leads],
  );

  const filteredLeads = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    const score = minimumScore === 'all' ? 0 : Number(minimumScore);
    return leads.filter((lead) => {
      const haystack = [lead.Entreprise, lead.Activité, lead.City, lead.Telephone, lead.Email]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase();
      return (
        (!normalizedQuery || haystack.includes(normalizedQuery)) &&
        (quality === 'all' || lead.LeadQuality?.trim() === quality) &&
        (lead.LeadScore ?? 0) >= score
      );
    });
  }, [leads, minimumScore, quality, query]);

  const refreshLead = useCallback(async (leadId: string) => {
    const { data } = await supabase.from('Leads').select('*').eq('id', leadId).eq('User_id', userId).maybeSingle();
    if (data) setLeads((current) => upsertLead(current, data));
  }, [userId]);

  const moveLead = useCallback(
    async (leadId: string, newStageId: string) => {
      const snapshot = leads.find((lead) => lead.id === leadId);
      if (!snapshot || snapshot.pipeline_stage_id === newStageId || busyLeadIds.has(leadId)) return;

      setError(null);
      setNotice(null);
      setBusyLeadIds((current) => new Set(current).add(leadId));
      setLeads((current) =>
        current.map((lead) =>
          lead.id === leadId
            ? {
                ...lead,
                pipeline_stage_id: newStageId,
                pipeline_version: lead.pipeline_version + 1,
                pipeline_updated_at: new Date().toISOString(),
                pipeline_updated_by: userId,
              }
            : lead,
        ),
      );

      const { data, error: updateError } = await supabase
        .from('Leads')
        .update({ pipeline_stage_id: newStageId })
        .eq('id', leadId)
        .eq('User_id', userId)
        .eq('pipeline_version', snapshot.pipeline_version)
        .select('*')
        .maybeSingle();

      if (updateError || !data) {
        await refreshLead(leadId);
        setError(
          updateError?.message ||
            t('errors.concurrentLeadUpdate'),
        );
      } else {
        setLeads((current) => upsertLead(current, data));
        setNotice(t('notices.stageSaved'));
      }

      setBusyLeadIds((current) => {
        const next = new Set(current);
        next.delete(leadId);
        return next;
      });
    },
    [busyLeadIds, leads, refreshLead, userId],
  );

  const saveEstimatedValue = useCallback(
    async (leadId: string, value: number) => {
      const snapshot = leads.find((lead) => lead.id === leadId);
      if (!snapshot || busyLeadIds.has(leadId) || Number(snapshot.estimated_value) === value) return;
      if (!Number.isFinite(value) || value < 0) {
        setError(t('errors.invalidEstimatedValue'));
        return;
      }

      setError(null);
      setBusyLeadIds((current) => new Set(current).add(leadId));
      setLeads((current) => current.map((lead) => lead.id === leadId ? {
        ...lead,
        estimated_value: value,
        pipeline_version: lead.pipeline_version + 1,
        pipeline_updated_at: new Date().toISOString(),
        pipeline_updated_by: userId,
      } : lead));

      const { data, error: updateError } = await supabase
        .from('Leads')
        .update({ estimated_value: value })
        .eq('id', leadId)
        .eq('User_id', userId)
        .eq('pipeline_version', snapshot.pipeline_version)
        .select('*')
        .maybeSingle();

      if (updateError || !data) {
        await refreshLead(leadId);
        setError(updateError?.message || t('errors.concurrentLeadUpdate'));
      } else {
        setLeads((current) => upsertLead(current, data));
        setNotice(t('notices.valueSaved'));
      }
      setBusyLeadIds((current) => {
        const next = new Set(current);
        next.delete(leadId);
        return next;
      });
    },
    [busyLeadIds, leads, refreshLead, userId],
  );

  const addStage = async () => {
    const name = newStageName.trim();
    if (!name || addingStage) return;
    setAddingStage(true);
    setError(null);
    const position = (stages.at(-1)?.position ?? 0) + 10;
    const { data, error: insertError } = await supabase
      .from('Pipeline_Stages')
      .insert({
        user_id: userId,
        slug: `custom-${crypto.randomUUID().slice(0, 8)}`,
        name,
        position,
        color: '#64748B',
        is_terminal: false,
      })
      .select('*')
      .single();

    if (insertError) setError(insertError.message);
    else {
      setStages((current) => [...current.filter((stage) => stage.id !== data.id), data].sort((a, b) => a.position - b.position));
      setNewStageName('');
      setNotice(t('notices.stageAdded'));
    }
    setAddingStage(false);
  };

  const finishTouchDrag = (event: React.PointerEvent<HTMLElement>, leadId: string) => {
    if (!touchLeadId) return;
    const target = document
      .elementFromPoint(event.clientX, event.clientY)
      ?.closest<HTMLElement>('[data-pipeline-stage-id]');
    setTouchLeadId(null);
    if (target?.dataset.pipelineStageId) void moveLead(leadId, target.dataset.pipelineStageId);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-28 rounded-3xl" />
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 xl:grid-cols-5">
          {[1, 2, 3, 4, 5].map((item) => <Skeleton key={item} className="h-96 rounded-3xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Card className="overflow-hidden border-0 bg-[linear-gradient(135deg,#ffffff_0%,#f7fef9_58%,#ecfdf5_100%)] shadow-[0_18px_55px_rgba(2,44,34,0.07)] ring-1 ring-slate-200/70">
        <CardContent className="p-5 sm:p-6">
          <div className="flex flex-col justify-between gap-4 xl:flex-row xl:items-end">
            <div>
              <div className="flex items-center gap-2">
                <span className="grid size-11 place-items-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-200"><Sparkles className="size-5" /></span>
                <div>
                  <h2 className="text-xl font-black tracking-tight text-slate-950">{t('pipeline.title')}</h2>
                  <p className="mt-0.5 text-sm text-slate-500">{t('pipeline.description')}</p>
                </div>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3 xl:min-w-[680px]">
              <div className="relative rounded-xl bg-white shadow-sm ring-1 ring-slate-200/80">
                <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
                <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('pipeline.searchPlaceholder')} className="h-11 border-0 bg-transparent ps-9 shadow-none" />
              </div>
              <Select value={quality} onValueChange={(value) => setQuality(value ?? 'all')}>
                <SelectTrigger className="h-11 w-full bg-white shadow-sm"><Filter className="size-4 text-slate-400" /><SelectValue>{quality === 'all' ? t('pipeline.allQuality') : leadQualityLabel(quality, t)}</SelectValue></SelectTrigger>
                <SelectContent><SelectItem value="all">{t('pipeline.allQuality')}</SelectItem>{qualities.map((item) => <SelectItem key={item} value={item}>{leadQualityLabel(item, t)}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={minimumScore} onValueChange={(value) => setMinimumScore(value ?? 'all')}>
                <SelectTrigger className="h-11 w-full bg-white shadow-sm"><BarChart3 className="size-4 text-slate-400" /><SelectValue>{minimumScore === 'all' ? t('pipeline.allScores') : t('pipeline.scoreAndAbove', { score: minimumScore })}</SelectValue></SelectTrigger>
                <SelectContent><SelectItem value="all">{t('pipeline.allScores')}</SelectItem>{['50', '70', '85'].map((score) => <SelectItem key={score} value={score}>{t('pipeline.scoreAndAbove', { score })}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-indigo-100/70 pt-4">
            <div className="flex gap-2">
              <Badge variant="outline" className="h-8 border-white bg-white px-3 shadow-sm">{t('pipeline.visibleClients', { count: filteredLeads.length })}</Badge>
              <Badge variant="outline" className="h-8 border-white bg-white px-3 shadow-sm">{t('pipeline.stageCount', { count: stages.length })}</Badge>
            </div>
            <Button variant="outline" size="sm" onClick={() => setShowStageManager((current) => !current)}>
              <Settings2 className="size-4" /> {t('pipeline.manageStages')}
            </Button>
          </div>

          {showStageManager && (
            <div className="mt-4 flex flex-col gap-3 rounded-2xl bg-slate-50 p-4 sm:flex-row sm:items-end">
              <label htmlFor="new-pipeline-stage" className="flex-1 text-sm font-bold text-slate-700">
                {t('pipeline.newStageName')}
                <Input id="new-pipeline-stage" value={newStageName} onChange={(event) => setNewStageName(event.target.value)} maxLength={80} placeholder={t('pipeline.newStagePlaceholder')} className="mt-2 bg-white" />
              </label>
              <Button onClick={() => void addStage()} disabled={!newStageName.trim() || addingStage} className="bg-indigo-600 hover:bg-indigo-700">
                <Plus className="size-4" /> {addingStage ? t('pipeline.addingStage') : t('pipeline.addStage')}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {notice && <Alert className="border-emerald-200 bg-emerald-50 text-emerald-900"><Sparkles /><AlertDescription>{notice}</AlertDescription></Alert>}
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}

      <div className="overflow-x-auto rounded-[2rem] border border-slate-200/80 bg-[linear-gradient(180deg,#f8fafc_0%,#eef2f7_100%)] p-3 pb-5 shadow-inner sm:p-4">
        <div className="grid min-w-max auto-cols-[292px] grid-flow-col gap-4">
          {stages.map((stage) => {
            const stageLeads = filteredLeads.filter((lead) => lead.pipeline_stage_id === stage.id);
            const totalValue = stageLeads.reduce((sum, lead) => sum + Number(lead.estimated_value || 0), 0);
            const averageScore = stageLeads.length
              ? Math.round(stageLeads.reduce((sum, lead) => sum + (lead.LeadScore ?? 0), 0) / stageLeads.length)
              : 0;
            const stageShare = percentage(stageLeads.length, filteredLeads.length);
            const contactCoverage = percentage(stageLeads.filter((lead) => available(lead.Telephone) || available(lead.Email)).length, stageLeads.length);
            const stalledCount = stageLeads.filter(isStalled).length;

            return (
              // Drag targets intentionally use a semantic fieldset so nested lead controls remain valid.
              // oxlint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
              <fieldset
                key={stage.id}
                data-pipeline-stage-id={stage.id}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                  event.preventDefault();
                  const leadId = event.dataTransfer.getData('text/plain') || draggedLeadId;
                  setDraggedLeadId(null);
                  if (leadId) void moveLead(leadId, stage.id);
                }}
                className="relative flex w-[292px] min-w-0 max-w-[292px] max-h-[72vh] min-h-[440px] flex-col overflow-hidden rounded-[1.65rem] border border-white/90 bg-white/55 p-3 shadow-[0_12px_32px_rgba(15,23,42,0.05)] backdrop-blur"
              >
                <legend className="sr-only">{t('lead.stage', { stage: stageLabel(stage) })}</legend>
                <span className="absolute inset-x-0 top-0 h-1" style={{ backgroundColor: stage.color }} />
                <header className="rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-slate-200/60">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-2">
                      <span className="grid size-8 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${stage.color}18`, color: stage.color }}><span className="size-2.5 rounded-full bg-current" /></span>
                      <h3 className="truncate text-[15px] font-black text-slate-900">{stageLabel(stage)}</h3>
                    </div>
                    <Badge className="min-w-8 justify-center rounded-full bg-slate-900 text-white hover:bg-slate-900">{stageLeads.length}</Badge>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <span className="rounded-xl bg-slate-50 px-2.5 py-2 text-slate-500">{t('pipeline.averageScore')} <b className="ms-1 text-slate-900">{averageScore}</b></span>
                    <span className="truncate rounded-xl bg-slate-50 px-2.5 py-2 text-slate-500">{t('pipeline.value')} <b className="ms-1 text-slate-900">{money(totalValue)}</b></span>
                    <span className="rounded-xl bg-slate-50 px-2.5 py-2 text-slate-500">{t('analytics.stageShare')} <b className="ms-1 text-slate-900">{stageShare}%</b></span>
                    <span className="rounded-xl bg-slate-50 px-2.5 py-2 text-slate-500">{t('analytics.contactCoverage')} <b className="ms-1 text-slate-900">{contactCoverage}%</b></span>
                  </div>
                  {stalledCount > 0 && <div className="mt-2 flex items-center justify-between rounded-xl border border-amber-200 bg-amber-50 px-2.5 py-2 text-xs font-semibold text-amber-800"><span>{t('analytics.stalledShort')}</span><b>{stalledCount}</b></div>}
                </header>

                <div className="mt-3 space-y-3 overflow-y-auto px-0.5 pb-2">
                  {stageLeads.length === 0 ? (
                    <div className="grid min-h-36 place-items-center rounded-2xl border border-dashed border-slate-300 bg-white/45 p-5 text-center text-sm text-slate-400"><div><GripVertical className="mx-auto mb-2 size-5 opacity-50" />{t('pipeline.dropHere')}</div></div>
                  ) : stageLeads.map((lead) => (
                    // The article is draggable, while navigation and stage selection stay explicit controls.
                    // oxlint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
                    <article
                      key={lead.id}
                      draggable={!busyLeadIds.has(lead.id)}
                      onDragStart={(event) => {
                        setDraggedLeadId(lead.id);
                        event.dataTransfer.effectAllowed = 'move';
                        event.dataTransfer.setData('text/plain', lead.id);
                      }}
                      onDragEnd={() => setDraggedLeadId(null)}
                      onPointerDown={(event) => {
                        if (event.pointerType !== 'mouse') setTouchLeadId(lead.id);
                      }}
                      onPointerUp={(event) => finishTouchDrag(event, lead.id)}
                      onPointerCancel={() => setTouchLeadId(null)}
                      className={`group touch-pan-y rounded-2xl bg-white p-3.5 shadow-[0_6px_20px_rgba(15,23,42,0.06)] ring-1 transition duration-200 ${touchLeadId === lead.id || draggedLeadId === lead.id ? 'scale-[0.98] opacity-60 ring-indigo-400' : 'ring-slate-200/70 hover:-translate-y-0.5 hover:ring-indigo-200 hover:shadow-[0_12px_28px_rgba(16,185,129,0.14)]'}`}
                    >
                      <div className="flex items-start gap-2">
                        <GripVertical className="mt-1 size-4 shrink-0 cursor-grab text-slate-300 transition group-hover:text-indigo-400" />
                        <div className="min-w-0 flex-1">
                          <h4 className="truncate text-[15px] font-black text-slate-900" title={lead.Entreprise || t('common.clientUnnamed')}>{compactLeadName(lead.Entreprise)}</h4>
                          <p className="mt-1 truncate text-xs font-medium text-slate-500">{lead.Activité || lead.City || t('common.client')}</p>
                        </div>
                        <Badge variant="outline" className="shrink-0 rounded-lg border-indigo-100 bg-indigo-50 text-indigo-700">{lead.LeadScore ?? 0}/100</Badge>
                      </div>
                      <div className="mt-3 flex items-center gap-2">
                        {available(lead.Telephone) ? <a href={`tel:${lead.Telephone}`} aria-label={t('pipeline.callClient', { name: compactLeadName(lead.Entreprise) })} title={lead.Telephone!} className="grid size-8 place-items-center rounded-xl bg-emerald-50 text-emerald-600 transition hover:bg-emerald-600 hover:text-white" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => event.stopPropagation()}><Phone className="size-3.5" /></a> : <span aria-label={t('pipeline.phoneUnavailable')} className="grid size-8 place-items-center rounded-xl bg-slate-100 text-slate-300"><Phone className="size-3.5" /></span>}
                        {available(lead.Email) ? <a href={`mailto:${lead.Email}`} aria-label={t('pipeline.emailClient', { name: compactLeadName(lead.Entreprise) })} title={lead.Email!} className="grid size-8 place-items-center rounded-xl bg-sky-50 text-sky-600 transition hover:bg-sky-600 hover:text-white" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => event.stopPropagation()}><Mail className="size-3.5" /></a> : <span aria-label={t('pipeline.emailUnavailable')} className="grid size-8 place-items-center rounded-xl bg-slate-100 text-slate-300"><Mail className="size-3.5" /></span>}
                        {Number(lead.estimated_value || 0) > 0 && <span className="ms-auto flex items-center gap-1 rounded-lg bg-slate-50 px-2 py-1 text-xs font-bold text-slate-600"><CircleDollarSign className="size-3.5" />{money(Number(lead.estimated_value))}</span>}
                      </div>
                      <label htmlFor={`lead-value-${lead.id}`} className="mt-3 flex items-center gap-2 rounded-xl bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-500">
                        <CircleDollarSign className="size-4 shrink-0 text-slate-400" />
                        <Input
                          key={`${lead.id}-${lead.pipeline_version}-${lead.estimated_value}`}
                          id={`lead-value-${lead.id}`}
                          type="number"
                          min={0}
                          step={100}
                          defaultValue={Number(lead.estimated_value || 0)}
                          disabled={busyLeadIds.has(lead.id)}
                          aria-label={t('pipeline.estimatedValue')}
                          className="h-7 min-w-0 flex-1 border-0 bg-transparent px-1 text-xs font-bold shadow-none focus-visible:ring-0"
                          onPointerDown={(event) => event.stopPropagation()}
                          onDragStart={(event) => event.stopPropagation()}
                          onBlur={(event) => void saveEstimatedValue(lead.id, Number(event.target.value))}
                        />
                        <span className="shrink-0 text-[11px] text-slate-400">MAD</span>
                      </label>
                      <div className="mt-3 flex items-center gap-2 border-t border-slate-100 pt-3">
                        <Select value={lead.pipeline_stage_id ?? ''} onValueChange={(value) => value && void moveLead(lead.id, value)} disabled={busyLeadIds.has(lead.id)}>
                          <SelectTrigger className="h-8 min-w-0 flex-1 bg-slate-50 text-xs"><SelectValue>{stages.find((item) => item.id === lead.pipeline_stage_id) ? stageLabel(stages.find((item) => item.id === lead.pipeline_stage_id)!) : t('pipeline.moveToStage')}</SelectValue></SelectTrigger>
                          <SelectContent>{stages.map((item) => <SelectItem key={item.id} value={item.id}>{stageLabel(item)}</SelectItem>)}</SelectContent>
                        </Select>
                        <Button size="sm" variant="ghost" className="h-8 px-2 text-xs" onClick={() => window.location.assign(`/leads/${encodeURIComponent(lead.id)}`)}>
                          <Building2 className="size-3.5" /> {t('common.view')}
                        </Button>
                      </div>
                    </article>
                  ))}
                </div>
              </fieldset>
            );
          })}
        </div>
      </div>
    </div>
  );
}
