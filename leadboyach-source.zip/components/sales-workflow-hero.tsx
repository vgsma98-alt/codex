'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Building2, Check, CirclePlay, DatabaseZap, Globe2, Mail, MapPin, MousePointer2, Pause, Phone, Play, Search, Sparkles } from 'lucide-react';
import { t, useI18n } from '@/lib/i18n';
import './sales-workflow-hero.css';

const slides = ['discover', 'qualify', 'convert'] as const;
const stages = ['new', 'contacted', 'qualified', 'proposal', 'won'] as const;

export function SalesWorkflowHero({ onStart, onDemo }: { onStart: () => void; onDemo: () => void }) {
  const { direction, formatNumber } = useI18n();
  const [slide, setSlide] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [interacting, setInteracting] = useState(false);
  const [reduced, setReduced] = useState(false);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = () => setReduced(media.matches);
    const visibility = () => setVisible(!document.hidden);
    sync(); media.addEventListener('change', sync); document.addEventListener('visibilitychange', visibility);
    return () => { media.removeEventListener('change', sync); document.removeEventListener('visibilitychange', visibility); };
  }, []);
  useEffect(() => {
    if (paused || interacting || reduced || !visible) return;
    const timer = window.setInterval(() => setProgress(p => Math.min(100, p + 100 / 70)), 100);
    return () => window.clearInterval(timer);
  }, [paused, interacting, reduced, visible]);
  useEffect(() => { if (progress >= 100) { setSlide(s => (s + 1) % 3); setProgress(0); } }, [progress]);
  const choose = (index: number) => { setSlide(index); setProgress(0); };
  const key = slides[slide];
  const step = reduced ? 4 : Math.min(4, Math.floor(progress / 20));
  const score = slide === 0 ? Math.min(92, Math.round(progress * 4)) : 94;
  const won = slide === 2 && step === 4;
  return (
    <section className="sw-hero" dir={direction} aria-label={t('landing.heroCarousel')}>
      <div className="sw-shell">
        <div className="sw-grid">
          <div className="sw-copy">
            <div className="sw-eyebrow"><Sparkles size={16} />{t('landing.sw.system')}</div>
            <div className="sw-copy-stack">
              {slides.map((item, index) => <div key={item} className={`sw-copy-panel ${slide === index ? 'is-active' : ''}`} aria-hidden={slide !== index}>
                <p className="sw-kicker">0{index + 1} / {t(`landing.hero.nav.${item}`)}</p>
                {index === 0 ? <h1>{t('landing.sw.title')}<span>{t('landing.sw.titleAccent')}</span></h1> : <h2>{t(`landing.hero.${item}Title`)}</h2>}
                <p className="sw-description">{t(index === 0 ? 'landing.sw.description' : `landing.hero.${item}Description`)}</p>
              </div>)}
            </div>
            <div className="sw-actions"><button className="sw-primary" onClick={onStart}>{t(`landing.hero.${key}Primary`)}<ArrowRight size={18} className="rtl:rotate-180" /></button><button className="sw-secondary" onClick={onDemo}><CirclePlay size={20}/>{t('landing.hero.discoverSecondary')}</button></div>
            <div className="sw-promise"><span/><p>{t('landing.sw.promise')}</p></div>
          </div>

          <div className={`sw-stage sw-stage-${slide} ${paused || interacting || reduced ? 'sw-paused' : ''}`} dir="ltr"
            onPointerEnter={e => { if (e.pointerType === 'mouse') setInteracting(true); }} onPointerLeave={() => setInteracting(false)}
            onFocusCapture={() => setInteracting(true)} onBlurCapture={e => { if (!e.currentTarget.contains(e.relatedTarget)) setInteracting(false); }}>
            <div className="sw-stage-top"><span className="sw-workspace"><Image src="/leadboyach-logo.png" alt="" width={28} height={28}/>LEADBOYACH <span>/ {t('landing.sw.workspace')}</span></span><span className="sw-demo-label">{t('landing.demoFictionalData')}</span></div>
            <div className={`sw-scene sw-radar ${slide === 0 ? 'is-active' : ''}`} aria-hidden={slide !== 0}>
              <div className="sw-query"><Search size={17}/><span>{t('landing.demoActivityValue')}</span><i/><MapPin size={15}/><span>{t('landing.demoCityValue')}</span></div>
              <div className="sw-orbit"><div className="sw-scan"/><div className="sw-orbit-inner"/><div className="sw-core"><Image src="/leadboyach-logo.png" alt="LEADBOYACH" width={56} height={56}/></div></div>
              <svg className="sw-connectors" viewBox="0 0 600 440" aria-hidden="true"><path d="M300 220 L110 135 M300 220 L472 115 M300 220 L467 300"/></svg>
              <div className="sw-satellite sw-satellite-a"><Building2 size={18}/><span>Nexa Conseil<small>{t('landing.hero.state.qualified')}</small></span><b>84</b></div>
              <div className="sw-satellite sw-satellite-b"><Building2 size={18}/><span>Rimal Properties<small>{t('landing.hero.state.potential')}</small></span><b>76</b></div>
              <MousePointer2 className="sw-pointer" size={25}/>
              <div className="sw-discovery-count"><b>{formatNumber(reduced ? 2847 : Math.min(2847, Math.round(progress * 125)))}</b><span>{t('landing.hero.companiesFound')}</span><span className="sw-count-tag">+ {formatNumber(326)} {t('landing.hero.qualifiedOpportunities')}</span></div>
            </div>
            <div className={`sw-scene sw-engine ${slide === 1 ? 'is-active' : ''}`} aria-hidden={slide !== 1}>
              <div className="sw-engine-caption"><DatabaseZap size={22}/><span>{t('landing.sw.engine')}<small>{t('landing.sw.engineText')}</small></span></div>
              <div className="sw-processing-line">{['discover','enrich','score','qualify'].map((item,index) => <div key={item} className={step >= index ? 'is-done' : ''}><span>{step >= index ? <Check size={14}/> : index + 1}</span>{t(`landing.hero.engine.${item}`)}</div>)}</div>
              <div className="sw-data-fields">{[{ Icon: Phone, field: 3 }, { Icon: Mail, field: 0 }, { Icon: Globe2, field: 1 }, { Icon: MapPin, field: 2 }].map(({ Icon, field }, index) => <div key={field} className={step >= index ? 'is-done' : ''}><Icon size={16}/><span>{t(`landing.sw.field${field}`)}</span><Check size={14}/></div>)}</div>
              <div className="sw-ready"><Check size={16}/>{t('landing.sw.ready')}</div>
            </div>
            <div className={`sw-scene sw-kanban ${slide === 2 ? 'is-active' : ''}`} aria-hidden={slide !== 2}>
              <div className="sw-kanban-title"><span>{t('landing.sw.pipeline')}</span><b>{formatNumber(124500)} MAD</b></div>
              <div className="sw-columns">{stages.map((item,index) => <div key={item} className={step === index ? 'is-current' : ''}><p><span/>{t(`landing.hero.stage.${item}`)}</p><div className="sw-ghost-card"/><div className="sw-ghost-card sw-ghost-short"/></div>)}</div>
              <div className={`sw-won ${won ? 'is-visible' : ''}`}><span><Check size={18}/></span><div>{t('landing.sw.won')}<b>+ {formatNumber(24500)} MAD</b></div></div>
              <div className="sw-mini-metrics"><span><b>42</b>{t('landing.hero.metric.activeLeads')}</span><span><b>18</b>{t('landing.hero.metric.qualifiedLeads')}</span><span><b>7</b>{t('landing.hero.metric.opportunities')}</span></div>
            </div>

            <div className={`sw-shared-lead ${won ? 'is-won' : ''}`} style={slide === 2 ? { left: `${3 + step * 18}%`, top: '45%' } : undefined}>
              <div className="sw-lead-top"><span className="sw-company-mark">A</span><span className="sw-company-name">Atlas Industrie<small>{t('landing.demoLocation')}</small></span><span className="sw-lead-check"><Check size={14}/></span></div>
              <div className="sw-lead-score"><span>{t('landing.sw.score')}</span><b>{reduced ? 94 : score}<small>/100</small></b></div>
              <div className="sw-score-line"><span style={{width:`${reduced ? 94 : score}%`}}/></div>
              <span className="sw-lead-status">{t(won ? 'landing.sw.won' : slide === 0 ? 'landing.sw.detected' : 'landing.sw.ready')}</span>
            </div>
            <div className="sw-stage-bottom"><span className="sw-signal"/>{t(`landing.sw.caption${slide}`)}<span>0{slide + 1} / 03</span></div>
          </div>
        </div>
        <div className="sw-navigation"><nav aria-label={t('landing.heroCarouselControls')}>{slides.map((item,index) => <button key={item} onClick={() => choose(index)} aria-current={slide === index ? 'step' : undefined} className={slide === index ? 'is-active' : ''}><span>0{index+1}</span><div><b>{t(`landing.hero.nav.${item}`)}</b><small>{t(`landing.sw.nav${index}`)}</small></div><ArrowRight size={16}/><i style={{transform:`scaleX(${slide === index ? progress / 100 : 0})`}}/></button>)}</nav><button className="sw-play" onClick={() => setPaused(p => !p)} aria-label={t(paused ? 'landing.playDemo' : 'landing.pauseDemo')} aria-pressed={paused}>{paused ? <Play size={18}/> : <Pause size={18}/>}</button></div>
      </div>
    </section>
  );
}
