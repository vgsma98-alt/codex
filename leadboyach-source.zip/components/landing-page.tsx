'use client';

import { useEffect, useState } from 'react';
import {
  ArrowRight,
  BarChart3,
  Check,
  ChevronRight,
  CirclePlay,
  DatabaseZap,
  Globe2,
  Mail,
  MapPinned,
  Menu,
  MousePointer2,
  Pause,
  Phone,
  Play,
  Search,
  ShieldCheck,
  Target,
  TrendingUp,
  UsersRound,
  X,
  Zap,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LanguageSwitcher } from '@/components/language-switcher';
import { ChayobLogo } from '@/components/chayob-logo';
import { SalesWorkflowHero } from '@/components/sales-workflow-hero';
import { t, useI18n } from '@/lib/i18n';

const featureIcons = [Search, DatabaseZap, UsersRound, BarChart3, ShieldCheck, Globe2];
const demoStages = ['new', 'contacted', 'qualified', 'won'] as const;
const howSteps = [
  { Icon: Search, number: '01', title: 'landing.step1Title', text: 'landing.step1Text' },
  { Icon: Zap, number: '02', title: 'landing.step2Title', text: 'landing.step2Text' },
  { Icon: Target, number: '03', title: 'landing.step3Title', text: 'landing.step3Text' },
];

export function LandingPage({ onAuthenticate }: { onAuthenticate: (mode?: 'login' | 'signup') => void }) {
  const { direction, formatNumber } = useI18n();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoPlaying, setDemoPlaying] = useState(true);
  const [demoStep, setDemoStep] = useState(0);
  useEffect(() => {
    if (!demoPlaying) return;
    const timer = window.setTimeout(() => setDemoStep((step) => (step + 1) % 3), 4500);
    return () => window.clearTimeout(timer);
  }, [demoPlaying, demoStep]);

  const goTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <main dir={direction} className="min-h-screen overflow-hidden bg-[#f8fafc] text-slate-950">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-emerald-300/10 bg-[#032e25]/92 text-white backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <button type="button" aria-label={t('landing.home')} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <ChayobLogo inverse />
          </button>
          <nav className="hidden items-center gap-8 text-sm font-bold text-slate-300 lg:flex" aria-label={t('landing.navigation')}>
            <button className="transition hover:text-white" onClick={() => goTo('how-it-works')}>{t('landing.navHow')}</button>
            <button className="transition hover:text-white" onClick={() => goTo('features')}>{t('landing.navFeatures')}</button>
            <button className="transition hover:text-white" onClick={() => goTo('pricing')}>{t('landing.navPricing')}</button>
            <button className="transition hover:text-white" onClick={() => window.location.assign('/contact')}>{t('landing.navContact')}</button>
          </nav>
          <div className="hidden items-center gap-3 lg:flex">
            <LanguageSwitcher className="border-white/15 bg-white/10 text-white hover:bg-white/15" />
            <Button variant="ghost" className="text-white hover:bg-white/10 hover:text-white" onClick={() => onAuthenticate('login')}>{t('landing.login')}</Button>
            <Button className="rounded-xl bg-white font-black text-slate-950 hover:bg-indigo-50" onClick={() => onAuthenticate('signup')}>{t('landing.startFree')}</Button>
          </div>
          <Button size="icon" variant="ghost" className="text-white hover:bg-white/10 hover:text-white lg:hidden" aria-label={t('landing.menu')} onClick={() => setMobileMenuOpen((open) => !open)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
        {mobileMenuOpen && (
          <div className="border-t border-white/10 bg-[#032e25] px-5 py-5 lg:hidden">
            <div className="mx-auto grid max-w-[1440px] gap-2">
              <Button variant="ghost" className="justify-start text-white" onClick={() => goTo('how-it-works')}>{t('landing.navHow')}</Button>
              <Button variant="ghost" className="justify-start text-white" onClick={() => goTo('features')}>{t('landing.navFeatures')}</Button>
              <Button variant="ghost" className="justify-start text-white" onClick={() => goTo('pricing')}>{t('landing.navPricing')}</Button>
              <Button variant="ghost" className="justify-start text-white" onClick={() => window.location.assign('/contact')}>{t('landing.navContact')}</Button>
              <div className="mt-3 flex items-center gap-2"><LanguageSwitcher /><Button className="flex-1" onClick={() => onAuthenticate('signup')}>{t('landing.startFree')}</Button></div>
            </div>
          </div>
        )}
      </header>

      <SalesWorkflowHero onStart={() => onAuthenticate('signup')} onDemo={() => goTo('product-tour')} />

      <section className="relative z-10 mx-auto -mt-10 max-w-[1240px] px-5 sm:px-8">
        <div className="grid overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl shadow-slate-200/70 sm:grid-cols-3">
          {[
            [MapPinned, 'landing.statDiscover', 'landing.statDiscoverText'],
            [MousePointer2, 'landing.statOrganize', 'landing.statOrganizeText'],
            [TrendingUp, 'landing.statConvert', 'landing.statConvertText'],
          ].map(([Icon, title, description], index) => (
            <div key={String(title)} className={`p-6 sm:p-7 ${index < 2 ? 'border-b border-slate-100 sm:border-b-0 sm:border-e' : ''}`}>
              <Icon className="size-6 text-indigo-600" /><p className="mt-3 text-lg font-black">{t(String(title))}</p><p className="mt-1 text-sm leading-6 text-slate-500">{t(String(description))}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how-it-works" className="scroll-mt-24 px-5 py-24 sm:px-8 lg:py-32">
        <div className="mx-auto max-w-[1240px]">
          <SectionHeading eyebrow={t('landing.howEyebrow')} title={t('landing.howTitle')} description={t('landing.howDescription')} />
          <div className="mt-14 grid gap-5 lg:grid-cols-3">
            {howSteps.map(({ Icon, number, title, text }) => (
              <article key={number} className="group relative overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white p-7 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-100">
                <span className="absolute end-5 top-3 text-7xl font-black text-slate-50">{number}</span>
                <span className="relative grid size-13 place-items-center rounded-2xl bg-indigo-50 text-indigo-600 transition group-hover:bg-indigo-600 group-hover:text-white"><Icon className="size-6" /></span>
                <h3 className="relative mt-7 text-xl font-black">{t(title)}</h3><p className="relative mt-3 leading-7 text-slate-500">{t(text)}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="product-tour" className="scroll-mt-24 bg-[#ecfdf5] px-5 py-24 sm:px-8 lg:py-32">
        <div className="mx-auto grid max-w-[1240px] items-center gap-12 lg:grid-cols-[.8fr_1.2fr]">
          <div>
            <Badge className="rounded-full bg-indigo-600 text-white"><Play className="size-3.5" />{t('landing.demoEyebrow')}</Badge>
            <h2 className="mt-5 text-3xl font-black leading-tight sm:text-5xl">{t('landing.demoTitle')}</h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">{t('landing.demoDescription')}</p>
            <div className="mt-8 space-y-4">
              {['search', 'enrich', 'manage'].map((key, index) => (
                <button key={key} onClick={() => { setDemoStep(index); setDemoPlaying(true); }} className={`flex w-full items-center gap-4 rounded-2xl border p-4 text-start transition ${demoStep === index ? 'border-indigo-300 bg-white shadow-lg shadow-indigo-100' : 'border-transparent hover:bg-white/60'}`}>
                  <span className={`grid size-9 place-items-center rounded-xl text-sm font-black ${demoStep === index ? 'bg-indigo-600 text-white' : 'bg-white text-slate-500'}`}>{index + 1}</span>
                  <span><span className="block font-black">{t(`landing.demo.${key}Title`)}</span><span className="mt-1 block text-sm text-slate-500">{t(`landing.demo.${key}Text`)}</span></span>
                </button>
              ))}
            </div>
          </div>
          <div className="relative overflow-hidden rounded-[2rem] border border-emerald-900/20 bg-[#052e2b] p-3 shadow-2xl shadow-indigo-200/70" aria-label={t('landing.demoVideoLabel')}>
            <div className="flex items-center justify-between border-b border-white/10 px-3 pb-3 text-white">
              <div className="flex items-center gap-2"><span className="size-2.5 rounded-full bg-red-400" /><span className="size-2.5 rounded-full bg-amber-400" /><span className="size-2.5 rounded-full bg-emerald-400" /></div>
              <span className="flex items-center gap-2 text-xs font-bold text-slate-400"><CirclePlay className="size-4 text-indigo-300" />{t('landing.demoWindow')}</span>
              <button onClick={() => setDemoPlaying((playing) => !playing)} className="grid size-9 place-items-center rounded-xl bg-white/10 transition hover:bg-white/15" aria-label={demoPlaying ? t('landing.pauseDemo') : t('landing.playDemo')}>{demoPlaying ? <Pause className="size-4" /> : <Play className="size-4" />}</button>
            </div>
            <div className="flex gap-1.5 px-3 pt-3" aria-hidden="true">{[0, 1, 2].map((step) => <span key={step} className="h-1 flex-1 overflow-hidden rounded-full bg-white/10"><span key={`${step}-${demoStep}-${demoPlaying}`} className={`block h-full origin-left bg-gradient-to-r from-indigo-400 to-cyan-300 rtl:origin-right ${step < demoStep ? 'w-full' : step === demoStep ? demoPlaying ? 'landing-demo-progress' : 'w-1/2' : 'w-0'}`} /></span>)}</div>
            <div className="grid min-h-[440px] gap-3 p-3 sm:grid-cols-[.34fr_1fr]">
              <div className="hidden rounded-2xl bg-white/[0.06] p-4 sm:block"><ChayobLogo inverse compact /><div className="mt-8 space-y-3">{['landing.demoNav1', 'landing.demoNav2', 'landing.demoNav3'].map((key, index) => <button key={key} type="button" onClick={() => { setDemoStep(index); setDemoPlaying(true); }} className={`w-full rounded-xl px-3 py-2.5 text-start text-xs font-bold transition ${demoStep === index ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-950/40' : 'text-slate-400 hover:bg-white/5'}`}>{t(key)}</button>)}</div><div className="mt-8 rounded-xl border border-white/10 bg-white/5 p-3 text-xs leading-5 text-slate-400"><MapPinned className="mb-2 size-4 text-cyan-300" />{t('landing.demoLocation')}</div></div>
              <div className="overflow-hidden rounded-2xl bg-slate-50 p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3"><div aria-live="polite"><p className="text-xs font-bold text-indigo-600">{t(`landing.demo.scene${demoStep + 1}Eyebrow`)}</p><h3 className="mt-1 text-lg font-black">{t(`landing.demo.scene${demoStep + 1}Title`)}</h3></div><div className="flex shrink-0 flex-col items-end gap-1.5"><span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700"><span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />{t('landing.demoRealtime')}</span><span className="rounded-full bg-slate-200 px-2 py-1 text-[9px] font-bold text-slate-600">{t('landing.demoFictionalData')}</span></div></div>

                {demoStep === 0 && <div className="mt-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className="grid gap-3 sm:grid-cols-3">{[
                    ['landing.demoActivity', 'landing.demoActivityValue'],
                    ['landing.demoCity', 'landing.demoCityValue'],
                    ['landing.demoCountry', 'landing.demoCountryValue'],
                  ].map(([label, value]) => <div key={label} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{t(label)}</p><p className="mt-2 text-xs font-black text-slate-800">{t(value)}</p></div>)}</div>
                  <div className="mt-4 rounded-xl border border-indigo-100 bg-indigo-50/70 p-4"><div className="flex items-center justify-between gap-4"><div><p className="text-xs font-black text-indigo-950">{t('landing.demoSearchTarget')}</p><p className="mt-1 text-[11px] text-indigo-700">{t('landing.demoSearchTargetText')}</p></div><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-indigo-600 text-white"><Search className="size-4" /></span></div></div>
                  <button type="button" onClick={() => setDemoStep(1)} className="mt-4 flex h-11 w-full animate-pulse items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-sm font-black text-white shadow-lg shadow-indigo-200"><Search className="size-4" />{t('landing.demoLaunchSearch')}</button>
                </div>}

                {demoStep === 1 && <div className="mt-5 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className="grid grid-cols-3 gap-2">{[[12,'landing.demoProspects'],[10,'landing.demoPhones'],[7,'landing.demoEmails']].map(([value,key]) => <div key={String(key)} className="rounded-xl bg-white p-3 shadow-sm"><p className="text-lg font-black tabular-nums">{formatNumber(Number(value))}</p><p className="mt-1 text-[10px] text-slate-500">{t(String(key))}</p></div>)}</div>
                  <div className="mt-4 overflow-hidden rounded-xl border border-slate-200 bg-white">
                    <div className="hidden grid-cols-[minmax(0,1.15fr)_minmax(8.75rem,.9fr)_minmax(0,1.15fr)] gap-3 border-b border-slate-100 bg-slate-50 px-3 py-2 text-[9px] font-bold text-slate-400 sm:grid">
                      <span>{t('landing.demoProspects')}</span>
                      <span>{t('landing.demoPhones')}</span>
                      <span>{t('landing.demoEmails')}</span>
                    </div>
                    {[
                      ['Madar Immobilier', '+212 5 22 40 18 72', 'contact@madar-immo.test'],
                      ['Casa Nova Habitat', '+212 6 12 34 56 78', 'info@casa-nova.test'],
                      ['Rimal Properties', '+212 6 61 27 49 30', 'commercial@rimal-properties.test'],
                    ].map(([name, phone, email], index) => (
                      <div key={name} className={`grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-2 p-3 sm:grid-cols-[minmax(0,1.15fr)_minmax(8.75rem,.9fr)_minmax(0,1.15fr)] ${index < 2 ? 'border-b border-slate-100' : ''}`}>
                        <div className="min-w-0"><p dir="ltr" className="truncate text-start text-xs font-black">{name}</p><p className="mt-1 text-[10px] text-slate-400">{t('landing.demoActivityValue')}</p></div>
                        <p dir="ltr" className="flex items-center justify-start gap-1.5 whitespace-nowrap text-left text-[10px] tabular-nums text-slate-600"><Phone className="size-3 shrink-0 text-emerald-500" /><bdi>{phone}</bdi></p>
                        <p dir="ltr" className="col-span-2 flex min-w-0 items-center justify-start gap-1.5 text-left text-[10px] text-slate-600 sm:col-span-1"><Mail className="size-3 shrink-0 text-cyan-500" /><bdi className="truncate">{email}</bdi></p>
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 flex items-center gap-2 text-[11px] font-bold text-emerald-700"><span className="grid size-5 place-items-center rounded-full bg-emerald-100"><Check className="size-3" /></span>{t('landing.demoDataFound')}</p>
                </div>}

                {demoStep === 2 && <div className="mt-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{demoStages.map((stage, index) => <div key={stage} className={`min-h-36 rounded-xl border p-2.5 ${index === 2 ? 'border-indigo-300 bg-indigo-50 ring-2 ring-indigo-100' : 'border-slate-200 bg-white'}`}><div className="flex items-center justify-between"><span className="text-[10px] font-black">{t(`landing.stage.${stage}`)}</span><span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-black text-slate-600">{[6,3,2,1][index]}</span></div>{index === 0 && <DemoLead name="Casa Nova Habitat" />}{index === 1 && <DemoLead name="Madar Immobilier" />}{index === 2 && <DemoLead name="Rimal Properties" active />}{index === 3 && <DemoLead name="Safa Immobilier" won />}</div>)}</div>
                  <div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-slate-950 px-4 py-3 text-white"><div><p className="text-xs font-black">{t('landing.demoPipelineInsight')}</p><p className="mt-1 text-[10px] text-slate-400">{t('landing.demoPipelineInsightText')}</p></div><TrendingUp className="size-5 shrink-0 text-emerald-400" /></div>
                </div>}
              </div>
            </div>
            <div className="pointer-events-none absolute z-30 hidden transition-all duration-1000 ease-in-out sm:block" style={{ left: ['72%', '78%', '68%'][demoStep], top: ['77%', '64%', '66%'][demoStep] }} aria-hidden="true">
              <span key={demoStep} className="absolute -left-3 -top-3 size-9 animate-ping rounded-full border-2 border-indigo-400/70 bg-indigo-400/20" />
              <MousePointer2 className="relative size-8 fill-white text-slate-950 drop-shadow-[0_3px_4px_rgba(0,0,0,.45)]" />
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="scroll-mt-24 px-5 py-24 sm:px-8 lg:py-32">
        <div className="mx-auto max-w-[1240px]">
          <SectionHeading eyebrow={t('landing.featuresEyebrow')} title={t('landing.featuresTitle')} description={t('landing.featuresDescription')} />
          <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {featureIcons.map((Icon, index) => <article key={index} className="rounded-3xl border border-slate-200 bg-white p-6"><span className="grid size-11 place-items-center rounded-2xl bg-slate-950 text-white"><Icon className="size-5" /></span><h3 className="mt-5 text-lg font-black">{t(`landing.feature${index + 1}Title`)}</h3><p className="mt-2 leading-7 text-slate-500">{t(`landing.feature${index + 1}Text`)}</p></article>)}
          </div>
        </div>
      </section>

      <section id="pricing" className="scroll-mt-24 bg-[#032e25] px-5 py-24 text-white sm:px-8 lg:py-32">
        <div className="mx-auto max-w-[1240px]">
          <SectionHeading dark eyebrow={t('landing.pricingEyebrow')} title={t('landing.pricingTitle')} description={t('landing.pricingDescription')} />
          <div className="mt-14 grid items-stretch gap-5 md:grid-cols-2 xl:grid-cols-4">
            {[
              { key: 'starter', price: t('landing.trialPrice'), monthlyLeads: 30, accent: false },
              { key: 'professional', price: '499', monthlyLeads: 1500, accent: true },
              { key: 'company', price: '1499', monthlyLeads: 6000, accent: false },
              { key: 'custom', price: t('landing.contactUs'), monthlyLeads: null, accent: false },
            ].map((plan) => (
              <article key={plan.key} className={`relative flex flex-col rounded-[2rem] border p-7 ${plan.accent ? 'border-indigo-400 bg-gradient-to-b from-indigo-500/20 to-white/[0.06] shadow-2xl shadow-indigo-950' : 'border-white/10 bg-white/[0.04]'}`}>
                {plan.accent && <Badge className="absolute -top-3 end-6 bg-indigo-500 text-white">{t('landing.mostPopular')}</Badge>}
                <p className="text-lg font-black">{t(`landing.plan.${plan.key}`)}</p><p className="mt-2 min-h-12 text-sm leading-6 text-slate-400">{t(`landing.plan.${plan.key}Text`)}</p>
                <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3">
                  <p className="text-xs font-bold text-slate-400">{t('landing.monthlyCapacity')}</p>
                  <p className="mt-1 flex items-baseline gap-2"><span className="text-2xl font-black text-white">{plan.monthlyLeads === null ? t('landing.customCapacity') : formatNumber(plan.monthlyLeads)}</span>{plan.monthlyLeads !== null && <span className="text-sm font-semibold text-slate-300">{t('landing.prospectsPerMonth')}</span>}</p>
                </div>
                <div className="mt-7 flex items-end gap-2"><span className={plan.key === 'custom' ? 'text-2xl font-black' : 'text-4xl font-black'}>{plan.price}</span>{!['starter', 'custom'].includes(plan.key) && <span className="pb-1 text-sm text-slate-400">{t('landing.perMonth')}</span>}</div>
                <div className="my-7 h-px bg-white/10" />
                <ul className="flex-1 space-y-4">{[1,2,3,4].map((item) => <li key={item} className="flex items-start gap-3 text-sm text-slate-300"><span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-emerald-400/15 text-emerald-300"><Check className="size-3" /></span>{t(`landing.plan.${plan.key}Feature${item}`)}</li>)}</ul>
                <Button size="lg" className={`mt-8 h-12 rounded-xl font-black ${plan.accent ? 'bg-white text-slate-950 hover:bg-indigo-50' : 'bg-white/10 text-white hover:bg-white/15'}`} onClick={() => plan.key === 'custom' ? window.location.assign('/contact') : onAuthenticate('signup')}>{plan.key === 'custom' ? t('landing.contactUs') : plan.key === 'starter' ? t('landing.startTrial') : t('landing.choosePlan')}<ChevronRight className="size-4 rtl:rotate-180" /></Button>
              </article>
            ))}
          </div>
          <p className="mt-6 text-center text-sm text-slate-500">{t('landing.pricingNote')}</p>
        </div>
      </section>

      <section className="px-5 py-20 sm:px-8">
        <div className="relative mx-auto max-w-[1240px] overflow-hidden rounded-[2.25rem] bg-gradient-to-br from-indigo-600 via-violet-600 to-cyan-500 p-8 text-white sm:p-12 lg:flex lg:items-center lg:justify-between">
          <div className="absolute inset-0 opacity-20 [background-image:radial-gradient(circle_at_20%_20%,white_0,transparent_35%)]" />
          <div className="relative max-w-2xl"><p className="text-sm font-black uppercase tracking-[.2em] text-indigo-100">{t('landing.ctaEyebrow')}</p><h2 className="mt-3 text-3xl font-black sm:text-5xl">{t('landing.ctaTitle')}</h2><p className="mt-4 text-lg text-indigo-100">{t('landing.ctaText')}</p></div>
          <Button size="lg" className="relative mt-8 h-14 rounded-2xl bg-white px-7 font-black text-slate-950 hover:bg-indigo-50 lg:mt-0" onClick={() => onAuthenticate('signup')}>{t('landing.startFree')}<ArrowRight className="rtl:rotate-180" /></Button>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white px-5 py-8 sm:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-col items-center justify-between gap-5 sm:flex-row"><button type="button" aria-label={t('landing.home')} onClick={() => window.location.assign('/landing')}><ChayobLogo /></button><p className="text-sm text-slate-500">{t('landing.footer')}</p><div className="flex items-center gap-2"><Button variant="ghost" onClick={() => window.location.assign('/contact')}>{t('landing.navContact')}</Button><Button variant="ghost" onClick={() => onAuthenticate('login')}>{t('landing.login')}</Button></div></div>
      </footer>
    </main>
  );
}

function SectionHeading({ eyebrow, title, description, dark = false }: { eyebrow: string; title: string; description: string; dark?: boolean }) {
  return <div className="mx-auto max-w-3xl text-center"><p className="text-sm font-black uppercase tracking-[.18em] text-indigo-500">{eyebrow}</p><h2 className={`mt-4 text-3xl font-black leading-tight sm:text-5xl ${dark ? 'text-white' : 'text-slate-950'}`}>{title}</h2><p className={`mx-auto mt-5 max-w-2xl text-lg leading-8 ${dark ? 'text-slate-400' : 'text-slate-500'}`}>{description}</p></div>;
}

function DemoLead({ name, active = false, won = false }: { name: string; active?: boolean; won?: boolean }) {
  return <div className={`mt-3 rounded-lg border p-2 shadow-sm transition-all duration-500 ${active ? 'translate-y-1 border-indigo-300 bg-white shadow-indigo-100' : won ? 'border-emerald-200 bg-emerald-50' : 'border-slate-100 bg-slate-50'}`}><p className="truncate text-[10px] font-black text-slate-800">{name}</p><div className="mt-2 flex items-center gap-1"><span className={`size-1.5 rounded-full ${won ? 'bg-emerald-500' : active ? 'animate-pulse bg-indigo-500' : 'bg-slate-300'}`} /><span className="text-[9px] text-slate-400">{t('landing.demoLeadMeta')}</span></div></div>;
}
