'use client';

import Image from 'next/image';

import { t } from '@/lib/i18n';

export function ChayobLogo({ inverse = false, compact = false }: { inverse?: boolean; compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" aria-label="LEADBOYACH">
      <span
        className={`${compact ? 'size-14' : 'size-[4.5rem]'} relative block shrink-0 overflow-hidden rounded-[1.35rem] bg-emerald-600 shadow-lg shadow-emerald-950/20 ring-1 ring-white/15`}
      >
        <Image
          src="/leadboyach-logo.png"
          alt="Logo LEADBOYACH — Find, Connect, Grow"
          fill
          sizes={compact ? '56px' : '72px'}
          priority
          className="scale-[1.06] object-cover"
        />
      </span>
      {!compact && (
        <span className="min-w-0">
          <span className={`block text-[1.05rem] font-black tracking-[-0.04em] ${inverse ? 'text-white' : 'text-slate-950'}`}>LEADBOYACH</span>
          <span className={`block text-[11px] font-semibold ${inverse ? 'text-emerald-200' : 'text-slate-500'}`}>{t('landing.logoTagline')}</span>
        </span>
      )}
    </div>
  );
}
