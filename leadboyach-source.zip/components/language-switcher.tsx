'use client';

import { Languages } from 'lucide-react';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { t, type Language, useI18n } from '@/lib/i18n';

const flags: Record<Language, string> = { ar: '🇲🇦', fr: '🇫🇷', en: '🇬🇧' };

export function LanguageSwitcher({ className = '' }: { className?: string }) {
  const { language, setLanguage } = useI18n();
  const currentLabel = `${flags[language]} ${t(`language.${language}`)}`;

  return (
    <Select value={language} onValueChange={(value) => void setLanguage(value as Language)}>
      <SelectTrigger className={`h-10 min-w-36 bg-white/90 ${className}`} aria-label={t('language.label')}>
        <Languages className="size-4" />
        <SelectValue>{currentLabel}</SelectValue>
      </SelectTrigger>
      <SelectContent>
        {(['fr', 'en', 'ar'] as Language[]).map((item) => (
          <SelectItem key={item} value={item}>{flags[item]} {t(`language.${item}`)}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
