'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Building2, FileSpreadsheet, Phone, RotateCcw, Search, SlidersHorizontal } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { Lead, PipelineStage } from '@/lib/database.types';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { exportLeadsToExcel } from '@/lib/lead-export';
import { PipelineStageSelect } from '@/components/pipeline-stage-status';
import { leadQualityLabel, leadQualityTone } from '@/lib/lead-quality';
import { ProspectEmailCell, ProspectNameHover } from '@/components/prospect-hover-card';

const PAGE_SIZE = 25;
const DATABASE_PAGE_SIZE = 1000;

function isAvailable(value: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(normalized && !['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined'].includes(normalized));
}

function compactName(value: string | null, fallback: string) {
  const fullName = value?.trim() || fallback;
  const words = fullName.split(/\s+/).filter((word) => word.replace(/[-–—|,;:/]+/g, '').length > 0);
  return words.length > 7 ? `${words.slice(0, 7).join(' ')}…` : fullName;
}

function firstUpper(value: string | null) {
  const text = value?.trim() || '—';
  return text === '—' ? text : `${text.charAt(0).toLocaleUpperCase()}${text.slice(1)}`;
}

function leadCity(lead: Lead, fallbackCity?: string | null): string | null {
  const city = lead.City?.trim();
  const normalized = city?.toLocaleLowerCase().replace(/[\s./_-]/g, '');
  const invalidValues = new Set(['nr', 'na', 'notfound', 'unknown', 'inconnu', 'غيرمعروف']);
  return normalized && !invalidValues.has(normalized) ? (city ?? null) : fallbackCity?.trim() || null;
}

function QualityBadge({ quality }: { quality: string | null }) {
  const { t } = useI18n();
  const tone = leadQualityTone(quality);
  const className = tone === 'positive'
    ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
    : tone === 'average'
      ? 'border-amber-200 bg-amber-50 text-amber-700'
      : tone === 'negative'
        ? 'border-red-200 bg-red-50 text-red-700'
        : 'border-slate-200 bg-slate-50 text-slate-500';
  return <Badge variant="outline" className={className}>{leadQualityLabel(quality, t)}</Badge>;
}

function upsertLead(current: Lead[], incoming: Lead) {
  const existing = current.find((lead) => lead.id === incoming.id);
  if (existing && existing.pipeline_version > incoming.pipeline_version) return current;
  return existing
    ? current.map((lead) => (lead.id === incoming.id ? incoming : lead))
    : [incoming, ...current];
}

export function AllProspects({ userId }: { userId: string }) {
  const { t, formatNumber } = useI18n();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stages, setStages] = useState<PipelineStage[]>([]);
  const [searchCities, setSearchCities] = useState<Map<number, string>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stageError, setStageError] = useState('');
  const [busyLeadIds, setBusyLeadIds] = useState<Set<string>>(new Set());
  const [query, setQuery] = useState('');
  const [availability, setAvailability] = useState('all');
  const [score, setScore] = useState('all');
  const [quality, setQuality] = useState('all');
  const [activity, setActivity] = useState('all');
  const [location, setLocation] = useState('all');
  const [page, setPage] = useState(1);

  const loadLeads = useCallback(async () => {
    setLoading(true);
    setError('');
    const stageRequest = supabase
      .from('Pipeline_Stages')
      .select('*')
      .eq('user_id', userId)
      .order('position', { ascending: true });
    const searchRequest = supabase
      .from('Searches')
      .select('id,Ville')
      .eq('User_id', userId);
    const rows: Lead[] = [];
    for (let from = 0; ; from += DATABASE_PAGE_SIZE) {
      const { data, error: loadError } = await supabase
        .from('Leads')
        .select('*')
        .eq('User_id', userId)
        .order('Search_id', { ascending: false })
        .range(from, from + DATABASE_PAGE_SIZE - 1);
      if (loadError) {
        setError(t('prospects.loadError'));
        setLoading(false);
        return;
      }
      const batch = (data ?? []) as Lead[];
      rows.push(...batch);
      if (batch.length < DATABASE_PAGE_SIZE) break;
    }
    const [stageResult, searchResult] = await Promise.all([stageRequest, searchRequest]);
    if (stageResult.error || searchResult.error) {
      setError(t('prospects.loadError'));
      setLoading(false);
      return;
    }
    setLeads(rows);
    setStages(stageResult.data ?? []);
    setSearchCities(new Map((searchResult.data ?? []).map((search) => [search.id, search.Ville?.trim() || ''])));
    setLoading(false);
  }, [t, userId]);

  useEffect(() => {
    void loadLeads();
    const channel = supabase
      .channel(`all-prospects-${userId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'Leads', filter: `User_id=eq.${userId}` }, () => void loadLeads())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'Pipeline_Stages', filter: `user_id=eq.${userId}` }, () => void loadLeads())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'Searches', filter: `User_id=eq.${userId}` }, () => void loadLeads())
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [loadLeads, userId]);

  const qualityOptions = useMemo(
    () => [...new Set(leads.map((lead) => lead.LeadQuality?.trim()).filter((value): value is string => Boolean(value)))].sort((a, b) => a.localeCompare(b)),
    [leads],
  );

  const activityOptions = useMemo(
    () => [...new Set(leads.map((lead) => lead.Activité?.trim()).filter((value): value is string => Boolean(value)))].sort((a, b) => a.localeCompare(b)),
    [leads],
  );

  const locationOptions = useMemo(
    () => [...new Set(leads.map((lead) => leadCity(lead, searchCities.get(lead.Search_id ?? -1))).filter((value): value is string => Boolean(value)))].sort((a, b) => a.localeCompare(b)),
    [leads, searchCities],
  );

  const filteredLeads = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    return leads.filter((lead) => {
      const hasPhone = isAvailable(lead.Telephone);
      const hasEmail = isAvailable(lead.Email);
      const hasWebsite = isAvailable(lead.Siteweb);
      const matchesAvailability = availability === 'all'
        || (availability === 'phone' && hasPhone)
        || (availability === 'email' && hasEmail)
        || (availability === 'website' && hasWebsite)
        || (availability === 'complete' && hasPhone && hasEmail && hasWebsite)
        || (availability === 'missing' && (!hasPhone || !hasEmail || !hasWebsite));
      const leadScore = lead.LeadScore ?? 0;
      const matchesScore = score === 'all'
        || (score === 'high' && leadScore >= 80)
        || (score === 'medium' && leadScore >= 60 && leadScore < 80)
        || (score === 'low' && leadScore < 60);
      const matchesQuality = quality === 'all' || lead.LeadQuality?.trim() === quality;
      const matchesActivity = activity === 'all' || lead.Activité?.trim() === activity;
      const resolvedCity = leadCity(lead, searchCities.get(lead.Search_id ?? -1));
      const matchesLocation = location === 'all' || resolvedCity === location;
      const searchable = [lead.Entreprise, lead.Activité, resolvedCity, lead.Adresse, lead.Telephone, lead.Email, lead.Siteweb]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase();
      return matchesAvailability && matchesScore && matchesQuality && matchesActivity && matchesLocation && (!normalizedQuery || searchable.includes(normalizedQuery));
    });
  }, [activity, availability, leads, location, quality, query, score, searchCities]);

  const exportableLeads = useMemo(
    () => filteredLeads.map((lead) => ({ ...lead, City: leadCity(lead, searchCities.get(lead.Search_id ?? -1)) })),
    [filteredLeads, searchCities],
  );

  useEffect(() => { setPage(1); }, [activity, availability, location, quality, query, score]);
  const totalPages = Math.max(1, Math.ceil(filteredLeads.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageLeads = filteredLeads.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const activeFilterCount = Number(Boolean(query.trim())) + Number(availability !== 'all') + Number(score !== 'all') + Number(quality !== 'all') + Number(activity !== 'all') + Number(location !== 'all');

  const clearFilters = () => {
    setQuery('');
    setAvailability('all');
    setScore('all');
    setQuality('all');
    setActivity('all');
    setLocation('all');
  };

  const stageLabel = (stage: PipelineStage) => {
    const key = `pipeline.stage.${stage.slug}`;
    const translated = t(key);
    return translated === key ? stage.name : translated;
  };

  const refreshLead = useCallback(async (leadId: string) => {
    const { data } = await supabase.from('Leads').select('*').eq('id', leadId).eq('User_id', userId).maybeSingle();
    if (data) setLeads((current) => upsertLead(current, data));
  }, [userId]);

  const changeStage = useCallback(async (leadId: string, newStageId: string) => {
    const snapshot = leads.find((lead) => lead.id === leadId);
    if (!snapshot || snapshot.pipeline_stage_id === newStageId || busyLeadIds.has(leadId)) return;

    setStageError('');
    setBusyLeadIds((current) => new Set(current).add(leadId));
    setLeads((current) => current.map((lead) => lead.id === leadId ? {
      ...lead,
      pipeline_stage_id: newStageId,
      pipeline_version: lead.pipeline_version + 1,
      pipeline_updated_at: new Date().toISOString(),
      pipeline_updated_by: userId,
    } : lead));

    const { data, error: updateError } = await supabase
      .from('Leads')
      .update({ pipeline_stage_id: newStageId })
      .eq('id', leadId)
      .eq('User_id', userId)
      .eq('pipeline_version', snapshot.pipeline_version)
      .select('*')
      .maybeSingle();

    if (updateError || !data) {
      await refreshLead(leadId);
      setStageError(updateError?.message || t('errors.concurrentLeadUpdate'));
    } else {
      setLeads((current) => upsertLead(current, data));
    }

    setBusyLeadIds((current) => {
      const next = new Set(current);
      next.delete(leadId);
      return next;
    });
  }, [busyLeadIds, leads, refreshLead, t, userId]);

  return (
    <Card className="overflow-hidden border-0 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] ring-0">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-xl font-black text-slate-950">{t('prospects.title')}</CardTitle>
        <CardDescription>{t('prospects.description')}</CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="border-b border-slate-100 bg-slate-50/70 p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-xl bg-white text-indigo-600 shadow-sm ring-1 ring-slate-200"><SlidersHorizontal className="size-4" /></span>
              <div><h2 className="font-black text-slate-900">{t('prospects.filters')}</h2><p className="text-xs text-slate-500">{t('prospects.filtersDescription')}</p></div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="h-8 bg-white px-3 text-slate-700">{t('prospects.count', { visible: filteredLeads.length, total: leads.length })}</Badge>
              <Button type="button" size="sm" variant="outline" className="h-8 bg-white" disabled={filteredLeads.length === 0} onClick={() => exportLeadsToExcel(exportableLeads, { title: t('export.allProspectsTitle') })}><FileSpreadsheet className="size-3.5 text-emerald-600" />{t('export.downloadProspects')}</Button>
              {activeFilterCount > 0 && <Button type="button" size="sm" variant="ghost" className="h-8" onClick={clearFilters}><RotateCcw className="size-3.5" />{t('search.clearFilters')}</Button>}
            </div>
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <div className="space-y-2"><Label htmlFor="prospects-query">{t('prospects.searchLabel')}</Label><div className="relative"><Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><Input id="prospects-query" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('prospects.searchPlaceholder')} className="h-11 bg-white ps-9" /></div></div>
            <div className="space-y-2"><Label htmlFor="prospects-activity">{t('prospects.activityFilter')}</Label><Select value={activity} onValueChange={setActivity}><SelectTrigger id="prospects-activity" className="h-11 bg-white"><SelectValue>{activity === 'all' ? t('prospects.allActivities') : firstUpper(activity)}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('prospects.allActivities')}</SelectItem>{activityOptions.map((item) => <SelectItem key={item} value={item}>{firstUpper(item)}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label htmlFor="prospects-location">{t('prospects.locationFilter')}</Label><Select value={location} onValueChange={setLocation}><SelectTrigger id="prospects-location" className="h-11 bg-white"><SelectValue>{location === 'all' ? t('prospects.allLocations') : firstUpper(location)}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('prospects.allLocations')}</SelectItem>{locationOptions.map((item) => <SelectItem key={item} value={item}>{firstUpper(item)}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label htmlFor="prospects-availability">{t('search.contactAvailability')}</Label><Select value={availability} onValueChange={setAvailability}><SelectTrigger id="prospects-availability" className="h-11 bg-white"><SelectValue>{{ all: t('common.all'), phone: t('search.phoneAvailable'), email: t('search.emailAvailable'), website: t('search.websiteAvailable'), complete: t('search.allContactAvailable'), missing: t('search.incompleteData') }[availability] ?? availability}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('common.all')}</SelectItem><SelectItem value="phone">{t('search.phoneAvailable')}</SelectItem><SelectItem value="email">{t('search.emailAvailable')}</SelectItem><SelectItem value="website">{t('search.websiteAvailable')}</SelectItem><SelectItem value="complete">{t('search.allContactAvailable')}</SelectItem><SelectItem value="missing">{t('search.incompleteData')}</SelectItem></SelectContent></Select></div>
            <div className="space-y-2"><Label htmlFor="prospects-score">{t('prospects.score')}</Label><Select value={score} onValueChange={setScore}><SelectTrigger id="prospects-score" className="h-11 bg-white"><SelectValue>{{ all: t('prospects.allScores'), high: t('prospects.scoreHigh'), medium: t('prospects.scoreMedium'), low: t('prospects.scoreLow') }[score] ?? score}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('prospects.allScores')}</SelectItem><SelectItem value="high">{t('prospects.scoreHigh')}</SelectItem><SelectItem value="medium">{t('prospects.scoreMedium')}</SelectItem><SelectItem value="low">{t('prospects.scoreLow')}</SelectItem></SelectContent></Select></div>
            <div className="space-y-2"><Label htmlFor="prospects-quality">{t('search.clientReputation')}</Label><Select value={quality} onValueChange={setQuality}><SelectTrigger id="prospects-quality" className="h-11 bg-white"><SelectValue>{quality === 'all' ? t('prospects.allQualities') : leadQualityLabel(quality, t)}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('prospects.allQualities')}</SelectItem>{qualityOptions.map((item) => <SelectItem key={item} value={item}>{leadQualityLabel(item, t)}</SelectItem>)}</SelectContent></Select></div>
          </div>
          {stageError && <p role="alert" className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{stageError}</p>}
        </div>

        {loading ? <div className="space-y-3 p-5">{[1, 2, 3, 4].map((item) => <Skeleton key={item} className="h-14 w-full" />)}</div>
          : error ? <div className="p-8 text-center"><p className="font-medium text-red-600">{error}</p><Button className="mt-4" variant="outline" onClick={() => void loadLeads()}>{t('prospects.retry')}</Button></div>
          : leads.length === 0 ? <Empty className="min-h-72"><EmptyHeader><EmptyMedia variant="icon"><Building2 /></EmptyMedia><EmptyTitle>{t('prospects.emptyTitle')}</EmptyTitle><EmptyDescription>{t('prospects.emptyDescription')}</EmptyDescription></EmptyHeader></Empty>
          : <>
              <Table className="min-w-[1080px] table-fixed xl:min-w-0">
                <colgroup>
                  <col className="w-[28%]" />
                  <col className="w-[7%]" />
                  <col className="w-[8%]" />
                  <col className="w-[12%]" />
                  <col className="w-[6%]" />
                  <col className="w-[11%]" />
                  <col className="w-[15%]" />
                  <col className="w-[13%]" />
                </colgroup>
                <TableHeader><TableRow className="bg-white hover:bg-white"><TableHead className="px-5 text-start">{t('common.client')}</TableHead><TableHead className="text-start">{t('prospects.score')}</TableHead><TableHead className="text-start">{t('search.clientReputation')}</TableHead><TableHead className="text-start">{t('common.activity')}</TableHead><TableHead className="text-start">{t('common.city')}</TableHead><TableHead className="text-start">{t('common.phone')}</TableHead><TableHead className="text-start">{t('common.email')}</TableHead><TableHead className="px-5 text-start">{t('lead.commercialStage')}</TableHead></TableRow></TableHeader>
                <TableBody>
                  {pageLeads.length === 0 ? <TableRow><TableCell colSpan={8} className="h-32 text-center text-slate-500">{t('prospects.noMatches')}</TableCell></TableRow>
                    : pageLeads.map((lead) => <TableRow key={lead.id} role="button" tabIndex={0} className="group h-16 cursor-pointer outline-none hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500" onClick={() => window.location.assign(`/leads/${encodeURIComponent(lead.id)}`)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); window.location.assign(`/leads/${encodeURIComponent(lead.id)}`); } }}>
                      <TableCell className="min-w-0 overflow-hidden px-5 font-bold text-slate-900"><ProspectNameHover lead={lead} fallbackCity={searchCities.get(lead.Search_id ?? -1)}><span title={lead.Entreprise || t('common.clientUnnamed')} className="block truncate group-hover:text-indigo-600">{compactName(lead.Entreprise, t('common.clientUnnamed'))}</span></ProspectNameHover></TableCell>
                      <TableCell className="whitespace-nowrap font-bold text-slate-800">{formatNumber(lead.LeadScore ?? 0)}/100</TableCell>
                      <TableCell><QualityBadge quality={lead.LeadQuality} /></TableCell>
                      <TableCell className="overflow-hidden text-ellipsis text-slate-600" title={lead.Activité || undefined}>{firstUpper(lead.Activité)}</TableCell>
                      <TableCell className="overflow-hidden text-ellipsis text-slate-500" title={leadCity(lead, searchCities.get(lead.Search_id ?? -1)) || undefined}>{firstUpper(leadCity(lead, searchCities.get(lead.Search_id ?? -1)))}</TableCell>
                      <TableCell className="whitespace-nowrap" dir="ltr">{isAvailable(lead.Telephone) ? <a href={`tel:${lead.Telephone}`} className="inline-flex items-center gap-1.5 font-semibold text-slate-700 hover:text-indigo-600" onClick={(event) => event.stopPropagation()}><Phone className="size-3.5" />{lead.Telephone}</a> : '—'}</TableCell>
                      <TableCell><ProspectEmailCell lead={lead} /></TableCell>
                      <TableCell onClick={(event) => event.stopPropagation()} onKeyDown={(event) => event.stopPropagation()}>
                        <PipelineStageSelect stages={stages} value={lead.pipeline_stage_id} onValueChange={(value) => value && void changeStage(lead.id, value)} disabled={busyLeadIds.has(lead.id)} placeholder={t('lead.chooseStage')} label={stageLabel} className="h-9 w-full min-w-0 text-xs" />
                      </TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>
            {filteredLeads.length > 0 && <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-5 py-4"><p className="text-sm text-slate-500">{t('prospects.pageStatus', { page: formatNumber(safePage), pages: formatNumber(totalPages) })}</p><div className="flex gap-2"><Button type="button" variant="outline" size="sm" disabled={safePage <= 1} onClick={() => setPage((current) => Math.max(1, current - 1))}>{t('prospects.previous')}</Button><Button type="button" variant="outline" size="sm" disabled={safePage >= totalPages} onClick={() => setPage((current) => Math.min(totalPages, current + 1))}>{t('prospects.next')}</Button></div></div>}
          </>}
      </CardContent>
    </Card>
  );
}
