'use client';

import type { PipelineStage } from '@/lib/database.types';
import { cn } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const FALLBACK_COLOR = '#64748B';

function safeStageColor(color?: string | null) {
  const value = color?.trim();
  return value && /^#[0-9a-f]{6}$/i.test(value) ? value.toUpperCase() : FALLBACK_COLOR;
}

function colorWithAlpha(color: string, alpha: number) {
  const safe = safeStageColor(color);
  const red = Number.parseInt(safe.slice(1, 3), 16);
  const green = Number.parseInt(safe.slice(3, 5), 16);
  const blue = Number.parseInt(safe.slice(5, 7), 16);
  return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}

export function PipelineStageSelect({
  stages,
  value,
  onValueChange,
  disabled,
  placeholder,
  label,
  className,
}: {
  stages: PipelineStage[];
  value: string | null;
  onValueChange: (value: string) => void;
  disabled?: boolean;
  placeholder: string;
  label: (stage: PipelineStage) => string;
  className?: string;
}) {
  const currentStage = stages.find((stage) => stage.id === value) ?? null;
  const currentColor = safeStageColor(currentStage?.color);

  return (
    <Select value={value ?? ''} onValueChange={onValueChange} disabled={disabled}>
      <SelectTrigger
        className={cn('font-bold shadow-sm transition-colors', className)}
        style={currentStage ? {
          borderColor: colorWithAlpha(currentColor, 0.45),
          backgroundColor: colorWithAlpha(currentColor, 0.09),
          color: currentColor,
        } : undefined}
      >
        <SelectValue>
          {currentStage ? (
            <span className="flex min-w-0 items-center gap-2">
              <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: currentColor }} />
              <span className="truncate">{label(currentStage)}</span>
            </span>
          ) : placeholder}
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {stages.map((stage) => {
          const color = safeStageColor(stage.color);
          return (
            <SelectItem key={stage.id} value={stage.id}>
              <span className="flex items-center gap-2 font-semibold">
                <span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: color }} />
                {label(stage)}
              </span>
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );
}

export function PipelineStageBadge({ stage, label, className }: { stage: PipelineStage | null; label: string; className?: string }) {
  const color = safeStageColor(stage?.color);
  return (
    <span
      className={cn('inline-flex h-9 items-center gap-2 rounded-full border px-3 text-sm font-black', className)}
      style={{
        borderColor: colorWithAlpha(color, 0.5),
        backgroundColor: colorWithAlpha(color, 0.17),
        color,
      }}
    >
      <span className="size-2.5 shrink-0 rounded-full bg-current" />
      {label}
    </span>
  );
}
