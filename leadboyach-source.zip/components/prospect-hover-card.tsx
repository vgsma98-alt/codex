'use client';
import { safeWebsiteUrl } from '@/lib/safe-url';

import { Building2, Globe2, Mail, MapPin, Phone, Star } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { EmailLookupIndicator } from '@/components/async-status';
import type { Lead } from '@/lib/database.types';
import { useI18n } from '@/lib/i18n';
import { leadQualityLabel, leadQualityTone } from '@/lib/lead-quality';

const UNAVAILABLE_VALUES = new Set(['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined']);

export function prospectEmails(value: string | null) {
  if (!value?.trim()) return [];
  return value
    .split(/[;,\n]+/)
    .map((email) => email.trim())
    .filter((email, index, emails) => email.length > 0 && !UNAVAILABLE_VALUES.has(email.toLocaleLowerCase()) && emails.indexOf(email) === index);
}

export function firstProspectEmail(value: string | null) {
  return prospectEmails(value)[0] ?? null;
}

function available(value: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(normalized && !UNAVAILABLE_VALUES.has(normalized));
}

function qualityClass(value: string | null) {
  const tone = leadQualityTone(value);
  if (tone === 'positive') return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  if (tone === 'average') return 'border-amber-200 bg-amber-50 text-amber-700';
  if (tone === 'negative') return 'border-red-200 bg-red-50 text-red-700';
  return 'border-slate-200 bg-slate-50 text-slate-500';
}

function PreviewItem({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="min-w-0 rounded-xl bg-slate-50 px-3 py-2">
      <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</p>
      <div className="mt-1 break-words text-xs font-semibold leading-5 text-slate-700">{value}</div>
    </div>
  );
}

export function ProspectNameHover({
  lead,
  children,
  fallbackCity,
}: {
  lead: Lead;
  children: React.ReactNode;
  fallbackCity?: string | null;
}) {
  const { t } = useI18n();
  const emails = prospectEmails(lead.Email);
  const city = lead.City?.trim() || fallbackCity?.trim() || '—';

  return (
    <HoverCard>
      <HoverCardTrigger
        href={`/leads/${encodeURIComponent(lead.id)}`}
        delay={250}
        closeDelay={150}
        className="inline-block max-w-full cursor-pointer text-inherit no-underline outline-none focus-visible:rounded focus-visible:ring-2 focus-visible:ring-indigo-500"
      >
        {children}
      </HoverCardTrigger>
      <HoverCardContent
        side="bottom"
        align="start"
        sideOffset={8}
        className="w-[min(34rem,calc(100vw-2rem))] rounded-2xl border-0 bg-white p-0 shadow-2xl ring-1 ring-slate-200"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="rounded-t-2xl bg-slate-950 p-4 text-white">
          <div className="flex items-start gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-white/10 text-indigo-200"><Building2 className="size-5" /></span>
            <div className="min-w-0">
              <p className="text-sm font-black leading-5">{lead.Entreprise || t('common.clientUnnamed')}</p>
              <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-300"><span>{lead.Activité || '—'}</span><span>•</span><span>{city}</span></p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 p-3">
          <PreviewItem label={t('common.phone')} value={available(lead.Telephone) ? <a dir="ltr" href={`tel:${lead.Telephone}`} className="inline-flex items-center gap-1.5 hover:text-indigo-600"><Phone className="size-3.5" />{lead.Telephone}</a> : t('common.unavailable')} />
          <PreviewItem label={t('common.email')} value={emails.length ? <span className="flex flex-col items-start gap-1">{emails.map((email) => <a key={email} dir="ltr" href={`mailto:${email}`} className="inline-flex max-w-full items-center gap-1.5 whitespace-nowrap hover:text-indigo-600"><Mail className="size-3.5 shrink-0" />{email}</a>)}</span> : t('common.unavailable')} />
          <PreviewItem label={t('common.website')} value={available(lead.Siteweb) ? <a href={safeWebsiteUrl(lead.Siteweb)} target="_blank" rel="noreferrer" className="inline-flex max-w-full items-center gap-1.5 break-all hover:text-indigo-600"><Globe2 className="size-3.5 shrink-0" />{lead.Siteweb}</a> : t('common.notFound')} />
          <PreviewItem label={t('common.address')} value={<span className="inline-flex items-start gap-1.5"><MapPin className="mt-0.5 size-3.5 shrink-0" />{lead.Adresse || city}</span>} />
          <PreviewItem label={t('search.theoreticalRating')} value={lead.LeadScore == null ? '—' : `${lead.LeadScore}/100`} />
          <PreviewItem label={t('common.quality')} value={<Badge variant="outline" className={qualityClass(lead.LeadQuality)}>{leadQualityLabel(lead.LeadQuality, t)}</Badge>} />
          <PreviewItem label={t('lead.googleRating')} value={lead.Rating == null ? '—' : <span className="inline-flex items-center gap-1"><Star className="size-3.5 fill-amber-400 text-amber-400" />{lead.Rating}/5</span>} />
          <PreviewItem label={t('lead.customerReviews')} value={lead.Reviews ?? '—'} />
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}

export function ProspectEmailCell({ lead }: { lead: Lead }) {
  const { t } = useI18n();
  const email = firstProspectEmail(lead.Email);
  if (email) {
    return <a dir="ltr" href={`mailto:${email}`} className="inline-flex max-w-52 items-center gap-1.5 truncate text-slate-600 hover:text-indigo-600" onClick={(event) => event.stopPropagation()}><Mail className="size-3.5 shrink-0" /><span className="truncate">{email}</span></a>;
  }
  const status = lead.Email_status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
  if (status !== 'not found' && !lead.Email?.trim()) return <EmailLookupIndicator />;
  return <span className="text-slate-400">{t('common.unavailable')}</span>;
}
