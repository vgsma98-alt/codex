'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Eye, Save, ShieldCheck, Trash2, UserRoundCheck, UsersRound } from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import type { AdminUserOverview, Team, TeamMember } from '@/lib/database.types';
import { getLanguage, t } from '@/lib/i18n';

type Draft = { id: string | null; name: string; supervisorId: string; memberIds: string[] };
const EMPTY_DRAFT: Draft = { id: null, name: '', supervisorId: '', memberIds: [] };

export function AdminTeams({ accessToken, users }: { accessToken: string; users: AdminUserOverview[] }) {
  const [teams, setTeams] = useState<Team[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const request = useCallback((url: string, init?: RequestInit) => {
    const headers = new Headers(init?.headers);
    headers.set('Content-Type', 'application/json');
    headers.set('Authorization', `Bearer ${accessToken}`);
    headers.set('x-app-language', getLanguage());
    return fetch(url, { ...init, headers });
  }, [accessToken]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await request('/api/admin?resource=teams');
      const result = await response.json() as { error?: string; teams?: Team[]; members?: TeamMember[] };
      if (!response.ok) throw new Error(result.error || t('errors.loadTeams'));
      setTeams(result.teams ?? []);
      setMembers(result.members ?? []);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t('errors.loadTeams'));
    } finally {
      setLoading(false);
    }
  }, [request]);

  // oxlint-disable-next-line react-compiler/react-compiler
  useEffect(() => { void load(); }, [load]);

  const userMap = useMemo(() => new Map(users.map((user) => [user.User_id, user])), [users]);
  const assignedUserIds = useMemo(() => new Set(members.filter((item) => item.team_id !== draft.id).map((item) => item.user_id)), [draft.id, members]);
  const eligibleUsers = users.filter((user) => user.Account_status === 'active' && !assignedUserIds.has(user.User_id));

  function editTeam(team: Team) {
    setDraft({
      id: team.id,
      name: team.name,
      supervisorId: team.supervisor_id,
      memberIds: members.filter((item) => item.team_id === team.id).map((item) => item.user_id),
    });
    setNotice(null);
    setError(null);
  }

  function toggleMember(userId: string) {
    setDraft((current) => ({
      ...current,
      memberIds: current.memberIds.includes(userId)
        ? current.memberIds.filter((id) => id !== userId)
        : [...current.memberIds, userId],
    }));
  }

  async function saveTeam() {
    if (!draft.name.trim() || !draft.supervisorId) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await request('/api/admin', {
        method: 'POST',
        body: JSON.stringify({
          type: 'team', id: draft.id ?? undefined, name: draft.name,
          supervisorId: draft.supervisorId,
          memberIds: Array.from(new Set([...draft.memberIds, draft.supervisorId])),
        }),
      });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.saveTeam'));
      setDraft(EMPTY_DRAFT);
      setNotice(t(draft.id ? 'notices.teamUpdated' : 'notices.teamCreated'));
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t('errors.saveTeam'));
    } finally {
      setSaving(false);
    }
  }

  async function deleteTeam(team: Team) {
    if (!window.confirm(t('teams.confirmDelete', { name: team.name }))) return;
    setError(null);
    try {
      const response = await request(`/api/admin?team_id=${encodeURIComponent(team.id)}`, { method: 'DELETE' });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.deleteTeam'));
      if (draft.id === team.id) setDraft(EMPTY_DRAFT);
      setNotice(t('notices.teamDeleted'));
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t('errors.deleteTeam'));
    }
  }

  if (loading) return <div className="grid gap-4 lg:grid-cols-2"><Skeleton className="h-80 rounded-3xl" /><Skeleton className="h-80 rounded-3xl" /></div>;

  return <div className="space-y-5">
    {notice && <Alert className="border-emerald-200 bg-emerald-50 text-emerald-900"><ShieldCheck /><AlertDescription>{notice}</AlertDescription></Alert>}
    {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}

    <div className="grid gap-5 xl:grid-cols-[minmax(0,1.15fr)_minmax(360px,.85fr)]">
      <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/70">
        <CardHeader className="bg-[linear-gradient(135deg,#032e25,#064e3b)] text-white">
          <div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-2xl bg-white/10"><UsersRound /></span><div><CardTitle>{t('teams.adminTitle')}</CardTitle><CardDescription className="text-slate-300">{t('teams.adminDescription')}</CardDescription></div></div>
        </CardHeader>
        <CardContent className="space-y-3 p-5">
          {teams.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">{t('teams.empty')}</div> : teams.map((team) => {
            const teamMembers = members.filter((item) => item.team_id === team.id);
            const supervisor = userMap.get(team.supervisor_id);
            return <article key={team.id} className="rounded-2xl border border-slate-200 bg-white p-4 transition hover:border-indigo-200 hover:shadow-md">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h3 className="font-black text-slate-950">{team.name}</h3><p className="mt-1 text-sm text-slate-500">{t('teams.supervisor')}: <b>{supervisor?.Name || supervisor?.Email || '—'}</b></p></div>
                <div className="flex gap-2"><Badge variant="outline">{t('teams.memberCount', { count: teamMembers.length })}</Badge><Badge className="bg-indigo-50 text-indigo-700 hover:bg-indigo-50"><Eye className="size-3" /> {t('teams.auditEnabled')}</Badge></div>
              </div>
              <div className="mt-4 flex gap-2 border-t border-slate-100 pt-3"><Button size="sm" variant="outline" onClick={() => editTeam(team)}>{t('common.edit')}</Button><Button size="sm" variant="ghost" className="text-rose-600 hover:bg-rose-50 hover:text-rose-700" onClick={() => void deleteTeam(team)}><Trash2 className="size-4" />{t('common.delete')}</Button></div>
            </article>;
          })}
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm ring-1 ring-slate-200/70">
        <CardHeader><CardTitle>{draft.id ? t('teams.editTeam') : t('teams.createTeam')}</CardTitle><CardDescription>{t('teams.formDescription')}</CardDescription></CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2"><Label htmlFor="team-name">{t('teams.name')}</Label><Input id="team-name" value={draft.name} maxLength={100} onChange={(event) => setDraft({ ...draft, name: event.target.value })} placeholder={t('teams.namePlaceholder')} /></div>
          <div className="space-y-2"><Label>{t('teams.supervisor')}</Label><Select value={draft.supervisorId} onValueChange={(value) => setDraft({ ...draft, supervisorId: value ?? '' })}><SelectTrigger><SelectValue placeholder={t('teams.chooseSupervisor')} /></SelectTrigger><SelectContent>{eligibleUsers.map((user) => <SelectItem key={user.User_id} value={user.User_id}>{user.Name || user.Email || t('admin.unnamedUser')}</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-2"><Label>{t('teams.members')}</Label><div className="max-h-72 space-y-2 overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50 p-2">{eligibleUsers.length === 0 ? <p className="p-4 text-center text-sm text-slate-500">{t('teams.noEligibleMembers')}</p> : eligibleUsers.map((user) => {
            const checked = draft.memberIds.includes(user.User_id) || draft.supervisorId === user.User_id;
            return <label key={user.User_id} className="flex cursor-pointer items-center gap-3 rounded-xl bg-white p-3 text-sm shadow-sm ring-1 ring-slate-200/60"><input type="checkbox" checked={checked} disabled={draft.supervisorId === user.User_id} onChange={() => toggleMember(user.User_id)} className="size-4 accent-indigo-600" /><UserRoundCheck className="size-4 text-indigo-500" /><span className="min-w-0"><b className="block truncate">{user.Name || t('admin.unnamedUser')}</b><span className="block truncate text-xs text-slate-500">{user.Email || '—'}</span></span></label>;
          })}</div></div>
          <div className="flex gap-2"><Button className="flex-1 bg-indigo-600 hover:bg-indigo-700" disabled={saving || !draft.name.trim() || !draft.supervisorId} onClick={() => void saveTeam()}><Save className="size-4" />{saving ? t('common.loading') : t('teams.save')}</Button>{draft.id && <Button variant="outline" onClick={() => setDraft(EMPTY_DRAFT)}>{t('common.cancel')}</Button>}</div>
        </CardContent>
      </Card>
    </div>
  </div>;
}
