'use client';

/* oxlint-disable jsx-a11y/control-has-associated-label -- Chart buttons contain visible labels through composed children. */

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3, CircleDollarSign, Clock3, Filter, RotateCcw, Target, TrendingUp, TriangleAlert, Trophy, UsersRound } from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Skeleton } from '@/components/ui/skeleton';
import type { Lead } from '@/lib/database.types';
import { formatNumber, t, useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';

type AnalyticsStage = { id:string; slug:string; name:string; position:number; color:string; is_terminal:boolean; current_count:number; share:number; reached_count:number; average_days:number|null; passage_rate:number|null; dropoff_rate:number|null; passed_count:number; lost_from_count:number; estimated_value:number; final_value:number; lost_value:number; blocked_count:number };
type TrendPoint = { bucket:string; new:number; contacted:number; qualified:number; proposal:number; negotiation:number; won:number; lost:number; generated_revenue:number };
type AnalyticsData = {
  period:{ start:string; end:string; previous_start:string; previous_end:string; granularity:string };
  kpis:{ total:number; won:number; lost:number; conversion_rate:number; generated_revenue:number; potential_revenue:number; lost_revenue:number; average_won_value:number|null; previous:{ total:number; won:number; conversion_rate:number|null; generated_revenue:number; potential_revenue:number } };
  stages:AnalyticsStage[];
  trend:TrendPoint[];
  loss_reasons:Array<{reason:string;count:number;value:number}>;
  blocked:Array<{stage_id:string;slug:string;name:string;color:string;count:number;threshold_days:number}>;
  filters:{sources:string[];cities:string[];commercials:string[]};
};
type Filters = { period:string; stageId:string; source:string; city:string; commercialId:string; start:string; end:string; granularity:string };
type DrilldownTarget = { title:string; kind:'total'|'stage'|'won'|'lost'|'blocked'|'generated'|'potential'|'lossFrom'|'lossReason'; stageId?:string; reason?:string; thresholdDays?:number };

const initialFilters:Filters = { period:'30d',stageId:'all',source:'all',city:'all',commercialId:'all',start:'',end:'',granularity:'day' };
const financialStageSlugs = new Set(['qualified','proposal','negotiation','won','lost']);
const trendMetrics = ['new','contacted','qualified','proposal','negotiation','won','lost'] as const;
function money(value:number) { return formatNumber(Number(value||0),{style:'currency',currency:'MAD',maximumFractionDigits:0}); }
function stageLabel(stage:{slug:string;name:string}) { const key=`pipeline.stage.${stage.slug}`; const translated=t(key); return translated===key?stage.name:translated; }
function safeData(value:unknown):AnalyticsData|null { return value && typeof value==='object' ? value as AnalyticsData : null; }
function comparison(current:number,previous:number|null|undefined,points=false) {
  if (previous===null||previous===undefined||!Number.isFinite(previous)) return {kind:'insufficient' as const,value:0};
  if (previous===0) return current===0?{kind:'insufficient' as const,value:0}:{kind:'new' as const,value:0};
  return {kind:'delta' as const,value:points?current-previous:((current-previous)/Math.abs(previous))*100};
}

export function SalesAnalytics({userId}:{userId:string}) {
  const {t:translate,formatNumber:localNumber,formatDate:localDate,direction}=useI18n();
  const [filters,setFilters]=useState<Filters>(initialFilters);
  const [data,setData]=useState<AnalyticsData|null>(null);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [metric,setMetric]=useState<(typeof trendMetrics)[number]>('new');
  const [drilldown,setDrilldown]=useState<DrilldownTarget|null>(null);
  const [drilldownLeads,setDrilldownLeads]=useState<Lead[]>([]);
  const [drilldownLoading,setDrilldownLoading]=useState(false);

  const load=useCallback(async()=>{
    if(filters.period==='custom'&&(!filters.start||!filters.end)) return;
    setLoading(true); setError('');
    const {data:result,error:loadError}=await supabase.rpc('get_sales_analytics',{
      p_period:filters.period,
      p_stage_id:filters.stageId==='all'?null:filters.stageId,
      p_source:filters.source==='all'?null:filters.source,
      p_city:filters.city==='all'?null:filters.city,
      p_commercial_id:filters.commercialId==='all'?null:filters.commercialId,
      p_custom_start:filters.period==='custom'&&filters.start?new Date(`${filters.start}T00:00:00`).toISOString():null,
      p_custom_end:filters.period==='custom'&&filters.end?new Date(`${filters.end}T23:59:59.999`).toISOString():null,
      p_granularity:filters.granularity,
    });
    if(loadError||!result) setError(translate('analytics.loadError')); else setData(safeData(result));
    setLoading(false);
  },[filters,translate]);

  useEffect(()=>{ const timer=window.setTimeout(()=>void load(),120); return()=>window.clearTimeout(timer); },[load]);
  useEffect(()=>{
    const channel=supabase.channel(`analytics-summary-${userId}`)
      .on('postgres_changes',{event:'*',schema:'public',table:'Leads',filter:`User_id=eq.${userId}`},()=>void load())
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'Lead_Audit_Log',filter:`user_id=eq.${userId}`},()=>void load()).subscribe();
    return()=>{void supabase.removeChannel(channel);};
  },[load,userId]);

  const openDrilldown=useCallback(async(target:DrilldownTarget)=>{
    if(!data)return;
    setDrilldown(target); setDrilldownLoading(true); setDrilldownLeads([]);
    let leadIds:string[]|null=null;
    if(target.kind==='lossFrom') {
      const lostId=data.stages.find(stage=>stage.slug==='lost')?.id;
      if(!lostId||!target.stageId){setDrilldownLoading(false);return;}
      const {data:logs}=await supabase.from('Lead_Audit_Log').select('lead_id').eq('user_id',userId).eq('event_type','stage_changed').eq('previous_stage_id',target.stageId).eq('new_stage_id',lostId).limit(200);
      leadIds=[...new Set((logs??[]).map(row=>row.lead_id))];
      if(!leadIds.length){setDrilldownLoading(false);return;}
    }
    let query=supabase.from('Leads').select('*').eq('User_id',userId).gte('created_at',data.period.start).lt('created_at',data.period.end).order('pipeline_updated_at',{ascending:false}).limit(200);
    if(filters.source!=='all')query=query.eq('lead_source',filters.source);
    if(filters.city!=='all')query=query.eq('City',filters.city);
    if(filters.commercialId!=='all')query=query.eq('commercial_id',filters.commercialId);
    if(leadIds)query=query.in('id',leadIds);
    const selectedStage=target.stageId??(filters.stageId==='all'?null:filters.stageId);
    if(selectedStage)query=query.eq('pipeline_stage_id',selectedStage);
    if(target.kind==='won')query=query.eq('pipeline_stage_id',data.stages.find(stage=>stage.slug==='won')?.id??'00000000-0000-0000-0000-000000000000');
    if(target.kind==='lost'||target.kind==='lossReason')query=query.eq('pipeline_stage_id',data.stages.find(stage=>stage.slug==='lost')?.id??'00000000-0000-0000-0000-000000000000');
    if(target.kind==='generated')query=query.eq('pipeline_stage_id',data.stages.find(stage=>stage.slug==='won')?.id??'00000000-0000-0000-0000-000000000000').not('final_deal_amount','is',null).gt('final_deal_amount',0);
    if(target.kind==='potential') {
      const qualifiedPosition=data.stages.find(stage=>stage.slug==='qualified')?.position;
      const eligibleStages=data.stages.filter(stage=>qualifiedPosition!==undefined&&stage.position>=qualifiedPosition&&!stage.is_terminal).map(stage=>stage.id);
      if(!eligibleStages.length){setDrilldownLoading(false);return;}
      query=query.in('pipeline_stage_id',eligibleStages).gt('estimated_value',0);
    }
    if(target.kind==='blocked'&&target.thresholdDays)query=query.lt('stage_entered_at',new Date(Date.now()-target.thresholdDays*86400000).toISOString());
    if(target.kind==='lossReason'&&target.reason&&target.reason!=='unspecified')query=query.eq('loss_reason',target.reason);
    if(target.kind==='lossReason'&&target.reason==='unspecified')query=query.is('loss_reason',null);
    const {data:rows}=await query;
    setDrilldownLeads((rows??[]) as Lead[]); setDrilldownLoading(false);
  },[data,filters,userId]);

  const strongestLeak=useMemo(()=>data?.stages.filter(stage=>!stage.is_terminal&&stage.dropoff_rate!==null).sort((a,b)=>(b.dropoff_rate??0)-(a.dropoff_rate??0))[0]??null,[data]);
  const slowestStage=useMemo(()=>data?.stages.filter(stage=>!stage.is_terminal&&stage.average_days!==null).sort((a,b)=>(b.average_days??0)-(a.average_days??0))[0]??null,[data]);

  if(!data&&loading)return <AnalyticsSkeleton/>;
  if(!data)return <Alert variant="destructive"><TriangleAlert/><AlertDescription>{error||translate('analytics.loadError')}</AlertDescription></Alert>;
  const previous=data.kpis.previous;
  const metricColor=data.stages.find(stage=>stage.slug===metric)?.color??'#6366f1';

  return <div className="space-y-5">
    <div className="rounded-3xl bg-[linear-gradient(135deg,#032e25,#064e3b_62%,#3f6212)] px-6 py-5 text-white shadow-[0_18px_50px_rgba(2,44,34,.18)]"><Badge className="mb-2 bg-white/10 text-indigo-100 hover:bg-white/10"><Activity className="size-3.5"/>{translate('analytics.liveSnapshot')}</Badge><h2 className="text-2xl font-black">{translate('analytics.title')}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-indigo-100/80">{translate('analytics.decisionDescription')}</p></div>

    <AnalyticsFilters filters={filters} setFilters={setFilters} data={data} reset={()=>setFilters(initialFilters)}/>

    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
      <KpiCard label={translate('analytics.totalProspects')} value={localNumber(data.kpis.total)} icon={<UsersRound/>} tone="indigo" comparisonValue={comparison(data.kpis.total,previous.total)} onClick={()=>void openDrilldown({title:translate('analytics.totalProspects'),kind:'total'})}/>
      <KpiCard label={translate('analytics.won')} value={localNumber(data.kpis.won)} icon={<Trophy/>} tone="emerald" comparisonValue={comparison(data.kpis.won,previous.won)} onClick={()=>void openDrilldown({title:translate('analytics.won'),kind:'won'})}/>
      <KpiCard label={translate('analytics.conversionRate')} value={`${localNumber(data.kpis.conversion_rate)}%`} icon={<Target/>} tone="cyan" comparisonValue={comparison(data.kpis.conversion_rate,previous.conversion_rate,true)} points onClick={()=>void openDrilldown({title:translate('analytics.won'),kind:'won'})}/>
      <KpiCard label={translate('analytics.generatedRevenue')} value={money(data.kpis.generated_revenue)} icon={<CircleDollarSign/>} tone="emerald" comparisonValue={comparison(data.kpis.generated_revenue,previous.generated_revenue)} onClick={()=>void openDrilldown({title:translate('analytics.generatedRevenue'),kind:'generated'})}/>
      <KpiCard label={translate('analytics.potentialRevenue')} value={money(data.kpis.potential_revenue)} icon={<TrendingUp/>} tone="violet" comparisonValue={comparison(data.kpis.potential_revenue,previous.potential_revenue)} onClick={()=>void openDrilldown({title:translate('analytics.potentialRevenue'),kind:'potential'})}/>
    </div>

    <div className="grid gap-5 xl:grid-cols-[1.45fr_.75fr]">
      <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader className="pb-3"><CardTitle>{translate('analytics.funnel')}</CardTitle><p className="text-sm text-slate-500">{translate('analytics.funnelDescription')}</p></CardHeader><CardContent><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">{data.stages.filter(stage=>stage.slug!=='lost').map(stage=><FunnelStep key={stage.id} stage={stage} strongest={strongestLeak?.id===stage.id} onStage={()=>void openDrilldown({title:stageLabel(stage),kind:'stage',stageId:stage.id})} onLoss={()=>void openDrilldown({title:translate('analytics.lossFrom',{stage:stageLabel(stage)}),kind:'lossFrom',stageId:stage.id})}/>)}</div></CardContent></Card>
      <ActionableInsights total={data.kpis.total} stages={data.stages} strongestLeak={strongestLeak} slowestStage={slowestStage} blocked={data.blocked} onOpen={openDrilldown}/>
    </div>

    <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2"><BarChart3 className="size-5 text-indigo-600"/>{translate('analytics.stagePerformance')}</CardTitle><p className="text-sm text-slate-500">{translate('analytics.stagePerformanceNewDescription')}</p></CardHeader><CardContent><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{data.stages.map(stage=><StageCard key={stage.id} stage={stage} total={data.kpis.total} lossReasons={data.loss_reasons} onOpen={openDrilldown}/>)}</div></CardContent></Card>

    <div className="grid gap-5 xl:grid-cols-2">
      <ChartCard title={translate('analytics.pipelineEvolution')} description={translate('analytics.pipelineEvolutionDescription')} controls={<div className="flex flex-wrap gap-2"><Select value={metric} onValueChange={value=>setMetric(value as typeof metric)}><SelectTrigger className="w-44"><SelectValue>{translate(`analytics.metric.${metric}`)}</SelectValue></SelectTrigger><SelectContent>{trendMetrics.map(item=><SelectItem key={item} value={item}>{translate(`analytics.metric.${item}`)}</SelectItem>)}</SelectContent></Select><GranularitySelect value={filters.granularity} onChange={value=>setFilters(current=>({...current,granularity:value}))}/></div>}><ResponsiveContainer width="100%" height={270}><AreaChart data={data.trend}><defs><linearGradient id="pipelineFill" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={metricColor} stopOpacity={.35}/><stop offset="95%" stopColor={metricColor} stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="bucket" tickFormatter={value=>localDate(value,{day:'2-digit',month:'short'})} fontSize={12}/><YAxis allowDecimals={false} fontSize={12}/><Tooltip labelFormatter={value=>localDate(value as string,{dateStyle:'medium'})} formatter={(value)=>[localNumber(Number(value)),translate(`analytics.metric.${metric}`)]}/><Area type="monotone" dataKey={metric} stroke={metricColor} fill="url(#pipelineFill)" strokeWidth={3}/></AreaChart></ResponsiveContainer></ChartCard>
      <ChartCard title={translate('analytics.revenueEvolution')} description={translate('analytics.revenueEvolutionDescription')} controls={<GranularitySelect value={filters.granularity} onChange={value=>setFilters(current=>({...current,granularity:value}))}/>}><div className="mb-3 grid grid-cols-3 gap-2"><MiniValue label={translate('analytics.generatedRevenue')} value={money(data.kpis.generated_revenue)}/><MiniValue label={translate('analytics.averageWonValue')} value={data.kpis.average_won_value===null?'—':money(data.kpis.average_won_value)}/><MiniValue label={translate('analytics.lostRevenue')} value={money(data.kpis.lost_revenue)}/></div><ResponsiveContainer width="100%" height={220}><AreaChart data={data.trend}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="bucket" tickFormatter={value=>localDate(value,{day:'2-digit',month:'short'})} fontSize={12}/><YAxis tickFormatter={value=>localNumber(Number(value),{notation:'compact'})} fontSize={12}/><Tooltip labelFormatter={value=>localDate(value as string,{dateStyle:'medium'})} formatter={(value)=>[money(Number(value)),translate('analytics.generatedRevenue')]}/><Area type="monotone" dataKey="generated_revenue" stroke="#16a34a" fill="#dcfce7" strokeWidth={3}/></AreaChart></ResponsiveContainer></ChartCard>
    </div>

    <div className="grid gap-5 xl:grid-cols-2"><BlockedProspects items={data.blocked} onOpen={openDrilldown}/><LossReasons items={data.loss_reasons} onOpen={openDrilldown}/></div>

    <Sheet open={Boolean(drilldown)} onOpenChange={open=>{if(!open)setDrilldown(null)}}><SheetContent side={direction==='rtl'?'left':'right'} className="w-full overflow-y-auto sm:max-w-xl"><SheetHeader><SheetTitle>{drilldown?.title}</SheetTitle><SheetDescription>{translate('analytics.drilldownDescription')}</SheetDescription></SheetHeader><div className="space-y-2 px-4 pb-6">{drilldownLoading?[1,2,3,4].map(item=><Skeleton key={item} className="h-20 rounded-2xl"/>):drilldownLeads.length?drilldownLeads.map(lead=><a key={lead.id} href={`/leads/${lead.id}`} className="block rounded-2xl border border-slate-200 p-4 transition hover:border-indigo-300 hover:bg-indigo-50/40"><b className="block truncate text-slate-950">{lead.Entreprise||translate('common.clientUnnamed')}</b><span className="mt-1 flex flex-wrap gap-2 text-xs text-slate-500"><span>{lead.Activité||'—'}</span><span>·</span><span>{lead.City||'—'}</span>{lead.estimated_value>0&&<><span>·</span><span>{money(lead.estimated_value)}</span></>}</span></a>):<p className="rounded-2xl bg-slate-50 p-6 text-center text-slate-500">{translate('analytics.noMatchingProspects')}</p>}</div></SheetContent></Sheet>
  </div>;
}

function AnalyticsFilters({filters,setFilters,data,reset}:{filters:Filters;setFilters:React.Dispatch<React.SetStateAction<Filters>>;data:AnalyticsData;reset:()=>void}) {
  const {t:translate}=useI18n(); const update=(key:keyof Filters,value:string)=>setFilters(current=>({...current,[key]:value}));
  return <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardContent className="p-4"><div className="mb-3 flex items-center justify-between"><span className="flex items-center gap-2 font-bold"><Filter className="size-4 text-indigo-600"/>{translate('analytics.filters')}</span><Button variant="ghost" size="sm" onClick={reset}><RotateCcw/>{translate('analytics.resetFilters')}</Button></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5"><FilterSelect label={translate('analytics.period')} value={filters.period} onChange={value=>update('period',value)} options={['today','7d','30d','month','previous_month','3m','year','custom'].map(value=>({value,label:translate(`analytics.period.${value}`)}))}/><FilterSelect label={translate('analytics.stage')} value={filters.stageId} onChange={value=>update('stageId',value)} options={[{value:'all',label:translate('common.all')},...data.stages.map(stage=>({value:stage.id,label:stageLabel(stage)}))]}/><FilterSelect label={translate('analytics.source')} value={filters.source} onChange={value=>update('source',value)} options={[{value:'all',label:translate('common.all')},...data.filters.sources.map(value=>({value,label:value==='search'?translate('analytics.source.search'):value}))]}/><FilterSelect label={translate('common.city')} value={filters.city} onChange={value=>update('city',value)} options={[{value:'all',label:translate('common.all')},...data.filters.cities.map(value=>({value,label:value}))]}/>{data.filters.commercials.length>1&&<FilterSelect label={translate('analytics.commercial')} value={filters.commercialId} onChange={value=>update('commercialId',value)} options={[{value:'all',label:translate('common.all')},...data.filters.commercials.map((value,index)=>({value,label:translate('analytics.commercialNumber',{number:index+1})}))]}/>}</div>{filters.period==='custom'&&<div className="mt-3 grid gap-3 sm:grid-cols-2"><div><Label>{translate('analytics.startDate')}</Label><Input type="date" value={filters.start} onChange={event=>update('start',event.target.value)}/></div><div><Label>{translate('analytics.endDate')}</Label><Input type="date" value={filters.end} onChange={event=>update('end',event.target.value)}/></div></div>}</CardContent></Card>;
}
function FilterSelect({label,value,onChange,options}:{label:string;value:string;onChange:(value:string)=>void;options:Array<{value:string;label:string}>}) { return <div><Label className="mb-1.5">{label}</Label><Select value={value} onValueChange={onChange}><SelectTrigger className="w-full"><SelectValue>{options.find(item=>item.value===value)?.label ?? value}</SelectValue></SelectTrigger><SelectContent>{options.map(item=><SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div>; }

function KpiCard({label,value,icon,tone,comparisonValue,points,onClick}:{label:string;value:string;icon:React.ReactNode;tone:'indigo'|'emerald'|'cyan'|'violet';comparisonValue:ReturnType<typeof comparison>;points?:boolean;onClick?:()=>void}) {
  const tones={indigo:'bg-indigo-50 text-indigo-600',emerald:'bg-emerald-50 text-emerald-600',cyan:'bg-cyan-50 text-cyan-600',violet:'bg-violet-50 text-violet-600'};
  // The visible KPI label is nested inside the composed Card.
  // oxlint-disable-next-line jsx-a11y/control-has-associated-label
  return <button type="button" onClick={onClick} disabled={!onClick} className="text-start disabled:cursor-default"><Card className="h-full border-0 shadow-sm ring-1 ring-slate-200/70 transition hover:ring-indigo-200"><CardContent className="p-4"><div className="flex items-start justify-between gap-2"><div><p className="text-sm font-semibold text-slate-500">{label}</p><b className="mt-1 block text-2xl font-black text-slate-950">{value}</b></div><span className={`grid size-10 place-items-center rounded-2xl ${tones[tone]}`}>{icon}</span></div><ComparisonBadge result={comparisonValue} points={points}/></CardContent></Card></button>;
}
function ComparisonBadge({result,points}:{result:ReturnType<typeof comparison>;points?:boolean}) { const {t:translate,formatNumber:localNumber}=useI18n(); if(result.kind==='insufficient')return <p className="mt-3 text-xs text-slate-400">{translate('analytics.insufficientComparison')}</p>; if(result.kind==='new')return <p className="mt-3 text-xs font-semibold text-indigo-600">{translate('analytics.newThisPeriod')}</p>; const Icon=result.value>0?ArrowUpRight:result.value<0?ArrowDownRight:ArrowRight; const tone=result.value>0?'text-emerald-600':result.value<0?'text-rose-600':'text-slate-500'; return <p className={`mt-3 flex items-center gap-1 text-xs font-bold ${tone}`}><Icon className="size-3.5"/>{result.value>0?'+':''}{localNumber(result.value,{maximumFractionDigits:1})}{points?` ${translate('analytics.points')}`:'%'} <span className="font-normal text-slate-400">{translate('analytics.vsPrevious')}</span></p>; }

function FunnelStep({stage,strongest,onStage,onLoss}:{stage:AnalyticsStage;strongest:boolean;onStage:()=>void;onLoss:()=>void}) { const {t:translate,formatNumber:localNumber}=useI18n(); return <div className={`relative rounded-2xl border p-3 ${strongest?'border-rose-300 bg-rose-50/60':'border-slate-200 bg-slate-50/70'}`}>{strongest&&<Badge className="absolute -top-2 end-2 bg-rose-600 text-white">{translate('analytics.biggestLeak')}</Badge>}<button type="button" onClick={onStage} className="w-full text-start"><span className="flex items-center gap-2 font-bold"><i className="size-2.5 rounded-full" style={{backgroundColor:stage.color}}/>{stageLabel(stage)}</span><b className="mt-2 block text-2xl text-slate-950">{localNumber(stage.reached_count)}</b><span className="text-xs text-slate-500">{translate('analytics.reached')} · {localNumber(stage.share)}%</span><Progress value={stage.passage_rate??0} className="mt-3 h-1.5"/><span className="mt-1 block text-xs text-slate-500">{translate('analytics.passageRate')}: {stage.passage_rate===null?'—':`${localNumber(stage.passage_rate)}%`}</span></button>{(stage.lost_from_count>0||stage.dropoff_rate!==null)&&<button type="button" onClick={onLoss} className="mt-2 text-xs font-semibold text-rose-600">{localNumber(stage.lost_from_count)} {translate('analytics.lostLower')} · {localNumber(stage.dropoff_rate??0)}%</button>}</div>; }

function ActionableInsights({total,stages,strongestLeak,slowestStage,blocked,onOpen}:{total:number;stages:AnalyticsStage[];strongestLeak:AnalyticsStage|null;slowestStage:AnalyticsStage|null;blocked:AnalyticsData['blocked'];onOpen:(target:DrilldownTarget)=>Promise<void>}) { const {t:translate,formatNumber:localNumber}=useI18n(); const largest=[...stages].sort((a,b)=>b.current_count-a.current_count)[0]; const topBlocked=blocked[0]; const insights=[largest&&{key:'volume',tone:'indigo',title:translate('analytics.insight.stageVolume',{count:largest.current_count,stage:stageLabel(largest)}),detail:translate('analytics.insight.stageVolumeWhy',{share:largest.share}),action:translate('analytics.viewProspects'),target:{title:stageLabel(largest),kind:'stage' as const,stageId:largest.id}},topBlocked&&{key:'blocked',tone:'amber',title:translate('analytics.insight.blockedAction',{count:topBlocked.count,days:topBlocked.threshold_days}),detail:translate('analytics.insight.blockedWhy',{stage:stageLabel(topBlocked)}),action:translate('analytics.followUp'),target:{title:translate('analytics.blockedProspects'),kind:'blocked' as const,stageId:topBlocked.stage_id,thresholdDays:topBlocked.threshold_days}},strongestLeak&&{key:'leak',tone:'rose',title:translate('analytics.insight.leakAction',{stage:stageLabel(strongestLeak),rate:strongestLeak.dropoff_rate??0}),detail:translate('analytics.insight.leakWhy'),action:translate('analytics.analyse'),target:{title:translate('analytics.lossFrom',{stage:stageLabel(strongestLeak)}),kind:'lossFrom' as const,stageId:strongestLeak.id}},slowestStage&&{key:'slow',tone:'violet',title:translate('analytics.insight.slowAction',{stage:stageLabel(slowestStage),days:localNumber(slowestStage.average_days??0,{maximumFractionDigits:1})}),detail:translate('analytics.insight.slowWhy'),action:translate('analytics.viewProspects'),target:{title:stageLabel(slowestStage),kind:'stage' as const,stageId:slowestStage.id}}].filter(Boolean) as Array<{key:string;tone:string;title:string;detail:string;action:string;target:DrilldownTarget}>; return <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader className="pb-2"><CardTitle>{translate('analytics.actionableInsights')}</CardTitle><p className="text-sm text-slate-500">{translate('analytics.actionableDescription')}</p></CardHeader><CardContent className="space-y-2">{total===0?<p className="text-sm text-slate-500">{translate('analytics.noData')}</p>:insights.map(item=><div key={item.key} className="rounded-2xl border border-slate-200 p-3"><b className="block text-sm text-slate-900">{item.title}</b><p className="mt-1 text-xs leading-5 text-slate-500">{item.detail}</p><Button variant="link" size="sm" className="mt-1 h-auto px-0" onClick={()=>void onOpen(item.target)}>{item.action}<ArrowRight/></Button></div>)}</CardContent></Card>; }

function StageCard({stage,total,lossReasons,onOpen}:{stage:AnalyticsStage;total:number;lossReasons:AnalyticsData['loss_reasons'];onOpen:(target:DrilldownTarget)=>Promise<void>}) { const {t:translate,formatNumber:localNumber}=useI18n(); const financial=financialStageSlugs.has(stage.slug); const mainReason=stage.slug==='lost'?lossReasons[0]:null; return <div className="rounded-2xl border border-slate-200 p-4"><div className="flex items-center justify-between"><button type="button" onClick={()=>void onOpen({title:stageLabel(stage),kind:'stage',stageId:stage.id})} className="flex items-center gap-2 font-bold"><i className="size-3 rounded-full" style={{backgroundColor:stage.color}}/>{stageLabel(stage)}</button><Badge variant="outline">{localNumber(stage.current_count)}</Badge></div><div className="mt-3 grid grid-cols-2 gap-2 text-xs"><MiniValue label={translate('analytics.totalShare')} value={`${localNumber(stage.share)}%`}/><MiniValue label={translate('analytics.averageStageTime')} value={stage.average_days===null?translate('analytics.insufficientData'):translate('analytics.daysValue',{value:localNumber(stage.average_days,{maximumFractionDigits:1})})}/><MiniValue label={translate('analytics.passageRate')} value={stage.passage_rate===null?'—':`${localNumber(stage.passage_rate)}%`}/><MiniValue label={translate('analytics.dropoffRate')} value={stage.dropoff_rate===null?'—':`${localNumber(stage.dropoff_rate)}%`}/>{financial&&stage.slug!=='won'&&stage.slug!=='lost'&&stage.estimated_value>0&&<MiniValue label={stage.slug==='proposal'?translate('analytics.proposedAmount'):translate('analytics.estimatedValue')} value={money(stage.estimated_value)}/>} {stage.slug==='won'&&<><MiniValue label={translate('analytics.generatedRevenue')} value={money(stage.final_value)}/><MiniValue label={translate('analytics.averageWonValue')} value={stage.current_count?money(stage.final_value/stage.current_count):'—'}/></>} {stage.slug==='lost'&&<><MiniValue label={translate('analytics.lostRevenue')} value={money(stage.lost_value)}/><MiniValue label={translate('analytics.mainLossReason')} value={mainReason?translate(`analytics.lossReason.${mainReason.reason}`):translate('analytics.insufficientData')}/></>}</div>{stage.lost_from_count>0&&<button type="button" onClick={()=>void onOpen({title:translate('analytics.lossFrom',{stage:stageLabel(stage)}),kind:'lossFrom',stageId:stage.id})} className="mt-3 text-xs font-bold text-rose-600">{localNumber(stage.lost_from_count)} {translate('analytics.lostLower')} · {localNumber(stage.dropoff_rate??0)}% {translate('analytics.lossRate')}</button>}{total===0&&<span/>}</div>; }

function ChartCard({title,description,controls,children}:{title:string;description:string;controls:React.ReactNode;children:React.ReactNode}) { return <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader className="pb-2"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start"><div><CardTitle>{title}</CardTitle><p className="mt-1 text-sm text-slate-500">{description}</p></div>{controls}</div></CardHeader><CardContent>{children}</CardContent></Card>; }
function GranularitySelect({value,onChange}:{value:string;onChange:(value:string)=>void}) { const {t:translate}=useI18n(); return <Select value={value} onValueChange={onChange}><SelectTrigger className="w-32"><SelectValue>{translate(`analytics.granularity.${value}`)}</SelectValue></SelectTrigger><SelectContent>{['day','week','month'].map(item=><SelectItem key={item} value={item}>{translate(`analytics.granularity.${item}`)}</SelectItem>)}</SelectContent></Select>; }
function MiniValue({label,value}:{label:string;value:string}) { return <div className="rounded-xl bg-slate-50 p-2.5"><span className="block truncate text-xs text-slate-500">{label}</span><b className="mt-1 block truncate text-sm text-slate-900" title={value}>{value}</b></div>; }
function BlockedProspects({items,onOpen}:{items:AnalyticsData['blocked'];onOpen:(target:DrilldownTarget)=>Promise<void>}) { const {t:translate,formatNumber:localNumber}=useI18n(); return <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader><CardTitle className="flex items-center gap-2"><Clock3 className="size-5 text-amber-500"/>{translate('analytics.blockedProspects')}</CardTitle></CardHeader><CardContent className="space-y-2">{items.length?items.map(item=><button type="button" key={item.stage_id} onClick={()=>void onOpen({title:translate('analytics.blockedIn',{stage:stageLabel(item)}),kind:'blocked',stageId:item.stage_id,thresholdDays:item.threshold_days})} className="flex w-full items-center justify-between rounded-2xl border border-amber-100 bg-amber-50/60 p-3 text-start"><span><b className="block">{stageLabel(item)}</b><small className="text-amber-700">&gt; {localNumber(item.threshold_days)} {translate('analytics.days')}</small></span><Badge className="bg-amber-500 text-white">{localNumber(item.count)}</Badge></button>):<p className="rounded-2xl bg-emerald-50 p-5 text-sm text-emerald-700">{translate('analytics.noBlockedProspects')}</p>}</CardContent></Card>; }
function LossReasons({items,onOpen}:{items:AnalyticsData['loss_reasons'];onOpen:(target:DrilldownTarget)=>Promise<void>}) { const {t:translate,formatNumber:localNumber}=useI18n(); const max=Math.max(1,...items.map(item=>item.count)); return <Card className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardHeader><CardTitle>{translate('analytics.lossReasons')}</CardTitle></CardHeader><CardContent className="space-y-3">{items.length?items.map(item=><button type="button" key={item.reason} onClick={()=>void onOpen({title:translate(`analytics.lossReason.${item.reason}`),kind:'lossReason',reason:item.reason})} className="block w-full text-start"><span className="flex justify-between text-sm"><b>{translate(`analytics.lossReason.${item.reason}`)}</b><span>{localNumber(item.count)}</span></span><span className="mt-1 block h-2 overflow-hidden rounded-full bg-slate-100"><i className="block h-full rounded-full bg-rose-500" style={{width:`${item.count/max*100}%`}}/></span></button>):<p className="text-sm text-slate-500">{translate('analytics.noLossReasons')}</p>}</CardContent></Card>; }
function AnalyticsSkeleton(){return <div className="space-y-5"><Skeleton className="h-28 rounded-3xl"/><Skeleton className="h-32 rounded-3xl"/><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{[1,2,3,4,5].map(item=><Skeleton key={item} className="h-28 rounded-2xl"/>)}</div><Skeleton className="h-96 rounded-3xl"/></div>;}
