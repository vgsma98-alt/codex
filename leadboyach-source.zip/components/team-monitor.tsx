'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, ArrowLeftRight, Building2, Clock3, Eye, Search, ShieldCheck, UserRoundCheck, UsersRound } from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import type { Lead, LeadAuditLog, Team, TeamMember, UserPlan } from '@/lib/database.types';
import { formatDate, formatNumber, t } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';

function compactName(value: string | null) {
  const words = (value?.trim() || t('common.clientUnnamed')).split(/\s+/);
  return words.length > 7 ? `${words.slice(0, 7).join(' ')}…` : words.join(' ');
}

export function TeamMonitor({ userId }: { userId: string }) {
  const [team, setTeam] = useState<Team | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [profiles, setProfiles] = useState<UserPlan[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [logs, setLogs] = useState<LeadAuditLog[]>([]);
  const [query, setQuery] = useState('');
  const [memberFilter, setMemberFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const { data: teamData, error: teamError } = await supabase.from('Teams').select('*').eq('supervisor_id', userId).order('created_at').limit(1).maybeSingle();
    if (teamError) { setError(teamError.message); setLoading(false); return; }
    if (!teamData) { setTeam(null); setLoading(false); return; }

    const { data: memberData, error: memberError } = await supabase.from('Team_Members').select('*').eq('team_id', teamData.id).order('joined_at');
    if (memberError) { setError(memberError.message); setLoading(false); return; }
    const memberIds = (memberData ?? []).map((item) => item.user_id);
    if (memberIds.length === 0) { setTeam(teamData); setMembers([]); setProfiles([]); setLeads([]); setLogs([]); setLoading(false); return; }

    const [profileResult, leadResult, logResult] = await Promise.all([
      supabase.from('User_Plans').select('*').in('User_id', memberIds).order('Name'),
      supabase.from('Leads').select('*').in('User_id', memberIds).order('pipeline_updated_at', { ascending: false }).limit(500),
      supabase.from('Lead_Audit_Log').select('*').in('user_id', memberIds).order('changed_at', { ascending: false }).limit(500),
    ]);
    const firstError = profileResult.error || leadResult.error || logResult.error;
    if (firstError) setError(firstError.message);
    else {
      setTeam(teamData); setMembers(memberData ?? []); setProfiles(profileResult.data ?? []);
      setLeads(leadResult.data ?? []); setLogs(logResult.data ?? []);
    }
    setLoading(false);
  }, [userId]);

  // oxlint-disable-next-line react-compiler/react-compiler
  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const channel = supabase.channel(`team-audit-${userId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'Lead_Audit_Log' }, () => void load()).subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [load, userId]);

  const profileMap = useMemo(() => new Map(profiles.map((profile) => [profile.User_id, profile])), [profiles]);
  const leadMap = useMemo(() => new Map(leads.map((lead) => [lead.id, lead])), [leads]);
  const filteredLogs = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return logs.filter((log) => {
      const lead = leadMap.get(log.lead_id);
      const profile = profileMap.get(log.user_id ?? '');
      return (memberFilter === 'all' || log.user_id === memberFilter) && (!needle || `${lead?.Entreprise ?? ''} ${profile?.Name ?? ''} ${profile?.Email ?? ''} ${log.changed_fields.join(' ')}`.toLocaleLowerCase().includes(needle));
    });
  }, [leadMap, logs, memberFilter, profileMap, query]);

  if (loading) return <div className="space-y-4"><Skeleton className="h-40 rounded-3xl" /><Skeleton className="h-96 rounded-3xl" /></div>;
  if (!team) return <Alert><Eye /><AlertDescription>{t('teams.notSupervisor')}</AlertDescription></Alert>;

  return <div className="space-y-6">
    {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
    <Card className="overflow-hidden border-0 bg-[linear-gradient(135deg,#032e25_0%,#064e3b_100%)] text-white shadow-xl">
      <CardContent className="p-6 sm:p-8"><div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-center"><div className="flex items-center gap-4"><span className="grid size-14 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/15"><UsersRound /></span><div><Badge className="mb-2 bg-indigo-400/15 text-indigo-100 hover:bg-indigo-400/15"><ShieldCheck className="size-3" />{t('teams.supervisorBadge')}</Badge><h2 className="text-2xl font-black">{team.name}</h2><p className="mt-1 text-sm text-slate-300">{t('teams.monitorDescription')}</p></div></div><div className="grid grid-cols-3 gap-3 text-center"><div className="rounded-2xl bg-white/10 p-4"><b className="block text-2xl">{formatNumber(members.length)}</b><span className="text-xs text-slate-300">{t('teams.members')}</span></div><div className="rounded-2xl bg-white/10 p-4"><b className="block text-2xl">{formatNumber(leads.length)}</b><span className="text-xs text-slate-300">{t('admin.leads')}</span></div><div className="rounded-2xl bg-white/10 p-4"><b className="block text-2xl">{formatNumber(logs.length)}</b><span className="text-xs text-slate-300">{t('teams.changes')}</span></div></div></div></CardContent>
    </Card>

    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{profiles.map((profile) => {
      const count = leads.filter((lead) => lead.User_id === profile.User_id).length;
      const changes = logs.filter((log) => log.user_id === profile.User_id).length;
      return <Card key={profile.User_id} className="border-0 shadow-sm ring-1 ring-slate-200/70"><CardContent className="p-4"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-indigo-50 text-indigo-600"><UserRoundCheck className="size-5" /></span><div className="min-w-0"><p className="truncate font-black">{profile.Name || t('admin.unnamedUser')}</p><p className="truncate text-xs text-slate-500">{profile.Email || '—'}</p></div></div><div className="mt-4 flex gap-2"><Badge variant="outline"><Building2 className="size-3" />{t('teams.leadCount', { count })}</Badge><Badge variant="outline"><Activity className="size-3" />{t('teams.changeCount', { count: changes })}</Badge></div></CardContent></Card>;
    })}</div>

    <Card className="border-0 shadow-sm ring-1 ring-slate-200/70">
      <CardHeader><div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end"><div><CardTitle>{t('teams.activityLog')}</CardTitle><CardDescription>{t('teams.activityLogDescription')}</CardDescription></div><div className="grid gap-2 sm:grid-cols-2 lg:min-w-[560px]"><div className="relative"><Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('teams.searchLogs')} className="ps-9" /></div><Select value={memberFilter} onValueChange={(value) => setMemberFilter(value ?? 'all')}><SelectTrigger><SelectValue>{memberFilter === 'all' ? t('teams.allMembers') : (profileMap.get(memberFilter)?.Name || profileMap.get(memberFilter)?.Email || t('admin.unnamedUser'))}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('teams.allMembers')}</SelectItem>{profiles.map((profile) => <SelectItem key={profile.User_id} value={profile.User_id}>{profile.Name || profile.Email || t('admin.unnamedUser')}</SelectItem>)}</SelectContent></Select></div></div></CardHeader>
      <CardContent className="space-y-3">{filteredLogs.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500">{t('teams.noLogs')}</div> : filteredLogs.map((log) => {
        const lead = leadMap.get(log.lead_id); const owner = profileMap.get(log.user_id ?? ''); const actor = profileMap.get(log.changed_by ?? '');
        return <button key={log.id} type="button" onClick={() => window.location.assign(`/leads/${encodeURIComponent(log.lead_id)}`)} className="flex w-full flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-start transition hover:border-indigo-200 hover:bg-indigo-50/30 sm:flex-row sm:items-center">
          <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-indigo-50 text-indigo-600">{log.event_type === 'stage_changed' ? <ArrowLeftRight className="size-5" /> : <Activity className="size-5" />}</span>
          <span className="min-w-0 flex-1"><b className="block truncate text-slate-950">{compactName(lead?.Entreprise ?? null)}</b><span className="mt-1 block text-xs text-slate-500">{t(`audit.${log.event_type}`)} · {owner?.Name || owner?.Email || t('common.user')}</span>{log.event_type === 'stage_changed' && <span className="mt-2 inline-flex rounded-lg bg-slate-100 px-2 py-1 text-xs font-bold text-slate-600">{log.previous_stage || '—'} → {log.new_stage || '—'}</span>}</span>
          <span className="shrink-0 text-xs text-slate-500"><span className="mb-1 flex items-center gap-1"><UserRoundCheck className="size-3" />{actor?.Name || actor?.Email || t('teams.systemActor')}</span><span className="flex items-center gap-1"><Clock3 className="size-3" />{formatDate(log.changed_at, { dateStyle: 'medium', timeStyle: 'short' })}</span></span>
        </button>;
      })}</CardContent>
    </Card>
  </div>;
}
