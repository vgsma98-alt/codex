# رفع LEADBOYACH على VPS عبر Easypanel

الموقع التعريفي والتطبيق جزء من مشروع واحد؛ لا تحتاج رفعهما كخدمتين منفصلتين. الروابط تبقى `/landing` للموقع، و`/` للتطبيق، و`/contact` للاتصال.

تمت إضافة وضع بناء Node.js مستقل وDockerfile. إعداد Cloudflare الحالي محفوظ. هذه الحزمة لا تنقل قاعدة البيانات ولا n8n ولا تنشر شيئًا تلقائيًا على الخادم.

## قبل البدء

- احتفظ بالنسخة الحالية حتى تنجح اختبارات النسخة الجديدة.
- خذ نسخة احتياطية أو Snapshot للخادم من Hostinger قبل التغييرات.
- استخدم مشروعًا وخدمة جديدين في Easypanel، ولا تعدّل أو توقف خدمة n8n الموجودة.
- اختر الدومين الذي تملكه. `leadboyach.com` في الأمثلة مجرد اسم تستبدله عند الحاجة.
- جهّز عنوان مشروع Supabase ومفتاحه العام ورابط Webhook الخاص بـ n8n من إعداداتك الحالية، دون نشرها في مستودع عام.

## 1. رفع الملفات

افتح Easypanel من لوحة VPS في Hostinger وسجّل الدخول بنفسك. أنشئ مشروعًا باسم `leadboyach`، ثم **New Service → App** باسم `web`.

من **Source → Upload** ارفع ملف `LEADBOYACH-VPS-source.zip` المرفق. ملفات المشروع موجودة في جذر الأرشيف؛ مسار البناء `/` وملف Dockerfile هو `Dockerfile`.

من **Build** اختر **Dockerfile**، وليس أمر التشغيل الافتراضي `pnpm start`؛ ذلك الأمر لا يزال خاصًا بالنسخة الحالية على Cloudflare.

## 2. إدخال الإعدادات

في **Environment** أدخل القيم التالية، بعد استبدال القيم التوضيحية:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-publishable-or-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
N8N_WEBHOOK_URL=https://your-n8n-domain/webhook/your-webhook
N8N_WEBHOOK_METHOD=POST
VINEXT_TRUSTED_HOSTS=leadboyach.com,www.leadboyach.com
NODE_ENV=production
PORT=3000
HOST=0.0.0.0
```

`VINEXT_TRUSTED_HOSTS` يحتوي فقط أسماء الدومينات الخارجية، دون `https://` ودون مسارات. أضف اسم الدومين التجريبي الذي يوفره Easypanel إذا استعملته للاختبار. هذا ضروري لطلبات API خلف وكيل HTTPS، ولا يُستعمل إلا عندما تمر الزيارات عبر الوكيل الموثوق.

البناء يحتاج **Build Arguments** بالاسمين `NEXT_PUBLIC_SUPABASE_URL` و`NEXT_PUBLIC_SUPABASE_ANON_KEY` وبالقيم نفسها. Easypanel يوفر متغيرات البيئة للبناء والتشغيل؛ تأكد من تمرير هذين الاسمين إلى Docker build في إعدادات إصدارك. إذا ظهر فشل في سطر `test -n`، فهما لم يصلا إلى مرحلة البناء. لا تمرّر رابط Webhook أو `service_role` كـ Build Arguments.

لا ترفع `.env.local`؛ الأرشيف لا يحتوي عليه. متغير `SUPABASE_SERVICE_ROLE_KEY` مطلوب فقط على الخادم كي يستطيع مدير التطبيق إنشاء المستخدمين وحذفهم؛ لا تضفه إلى Build Arguments ولا تضع قبله `NEXT_PUBLIC_` ولا تعرضه في الواجهة. المتغيرات العامة تُدمج أثناء البناء؛ تغييرها يتطلب إعادة البناء، وليس Restart فقط.

## 3. النشر وربط الدومين

اضغط **Deploy** وانتظر نجاح البناء، ثم راجع Logs. التطبيق يستمع داخل الحاوية على المنفذ **3000**.

في DNS أضف سجل **A** للدومين المطلوب نحو عنوان IPv4 لخادمك. العنوان الذي ظهر عند الفحص: `187.55.225.29`؛ تأكد أنه لم يتغير في لوحة Hostinger. يمكنك جعل `www` سجل CNAME إلى الدومين الرئيسي. لا تغيّر سجلات البريد MX/TXT أو سجلات خدمات أخرى.

من **Domains** في Easypanel أضف الدومين، والمسار `/`، والوجهة الداخلية **HTTP، port 3000**، ثم فعّل HTTPS. لا تنشر المنفذ 3000 مباشرة إلى الإنترنت. إذا كان جدار الحماية يحجب المرور، اسمح بمنفذي HTTP/HTTPS فقط وفق إعداداتك، دون تغيير وصول SSH أو خدمات n8n.

النتيجة بعد استبدال الدومين:

- `https://leadboyach.com/landing`
- `https://leadboyach.com/`
- `https://leadboyach.com/contact`

الحاوية لا تحتاج قرصًا لحفظ بيانات العملاء؛ البيانات محفوظة في Supabase. لا تمسح قواعد البيانات أو تعِد تشغيل الترحيلات الموجودة لمجرد نقل الاستضافة.

## 4. تعديل روابط المصادقة في Supabase

من **Authentication → URL Configuration**:

1. أضف عنوان النسخة الجديدة، مثل `https://leadboyach.com/`، إلى Redirect URLs.
2. عند اعتماد الدومين الجديد للإنتاج، اضبط Site URL على عنوانه.
3. احتفظ بعنوان النسخة القديمة ضمن القائمة أثناء الانتقال.
4. اختبر رسالة تأكيد حساب جديد على الدومين الجديد.

استخدم المسارات الدقيقة الفعلية، ولا تسمح بدومينات غير موثوقة. تخصيص قالب رسالة التسجيل واسم المرسل وSMTP عملية منفصلة؛ الحزمة لا تفعّلها تلقائيًا.

### تخصيص رسالة تأكيد الحساب على Supabase Free

المشاريع المجانية الجديدة التي تستخدم SMTP الافتراضي من Supabase لا تقبل تخصيص قوالب رسائل Auth. لتظهر رسالة LEADBOYACH بدل رسالة `Supabase Auth` الافتراضية، فعّل مزود SMTP خاصًا أولًا من **Authentication → Emails → SMTP Settings**.

إذا كنت تستعمل Hostinger Email، أنشئ صندوقًا مثل `no-reply@leadboyach.com` ثم استعمل إعداداته الآتية دون مشاركة كلمة مروره أو حفظها داخل المشروع:

```text
Sender name: LEADBOYACH
Sender email: no-reply@leadboyach.com
Host: smtp.hostinger.com
Port: 465
Username: no-reply@leadboyach.com
Password: كلمة مرور صندوق البريد نفسه
```

بعد نجاح اختبار SMTP، افتح **Authentication → Emails → Templates → Confirm signup**، واجعل العنوان `Confirmez votre compte LEADBOYACH` والصق محتوى `deploy/supabase-confirm-signup.html` ثم احفظه. يستخدم القالب `{{ .ConfirmationURL }}` حتى يحافظ Supabase على رابط التأكيد الآمن.

## 5. الاختبارات قبل اعتماد النسخة

- افتح `/api/health`: يجب أن يعرض `{"status":"ok"}`. هذا فحص تشغيل فقط، وليس فحص اتصال قاعدة البيانات.
- جرّب `/landing` و`/contact` واللغات الثلاث، وتأكد أن الصور والحركات تعمل.
- سجّل الدخول بحسابك وافتح Prospects والتفاصيل وMes recherches.
- نفّذ بحثًا صغيرًا ضمن حصتك وتأكد من ظهور النتائج والإيميلات وتصدير Excel.
- حدّث حالة Prospect وتأكد من حفظها بعد إعادة فتح الصفحة.
- اختبر صلاحيات المستخدم العادي والإدارة بحساباتك المصرّح بها.
- اختبر نموذج الاتصال واستلام الرسالة؛ قد يحتاج FormSubmit موافقة مالك البريد، ولا يكفي ظهور رسالة نجاح أو حفظ نسخة في قاعدة البيانات.

إذا رفضت API الطلبات برسالة عامة، راجع الدومين في `VINEXT_TRUSTED_HOSTS` وترويسات Host وX-Forwarded-Proto في الوكيل. لا تعطّل التحقق من Origin أو RLS لحل المشكلة.

## بديل: Docker Compose عبر SSH

هذا البديل لمن يعرف إدارة الخادم. لا تشغّله بالتوازي مع خدمة Easypanel نفسها.

ارفع الأرشيف وفكّه داخل مجلد جديد، ثم:

```sh
cp deploy/vps.env.example .env.vps
chmod 600 .env.vps
nano .env.vps
docker compose --env-file .env.vps build
docker compose --env-file .env.vps up -d
docker compose --env-file .env.vps ps
docker compose --env-file .env.vps logs --tail=100
curl http://127.0.0.1:3000/api/health
```

ملف Compose يربط المنفذ بـ localhost فقط. يلزم وكيل HTTPS قائم على الخادم يمرّر Host وX-Forwarded-Proto، مع الدومين الدقيق في قائمة الثقة. لا تستبدل الوكيل الحالي أو تربط 80/443 بحاوية جديدة إذا كانت Easypanel تستخدمهما.

## التحديث والرجوع

ارفع الحزمة الجديدة إلى الخدمة نفسها ثم Deploy، واحتفظ بالحزمة/الصورة السابقة. عند فشل الإصدار أعد نشر الصورة أو المصدر السابق؛ لا تُعِد تثبيت نظام VPS ولا تسترجع Snapshot كاملًا إلا بعد تقدير ما سيُفقد من خدمات أخرى.

شغّل البناء في Linux على الخادم؛ لا ترفع `node_modules` المبني على Windows. فُحص وضع Node محليًا، لكن تشغيل Docker على Linux وHTTPS والخدمات الخارجية يجب التحقق منها على خادمك قبل اعتماد الإنتاج.

## مصادر الإعداد

- [Vinext](https://github.com/cloudflare/vinext)
- [خدمة App في Easypanel](https://easypanel.io/docs/services/app)
- [روابط إعادة التوجيه في Supabase](https://supabase.com/docs/guides/auth/redirect-urls)
