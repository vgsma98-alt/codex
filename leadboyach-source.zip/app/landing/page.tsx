'use client';

import { LandingPage } from '@/components/landing-page';

export default function MarketingLandingPage() {
  return <LandingPage onAuthenticate={(mode = 'signup') => window.location.assign(`/?auth=${mode}`)} />;
}
