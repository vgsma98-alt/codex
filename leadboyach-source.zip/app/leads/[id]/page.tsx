'use client';
import { safeWebsiteUrl } from '@/lib/safe-url';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  ArrowRight,
  Building2,
  ChevronLeft,
  CircleAlert,
  CircleDollarSign,
  Clock3,
  Globe2,
  Mail,
  MapPin,
  MapPinned,
  MessageSquareText,
  Phone,
  PhoneCall,
  Sparkles,
  Star,
  Workflow,
} from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import type { Lead, LeadAuditLog, PipelineStage, SearchRecord } from '@/lib/database.types';
import { supabase } from '@/lib/supabase';
import { LanguageSwitcher } from '@/components/language-switcher';
import { PipelineStageSelect } from '@/components/pipeline-stage-status';
import { formatDate, t, useI18n } from '@/lib/i18n';
import { leadQualityLabel, leadQualityTone } from '@/lib/lead-quality';
import { EmailLookupIndicator } from '@/components/async-status';

function available(value?: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(
    normalized &&
      !['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined'].includes(normalized),
  );
}

function capitalizeFirst(value?: string | null) {
  const text = value?.trim();
  if (!text) return '—';
  return `${text.charAt(0).toLocaleUpperCase()}${text.slice(1)}`;
}

function cityLabel(lead: Lead, fallback?: string | null) {
  const city = lead.City?.trim();
  const normalized = city?.toLocaleLowerCase().replace(/[\s./_-]/g, '');
  if (normalized && !['nr', 'na', 'notfound', 'unknown', 'inconnu', 'غيرمعروف'].includes(normalized)) {
    return capitalizeFirst(city);
  }
  return capitalizeFirst(fallback);
}

function emailLabel(lead: Lead) {
  if (available(lead.Email)) return lead.Email!;
  const status = lead.Email_status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
  return status === 'not found' || Boolean(lead.Email?.trim()) ? t('common.unavailable') : t('common.searching');
}

function phoneContact(phone: string, country?: string | null, address?: string | null) {
  const primary = phone.split(/[;,\n]/)[0]?.trim() || phone.trim();
  let digits = primary.replace(/\D/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);

  const location = `${country ?? ''} ${address ?? ''}`.toLocaleLowerCase();
  let nationalNumber = digits;
  let internationalNumber = digits;
  let knownCountry: 'ma' | 'fr' | null = null;

  if (digits.startsWith('212')) {
    knownCountry = 'ma';
    nationalNumber = digits.slice(3).replace(/^0/, '');
    internationalNumber = `212${nationalNumber}`;
  } else if (digits.startsWith('33')) {
    knownCountry = 'fr';
    nationalNumber = digits.slice(2).replace(/^0/, '');
    internationalNumber = `33${nationalNumber}`;
  } else if (digits.startsWith('0')) {
    nationalNumber = digits.slice(1);
    if (/maroc|morocco|المغرب/.test(location)) {
      knownCountry = 'ma';
      internationalNumber = `212${nationalNumber}`;
    } else if (/france|فرنسا/.test(location)) {
      knownCountry = 'fr';
      internationalNumber = `33${nationalNumber}`;
    }
  }

  const isMobile =
    (knownCountry === 'ma' || knownCountry === 'fr') &&
    /^[67]/.test(nationalNumber);

  return {
    display: primary,
    href: isMobile ? `https://wa.me/${internationalNumber}` : `tel:${primary}`,
    type: isMobile ? 'mobile' as const : 'landline' as const,
  };
}

function WhatsAppLogo() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.075-.792.372-.272.297-1.04 1.016-1.04 2.479s1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.693.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.981.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884a9.8 9.8 0 0 1 7.03 2.914 9.78 9.78 0 0 1 2.9 7.02c-.003 5.45-4.437 9.884-9.884 9.884m8.413-18.297A11.8 11.8 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.14 1.588 5.945L.057 24l6.305-1.654a11.88 11.88 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.82 11.82 0 0 0-3.48-8.413Z" />
    </svg>
  );
}

function stageLabel(stage?: PipelineStage | null) {
  if (!stage) return t('pipeline.stage.new');
  const key = `pipeline.stage.${stage.slug}`;
  const translated = t(key);
  return translated === key ? stage.name : translated;
}

const defaultStageAliases: Record<string, string> = {
  new: 'new',
  nouveau: 'new',
  'جديد': 'new',
  contacted: 'contacted',
  'contacté': 'contacted',
  'تم التواصل': 'contacted',
  qualified: 'qualified',
  'qualifié': 'qualified',
  'مؤهل': 'qualified',
  proposal: 'proposal',
  proposition: 'proposal',
  'عرض': 'proposal',
  won: 'won',
  'gagné': 'won',
  'ناجح': 'won',
  lost: 'lost',
  perdu: 'lost',
  'مفقود': 'lost',
};

function auditStageLabel(value: string | null, stages: PipelineStage[]) {
  if (!value) return null;
  const normalized = value.trim().toLocaleLowerCase();
  const storedStage = stages.find(
    (stage) =>
      stage.id === value ||
      stage.slug.toLocaleLowerCase() === normalized ||
      stage.name.trim().toLocaleLowerCase() === normalized,
  );
  if (storedStage) return stageLabel(storedStage);
  const defaultSlug = defaultStageAliases[normalized];
  return defaultSlug ? t(`pipeline.stage.${defaultSlug}`) : value;
}

export default function LeadDetailsPage() {
  const { direction } = useI18n();
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const leadId = Array.isArray(params.id) ? params.id[0] : params.id;
  const [lead, setLead] = useState<Lead | null>(null);
  const [search, setSearch] = useState<SearchRecord | null>(null);
  const [stages, setStages] = useState<PipelineStage[]>([]);
  const [auditLog, setAuditLog] = useState<LeadAuditLog[]>([]);
  const [viewerId, setViewerId] = useState<string | null>(null);
  const [movingStage, setMovingStage] = useState(false);
  const [savingCommercialData, setSavingCommercialData] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadLead() {
      setLoading(true);
      setError(null);

      const { data: authData } = await supabase.auth.getUser();
      if (!authData.user) {
        router.replace('/');
        return;
      }
      setViewerId(authData.user.id);

      const { data, error: leadError } = await supabase
        .from('Leads')
        .select('*')
        .eq('id', leadId)
        .maybeSingle();

      if (cancelled) return;
      if (leadError) {
        setError(leadError.message);
        setLoading(false);
        return;
      }
      if (!data) {
        setError(t('lead.notFound'));
        setLoading(false);
        return;
      }

      setLead(data);
      const [searchResult, stageResult, auditResult] = await Promise.all([
        data.Search_id !== null
          ? supabase.from('Searches').select('*').eq('id', data.Search_id).maybeSingle()
          : Promise.resolve({ data: null }),
        data.User_id
          ? supabase.from('Pipeline_Stages').select('*').eq('user_id', data.User_id).order('position')
          : Promise.resolve({ data: [] as PipelineStage[] }),
        supabase.from('Lead_Audit_Log').select('*').eq('lead_id', data.id).order('changed_at', { ascending: false }).limit(50),
      ]);
      if (!cancelled) {
        setSearch(searchResult.data ?? null);
        setStages(stageResult.data ?? []);
        setAuditLog(auditResult.data ?? []);
      }
      if (!cancelled) setLoading(false);
    }

    void loadLead();
    return () => {
      cancelled = true;
    };
  }, [leadId, router]);

  useEffect(() => {
    if (!leadId) return;
    const channel = supabase
      .channel(`lead-details-${leadId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'Leads', filter: `id=eq.${leadId}` },
        (payload) => setLead(payload.new as Lead),
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'Lead_Audit_Log', filter: `lead_id=eq.${leadId}` },
        (payload) => {
          const entry = payload.new as LeadAuditLog;
          setAuditLog((current) => [entry, ...current.filter((item) => item.id !== entry.id)].slice(0, 50));
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [leadId]);

  const goBack = () => {
    if (window.history.length > 1) router.back();
    else router.push('/');
  };

  const changeStage = async (stageId: string) => {
    if (!lead || movingStage || lead.pipeline_stage_id === stageId) return;
    const snapshot = lead;
    setMovingStage(true);
    setActionError(null);
    setLead({
      ...lead,
      pipeline_stage_id: stageId,
      pipeline_version: lead.pipeline_version + 1,
      pipeline_updated_at: new Date().toISOString(),
      pipeline_updated_by: viewerId,
    });

    const { data, error: updateError } = await supabase
      .from('Leads')
      .update({ pipeline_stage_id: stageId })
      .eq('id', lead.id)
      .eq('pipeline_version', snapshot.pipeline_version)
      .select('*')
      .maybeSingle();

    if (updateError || !data) {
      const { data: fresh } = await supabase.from('Leads').select('*').eq('id', lead.id).maybeSingle();
      setLead(fresh ?? snapshot);
      setActionError(updateError?.message || t('errors.concurrentLeadUpdate'));
    } else {
      setLead(data);
    }
    setMovingStage(false);
  };

  const saveCommercialData = async (
    changes: Partial<Pick<Lead, 'estimated_value' | 'final_deal_amount' | 'loss_reason'>>,
  ) => {
    if (!lead || savingCommercialData) return;
    const snapshot = lead;
    setSavingCommercialData(true);
    setActionError(null);
    setLead({ ...lead, ...changes });
    const { data, error: updateError } = await supabase
      .from('Leads')
      .update(changes)
      .eq('id', lead.id)
      .eq('pipeline_version', snapshot.pipeline_version)
      .select('*')
      .maybeSingle();
    if (updateError || !data) {
      const { data: fresh } = await supabase.from('Leads').select('*').eq('id', lead.id).maybeSingle();
      setLead(fresh ?? snapshot);
      setActionError(updateError?.message || t('errors.concurrentLeadUpdate'));
    } else {
      setLead(data);
    }
    setSavingCommercialData(false);
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-slate-50 p-4 sm:p-8" dir={direction}>
        <div className="mx-auto max-w-7xl space-y-5">
          <Skeleton className="h-14 w-40 rounded-xl" />
          <Skeleton className="h-64 rounded-3xl" />
          <div className="grid gap-4 lg:grid-cols-3">
            <Skeleton className="h-80 rounded-3xl lg:col-span-2" />
            <Skeleton className="h-80 rounded-3xl" />
          </div>
        </div>
      </main>
    );
  }

  if (error || !lead) {
    return (
      <main className="grid min-h-screen place-items-center bg-slate-50 p-5" dir={direction}>
        <Card className="w-full max-w-xl border-0 p-3 text-center shadow-xl ring-1 ring-slate-200">
          <CardContent className="space-y-5 p-7">
            <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-red-50 text-red-600">
              <CircleAlert className="size-7" />
            </span>
            <div>
              <h1 className="text-2xl font-black text-slate-950">{t('lead.openFailed')}</h1>
              <p className="mt-2 text-slate-500">{error}</p>
            </div>
            <Button onClick={() => router.push('/')} className="bg-indigo-600 hover:bg-indigo-700">
              {t('common.backToDashboard')}
            </Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  const phone = available(lead.Telephone)
    ? phoneContact(lead.Telephone!, search?.Pays, lead.Adresse)
    : null;
  const websiteAvailable = available(lead.Siteweb);
  const emailText = emailLabel(lead);
  const emailAddresses = available(lead.Email)
    ? lead.Email!.split(/[;,]/).map((item) => item.trim()).filter(Boolean)
    : [];
  const email = emailText === t('common.searching')
    ? <EmailLookupIndicator />
    : emailAddresses.length
      ? <EmailList addresses={emailAddresses} />
      : emailText;
  const city = cityLabel(lead, search?.Ville);
  const theoreticalScore = lead.LeadScore !== null ? `${lead.LeadScore}/100` : '—';
  const currentStage = stages.find((stage) => stage.id === lead.pipeline_stage_id) ?? null;
  const qualifiedPosition = stages.find((stage) => stage.slug === 'qualified')?.position;
  const hasCommercialValue = qualifiedPosition !== undefined && currentStage !== null && currentStage.position >= qualifiedPosition;

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.12),transparent_32%),linear-gradient(180deg,#f8fafc_0%,#f0fdf4_100%)] pb-12" dir={direction}>
      <header className="border-b border-slate-200/80 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex min-h-20 max-w-7xl items-center justify-between gap-4 px-4 sm:px-8">
          <Button variant="outline" onClick={goBack} className="border-slate-200 bg-white shadow-sm">
            <ArrowRight className="size-4 rtl:rotate-0 ltr:rotate-180" />
            {t('common.back')}
          </Button>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
            <span className="grid size-9 place-items-center rounded-xl bg-indigo-600 text-white">
              <Sparkles className="size-4" />
            </span>
            {t('common.brand')}
            <LanguageSwitcher className="ms-2" />
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl space-y-5 px-4 pt-6 sm:px-8 sm:pt-8">
        <section className="overflow-hidden rounded-3xl bg-[#032e25] text-white shadow-[0_24px_70px_rgba(2,44,34,0.22)]">
          <div className="relative p-6 sm:p-9">
            <div className="absolute inset-y-0 left-0 w-1/2 bg-[radial-gradient(circle_at_center,rgba(163,230,53,0.18),transparent_68%)]" />
            <div className="relative flex flex-col justify-between gap-7 lg:flex-row lg:items-end">
              <div className="flex items-start gap-4">
                <span className="grid size-16 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/10 text-indigo-200 shadow-inner">
                  <Building2 className="size-8" />
                </span>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className="border-indigo-400/30 bg-indigo-400/15 text-indigo-100 hover:bg-indigo-400/15">
                      {t('lead.details')}
                    </Badge>
                  </div>
                  <h1 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">
                    {lead.Entreprise || t('common.clientUnnamed')}
                  </h1>
                  <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-slate-300">
                    <span>{capitalizeFirst(lead.Activité)}</span>
                    <span className="flex items-center gap-1.5"><MapPin className="size-4" />{city}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {actionError && (
          <Alert variant="destructive">
            <CircleAlert />
            <AlertDescription>{actionError}</AlertDescription>
          </Alert>
        )}

        <section className="grid gap-3 sm:grid-cols-2" aria-label={t('lead.contactData')}>
          {phone ? (
            <ContactCard
              icon={phone.type === 'mobile' ? <WhatsAppLogo /> : <PhoneCall />}
              label={phone.type === 'mobile' ? t('lead.mobileWhatsApp') : t('lead.landlinePhone')}
              value={phone.display}
              href={phone.href}
              external={phone.type === 'mobile'}
              actionLabel={phone.type === 'mobile' ? t('lead.openWhatsApp') : t('lead.callPhone')}
              tone={phone.type === 'mobile' ? 'whatsapp' : 'phone'}
              ltr
            />
          ) : (
            <ContactCard icon={<Phone />} label={t('common.phone')} value={t('common.unavailable')} ltr />
          )}
          <ContactCard icon={<Mail />} label={t('common.email')} value={email} />
          <ContactCard icon={<Globe2 />} label={t('common.website')} value={websiteAvailable ? lead.Siteweb! : t('common.notFound')} href={safeWebsiteUrl(lead.Siteweb)} external ltr />
          <ContactCard icon={<MapPin />} label={t('common.address')} value={lead.Adresse || t('common.unavailable')} />
        </section>

        <section className="grid gap-4 lg:grid-cols-[1.35fr_0.65fr]">
          <div className="space-y-4">
            <DetailsCard title={t('lead.information')} icon={<Building2 />}>
              <InfoItem label={t('lead.name')} value={lead.Entreprise || '—'} />
              <InfoItem label={t('common.activity')} value={capitalizeFirst(lead.Activité)} />
              <InfoItem label={t('common.city')} value={city} />
              <InfoItem label={t('common.address')} value={lead.Adresse || '—'} wide />
            </DetailsCard>

            <DetailsCard title={t('lead.geography')} icon={<MapPinned />}>
              <CompanyMap lead={lead} />
            </DetailsCard>

            <Card className="border-0 bg-white shadow-sm ring-1 ring-slate-200/80">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
                  <Clock3 className="size-5 text-indigo-600" /> {t('lead.audit')}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-5">
                {auditLog.length === 0 ? (
                  <p className="rounded-2xl bg-slate-50 p-5 text-center text-sm text-slate-500">{t('lead.noAudit')}</p>
                ) : (
                  <ol className="space-y-4">
                    {auditLog.map((entry) => (
                      <li key={entry.id} className="relative flex gap-3 border-b border-slate-100 pb-4 last:border-0 last:pb-0">
                        <span className="mt-1 grid size-9 shrink-0 place-items-center rounded-xl bg-indigo-50 text-indigo-600"><Workflow className="size-4" /></span>
                        <div className="min-w-0 flex-1">
                          <p className="font-bold text-slate-900">
                            {entry.event_type === 'created'
                              ? t('lead.addedToPipeline')
                              : entry.event_type === 'stage_changed'
                                ? t('lead.stageChanged', {
                                    previous: auditStageLabel(entry.previous_stage, stages) || t('lead.pipelineStart'),
                                    next: auditStageLabel(entry.new_stage, stages) || t('lead.unknownStage'),
                                  })
                                : entry.event_type === 'owner_changed'
                                  ? t('lead.ownerChanged')
                                  : t('lead.updated')}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">
                            {entry.changed_by === viewerId ? t('lead.byYou') : entry.changed_by ? t('lead.byAuthorizedUser') : t('lead.bySystem')}
                            {' · '}
                            {formatDate(entry.changed_at, { dateStyle: 'medium', timeStyle: 'short' })}
                          </p>
                        </div>
                        <Badge variant="outline" className="h-7 shrink-0 bg-slate-50">v{entry.version}</Badge>
                      </li>
                    ))}
                  </ol>
                )}
              </CardContent>
            </Card>

          </div>

          <aside className="space-y-4">
            <Card className="border-0 bg-white shadow-sm ring-1 ring-slate-200/80">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
                  <Workflow className="size-5 text-indigo-600" /> {t('lead.commercialStage')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PipelineStageSelect stages={stages} value={lead.pipeline_stage_id} onValueChange={(value) => value && void changeStage(value)} disabled={movingStage || stages.length === 0} placeholder={t('lead.chooseStage')} label={stageLabel} className="h-11 w-full" />
                <p className="mt-3 text-xs leading-5 text-slate-500">{t('lead.stageHistoryHint')}</p>
              </CardContent>
            </Card>
            {hasCommercialValue && (
              <Card className="border-0 bg-white shadow-sm ring-1 ring-slate-200/80">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
                    <CircleDollarSign className="size-5 text-emerald-600" /> {t('lead.commercialData')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="estimated-value">{t('lead.estimatedDealAmount')}</Label>
                    <div className="relative">
                      <Input
                        key={`estimated-${lead.pipeline_version}-${lead.estimated_value}`}
                        id="estimated-value"
                        type="number"
                        min={0}
                        step={100}
                        defaultValue={lead.estimated_value || ''}
                        disabled={savingCommercialData}
                        className="pe-16"
                        onBlur={(event) => void saveCommercialData({ estimated_value: event.target.value === '' ? 0 : Number(event.target.value) })}
                      />
                      <span className="pointer-events-none absolute inset-y-0 end-3 flex items-center text-xs font-bold text-slate-400">MAD</span>
                    </div>
                  </div>
                  {currentStage?.slug === 'won' && (
                    <div className="space-y-2">
                      <Label htmlFor="final-value">{t('lead.finalDealAmount')}</Label>
                      <div className="relative">
                        <Input
                          key={`final-${lead.pipeline_version}-${lead.final_deal_amount}`}
                          id="final-value"
                          type="number"
                          min={0}
                          step={100}
                          defaultValue={lead.final_deal_amount ?? ''}
                          disabled={savingCommercialData}
                          className="pe-16"
                          onBlur={(event) => void saveCommercialData({ final_deal_amount: event.target.value === '' ? null : Number(event.target.value) })}
                        />
                        <span className="pointer-events-none absolute inset-y-0 end-3 flex items-center text-xs font-bold text-slate-400">MAD</span>
                      </div>
                    </div>
                  )}
                  {currentStage?.slug === 'lost' && (
                    <div className="space-y-2">
                      <Label>{t('lead.lossReason')}</Label>
                      <Select value={lead.loss_reason ?? 'unspecified'} onValueChange={(value) => void saveCommercialData({ loss_reason: value === 'unspecified' ? null : value })} disabled={savingCommercialData}>
                        <SelectTrigger><SelectValue>{t(`analytics.lossReason.${lead.loss_reason ?? 'unspecified'}`)}</SelectValue></SelectTrigger>
                        <SelectContent>
                          {['unspecified','price_too_high','not_interested','competitor_chosen','insufficient_budget','no_response','project_cancelled','bad_timing','other'].map((reason) => (
                            <SelectItem key={reason} value={reason}>{t(`analytics.lossReason.${reason}`)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <p className="text-xs leading-5 text-slate-500">{t('lead.commercialDataHint')}</p>
                </CardContent>
              </Card>
            )}
            <Card className="border-0 bg-white shadow-sm ring-1 ring-slate-200/80">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
                  <Star className="size-5 text-amber-500" /> {t('lead.qualityAndRating')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <ScoreRow label={t('search.theoreticalRating')} value={theoreticalScore} tone="indigo" />
                <ScoreRow label={t('lead.reputation')} value={leadQualityLabel(lead.LeadQuality, t)} tone={leadQualityTone(lead.LeadQuality) === 'positive' ? 'emerald' : leadQualityTone(lead.LeadQuality) === 'average' ? 'amber' : leadQualityTone(lead.LeadQuality) === 'negative' ? 'red' : 'slate'} />
                <ScoreRow label={t('lead.googleRating')} value={lead.Rating ?? '—'} tone="amber" />
                <ScoreRow label={t('lead.customerReviews')} value={lead.Reviews ?? '—'} tone="cyan" />
              </CardContent>
            </Card>

            <Alert className="border-indigo-200 bg-indigo-50 text-indigo-950">
              <MessageSquareText className="text-indigo-600" />
              <AlertDescription>
                {t('lead.liveUpdate')}
              </AlertDescription>
            </Alert>
          </aside>
        </section>
      </div>
    </main>
  );
}

function ContactCard({
  icon,
  label,
  value,
  href,
  external = false,
  ltr = false,
  actionLabel,
  tone = 'default',
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  href?: string;
  external?: boolean;
  ltr?: boolean;
  actionLabel?: string;
  tone?: 'default' | 'whatsapp' | 'phone';
}) {
  const iconTone = tone === 'whatsapp'
    ? 'bg-emerald-100 text-emerald-700'
    : tone === 'phone'
      ? 'bg-sky-100 text-sky-700'
      : 'bg-indigo-50 text-indigo-600';
  const content = (
    <>
      <span className={`grid size-11 shrink-0 place-items-center rounded-xl [&_svg]:size-5 ${iconTone}`}>{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block text-xs font-bold uppercase tracking-wide text-slate-400">{label}</span>
        <span className="mt-1 block break-words font-bold text-slate-900" dir={ltr ? 'ltr' : undefined}>{value}</span>
      </span>
      {href && (
        <span className="flex shrink-0 items-center gap-1.5">
          {actionLabel && <span className={`hidden text-xs font-bold sm:inline ${tone === 'whatsapp' ? 'text-emerald-700' : tone === 'phone' ? 'text-sky-700' : 'text-indigo-600'}`}>{actionLabel}</span>}
          <ChevronLeft className="size-4 text-slate-300 rtl:rotate-0 ltr:rotate-180" />
        </span>
      )}
    </>
  );

  const classes = 'flex min-h-24 items-center gap-3 rounded-2xl border border-slate-200/80 bg-white p-4 text-start shadow-sm transition';
  return href ? (
    <a className={`${classes} hover:-translate-y-0.5 ${tone === 'whatsapp' ? 'hover:border-emerald-300' : tone === 'phone' ? 'hover:border-sky-300' : 'hover:border-indigo-200'} hover:shadow-md`} href={href} target={external ? '_blank' : undefined} rel={external ? 'noreferrer' : undefined} aria-label={actionLabel}>
      {content}
    </a>
  ) : (
    <div className={classes}>{content}</div>
  );
}

function EmailList({ addresses }: { addresses: string[] }) {
  return (
    <span className="flex flex-col items-start gap-1.5" dir="ltr">
      {addresses.map((address) => (
        <a key={address} href={`mailto:${address}`} className="break-all text-indigo-700 transition hover:underline">
          {address}
        </a>
      ))}
    </span>
  );
}

function DetailsCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Card className="border-0 bg-white shadow-sm ring-1 ring-slate-200/80">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
          <span className="text-indigo-600 [&_svg]:size-5">{icon}</span>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="grid gap-3 p-4 sm:grid-cols-2 sm:p-5">{children}</CardContent>
    </Card>
  );
}

function InfoItem({ label, value, wide = false, mono = false }: { label: string; value: React.ReactNode; wide?: boolean; mono?: boolean }) {
  return (
    <div className={`min-w-0 rounded-xl bg-slate-50 p-3.5 ${wide ? 'sm:col-span-2' : ''}`}>
      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">{label}</p>
      <div className={`mt-1.5 break-words font-semibold text-slate-800 ${mono ? 'font-mono text-xs' : 'text-sm'}`}>{value}</div>
    </div>
  );
}

function ScoreRow({ label, value, tone }: { label: string; value: string | number; tone: 'indigo' | 'emerald' | 'amber' | 'cyan' | 'red' | 'slate' }) {
  const tones = {
    indigo: 'bg-indigo-50 text-indigo-700',
    emerald: 'bg-emerald-50 text-emerald-700',
    amber: 'bg-amber-50 text-amber-700',
    cyan: 'bg-cyan-50 text-cyan-700',
    red: 'bg-red-50 text-red-700',
    slate: 'bg-slate-100 text-slate-700',
  };
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 px-3.5 py-3">
      <span className="text-sm font-semibold text-slate-600">{label}</span>
      <span className={`rounded-lg px-2.5 py-1 text-sm font-black ${tones[tone]}`}>{value}</span>
    </div>
  );
}

function CompanyMap({ lead }: { lead: Lead }) {
  const query =
    lead.Latitude !== null && lead.Longitude !== null
      ? `${lead.Latitude},${lead.Longitude}`
      : lead.Place_id
        ? `place_id:${lead.Place_id}`
        : [lead.Entreprise, lead.Adresse, lead.City].filter(Boolean).join(', ');

  if (!query) {
    return (
      <div className="sm:col-span-2 grid min-h-44 place-items-center rounded-2xl border border-dashed border-slate-200 bg-slate-50 text-center text-sm text-slate-500">
        {t('lead.locationUnavailable')}
      </div>
    );
  }

  const encodedQuery = encodeURIComponent(query);
  return (
    <div className="sm:col-span-2 overflow-hidden rounded-2xl border border-slate-200 bg-slate-100">
      <iframe
        title={`${t('lead.clientLocation')}: ${lead.Entreprise || t('common.client')}`}
        src={`https://www.google.com/maps?q=${encodedQuery}&z=16&output=embed`}
        className="h-72 w-full border-0 sm:h-80"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        allowFullScreen
      />
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-white p-3.5">
        <div>
          <p className="font-bold text-slate-900">{t('lead.clientLocation')}</p>
          <p className="text-xs text-slate-500">{lead.Adresse || capitalizeFirst(lead.City)}</p>
        </div>
        <a
          className="inline-flex min-h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white transition hover:bg-indigo-700"
          href={`https://www.google.com/maps/search/?api=1&query=${encodedQuery}`}
          target="_blank"
          rel="noreferrer"
        >
          <MapPinned className="size-4" />
          {t('lead.openGoogleMaps')}
        </a>
      </div>
    </div>
  );
}
