'use client';
import { safeWebsiteUrl } from '@/lib/safe-url';

import { useEffect, useMemo, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  ArrowRight,
  BarChart3,
  Building2,
  CircleAlert,
  FileSpreadsheet,
  Globe2,
  Mail,
  MapPin,
  Phone,
  RotateCcw,
  Search,
  SlidersHorizontal,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { Lead, PipelineStage, SearchRecord } from '@/lib/database.types';
import { supabase } from '@/lib/supabase';
import { LanguageSwitcher } from '@/components/language-switcher';
import { PipelineStageSelect } from '@/components/pipeline-stage-status';
import { formatDate, t, useI18n } from '@/lib/i18n';
import { leadQualityLabel, leadQualityTone } from '@/lib/lead-quality';
import { ResultsLoadingIndicator } from '@/components/async-status';
import { ProspectEmailCell, ProspectNameHover } from '@/components/prospect-hover-card';
import { exportLeadsToExcel } from '@/lib/lead-export';

function available(value?: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(
    normalized &&
      !['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined'].includes(normalized),
  );
}

function capitalizeFirst(value?: string | null) {
  const text = value?.trim();
  if (!text) return '—';
  return `${text.charAt(0).toLocaleUpperCase()}${text.slice(1)}`;
}

function compactLeadName(value?: string | null) {
  const fullName = value?.trim() || t('common.clientUnnamed');
  const words = fullName
    .split(/\s+/)
    .filter((word) => word.replace(/[-–—|,;:/]+/g, '').length > 0);
  return words.length > 7 ? `${words.slice(0, 7).join(' ')}…` : fullName;
}

function cityLabel(lead: Lead, fallback?: string | null) {
  const city = lead.City?.trim();
  const normalized = city?.toLocaleLowerCase().replace(/[\s./_-]/g, '');
  if (normalized && !['nr', 'na', 'notfound', 'unknown', 'inconnu', 'غيرمعروف'].includes(normalized)) {
    return capitalizeFirst(city);
  }
  return capitalizeFirst(fallback);
}

function qualityBadgeClass(value?: string | null) {
  const tone = leadQualityTone(value);
  if (tone === 'positive') {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  }
  if (tone === 'average') {
    return 'border-amber-200 bg-amber-50 text-amber-700';
  }
  if (tone === 'negative') {
    return 'border-red-200 bg-red-50 text-red-700';
  }
  return 'border-slate-200 bg-slate-50 text-slate-700';
}

function upsertLead(current: Lead[], incoming: Lead) {
  const existing = current.find((lead) => lead.id === incoming.id);
  if (existing && existing.pipeline_version > incoming.pipeline_version) return current;
  return existing
    ? current.map((lead) => (lead.id === incoming.id ? incoming : lead))
    : [...current, incoming].sort((a, b) => (b.LeadScore ?? 0) - (a.LeadScore ?? 0));
}

function statusLabel(search: SearchRecord, actualLeadCount: number) {
  const status = search.Status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
  if (['failed', 'error', 'échec', 'echec'].includes(status ?? '')) return t('status.failed');
  const requested = search['Nombre de clients'] ?? 0;
  const collected = Math.max(search['Total de Clients'] ?? 0, actualLeadCount);
  if (
    ['completed', 'complete', 'success', 'successful', 'done', 'terminé', 'termine'].includes(status ?? '') ||
    (requested > 0 && collected >= requested)
  ) return t('status.completed');
  return t('status.processing');
}

function Metric({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone: string }) {
  return (
    <Card className="border-0 bg-white shadow-[0_12px_38px_rgba(15,23,42,0.06)] ring-0">
      <CardContent className="flex items-center justify-between gap-3 p-4 sm:p-5">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-1 text-2xl font-black tabular-nums text-slate-950">{value}</p>
        </div>
        <span className={`grid size-11 place-items-center rounded-2xl ${tone}`}>{icon}</span>
      </CardContent>
    </Card>
  );
}

export default function SearchResultsPage() {
  const { direction } = useI18n();
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const rawId = Array.isArray(params.id) ? params.id[0] : params.id;
  const searchId = Number(rawId);
  const [searchRecord, setSearchRecord] = useState<SearchRecord | null>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stages, setStages] = useState<PipelineStage[]>([]);
  const [userId, setUserId] = useState('');
  const [busyLeadIds, setBusyLeadIds] = useState<Set<string>>(new Set());
  const [stageError, setStageError] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [availability, setAvailability] = useState('all');
  const [quality, setQuality] = useState('all');
  const [stageFilter, setStageFilter] = useState('all');
  const [scoreFilter, setScoreFilter] = useState('all');
  const [sortBy, setSortBy] = useState('score-desc');

  useEffect(() => {
    let cancelled = false;

    async function loadResults() {
      if (!Number.isInteger(searchId) || searchId <= 0) {
        setError(t('errors.invalidSearchId'));
        setLoading(false);
        return;
      }

      const { data: authData } = await supabase.auth.getUser();
      if (!authData.user) {
        router.replace('/');
        return;
      }
      setUserId(authData.user.id);

      const [searchResult, leadsResult, stagesResult] = await Promise.all([
        supabase.from('Searches').select('*').eq('id', searchId).eq('User_id', authData.user.id).maybeSingle(),
        supabase.from('Leads').select('*').eq('Search_id', searchId).eq('User_id', authData.user.id).order('LeadScore', { ascending: false }),
        supabase.from('Pipeline_Stages').select('*').eq('user_id', authData.user.id).order('position', { ascending: true }),
      ]);

      if (cancelled) return;
      if (searchResult.error || leadsResult.error || stagesResult.error) {
        setError(searchResult.error?.message || leadsResult.error?.message || stagesResult.error?.message || t('errors.loadResults'));
      } else if (!searchResult.data) {
        setError(t('errors.searchNotFound'));
      } else {
        setSearchRecord(searchResult.data);
        setLeads(leadsResult.data ?? []);
        setStages(stagesResult.data ?? []);
      }
      setLoading(false);
    }

    void loadResults();
    return () => {
      cancelled = true;
    };
  }, [router, searchId]);

  useEffect(() => {
    if (!Number.isInteger(searchId) || searchId <= 0) return;
    const channel = supabase
      .channel(`search-results-${searchId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'Leads', filter: `Search_id=eq.${searchId}` },
        (payload) => {
          const nextLead = payload.new as Lead;
          setLeads((current) => upsertLead(current, nextLead));
        },
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'Leads', filter: `Search_id=eq.${searchId}` },
        (payload) => setLeads((current) => upsertLead(current, payload.new as Lead)),
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'Searches', filter: `id=eq.${searchId}` },
        (payload) => setSearchRecord(payload.new as SearchRecord),
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [searchId]);

  const qualities = useMemo(
    () => [...new Set(leads.map((lead) => lead.LeadQuality?.trim()).filter((value): value is string => Boolean(value)))].sort(),
    [leads],
  );
  const filteredLeads = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    const matchingLeads = leads.filter((lead) => {
      const hasPhone = available(lead.Telephone);
      const hasWebsite = available(lead.Siteweb);
      const hasEmail = available(lead.Email);
      const matchesAvailability =
        availability === 'all' ||
        (availability === 'phone' && hasPhone) ||
        (availability === 'website' && hasWebsite) ||
        (availability === 'email' && hasEmail) ||
        (availability === 'complete' && hasPhone && hasWebsite && hasEmail) ||
        (availability === 'missing' && (!hasPhone || !hasWebsite || !hasEmail));
      const score = lead.LeadScore;
      const matchesScore =
        scoreFilter === 'all' ||
        (scoreFilter === '80-plus' && score !== null && score >= 80) ||
        (scoreFilter === '60-79' && score !== null && score >= 60 && score < 80) ||
        (scoreFilter === '40-59' && score !== null && score >= 40 && score < 60) ||
        (scoreFilter === 'under-40' && score !== null && score < 40) ||
        (scoreFilter === 'unrated' && score === null);
      const matchesStage =
        stageFilter === 'all' ||
        (stageFilter === 'unassigned' && !lead.pipeline_stage_id) ||
        lead.pipeline_stage_id === stageFilter;
      const haystack = [lead.Entreprise, lead.Activité, cityLabel(lead, searchRecord?.Ville), lead.Adresse, lead.Telephone, lead.Email]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase();
      return matchesAvailability && matchesScore && matchesStage && (quality === 'all' || lead.LeadQuality?.trim() === quality) && (!needle || haystack.includes(needle));
    });
    return [...matchingLeads].sort((a, b) => {
      if (sortBy === 'score-asc') return (a.LeadScore ?? -1) - (b.LeadScore ?? -1);
      if (sortBy === 'name-asc') return (a.Entreprise ?? '').localeCompare(b.Entreprise ?? '');
      if (sortBy === 'name-desc') return (b.Entreprise ?? '').localeCompare(a.Entreprise ?? '');
      return (b.LeadScore ?? -1) - (a.LeadScore ?? -1);
    });
  }, [availability, leads, quality, query, scoreFilter, searchRecord?.Ville, sortBy, stageFilter]);

  const phones = leads.filter((lead) => available(lead.Telephone)).length;
  const emails = leads.filter((lead) => available(lead.Email)).length;
  const averageScore = leads.length
    ? Math.round(leads.reduce((total, lead) => total + (lead.LeadScore ?? 0), 0) / leads.length)
    : 0;
  const activeFilterCount =
    Number(Boolean(query.trim())) +
    Number(availability !== 'all') +
    Number(quality !== 'all') +
    Number(stageFilter !== 'all') +
    Number(scoreFilter !== 'all') +
    Number(sortBy !== 'score-desc');
  const hasFilters = activeFilterCount > 0;

  const stageLabel = (stage: PipelineStage) => {
    const key = `pipeline.stage.${stage.slug}`;
    const translated = t(key);
    return translated === key ? stage.name : translated;
  };

  const availabilityLabels: Record<string, string> = {
    all: t('search.allContactData'),
    phone: t('search.phoneAvailable'),
    website: t('search.websiteAvailable'),
    email: t('search.emailAvailable'),
    complete: t('search.allContactAvailable'),
    missing: t('search.incompleteData'),
  };
  const scoreLabels: Record<string, string> = {
    all: t('search.allScores'),
    '80-plus': t('search.score80Plus'),
    '60-79': t('search.score60To79'),
    '40-59': t('search.score40To59'),
    'under-40': t('search.scoreUnder40'),
    unrated: t('search.scoreUnavailable'),
  };
  const sortLabels: Record<string, string> = {
    'score-desc': t('search.sortScoreDesc'),
    'score-asc': t('search.sortScoreAsc'),
    'name-asc': t('search.sortNameAsc'),
    'name-desc': t('search.sortNameDesc'),
  };
  const selectedStageLabel = stageFilter === 'all'
    ? t('search.allStages')
    : stageFilter === 'unassigned'
      ? t('search.unassignedStage')
      : stages.find((stage) => stage.id === stageFilter)
        ? stageLabel(stages.find((stage) => stage.id === stageFilter)!)
        : t('search.allStages');

  async function changeStage(leadId: string, newStageId: string) {
    const snapshot = leads.find((lead) => lead.id === leadId);
    if (!snapshot || !userId || snapshot.pipeline_stage_id === newStageId || busyLeadIds.has(leadId)) return;

    setStageError('');
    setBusyLeadIds((current) => new Set(current).add(leadId));
    setLeads((current) => current.map((lead) => lead.id === leadId ? {
      ...lead,
      pipeline_stage_id: newStageId,
      pipeline_version: lead.pipeline_version + 1,
      pipeline_updated_at: new Date().toISOString(),
      pipeline_updated_by: userId,
    } : lead));

    const { data, error: updateError } = await supabase
      .from('Leads')
      .update({ pipeline_stage_id: newStageId })
      .eq('id', leadId)
      .eq('Search_id', searchId)
      .eq('User_id', userId)
      .eq('pipeline_version', snapshot.pipeline_version)
      .select('*')
      .maybeSingle();

    if (updateError || !data) {
      const { data: freshLead } = await supabase
        .from('Leads')
        .select('*')
        .eq('id', leadId)
        .eq('User_id', userId)
        .maybeSingle();
      setLeads((current) => freshLead ? upsertLead(current, freshLead) : current.map((lead) => lead.id === leadId ? snapshot : lead));
      setStageError(updateError?.message || t('errors.concurrentLeadUpdate'));
    } else {
      setLeads((current) => upsertLead(current, data));
    }

    setBusyLeadIds((current) => {
      const next = new Set(current);
      next.delete(leadId);
      return next;
    });
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.11),transparent_32%),linear-gradient(180deg,#f8fafc_0%,#f0fdf4_100%)] text-slate-950" dir={direction}>
      <header className="border-b border-slate-200/80 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-4 py-4 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <Button variant="outline" size="icon" aria-label={t('common.backToDashboard')} onClick={() => router.push('/')}>
              <ArrowRight className="rtl:rotate-0 ltr:rotate-180" />
            </Button>
            <div className="min-w-0">
              <p className="text-xs font-bold text-indigo-600">LEADBOYACH</p>
              <h1 className="truncate text-xl font-black sm:text-2xl">{t('search.operationResults')}</h1>
            </div>
          </div>
          {searchRecord && <Badge variant="outline" className="border-indigo-200 bg-indigo-50 px-3 text-indigo-700">{statusLabel(searchRecord, leads.length)}</Badge>}
        </div>
      </header>

      <div className="mx-auto max-w-[1500px] space-y-5 p-4 sm:p-8">
        {loading ? (
          <div className="space-y-5"><Skeleton className="h-44 rounded-3xl" /><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[1, 2, 3, 4].map((item) => <Skeleton key={item} className="h-28 rounded-3xl" />)}</div><Skeleton className="h-96 rounded-3xl" /></div>
        ) : error ? (
          <Card className="mx-auto mt-16 max-w-2xl border-0 shadow-xl ring-0">
            <CardContent className="p-8 text-center">
              <CircleAlert className="mx-auto size-12 text-red-500" />
              <h2 className="mt-4 text-xl font-black">{t('search.openFailed')}</h2>
              <p className="mt-2 text-slate-500">{error}</p>
              <Button className="mt-6" onClick={() => router.push('/')}>{t('common.backToDashboard')}</Button>
            </CardContent>
          </Card>
        ) : searchRecord ? (
          <>
            <Card className="overflow-hidden border-0 bg-[#032e25] text-white shadow-[0_20px_60px_rgba(2,44,34,0.18)] ring-0">
              <CardContent className="flex flex-col justify-between gap-6 p-6 sm:p-8 lg:flex-row lg:items-end">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-sm text-indigo-200"><Badge className="bg-white/10 text-white hover:bg-white/10">{t('search.searchNumber', { id: searchRecord.id })}</Badge><span>{formatDate(searchRecord.Created_at, { dateStyle: 'long', timeStyle: 'short' })}</span></div>
                  <h2 className="mt-4 text-3xl font-black sm:text-4xl">{capitalizeFirst(searchRecord.Activité)}</h2>
                  <p className="mt-3 flex items-center gap-2 text-slate-300"><MapPin className="size-4 text-indigo-300" />{[capitalizeFirst(searchRecord.Ville), capitalizeFirst(searchRecord.Pays)].filter((value) => value !== '—').join('، ')}</p>
                </div>
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="rounded-2xl bg-white/[0.07] px-5 py-3 ring-1 ring-white/10"><p className="text-xs text-slate-400">{t('search.requestedCount')}</p><p className="mt-1 text-2xl font-black">{searchRecord['Nombre de clients'] ?? 0}</p></div>
                  <div className="rounded-2xl bg-white/[0.07] px-5 py-3 ring-1 ring-white/10"><p className="text-xs text-slate-400">{t('search.extractedCount')}</p><p className="mt-1 text-2xl font-black">{leads.length}</p></div>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Metric icon={<Building2 className="size-5" />} label={t('search.totalClients')} value={String(leads.length)} tone="bg-indigo-50 text-indigo-600" />
              <Metric icon={<Phone className="size-5" />} label={t('metrics.phones')} value={String(phones)} tone="bg-emerald-50 text-emerald-600" />
              <Metric icon={<Mail className="size-5" />} label={t('search.availableEmail')} value={String(emails)} tone="bg-cyan-50 text-cyan-600" />
              <Metric icon={<BarChart3 className="size-5" />} label={t('search.averageScore')} value={`${averageScore}/100`} tone="bg-amber-50 text-amber-600" />
            </div>

            <Card className="border-0 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] ring-0">
              <CardHeader className="border-b border-slate-100">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div><CardTitle className="text-lg font-black">{t('search.extractedClients')}</CardTitle><p className="mt-1 text-sm text-slate-500">{t('search.openClientHint')}</p></div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={filteredLeads.length === 0}
                      className="bg-white"
                      onClick={() => exportLeadsToExcel(filteredLeads, {
                        title: t('export.searchTitle', { activity: searchRecord.Activité || t('common.clients') }),
                        city: searchRecord.Ville,
                        country: searchRecord.Pays,
                      })}
                    >
                      <FileSpreadsheet className="size-4 text-emerald-600" />
                      {t('export.downloadProspects')}
                    </Button>
                    <Badge variant="outline" className="bg-slate-50 px-3">{t('search.resultCount', { visible: filteredLeads.length, total: leads.length })}</Badge>
                    <LanguageSwitcher />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-0">
                {leads.length === 0 ? (
                  <Empty className="min-h-72"><EmptyHeader><EmptyMedia variant="icon"><Building2 /></EmptyMedia><EmptyTitle>{t('search.noClientsYet')}</EmptyTitle>{statusLabel(searchRecord, leads.length) === t('status.processing') && <ResultsLoadingIndicator />}<EmptyDescription>{t('search.clientsWillAppear')}</EmptyDescription></EmptyHeader></Empty>
                ) : (
                  <>
                    <div className="border-b border-slate-100 bg-slate-50/70 p-4 sm:p-6">
                      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-200"><SlidersHorizontal className="size-5" /></span><div><h3 className="font-black">{t('search.filters')}</h3><p className="text-sm text-slate-500">{t('search.filtersDescription')}</p></div></div>
                        <div className="flex items-center gap-2">
                          {hasFilters && <Badge variant="outline" className="border-indigo-200 bg-indigo-50 px-3 text-indigo-700">{t('search.activeFilters', { count: activeFilterCount })}</Badge>}
                          {hasFilters && <Button variant="outline" size="sm" className="bg-white" onClick={() => { setQuery(''); setAvailability('all'); setQuality('all'); setStageFilter('all'); setScoreFilter('all'); setSortBy('score-desc'); }}><RotateCcw />{t('search.clearFilters')}</Button>}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
                        <div className="grid gap-x-5 gap-y-4 md:grid-cols-2 xl:grid-cols-3">
                        <div className="space-y-2">
                          <Label htmlFor="search-result-query" className="text-sm font-bold text-slate-700">{t('search.searchResults')}</Label>
                          <div className="relative"><Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><Input id="search-result-query" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('search.nameActivityCityContact')} className="h-11 border-slate-200 bg-slate-50/70 ps-9 shadow-none transition focus:bg-white" /></div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm font-bold text-slate-700">{t('search.contactAvailability')}</Label>
                          <Select value={availability} onValueChange={setAvailability}><SelectTrigger className="h-11 w-full border-slate-200 bg-slate-50/70 shadow-none transition hover:bg-white"><SelectValue>{availabilityLabels[availability] ?? t('search.allContactData')}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('search.allContactData')}</SelectItem><SelectItem value="phone">{t('search.phoneAvailable')}</SelectItem><SelectItem value="website">{t('search.websiteAvailable')}</SelectItem><SelectItem value="email">{t('search.emailAvailable')}</SelectItem><SelectItem value="complete">{t('search.allContactAvailable')}</SelectItem><SelectItem value="missing">{t('search.incompleteData')}</SelectItem></SelectContent></Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm font-bold text-slate-700">{t('lead.commercialStage')}</Label>
                          <Select value={stageFilter} onValueChange={setStageFilter}><SelectTrigger className="h-11 w-full border-slate-200 bg-slate-50/70 shadow-none transition hover:bg-white"><SelectValue>{selectedStageLabel}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('search.allStages')}</SelectItem><SelectItem value="unassigned">{t('search.unassignedStage')}</SelectItem>{stages.map((stage) => <SelectItem key={stage.id} value={stage.id}>{stageLabel(stage)}</SelectItem>)}</SelectContent></Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm font-bold text-slate-700">{t('search.clientReputation')}</Label>
                          <Select value={quality} onValueChange={setQuality}><SelectTrigger className="h-11 w-full border-slate-200 bg-slate-50/70 shadow-none transition hover:bg-white"><SelectValue>{quality === 'all' ? t('search.allReputationLevels') : leadQualityLabel(quality, t)}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('search.allReputationLevels')}</SelectItem>{qualities.map((item) => <SelectItem key={item} value={item}>{leadQualityLabel(item, t)}</SelectItem>)}</SelectContent></Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm font-bold text-slate-700">{t('search.theoreticalRating')}</Label>
                          <Select value={scoreFilter} onValueChange={setScoreFilter}><SelectTrigger className="h-11 w-full border-slate-200 bg-slate-50/70 shadow-none transition hover:bg-white"><SelectValue>{scoreLabels[scoreFilter] ?? t('search.allScores')}</SelectValue></SelectTrigger><SelectContent><SelectItem value="all">{t('search.allScores')}</SelectItem><SelectItem value="80-plus">{t('search.score80Plus')}</SelectItem><SelectItem value="60-79">{t('search.score60To79')}</SelectItem><SelectItem value="40-59">{t('search.score40To59')}</SelectItem><SelectItem value="under-40">{t('search.scoreUnder40')}</SelectItem><SelectItem value="unrated">{t('search.scoreUnavailable')}</SelectItem></SelectContent></Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm font-bold text-slate-700">{t('search.sortBy')}</Label>
                          <Select value={sortBy} onValueChange={setSortBy}><SelectTrigger className="h-11 w-full border-slate-200 bg-slate-50/70 shadow-none transition hover:bg-white"><SelectValue>{sortLabels[sortBy] ?? t('search.sortScoreDesc')}</SelectValue></SelectTrigger><SelectContent><SelectItem value="score-desc">{t('search.sortScoreDesc')}</SelectItem><SelectItem value="score-asc">{t('search.sortScoreAsc')}</SelectItem><SelectItem value="name-asc">{t('search.sortNameAsc')}</SelectItem><SelectItem value="name-desc">{t('search.sortNameDesc')}</SelectItem></SelectContent></Select>
                        </div>
                        </div>
                      </div>
                      {stageError && <p role="alert" className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{stageError}</p>}
                    </div>
                      <Table className="min-w-[1180px] table-fixed xl:min-w-0">
                        <colgroup>
                          <col className="w-[23%]" />
                          <col className="w-[6%]" />
                          <col className="w-[8%]" />
                          <col className="w-[12%]" />
                          <col className="w-[6%]" />
                          <col className="w-[10%]" />
                          <col className="w-[7%]" />
                          <col className="w-[15%]" />
                          <col className="w-[13%]" />
                        </colgroup>
                        <TableHeader><TableRow className="bg-slate-50/80 hover:bg-slate-50/80"><TableHead className="px-5 text-start">{t('search.clientName')}</TableHead><TableHead className="text-start">{t('search.theoreticalRating')}</TableHead><TableHead className="text-start">{t('search.clientReputation')}</TableHead><TableHead className="text-start">{t('common.activity')}</TableHead><TableHead className="text-start">{t('common.city')}</TableHead><TableHead className="text-start">{t('common.phone')}</TableHead><TableHead className="text-start">{t('common.website')}</TableHead><TableHead className="text-start">{t('common.email')}</TableHead><TableHead className="px-5 text-start">{t('lead.commercialStage')}</TableHead></TableRow></TableHeader>
                        <TableBody>
                          {filteredLeads.length === 0 ? <TableRow><TableCell colSpan={9} className="h-28 text-center text-slate-500">{t('search.noFilterMatches')}</TableCell></TableRow> : filteredLeads.map((lead) => (
                            <TableRow key={lead.id} role="button" tabIndex={0} className="group h-16 cursor-pointer outline-none hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500" onClick={() => router.push(`/leads/${encodeURIComponent(lead.id)}`)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); router.push(`/leads/${encodeURIComponent(lead.id)}`); } }}>
                              <TableCell className="min-w-0 overflow-hidden px-5 text-sm font-bold leading-5"><ProspectNameHover lead={lead} fallbackCity={searchRecord.Ville}><span title={lead.Entreprise || t('common.clientUnnamed')} className="block truncate transition group-hover:text-indigo-600">{compactLeadName(lead.Entreprise)}</span></ProspectNameHover></TableCell>
                              <TableCell className="whitespace-nowrap font-black">{lead.LeadScore !== null ? `${lead.LeadScore}/100` : '—'}</TableCell>
                              <TableCell><Badge variant="outline" className={qualityBadgeClass(lead.LeadQuality)}>{leadQualityLabel(lead.LeadQuality, t)}</Badge></TableCell>
                              <TableCell className="overflow-hidden text-ellipsis" title={lead.Activité || undefined}>{capitalizeFirst(lead.Activité)}</TableCell>
                              <TableCell className="overflow-hidden text-ellipsis text-slate-500" title={cityLabel(lead, searchRecord.Ville)}>{cityLabel(lead, searchRecord.Ville)}</TableCell>
                              <TableCell dir="ltr">{available(lead.Telephone) ? <a href={`tel:${lead.Telephone}`} className="font-semibold hover:text-indigo-600" onClick={(event) => event.stopPropagation()}>{lead.Telephone}</a> : '—'}</TableCell>
                              <TableCell>{available(lead.Siteweb) ? <a href={safeWebsiteUrl(lead.Siteweb)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-indigo-600" onClick={(event) => event.stopPropagation()}><Globe2 className="size-3.5" />{t('common.clickHere')}</a> : <span className="text-slate-400">{t('common.notFound')}</span>}</TableCell>
                              <TableCell><ProspectEmailCell lead={lead} /></TableCell>
                              <TableCell onClick={(event) => event.stopPropagation()} onKeyDown={(event) => event.stopPropagation()}>
                                <PipelineStageSelect stages={stages} value={lead.pipeline_stage_id} onValueChange={(value) => value && void changeStage(lead.id, value)} disabled={busyLeadIds.has(lead.id)} placeholder={t('lead.chooseStage')} label={stageLabel} className="h-9 w-full min-w-0 text-xs" />
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                  </>
                )}
              </CardContent>
            </Card>
          </>
        ) : null}
      </div>
    </main>
  );
}
