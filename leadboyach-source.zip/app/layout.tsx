import type { Metadata } from 'next';
import { I18nProvider } from '@/lib/i18n';
import './globals.css';

export const metadata: Metadata = {
  title: 'LEADBOYACH — Trouvez, enrichissez et développez vos prospects',
  description: 'Plateforme multilingue de prospection locale, enrichissement de contacts, pipeline commercial et analyse des ventes.',
  icons: {
    icon: '/leadboyach-logo.png',
    apple: '/leadboyach-logo.png',
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr" dir="ltr" suppressHydrationWarning>
      <body><I18nProvider>{children}</I18nProvider></body>
    </html>
  );
}
