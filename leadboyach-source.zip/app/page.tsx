'use client';
import { safeWebsiteUrl } from '@/lib/safe-url';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode, SyntheticEvent } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import {
  BarChart3,
  ArrowRight,
  Building2,
  Columns3,
  CheckCircle2,
  ChevronLeft,
  CircleUserRound,
  Crown,
  FileSpreadsheet,
  History,
  LayoutDashboard,
  LogOut,
  Mail,
  MapPin,
  MapPinned,
  Phone,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  RotateCcw,
  Trash2,
  UserPlus,
  Users,
  UsersRound,
  XCircle,
} from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Spinner } from '@/components/ui/spinner';
import { Progress } from '@/components/ui/progress';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PipelineBoard } from '@/components/pipeline-board';
import { AllProspects } from '@/components/all-prospects';
import { SalesAnalytics } from '@/components/sales-analytics';
import { LanguageSwitcher } from '@/components/language-switcher';
import { AdminTeams } from '@/components/admin-teams';
import { TeamMonitor } from '@/components/team-monitor';
import { EmailLookupIndicator, ResultsLoadingIndicator } from '@/components/async-status';
import type {
  AdminUserOverview,
  AppSettings,
  Lead,
  PlanDefinition,
  PlanUpgradeRequest,
  SearchRecord,
  UserPlan,
} from '@/lib/database.types';
import { supabase } from '@/lib/supabase';
import { formatDate, formatNumber as formatLocalizedNumber, getLanguage, t, useI18n } from '@/lib/i18n';
import { exportLeadsToExcel } from '@/lib/lead-export';
import { leadQualityLabel, leadQualityTone } from '@/lib/lead-quality';
import { ProspectEmailCell, ProspectNameHover } from '@/components/prospect-hover-card';
import { LandingPage } from '@/components/landing-page';
import { ChayobLogo } from '@/components/chayob-logo';

type View = 'search' | 'prospects' | 'pipeline' | 'analytics' | 'history' | 'plans' | 'team' | 'admin';
type AdminSection = 'dashboard' | 'users' | 'teams' | 'subscriptions' | 'usage' | 'searches' | 'leads' | 'settings';
type SearchInput = {
  activity: string;
  city: string;
  country: string;
  count: number;
};
type AccountLeadStats = {
  total: number;
  phones: number;
  emails: number;
  averageScore: number;
};

function isLeadValueAvailable(value: string | null) {
  const normalized = value?.trim().toLocaleLowerCase();
  return Boolean(
    normalized &&
      !['not found', 'not_found', 'notfound', 'n/a', 'null', 'undefined'].includes(normalized),
  );
}

function formText(form: FormData, name: string, fallback = '') {
  const value = form.get(name);
  return typeof value === 'string' ? value : fallback;
}

function compactLeadName(value?: string | null) {
  const fullName = value?.trim() || t('common.clientUnnamed');
  const words = fullName
    .split(/\s+/)
    .filter((word) => word.replace(/[-–—|,;:/]+/g, '').length > 0);
  return words.length > 7 ? `${words.slice(0, 7).join(' ')}…` : fullName;
}

function getLeadEmailLabel(lead: Lead) {
  if (isLeadValueAvailable(lead.Email)) return lead.Email;
  const status = lead.Email_status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
  if (status === 'not found' || Boolean(lead.Email?.trim())) return t('common.unavailable');
  return t('common.searching');
}

function LeadEmailValue({ lead }: { lead: Lead }) {
  const label = getLeadEmailLabel(lead);
  return label === t('common.searching') ? <EmailLookupIndicator /> : label;
}

function capitalizeFirst(value?: string | null) {
  const text = value?.trim();
  if (!text) return '—';
  return `${text.charAt(0).toLocaleUpperCase()}${text.slice(1)}`;
}

function planDisplayName(planId?: string | null, fallback?: string | null) {
  if (!planId) return fallback || '—';
  const key = `plans.${planId}`;
  const translated = t(key);
  return translated === key ? fallback || planId : translated;
}

function getLeadCityLabel(lead: Lead, fallbackCity?: string | null) {
  const city = lead.City?.trim();
  const normalized = city?.toLocaleLowerCase().replace(/[\s./_-]/g, '');
  const invalidValues = new Set(['nr', 'na', 'notfound', 'unknown', 'inconnu', 'غيرمعروف']);
  if (normalized && !invalidValues.has(normalized)) return capitalizeFirst(city);
  return capitalizeFirst(fallbackCity);
}

function isSuccessfulSearch(search: SearchRecord) {
  const status = search.Status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
  const requested = search['Nombre de clients'] ?? 0;
  const collected = search['Total de Clients'] ?? 0;
  return (
    ['completed', 'complete', 'success', 'successful', 'done', 'terminé', 'termine'].includes(
      status ?? '',
    ) ||
    (requested > 0 && collected >= requested)
  );
}

function getSearchStatusLabel(search: SearchRecord) {
  if (isSuccessfulSearch(search)) return t('status.completed');
  const status = search.Status?.trim().toLocaleLowerCase();
  if (status === 'failed' || status === 'error') return t('status.failed');
  return t('status.processing');
}

export default function Home() {
  useI18n();
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | null>(null);

  useEffect(() => {
    const requestedMode = new URLSearchParams(window.location.search).get('auth');
    if (requestedMode === 'login' || requestedMode === 'signup') {
      setAuthMode(requestedMode);
      window.history.replaceState({}, '', '/');
    }

    void supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthReady(true);
    });

    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setAuthReady(true);
    });

    return () => data.subscription.unsubscribe();
  }, []);

  if (!authReady) {
    return <AppLoading />;
  }

  if (!session) {
    if (!authMode) return <LandingPage onAuthenticate={(mode = 'signup') => setAuthMode(mode)} />;
    return <AuthScreen initialMode={authMode} onBack={() => setAuthMode(null)} />;
  }

  return <Dashboard session={session} user={session.user} />;
}

function Dashboard({ session, user }: { session: Session; user: User }) {
  const { direction } = useI18n();
  const [view, setView] = useState<View>('search');
  const [searches, setSearches] = useState<SearchRecord[]>([]);
  const [activeSearchId, setActiveSearchId] = useState<number | null>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loadingSearches, setLoadingSearches] = useState(true);
  const [loadingLeads, setLoadingLeads] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [userPlan, setUserPlan] = useState<UserPlan | null>(null);
  const [loadingPlan, setLoadingPlan] = useState(true);
  const [availablePlans, setAvailablePlans] = useState<PlanDefinition[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(true);
  const [accountLeadStats, setAccountLeadStats] = useState<AccountLeadStats>({
    total: 0,
    phones: 0,
    emails: 0,
    averageScore: 0,
  });
  const [loadingAccountLeadStats, setLoadingAccountLeadStats] = useState(true);
  const [isTeamSupervisor, setIsTeamSupervisor] = useState(false);
  const searchRequestInFlightRef = useRef(false);
  const recentSearchRequestRef = useRef<{
    signature: string;
    idempotencyKey: string;
    createdAt: number;
  } | null>(null);

  const activeSearch =
    searches.find((record) => record.id === activeSearchId) ?? searches[0] ?? null;

  const loadSearches = useCallback(async () => {
    const { data, error: queryError } = await supabase
      .from('Searches')
      .select('*')
      .order('Created_at', { ascending: false });

    if (queryError) {
      setError(queryError.message);
    } else {
      setSearches(data ?? []);
      setActiveSearchId((current) => current ?? data?.[0]?.id ?? null);
    }
    setLoadingSearches(false);
  }, []);

  const loadLeads = useCallback(async (searchId: number | null) => {
    if (!searchId) {
      setLeads([]);
      return;
    }

    setLoadingLeads(true);
    const { data, error: queryError } = await supabase
      .from('Leads')
      .select('*')
      .eq('Search_id', searchId)
      .order('LeadScore', { ascending: false });

    if (queryError) {
      setError(queryError.message);
    } else {
      setLeads(data ?? []);
    }
    setLoadingLeads(false);
  }, []);

  const loadPlan = useCallback(async () => {
    const { data, error: queryError } = await supabase
      .from('User_Plans')
      .select('*')
      .eq('User_id', user.id)
      .maybeSingle();

    if (queryError) {
      setError(queryError.message);
    } else {
      setUserPlan(data);
    }
    setLoadingPlan(false);
  }, [user.id]);

  const loadAvailablePlans = useCallback(async () => {
    const { data, error: queryError } = await supabase
      .from('Plans')
      .select('*')
      .order('Monthly_limit', { ascending: true });

    if (queryError) {
      setError(queryError.message);
    } else {
      setAvailablePlans(data ?? []);
    }
    setLoadingPlans(false);
  }, []);

  const loadAccountLeadStats = useCallback(async () => {
    const pageSize = 1000;
    let offset = 0;
    const rows: Pick<Lead, 'Email' | 'Telephone' | 'LeadScore'>[] = [];

    while (true) {
      const { data, error: queryError } = await supabase
        .from('Leads')
        .select('Email, Telephone, LeadScore')
        .eq('User_id', user.id)
        .order('id', { ascending: true })
        .range(offset, offset + pageSize - 1);

      if (queryError) {
        setError(queryError.message);
        setLoadingAccountLeadStats(false);
        return;
      }

      const page = data ?? [];
      rows.push(...page);
      if (page.length < pageSize) break;
      offset += pageSize;
    }

    const scores = rows
      .map((lead) => lead.LeadScore)
      .filter((score): score is number => score !== null);
    setAccountLeadStats({
      total: rows.length,
      phones: rows.filter((lead) => isLeadValueAvailable(lead.Telephone)).length,
      emails: rows.filter((lead) => isLeadValueAvailable(lead.Email)).length,
      averageScore: scores.length
        ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length)
        : 0,
    });
    setLoadingAccountLeadStats(false);
  }, [user.id]);

  useEffect(() => {
    void loadSearches();
  }, [loadSearches]);

  useEffect(() => {
    void loadPlan();
  }, [loadPlan]);

  useEffect(() => {
    void loadAvailablePlans();
  }, [loadAvailablePlans]);

  useEffect(() => {
    void loadAccountLeadStats();
  }, [loadAccountLeadStats]);

  useEffect(() => {
    void supabase.from('Teams').select('id', { count: 'exact', head: true }).eq('supervisor_id', user.id)
      .then(({ count }) => setIsTeamSupervisor((count ?? 0) > 0));
  }, [user.id]);

  useEffect(() => {
    void loadLeads(activeSearchId);
  }, [activeSearchId, loadLeads]);

  useEffect(() => {
    const channel = supabase
      .channel(`chayob-user-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'User_Plans',
          filter: `User_id=eq.${user.id}`,
        },
        () => void loadPlan(),
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'Searches',
          filter: `User_id=eq.${user.id}`,
        },
        () => void loadSearches(),
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'Leads',
          filter: `User_id=eq.${user.id}`,
        },
        (payload) => {
          const lead = payload.new as Lead;
          void loadAccountLeadStats();
          if (lead.Search_id === activeSearchId) {
            setLeads((current) =>
              current.some((item) => item.id === lead.id)
                ? current
                : [...current, lead].sort(
                    (a, b) => (b.LeadScore ?? 0) - (a.LeadScore ?? 0),
                  ),
            );
          }
        },
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'Leads',
          filter: `User_id=eq.${user.id}`,
        },
        (payload) => {
          const updatedLead = payload.new as Lead;
          void loadAccountLeadStats();
          if (updatedLead.Search_id === activeSearchId) {
            setLeads((current) =>
              current.map((lead) =>
                lead.id === updatedLead.id ? { ...lead, ...updatedLead } : lead,
              ),
            );
          }
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [activeSearchId, loadAccountLeadStats, loadPlan, loadSearches, user.id]);

  const startSearch = useCallback(
    async (input: SearchInput) => {
      if (searchRequestInFlightRef.current) {
        throw new Error(t('errors.searchSubmitting'));
      }

      searchRequestInFlightRef.current = true;
      setSubmitting(true);
      setError(null);
      setNotice(null);

      try {
        const signature = JSON.stringify([
          input.activity.trim().toLocaleLowerCase(),
          input.city.trim().toLocaleLowerCase(),
          input.country.trim().toLocaleLowerCase(),
          input.count,
        ]);
        const now = Date.now();
        const recentRequest = recentSearchRequestRef.current;
        const idempotencyKey =
          recentRequest &&
          recentRequest.signature === signature &&
          now - recentRequest.createdAt < 30_000
            ? recentRequest.idempotencyKey
            : crypto.randomUUID();

        recentSearchRequestRef.current = { signature, idempotencyKey, createdAt: now };
        const response = await fetch('/api/search', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
            'Idempotency-Key': idempotencyKey,
            'x-app-language': getLanguage(),
          },
          body: JSON.stringify({ ...input, idempotencyKey }),
        });
        const result = (await response.json()) as {
          error?: string;
          search?: SearchRecord;
          duplicate?: boolean;
        };

        if (!response.ok || !result.search) {
          throw new Error(result.error || t('errors.startSearch'));
        }

        setSearches((current) => [
          result.search!,
          ...current.filter((item) => item.id !== result.search!.id),
        ]);
        setActiveSearchId(result.search.id);
        setLeads([]);
        setView('search');
        setNotice(
          result.duplicate
            ? t('notices.duplicateSearch')
            : t('notices.searchStarted'),
        );
        return { searchId: result.search.id, status: result.search.Status };
      } finally {
        searchRequestInFlightRef.current = false;
        setSubmitting(false);
      }
    },
    [session.access_token],
  );

  useEffect(() => {
    const modelContext = (
      document as Document & {
        modelContext?: {
          registerTool: (
            tool: {
              name: string;
              title: string;
              description: string;
              inputSchema: object;
              annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
              execute: (input: unknown) => Promise<unknown>;
            },
            options: { signal: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;

    if (!modelContext?.registerTool) return;
    const lifecycle = new AbortController();

    void Promise.resolve(
      modelContext.registerTool(
        {
          name: 'start_lead_search',
          title: t('search.start'),
          description:
            t('search.actionDescription'),
          inputSchema: {
            type: 'object',
            properties: {
              activity: { type: 'string', minLength: 2 },
              city: { type: 'string', minLength: 2 },
              country: { type: 'string', minLength: 2 },
              count: { type: 'integer', minimum: 1, maximum: 500 },
            },
            required: ['activity', 'city', 'country', 'count'],
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false, untrustedContentHint: false },
          async execute(input) {
            const value = input as Partial<SearchInput>;
            if (
              !value.activity?.trim() ||
              !value.city?.trim() ||
              !value.country?.trim() ||
              !Number.isInteger(value.count) ||
              Number(value.count) < 1 ||
              Number(value.count) > 500
            ) {
              throw new Error(t('errors.invalidSearchData'));
            }

            return startSearch({
              activity: value.activity.trim(),
              city: value.city.trim(),
              country: value.country.trim(),
              count: Number(value.count),
            });
          },
        },
        { signal: lifecycle.signal },
      ),
    ).catch(() => undefined);

    return () => lifecycle.abort();
  }, [startSearch]);

  const monthStart = new Date();
  monthStart.setUTCDate(1);
  monthStart.setUTCHours(0, 0, 0, 0);
  const usedThisMonth = searches
    .filter((record) => new Date(record.Created_at) >= monthStart)
    .reduce((sum, record) => sum + (record['Total de Clients'] ?? 0), 0);
  const monthlyLimit = userPlan?.Monthly_limit ?? 50;
  const successfulSearches = searches.filter(isSuccessfulSearch).length;
  const currentPlanName = planDisplayName(
    userPlan?.Plan,
    availablePlans.find((plan) => plan.id === userPlan?.Plan)?.Name,
  );

  if (loadingPlan) {
    return <AppLoading />;
  }

  if (!userPlan) {
    return (
      <AccountStatusScreen
        status="missing"
        email={user.email ?? ''}
      />
    );
  }

  if (userPlan.Account_status !== 'active') {
    return (
      <AccountStatusScreen
        status={userPlan.Account_status}
        email={userPlan.Email ?? user.email ?? ''}
      />
    );
  }

  return (
    <main className="min-h-screen bg-background text-foreground" dir={direction}>
      <div className="mx-auto grid min-h-screen max-w-[1600px] lg:grid-cols-[252px_1fr]">
        <aside className="hidden border-e border-emerald-300/10 bg-[#032e25] px-5 py-6 text-white lg:flex lg:flex-col">
          <Brand />
          <nav className="mt-10 space-y-2" aria-label={t('nav.dashboard')}>
            <NavButton
              active={view === 'search'}
              icon={<LayoutDashboard />}
              onClick={() => setView('search')}
            >
              {t('nav.dashboard')}
            </NavButton>
            <NavButton
              active={view === 'prospects'}
              icon={<Building2 />}
              onClick={() => setView('prospects')}
            >
              {t('nav.prospects')}
            </NavButton>
            <NavButton
              active={view === 'pipeline'}
              icon={<Columns3 />}
              onClick={() => setView('pipeline')}
            >
              {t('nav.pipeline')}
            </NavButton>
            <NavButton
              active={view === 'analytics'}
              icon={<BarChart3 />}
              onClick={() => setView('analytics')}
            >
              {t('nav.analytics')}
            </NavButton>
            <NavButton
              active={view === 'history'}
              icon={<History />}
              onClick={() => setView('history')}
            >
              {t('nav.searches')}
            </NavButton>
            <NavButton
              active={view === 'plans'}
              icon={<Crown />}
              onClick={() => setView('plans')}
            >
              {t('nav.subscription')}
            </NavButton>
            {isTeamSupervisor && (
              <NavButton active={view === 'team'} icon={<UsersRound />} onClick={() => setView('team')}>
                {t('nav.team')}
              </NavButton>
            )}
            {userPlan.Role === 'admin' && (
              <NavButton
                active={view === 'admin'}
                icon={<Users />}
                onClick={() => setView('admin')}
              >
                {t('nav.admin')}
              </NavButton>
            )}
          </nav>

          <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-3">
            <div className="flex items-center gap-3">
              <CircleUserRound className="size-9 text-slate-300" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{user.email}</p>
                <p className="truncate text-xs text-slate-400">
                  {userPlan.Role === 'admin' ? t('account.admin') : t('account.active')}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                aria-label={t('nav.logout')}
                className="text-slate-400 hover:bg-white/10 hover:text-white"
                onClick={() => void supabase.auth.signOut()}
              >
                <LogOut />
              </Button>
            </div>
          </div>
        </aside>

        <section className="min-w-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.10),transparent_32%),linear-gradient(180deg,#f8fafc_0%,#f0fdf4_100%)]">
          <header className="flex min-h-20 items-center justify-between border-b border-slate-200/80 bg-white/75 px-5 py-4 backdrop-blur-xl sm:px-8">
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-950 sm:text-2xl">
                {view === 'search'
                  ? t('header.searchTitle')
                  : view === 'prospects'
                    ? t('header.prospectsTitle')
                  : view === 'pipeline'
                    ? t('header.pipelineTitle')
                  : view === 'analytics'
                    ? t('header.analyticsTitle')
                  : view === 'history'
                    ? t('header.historyTitle')
                  : view === 'plans'
                    ? t('header.subscriptionTitle')
                    : view === 'team'
                      ? t('header.teamTitle')
                      : t('header.adminTitle')}
              </h1>
              <p className="mt-1 text-sm text-slate-500">
                {view === 'search'
                  ? t('header.searchDescription')
                  : view === 'prospects'
                    ? t('header.prospectsDescription')
                  : view === 'pipeline'
                    ? t('header.pipelineDescription')
                  : view === 'analytics'
                    ? t('header.analyticsDescription')
                  : view === 'history'
                    ? t('header.historyDescription')
                  : view === 'plans'
                    ? t('header.subscriptionDescription')
                    : view === 'team'
                      ? t('header.teamDescription')
                      : t('header.adminDescription')}
              </p>
            </div>
            <div className="flex items-center gap-2"><LanguageSwitcher /><Badge variant="outline" className="hidden h-8 border-emerald-200 bg-emerald-50 px-3 text-emerald-700 xl:inline-flex"><span className="size-2 rounded-full bg-emerald-500" />{t('header.ready')}</Badge></div>
          </header>

          <div className="space-y-6 p-4 sm:p-8">
            {view === 'search' ? (
              <>
                <UserDashboardOverview
                  searches={searches}
                  loading={loadingSearches || loadingPlans || loadingAccountLeadStats}
                  used={usedThisMonth}
                  limit={monthlyLimit}
                  totalLeads={accountLeadStats.total}
                  successfulSearches={successfulSearches}
                  planName={currentPlanName}
                  onOpenSearch={(id) => window.location.assign(`/searches/${id}`)}
                />
                <SearchForm onSubmit={startSearch} submitting={submitting} />
                {notice && (
                  <Alert className="border-indigo-200 bg-indigo-50 text-indigo-900">
                    <Sparkles />
                    <AlertDescription>{notice}</AlertDescription>
                  </Alert>
                )}
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  <Metric
                    icon={<Building2 />}
                    label={t('metrics.clients')}
                    value={String(accountLeadStats.total)}
                    tone="indigo"
                  />
                  <Metric
                    icon={<Phone />}
                    label={t('metrics.phones')}
                    value={String(accountLeadStats.phones)}
                    tone="emerald"
                  />
                  <Metric
                    icon={<Mail />}
                    label={t('metrics.emails')}
                    value={String(accountLeadStats.emails)}
                    tone="cyan"
                  />
                  <Metric
                    icon={<BarChart3 />}
                    label={t('metrics.averageQuality')}
                    value={`${accountLeadStats.averageScore}%`}
                    tone="amber"
                  />
                </div>
                <LeadsTable
                  search={activeSearch}
                  leads={leads}
                  loading={loadingLeads}
                />
              </>
            ) : view === 'prospects' ? (
              <AllProspects userId={user.id} />
            ) : view === 'pipeline' ? (
              <PipelineBoard userId={user.id} />
            ) : view === 'analytics' ? (
              <SalesAnalytics userId={user.id} />
            ) : view === 'history' ? (
              <SearchHistory
                searches={searches}
                loading={loadingSearches}
                activeSearchId={activeSearchId}
                userId={user.id}
                onOpen={(id) => {
                  window.location.assign(`/searches/${id}`);
                }}
              />
            ) : view === 'plans' ? (
              <PlansPanel
                email={user.email ?? ''}
                userId={user.id}
                plan={userPlan}
                loading={loadingPlan || loadingSearches || loadingPlans}
                used={usedThisMonth}
                limit={monthlyLimit}
                options={availablePlans}
              />
            ) : view === 'team' ? (
              <TeamMonitor userId={user.id} />
            ) : (
              <AdminPanel
                accessToken={session.access_token}
                currentUserId={user.id}
                onPlansChanged={loadAvailablePlans}
              />
            )}
          </div>
        </section>
      </div>
    </main>
  );
}

function AccountStatusScreen({
  status,
  email,
}: {
  status: UserPlan['Account_status'] | 'missing';
  email: string;
}) {
  const { direction } = useI18n();
  const content = {
    pending: {
      title: t('account.pendingTitle'),
      description: t('account.pendingDescription'),
    },
    suspended: {
      title: t('account.suspendedTitle'),
      description: t('account.suspendedDescription'),
    },
    disabled: {
      title: t('account.disabledTitle'),
      description: t('account.disabledDescription'),
    },
    missing: {
      title: t('account.missingTitle'),
      description: t('account.missingDescription'),
    },
    active: { title: '', description: '' },
  }[status];

  return (
    <main
      dir={direction}
      className="grid min-h-screen place-items-center bg-[radial-gradient(circle_at_top_right,rgba(163,230,53,0.20),transparent_34%),linear-gradient(145deg,#032e25_0%,#064e3b_58%,#022c22_100%)] p-5"
    >
      <Card className="w-full max-w-xl border-0 p-2 text-center shadow-2xl shadow-slate-950/30">
        <CardHeader className="items-center px-6 pt-8">
          <div className="mb-2 self-end"><LanguageSwitcher /></div>
          <div className="mb-3 grid size-16 place-items-center rounded-3xl bg-amber-50 text-amber-600">
            <ShieldCheck className="size-8" />
          </div>
          <CardTitle className="text-2xl font-black text-slate-950">{content.title}</CardTitle>
          <CardDescription className="max-w-md text-sm leading-7">
            {content.description}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5 px-6 pb-8">
          <Badge variant="outline" className="border-slate-200 bg-slate-50 px-3 py-1 text-slate-600">
            {email}
          </Badge>
          <div>
            <Button variant="outline" onClick={() => void supabase.auth.signOut()}>
              <LogOut />
              {t('nav.logout')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

function adminStatusLabel(status: UserPlan['Account_status']) { return t(`status.${status}`); }

function AdminPanel({
  accessToken,
  currentUserId,
  onPlansChanged,
}: {
  accessToken: string;
  currentUserId: string;
  onPlansChanged: () => Promise<void>;
}) {
  const [adminSection, setAdminSection] = useState<AdminSection>('dashboard');
  const [users, setUsers] = useState<AdminUserOverview[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [plans, setPlans] = useState<PlanDefinition[]>([]);
  const [upgradeRequests, setUpgradeRequests] = useState<PlanUpgradeRequest[]>([]);
  const [planDrafts, setPlanDrafts] = useState<
    Record<string, Pick<PlanDefinition, 'Name' | 'Monthly_limit' | 'Description'>>
  >({});
  const [newPlan, setNewPlan] = useState({
    id: '',
    name: '',
    monthlyLimit: 100,
    description: '',
  });
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    plan: 'starter',
    status: 'active' as UserPlan['Account_status'],
    confirmEmail: true,
  });
  const [drafts, setDrafts] = useState<
    Record<string, { plan: UserPlan['Plan']; status: UserPlan['Account_status'] }>
  >({});
  const [selectedUser, setSelectedUser] = useState<AdminUserOverview | null>(null);
  const [selectedSearches, setSelectedSearches] = useState<SearchRecord[]>([]);
  const [selectedLeads, setSelectedLeads] = useState<Lead[]>([]);
  const [adminSearches, setAdminSearches] = useState<SearchRecord[]>([]);
  const [adminLeads, setAdminLeads] = useState<Lead[]>([]);
  const [inspectedLead, setInspectedLead] = useState<{ lead: Lead; fallbackCity?: string | null } | null>(null);
  const [summary, setSummary] = useState({ searches: 0, leads: 0 });
  const [userQuery, setUserQuery] = useState('');
  const [planFilter, setPlanFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [loadingResource, setLoadingResource] = useState(false);
  const [saving, setSaving] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [adminError, setAdminError] = useState<string | null>(null);

  const adminFetch = useCallback(
    (url: string, init?: RequestInit) => {
      const headers = new Headers(init?.headers);
      headers.set('Content-Type', 'application/json');
      headers.set('Authorization', `Bearer ${accessToken}`);
      headers.set('x-app-language', getLanguage());
      return fetch(url, {
        ...init,
        headers,
      });
    },
    [accessToken],
  );

  const loadAdmin = useCallback(async () => {
    setLoading(true);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin');
      const result = (await response.json()) as {
        error?: string;
        users?: AdminUserOverview[];
        settings?: AppSettings;
        plans?: PlanDefinition[];
        upgradeRequests?: PlanUpgradeRequest[];
        summary?: { searches: number; leads: number };
      };
      if (!response.ok) throw new Error(result.error || t('errors.loadAdmin'));
      const nextUsers = result.users ?? [];
      setUsers(nextUsers);
      setSettings(result.settings ?? null);
      const nextPlans = result.plans ?? [];
      setPlans(nextPlans);
      setUpgradeRequests(result.upgradeRequests ?? []);
      setSummary(result.summary ?? { searches: 0, leads: 0 });
      setPlanDrafts(
        Object.fromEntries(
          nextPlans.map((plan) => [
            plan.id,
            {
              Name: plan.Name,
              Monthly_limit: plan.Monthly_limit,
              Description: plan.Description,
            },
          ]),
        ),
      );
      setDrafts(
        Object.fromEntries(
          nextUsers.map((item) => [
            item.User_id,
            { plan: item.Plan, status: item.Account_status },
          ]),
        ),
      );
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.loadAdmin'));
    } finally {
      setLoading(false);
    }
  }, [adminFetch]);

  useEffect(() => {
    void loadAdmin();
  }, [loadAdmin]);

  const loadResource = useCallback(async (resource: 'searches' | 'leads') => {
    setLoadingResource(true);
    setAdminError(null);
    try {
      const response = await adminFetch(`/api/admin?resource=${resource}`);
      const result = (await response.json()) as {
        error?: string;
        searches?: SearchRecord[];
        leads?: Lead[];
      };
      if (!response.ok) throw new Error(result.error || t('errors.loadAdminData'));
      if (result.searches) setAdminSearches(result.searches);
      if (resource === 'leads') setAdminLeads(result.leads ?? []);
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.loadAdminData'));
    } finally {
      setLoadingResource(false);
    }
  }, [adminFetch]);

  useEffect(() => {
    if (adminSection === 'searches' && adminSearches.length === 0) void loadResource('searches');
    if (adminSection === 'leads' && adminLeads.length === 0) void loadResource('leads');
  }, [adminLeads.length, adminSearches.length, adminSection, loadResource]);

  async function saveSettings() {
    if (!settings) return;
    setSaving('settings');
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'PATCH',
        body: JSON.stringify({
          type: 'settings',
          activationMode: settings.Activation_mode,
          defaultPlan: 'starter',
        }),
      });
      const result = (await response.json()) as { error?: string; settings?: AppSettings };
      if (!response.ok) throw new Error(result.error || t('errors.saveSettings'));
      if (result.settings) setSettings(result.settings);
      setMessage(t('notices.settingsSaved'));
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.saveSettings'));
    } finally {
      setSaving(null);
    }
  }

  async function savePlan(plan: PlanDefinition) {
    const draft = planDrafts[plan.id];
    if (!draft) return;
    setSaving(`plan:${plan.id}`);
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'PATCH',
        body: JSON.stringify({
          type: 'plan',
          planId: plan.id,
          name: draft.Name,
          monthlyLimit: draft.Monthly_limit,
          description: draft.Description,
        }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.updatePlan'));
      setMessage(t('notices.planUpdated', { name: draft.Name }));
      await Promise.all([loadAdmin(), onPlansChanged()]);
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.updatePlan'));
    } finally {
      setSaving(null);
    }
  }

  async function createPlan(event: SyntheticEvent<HTMLFormElement, SubmitEvent>) {
    event.preventDefault();
    setSaving('new-plan');
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'POST',
        body: JSON.stringify(newPlan),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.createPlan'));
      setMessage(t('notices.planAdded', { name: newPlan.name }));
      setNewPlan({ id: '', name: '', monthlyLimit: 100, description: '' });
      await Promise.all([loadAdmin(), onPlansChanged()]);
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.createPlan'));
    } finally {
      setSaving(null);
    }
  }

  async function saveUser(
    item: AdminUserOverview,
    override?: { plan: UserPlan['Plan']; status: UserPlan['Account_status'] },
  ) {
    const draft = override ?? drafts[item.User_id];
    if (!draft) return;
    setSaving(item.User_id);
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'PATCH',
        body: JSON.stringify({ type: 'user', userId: item.User_id, ...draft }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.updateUser'));
      setMessage(t('notices.userUpdated', { name: item.Name || item.Email || '' }));
      await loadAdmin();
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.updateUser'));
    } finally {
      setSaving(null);
    }
  }

  async function createUser(event: SyntheticEvent<HTMLFormElement, SubmitEvent>) {
    event.preventDefault();
    setSaving('new-user');
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'POST',
        body: JSON.stringify({ type: 'user', ...newUser }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.createUser'));
      setMessage(t('notices.userCreated', { name: newUser.name }));
      setNewUser({ name: '', email: '', password: '', plan: 'starter', status: 'active', confirmEmail: true });
      await loadAdmin();
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.createUser'));
    } finally {
      setSaving(null);
    }
  }

  async function deleteUser(item: AdminUserOverview) {
    const name = item.Name || item.Email || t('admin.unnamedUser');
    if (!window.confirm(t('admin.deleteUserConfirm', { name }))) return;
    setSaving(`delete:${item.User_id}`);
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch(`/api/admin?user_id=${encodeURIComponent(item.User_id)}`, { method: 'DELETE' });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.deleteUser'));
      setMessage(t('notices.userDeleted', { name }));
      if (selectedUser?.User_id === item.User_id) setSelectedUser(null);
      await loadAdmin();
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.deleteUser'));
    } finally {
      setSaving(null);
    }
  }

  async function reviewUpgradeRequest(requestId: number, decision: 'approved' | 'rejected') {
    setSaving(`upgrade:${requestId}`);
    setMessage(null);
    setAdminError(null);
    try {
      const response = await adminFetch('/api/admin', {
        method: 'PATCH',
        body: JSON.stringify({ type: 'upgrade-request', requestId, decision }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || t('errors.reviewUpgrade'));
      setMessage(decision === 'approved' ? t('notices.upgradeApproved') : t('notices.upgradeRejected'));
      await Promise.all([loadAdmin(), onPlansChanged()]);
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.reviewUpgrade'));
    } finally {
      setSaving(null);
    }
  }

  async function openUser(item: AdminUserOverview) {
    setSelectedUser(item);
    setLoadingDetails(true);
    setAdminError(null);
    try {
      const response = await adminFetch(`/api/admin?user_id=${encodeURIComponent(item.User_id)}`);
      const result = (await response.json()) as {
        error?: string;
        searches?: SearchRecord[];
        leads?: Lead[];
      };
      if (!response.ok) throw new Error(result.error || t('errors.loadUserActivity'));
      setSelectedSearches(result.searches ?? []);
      setSelectedLeads(result.leads ?? []);
    } catch (cause) {
      setAdminError(cause instanceof Error ? cause.message : t('errors.loadUserActivity'));
    } finally {
      setLoadingDetails(false);
    }
  }

  const filteredUsers = useMemo(() => {
    const query = userQuery.trim().toLocaleLowerCase();
    return users.filter((item) => {
      const matchesQuery =
        !query ||
        `${item.Name ?? ''} ${item.Email ?? ''}`.toLocaleLowerCase().includes(query);
      const matchesPlan = planFilter === 'all' || item.Plan === planFilter;
      const matchesStatus = statusFilter === 'all' || item.Account_status === statusFilter;
      return matchesQuery && matchesPlan && matchesStatus;
    });
  }, [planFilter, statusFilter, userQuery, users]);

  const usersById = useMemo(
    () => new Map(users.map((item) => [item.User_id, item])),
    [users],
  );
  const adminSearchesById = useMemo(
    () => new Map(adminSearches.map((item) => [item.id, item])),
    [adminSearches],
  );
  const selectedSearchesById = useMemo(
    () => new Map(selectedSearches.map((item) => [item.id, item])),
    [selectedSearches],
  );

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-44 rounded-3xl" />
        <Skeleton className="h-80 rounded-3xl" />
      </div>
    );
  }

  const adminFormatDate = (value: string | null) =>
    value
      ? formatDate(value, { dateStyle: 'medium', timeStyle: 'short' })
      : '—';
  const formatNumber = (value: number) => formatLocalizedNumber(value);

  return (
    <div className="space-y-6">
      {message && (
        <Alert className="border-emerald-200 bg-emerald-50 text-emerald-900">
          <ShieldCheck />
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}
      {adminError && (
        <Alert variant="destructive">
          <AlertDescription>{adminError}</AlertDescription>
        </Alert>
      )}

      <Card className="border-0 bg-[#032e25] text-white shadow-sm ring-0">
        <CardContent className="p-3">
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-[minmax(190px,1.4fr)_repeat(7,minmax(132px,1fr))]" aria-label={t('nav.admin')}>
            {([
              ['dashboard', t('admin.dashboard'), <LayoutDashboard key="dashboard" />],
              ['users', t('admin.users'), <Users key="users" />],
              ['teams', t('admin.teams'), <UsersRound key="teams" />],
              ['subscriptions', t('admin.subscriptions'), <Crown key="subscriptions" />],
              ['usage', t('admin.usage'), <BarChart3 key="usage" />],
              ['searches', t('admin.searches'), <Search key="searches" />],
              ['leads', t('admin.leads'), <Building2 key="leads" />],
              ['settings', t('admin.settings'), <Settings2 key="settings" />],
            ] as [AdminSection, string, ReactNode][]).map(([section, label, icon]) => (
              <Button
                key={section}
                variant="ghost"
                className={
                  adminSection === section
                    ? 'h-12 min-w-0 justify-start bg-white px-3 text-slate-950 hover:bg-white'
                    : 'h-12 min-w-0 justify-start px-3 text-slate-300 hover:bg-white/10 hover:text-white'
                }
                onClick={() => setAdminSection(section)}
              >
                {icon}
                <span className="whitespace-nowrap">{label}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {adminSection === 'teams' && <AdminTeams accessToken={accessToken} users={users} />}

      {adminSection === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Metric icon={<Users />} label={t('admin.totalUsers')} value={formatNumber(users.length)} tone="indigo" />
            <Metric icon={<ShieldCheck />} label={t('admin.activeAccounts')} value={formatNumber(users.filter((item) => item.Account_status === 'active').length)} tone="emerald" />
            <Metric icon={<Search />} label={t('admin.searches')} value={formatNumber(summary.searches)} tone="cyan" />
            <Metric icon={<Building2 />} label={t('dashboard.totalLeads')} value={formatNumber(summary.leads)} tone="indigo" />
          </div>
          <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
            <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
              <CardHeader>
                <CardTitle>{t('admin.planOverview')}</CardTitle>
                <CardDescription>{t('admin.planOverviewDescription')}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {plans.map((plan) => {
                  const members = users.filter((item) => item.Plan === plan.id);
                  const usage = members.reduce((total, item) => total + item.Monthly_usage, 0);
                  return (
                    <div key={plan.id} className="rounded-2xl border border-slate-200 p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div><p className="font-black text-slate-900">{planDisplayName(plan.id, plan.Name)}</p><p className="text-xs text-slate-500">{t('admin.userCount', { count: members.length })}</p></div>
                        <p className="font-bold tabular-nums">{t('admin.usedLeads', { count: formatNumber(usage) })}</p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
              <CardHeader><CardTitle>{t('admin.accountStatuses')}</CardTitle><CardDescription>{t('admin.accountStatusesDescription')}</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                {(['pending', 'active', 'suspended', 'disabled'] as UserPlan['Account_status'][]).map((status) => (
                  <div key={status} className="flex items-center justify-between rounded-xl bg-slate-50 p-3">
                    <span className="font-medium text-slate-700">{adminStatusLabel(status)}</span>
                    <Badge variant="outline" className="bg-white">{users.filter((item) => item.Account_status === status).length}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {adminSection === 'settings' && (
        <>

      {settings && (
        <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="grid size-11 place-items-center rounded-2xl bg-indigo-50 text-indigo-600">
                <Settings2 className="size-5" />
              </div>
              <div>
                <CardTitle>{t('admin.signupSettings')}</CardTitle>
                <CardDescription>{t('admin.signupSettingsDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-4 lg:grid-cols-[1fr_1fr_auto] lg:items-end">
            <Field label={t('admin.activationMode')} htmlFor="activation-mode">
              <Select
                value={settings.Activation_mode}
                onValueChange={(value) =>
                  setSettings({ ...settings, Activation_mode: value as AppSettings['Activation_mode'] })
                }
              >
                <SelectTrigger id="activation-mode" className="h-11 w-full bg-white">
                  <SelectValue>
                    {settings.Activation_mode === 'automatic' ? t('admin.automatic') : t('admin.manual')}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatic">{t('admin.automatic')}</SelectItem>
                  <SelectItem value="manual">{t('admin.manual')}</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label={t('admin.defaultPlan')} htmlFor="default-plan">
              <div id="default-plan" className="flex h-11 items-center justify-between rounded-md border border-slate-200 bg-slate-50 px-3">
                <span className="font-semibold text-slate-800">{planDisplayName('starter', plans.find((plan) => plan.id === 'starter')?.Name)}</span>
                <Badge variant="outline" className="bg-white">{t('admin.fixedTrialQuota', { count: formatLocalizedNumber(30) })}</Badge>
              </div>
            </Field>
            <Button className="h-11 bg-[#059669] hover:bg-[#047857]" onClick={saveSettings} disabled={saving === 'settings'}>
              {saving === 'settings' && <Spinner />}
              {t('admin.saveSettings')}
            </Button>
          </CardContent>
        </Card>
      )}

      <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="grid size-11 place-items-center rounded-2xl bg-cyan-50 text-cyan-700">
              <Crown className="size-5" />
            </div>
            <div>
              <CardTitle>{t('admin.planManagement')}</CardTitle>
              <CardDescription>
                {t('admin.planManagementDescription')}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-3">
            {plans.map((plan) => {
              const draft = planDrafts[plan.id] ?? {
                Name: plan.Name,
                Monthly_limit: plan.Monthly_limit,
                Description: plan.Description,
              };
              return (
                <div key={plan.id} className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50/60 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <Badge variant="outline" className="bg-white font-mono text-xs">{plan.id}</Badge>
                    <span className="text-xs text-slate-500">
                      {t('admin.userCount', { count: users.filter((user) => user.Plan === plan.id).length })}
                    </span>
                  </div>
                  <Field label={t('admin.planName')} htmlFor={`plan-name-${plan.id}`}>
                    <Input
                      id={`plan-name-${plan.id}`}
                      value={draft.Name}
                      onChange={(event) =>
                        setPlanDrafts((current) => ({
                          ...current,
                          [plan.id]: { ...draft, Name: event.target.value },
                        }))
                      }
                      className="h-10 bg-white"
                    />
                  </Field>
                  <Field label={t('admin.monthlyLimit')} htmlFor={`plan-limit-${plan.id}`}>
                    <Input
                      id={`plan-limit-${plan.id}`}
                      type="number"
                      min={1}
                      max={1000000}
                      value={draft.Monthly_limit}
                      onChange={(event) =>
                        setPlanDrafts((current) => ({
                          ...current,
                          [plan.id]: { ...draft, Monthly_limit: Number(event.target.value) },
                        }))
                      }
                      className="h-10 bg-white"
                    />
                  </Field>
                  <Field label={t('admin.description')} htmlFor={`plan-description-${plan.id}`}>
                    <Input
                      id={`plan-description-${plan.id}`}
                      value={draft.Description ?? ''}
                      onChange={(event) =>
                        setPlanDrafts((current) => ({
                          ...current,
                          [plan.id]: { ...draft, Description: event.target.value },
                        }))
                      }
                      className="h-10 bg-white"
                    />
                  </Field>
                  <Button
                    className="w-full"
                    variant="outline"
                    disabled={saving === `plan:${plan.id}`}
                    onClick={() => void savePlan(plan)}
                  >
                    {saving === `plan:${plan.id}` && <Spinner />}
                    {t('admin.savePlan')}
                  </Button>
                </div>
              );
            })}
          </div>

          <form
            className="grid gap-4 rounded-2xl border border-dashed border-indigo-300 bg-indigo-50/50 p-4 lg:grid-cols-[0.8fr_1fr_0.8fr_1.4fr_auto] lg:items-end"
            onSubmit={createPlan}
          >
            <Field label={t('admin.planCode')} htmlFor="new-plan-id">
              <Input
                id="new-plan-id"
                value={newPlan.id}
                onChange={(event) =>
                  setNewPlan((current) => ({
                    ...current,
                    id: event.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''),
                  }))
                }
                pattern="[a-z0-9][a-z0-9_-]{1,31}"
                placeholder="business_plus"
                className="h-11 bg-white font-mono"
                required
              />
            </Field>
            <Field label={t('admin.planName')} htmlFor="new-plan-name">
              <Input
                id="new-plan-name"
                value={newPlan.name}
                onChange={(event) => setNewPlan((current) => ({ ...current, name: event.target.value }))}
                placeholder="Business Plus"
                className="h-11 bg-white"
                required
              />
            </Field>
            <Field label={t('admin.monthlyLimit')} htmlFor="new-plan-limit">
              <Input
                id="new-plan-limit"
                type="number"
                min={1}
                max={1000000}
                value={newPlan.monthlyLimit}
                onChange={(event) =>
                  setNewPlan((current) => ({ ...current, monthlyLimit: Number(event.target.value) }))
                }
                className="h-11 bg-white"
                required
              />
            </Field>
            <Field label={t('admin.description')} htmlFor="new-plan-description">
              <Input
                id="new-plan-description"
                value={newPlan.description}
                onChange={(event) =>
                  setNewPlan((current) => ({ ...current, description: event.target.value }))
                }
                placeholder={t('admin.planDescriptionPlaceholder')}
                className="h-11 bg-white"
              />
            </Field>
            <Button type="submit" className="h-11 bg-[#059669] hover:bg-[#047857]" disabled={saving === 'new-plan'}>
              {saving === 'new-plan' ? <Spinner /> : <Plus />}
              {t('admin.addPlan')}
            </Button>
          </form>
        </CardContent>
      </Card>

        </>
      )}

      {adminSection === 'users' && (
        <div className="space-y-6">
      <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="flex items-center gap-2"><UserPlus className="size-5 text-indigo-600" />{t('admin.addUser')}</CardTitle>
        </CardHeader>
        <CardContent className="pt-5">
          <form className="grid gap-4 md:grid-cols-2 xl:grid-cols-5" onSubmit={createUser}>
            <Field label={t('admin.userName')} htmlFor="admin-new-user-name">
              <Input id="admin-new-user-name" required minLength={2} value={newUser.name} onChange={(event) => setNewUser((current) => ({ ...current, name: event.target.value }))} />
            </Field>
            <Field label={t('admin.userEmail')} htmlFor="admin-new-user-email">
              <Input id="admin-new-user-email" required type="email" value={newUser.email} onChange={(event) => setNewUser((current) => ({ ...current, email: event.target.value }))} />
            </Field>
            <Field label={t('admin.temporaryPassword')} htmlFor="admin-new-user-password">
              <Input id="admin-new-user-password" required minLength={8} type="password" value={newUser.password} onChange={(event) => setNewUser((current) => ({ ...current, password: event.target.value }))} />
            </Field>
            <Field label={t('common.plan')} htmlFor="admin-new-user-plan">
              <Select value={newUser.plan} onValueChange={(value) => setNewUser((current) => ({ ...current, plan: value ?? 'starter' }))}>
                <SelectTrigger id="admin-new-user-plan">
                  <SelectValue>{planDisplayName(newUser.plan, plans.find((plan) => plan.id === newUser.plan)?.Name)}</SelectValue>
                </SelectTrigger>
                <SelectContent>{plans.map((plan) => <SelectItem key={plan.id} value={plan.id}>{planDisplayName(plan.id, plan.Name)}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label={t('common.status')} htmlFor="admin-new-user-status">
              <Select value={newUser.status} onValueChange={(value) => setNewUser((current) => ({ ...current, status: value as UserPlan['Account_status'] }))}>
                <SelectTrigger id="admin-new-user-status"><SelectValue>{adminStatusLabel(newUser.status)}</SelectValue></SelectTrigger>
                <SelectContent>{(['active', 'pending', 'suspended'] as UserPlan['Account_status'][]).map((value) => <SelectItem key={value} value={value}>{adminStatusLabel(value)}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <label className="flex items-center gap-2 text-sm font-medium text-slate-700 md:col-span-2 xl:col-span-4">
              <input type="checkbox" checked={newUser.confirmEmail} onChange={(event) => setNewUser((current) => ({ ...current, confirmEmail: event.target.checked }))} className="size-4 accent-indigo-600" />
              {t('admin.confirmEmail')}
            </label>
            <Button type="submit" disabled={saving === 'new-user'} className="h-11">
              {saving === 'new-user' ? <Spinner /> : <UserPlus />}{t('admin.createUser')}
            </Button>
          </form>
        </CardContent>
      </Card>
      <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/80">
        <CardHeader className="border-b border-slate-100">
          <CardTitle>{t('admin.users')}</CardTitle>
          <CardDescription>{t('admin.usersDescription', { visible: filteredUsers.length, total: users.length })}</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="grid gap-3 border-b border-slate-100 p-4 md:grid-cols-[1.5fr_1fr_1fr]">
            <div className="relative">
              <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
              <Input value={userQuery} onChange={(event) => setUserQuery(event.target.value)} placeholder={t('admin.searchUsers')} className="h-11 bg-white ps-9" />
            </div>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="h-11 bg-white">
                <SelectValue>{planFilter === 'all' ? t('admin.filterByPlan') : planDisplayName(planFilter, plans.find((plan) => plan.id === planFilter)?.Name)}</SelectValue>
              </SelectTrigger>
              <SelectContent><SelectItem value="all">{t('admin.filterByPlan')}</SelectItem>{plans.map((plan) => <SelectItem key={plan.id} value={plan.id}>{planDisplayName(plan.id, plan.Name)}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-11 bg-white">
                <SelectValue>{statusFilter === 'all' ? t('admin.filterByStatus') : adminStatusLabel(statusFilter as UserPlan['Account_status'])}</SelectValue>
              </SelectTrigger>
              <SelectContent><SelectItem value="all">{t('admin.filterByStatus')}</SelectItem>{(['pending', 'active', 'suspended', 'disabled'] as UserPlan['Account_status'][]).map((value) => <SelectItem key={value} value={value}>{adminStatusLabel(value)}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/80 hover:bg-slate-50/80">
                  <TableHead className="px-5 text-start">{t('common.user')}</TableHead>
                  <TableHead className="text-start">{t('common.plan')}</TableHead>
                  <TableHead className="text-start">{t('common.status')}</TableHead>
                  <TableHead className="text-start">{t('common.usage')}</TableHead>
                  <TableHead className="text-start">{t('common.createdAt')}</TableHead>
                  <TableHead className="text-start">{t('common.lastActivity')}</TableHead>
                  <TableHead className="px-5 text-start">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((item) => {
                  const draft = drafts[item.User_id] ?? { plan: item.Plan, status: item.Account_status };
                  return (
                    <TableRow key={item.User_id}>
                      <TableCell className="px-5">
                        <p className="font-bold text-slate-900">{item.Name || t('admin.unnamedUser')}</p>
                        <p className="mt-1 text-xs text-slate-500">{item.Email || '—'}</p>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={draft.plan}
                          onValueChange={(value) =>
                            setDrafts((current) => ({
                              ...current,
                              [item.User_id]: { ...draft, plan: value as UserPlan['Plan'] },
                            }))
                          }
                        >
                          <SelectTrigger className="w-36">
                            <SelectValue>{planDisplayName(draft.plan, plans.find((plan) => plan.id === draft.plan)?.Name)}</SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {plans.map((plan) => (
                              <SelectItem key={plan.id} value={plan.id}>{planDisplayName(plan.id, plan.Name)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={draft.status}
                          onValueChange={(value) =>
                            setDrafts((current) => ({
                              ...current,
                              [item.User_id]: { ...draft, status: value as UserPlan['Account_status'] },
                            }))
                          }
                        >
                          <SelectTrigger className="w-36"><SelectValue>{adminStatusLabel(draft.status)}</SelectValue></SelectTrigger>
                          <SelectContent>
                            {(['pending', 'active', 'suspended', 'disabled'] as UserPlan['Account_status'][]).map((value) => (
                              <SelectItem key={value} value={value}>{adminStatusLabel(value)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="font-bold tabular-nums">
                        {formatNumber(item.Monthly_usage)} / {formatNumber(item.Monthly_limit)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-xs text-slate-500">{adminFormatDate(item.Created_at)}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs text-slate-500">{adminFormatDate(item.Last_activity)}</TableCell>
                      <TableCell className="px-5">
                        <div className="flex min-w-max flex-wrap gap-2">
                          <Button size="sm" onClick={() => void saveUser(item)} disabled={saving === item.User_id || (item.User_id === currentUserId && draft.status !== 'active')}>
                            {saving === item.User_id && <Spinner />}
                            {t('common.save')}
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => void openUser(item)}>
                            {t('admin.viewActivity')}
                          </Button>
                          {item.User_id !== currentUserId && (
                            <Button
                              size="sm"
                              variant="outline"
                              className={draft.status === 'suspended' ? 'border-emerald-200 text-emerald-700 hover:bg-emerald-50' : 'border-amber-200 text-amber-700 hover:bg-amber-50'}
                              disabled={saving === item.User_id}
                              onClick={() => void saveUser(item, { plan: draft.plan, status: draft.status === 'suspended' ? 'active' : 'suspended' })}
                            >
                              {draft.status === 'suspended' ? t('admin.unfreeze') : t('admin.freeze')}
                            </Button>
                          )}
                          {item.User_id !== currentUserId && (
                            <Button size="sm" variant="outline" className="border-red-200 text-red-700 hover:bg-red-50" disabled={saving === `delete:${item.User_id}`} onClick={() => void deleteUser(item)}>
                              {saving === `delete:${item.User_id}` ? <Spinner /> : <Trash2 />}{t('admin.deleteUser')}
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {selectedUser && (
        <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/80">
          <CardHeader className="border-b border-slate-100">
            <CardTitle>{t('admin.userActivity', { name: selectedUser.Name || selectedUser.Email || t('common.user') })}</CardTitle>
            <CardDescription>{t('admin.userActivityDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 p-5">
            {loadingDetails ? (
              <Skeleton className="h-40 rounded-2xl" />
            ) : (
              <>
                <div>
                  <h3 className="mb-3 font-black text-slate-900">{t('admin.searchCount', { count: selectedSearches.length })}</h3>
                  <div className="overflow-x-auto rounded-xl border">
                    <Table>
                      <TableHeader><TableRow><TableHead className="text-start">{t('common.activity')}</TableHead><TableHead className="text-start">{t('common.location')}</TableHead><TableHead className="text-start">{t('common.total')}</TableHead><TableHead className="text-start">{t('common.date')}</TableHead></TableRow></TableHeader>
                      <TableBody>
                        {selectedSearches.map((search) => (
                          <TableRow key={search.id} role="button" tabIndex={0} className="cursor-pointer outline-none hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500" onClick={() => window.location.assign(`/searches/${search.id}`)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); window.location.assign(`/searches/${search.id}`); } }}><TableCell>{capitalizeFirst(search.Activité)}</TableCell><TableCell>{[capitalizeFirst(search.Ville), search.Pays].filter((value) => value && value !== '—').join('، ')}</TableCell><TableCell>{search['Total de Clients'] ?? 0}</TableCell><TableCell>{formatDate(search.Created_at)}<ChevronLeft className="mr-2 inline size-4 text-indigo-500" /></TableCell></TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
                <div>
                  <h3 className="mb-3 font-black text-slate-900">{t('admin.leads')} ({selectedLeads.length})</h3>
                  <div className="overflow-x-auto rounded-xl border">
                    <Table>
                      <TableHeader><TableRow><TableHead className="text-start">{t('common.client')}</TableHead><TableHead className="text-start">{t('common.city')}</TableHead><TableHead className="text-start">{t('common.phone')}</TableHead><TableHead className="text-start">{t('common.website')}</TableHead><TableHead className="text-start">{t('common.email')}</TableHead></TableRow></TableHeader>
                      <TableBody>
                        {selectedLeads.map((lead) => (
                          <TableRow
                            key={lead.id}
                            className="cursor-pointer hover:bg-indigo-50/60"
                            onClick={() => setInspectedLead({ lead, fallbackCity: selectedSearchesById.get(lead.Search_id ?? -1)?.Ville })}
                          ><TableCell><ProspectNameHover lead={lead} fallbackCity={selectedSearchesById.get(lead.Search_id ?? -1)?.Ville}>{compactLeadName(lead.Entreprise)}</ProspectNameHover></TableCell><TableCell>{getLeadCityLabel(lead, selectedSearchesById.get(lead.Search_id ?? -1)?.Ville)}</TableCell><TableCell dir="ltr">{lead.Telephone || '—'}</TableCell><TableCell>{isLeadValueAvailable(lead.Siteweb) ? <a href={safeWebsiteUrl(lead.Siteweb)} target="_blank" rel="noreferrer" className="text-indigo-600 underline" onClick={(event) => event.stopPropagation()}>{t('common.open')}</a> : t('common.notFound')}</TableCell><TableCell><ProspectEmailCell lead={lead} /></TableCell></TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
        </div>
      )}

      {adminSection === 'subscriptions' && (
        <div className="space-y-5">
          <Card className="border-0 shadow-sm ring-1 ring-slate-200/80">
            <CardHeader>
              <CardTitle>{t('admin.upgradeRequests')}</CardTitle>
              <CardDescription>{t('admin.upgradeRequestsDescription')}</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {upgradeRequests.filter((request) => request.Status === 'pending').length === 0 ? (
                <p className="px-6 pb-6 text-sm text-slate-500">{t('admin.noUpgradeRequests')}</p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader><TableRow className="bg-slate-50/80"><TableHead className="px-5 text-start">{t('common.user')}</TableHead><TableHead className="text-start">{t('admin.requestedPlan')}</TableHead><TableHead className="text-start">{t('common.date')}</TableHead><TableHead className="px-5 text-start">{t('common.actions')}</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {upgradeRequests.filter((request) => request.Status === 'pending').map((request) => {
                        const requestUser = users.find((item) => item.User_id === request.User_id);
                        const requestedPlan = plans.find((plan) => plan.id === request.Requested_plan);
                        return (
                          <TableRow key={request.id}>
                            <TableCell className="px-5"><p className="font-bold">{requestUser?.Name || t('admin.unnamedUser')}</p><p className="text-xs text-slate-500">{requestUser?.Email || '—'}</p></TableCell>
                            <TableCell><Badge variant="outline">{planDisplayName(request.Requested_plan, requestedPlan?.Name)}</Badge></TableCell>
                            <TableCell>{formatDate(request.Created_at)}</TableCell>
                            <TableCell className="px-5">
                              <div className="flex gap-2">
                                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={saving === `upgrade:${request.id}`} onClick={() => void reviewUpgradeRequest(request.id, 'approved')}><CheckCircle2 />{t('admin.approve')}</Button>
                                <Button size="sm" variant="outline" className="border-red-200 text-red-700 hover:bg-red-50" disabled={saving === `upgrade:${request.id}`} onClick={() => void reviewUpgradeRequest(request.id, 'rejected')}><XCircle />{t('admin.reject')}</Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
          <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
          {plans.map((plan) => {
            const members = users.filter((item) => item.Plan === plan.id);
            const activeMembers = members.filter((item) => item.Account_status === 'active').length;
            const usage = members.reduce((total, item) => total + item.Monthly_usage, 0);
            return (
              <Card key={plan.id} className="border-0 shadow-sm ring-1 ring-slate-200/80">
                <CardHeader>
                  <div className="flex items-center justify-between"><CardTitle>{planDisplayName(plan.id, plan.Name)}</CardTitle><Badge variant="outline">{plan.id}</Badge></div>
                  <CardDescription>{plan.Description || t('dashboard.customPlan')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-3xl font-black tabular-nums text-slate-950">{formatNumber(plan.Monthly_limit)} <span className="text-sm font-medium text-slate-500">{t('admin.leadsPerUser')}</span></p>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-xl bg-slate-50 p-3"><p className="text-lg font-black">{members.length}</p><p className="text-xs text-slate-500">{t('admin.subscribers')}</p></div>
                    <div className="rounded-xl bg-emerald-50 p-3"><p className="text-lg font-black text-emerald-700">{activeMembers}</p><p className="text-xs text-slate-500">{t('status.active')}</p></div>
                    <div className="rounded-xl bg-indigo-50 p-3"><p className="text-lg font-black text-indigo-700">{formatNumber(usage)}</p><p className="text-xs text-slate-500">{t('common.usage')}</p></div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          </div>
        </div>
      )}

      {adminSection === 'usage' && (
        <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/80">
          <CardHeader><CardTitle>{t('dashboard.monthlyUsage')}</CardTitle><CardDescription>{t('admin.usageDescription')}</CardDescription></CardHeader>
          <CardContent className="p-0"><div className="overflow-x-auto"><Table>
            <TableHeader><TableRow className="bg-slate-50/80"><TableHead className="px-5 text-start">{t('common.user')}</TableHead><TableHead className="text-start">{t('common.plan')}</TableHead><TableHead className="text-start">{t('common.usage')}</TableHead><TableHead className="text-start">{t('common.limit')}</TableHead><TableHead className="px-5 text-start">{t('common.percentage')}</TableHead></TableRow></TableHeader>
            <TableBody>{[...users].sort((a, b) => b.Monthly_usage - a.Monthly_usage).map((item) => {
              const percentage = item.Monthly_limit > 0 ? Math.min(Math.round((item.Monthly_usage / item.Monthly_limit) * 100), 100) : 0;
              return <TableRow key={item.User_id}><TableCell className="px-5"><p className="font-bold">{item.Name || t('admin.unnamedUser')}</p><p className="text-xs text-slate-500">{item.Email || '—'}</p></TableCell><TableCell>{planDisplayName(item.Plan, plans.find((plan) => plan.id === item.Plan)?.Name)}</TableCell><TableCell className="font-bold tabular-nums">{formatNumber(item.Monthly_usage)}</TableCell><TableCell className="tabular-nums">{formatNumber(item.Monthly_limit)}</TableCell><TableCell className="px-5"><div className="flex min-w-44 items-center gap-3"><div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-indigo-500" style={{ width: `${percentage}%` }} /></div><span className="w-10 text-left text-xs font-bold">{percentage}%</span></div></TableCell></TableRow>;
            })}</TableBody>
          </Table></div></CardContent>
        </Card>
      )}

      {adminSection === 'searches' && (
        <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/80">
          <CardHeader><CardTitle>{t('admin.allSearches')}</CardTitle><CardDescription>{t('admin.allSearchesDescription')}</CardDescription></CardHeader>
          <CardContent className="p-0">{loadingResource ? <div className="p-5"><Skeleton className="h-48 rounded-2xl" /></div> : <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow className="bg-slate-50/80"><TableHead className="px-5 text-start">{t('common.activity')}</TableHead><TableHead className="text-start">{t('common.user')}</TableHead><TableHead className="text-start">{t('common.location')}</TableHead><TableHead className="text-start">{t('common.required')}</TableHead><TableHead className="text-start">{t('common.total')}</TableHead><TableHead className="text-start">{t('common.status')}</TableHead><TableHead className="px-5 text-start">{t('common.date')}</TableHead></TableRow></TableHeader>
            <TableBody>{adminSearches.map((search) => <TableRow key={search.id} role="button" tabIndex={0} className="cursor-pointer outline-none hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500" onClick={() => window.location.assign(`/searches/${search.id}`)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); window.location.assign(`/searches/${search.id}`); } }}><TableCell className="px-5 font-bold">{capitalizeFirst(search.Activité)}</TableCell><TableCell>{usersById.get(search.User_id ?? '')?.Email || '—'}</TableCell><TableCell>{[capitalizeFirst(search.Ville), search.Pays].filter((value) => value && value !== '—').join('، ') || '—'}</TableCell><TableCell>{formatNumber(search['Nombre de clients'] ?? 0)}</TableCell><TableCell>{formatNumber(search['Total de Clients'] ?? 0)}</TableCell><TableCell><StatusBadge search={search} /></TableCell><TableCell className="px-5 whitespace-nowrap text-xs text-slate-500">{formatDate(search.Created_at)}<ChevronLeft className="mr-2 inline size-4 text-indigo-500" /></TableCell></TableRow>)}</TableBody>
          </Table></div>}</CardContent>
        </Card>
      )}

      {adminSection === 'leads' && (
        <Card className="overflow-hidden border-0 shadow-sm ring-1 ring-slate-200/80">
          <CardHeader><CardTitle>{t('admin.allLeads')}</CardTitle><CardDescription>{t('admin.allLeadsDescription')}</CardDescription></CardHeader>
          <CardContent className="p-0">{loadingResource ? <div className="p-5"><Skeleton className="h-48 rounded-2xl" /></div> : <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow className="bg-slate-50/80"><TableHead className="px-5 text-start">{t('common.client')}</TableHead><TableHead className="text-start">{t('common.user')}</TableHead><TableHead className="text-start">{t('common.city')}</TableHead><TableHead className="text-start">{t('common.phone')}</TableHead><TableHead className="text-start">{t('common.website')}</TableHead><TableHead className="text-start">{t('common.email')}</TableHead><TableHead className="text-start">{t('search.theoreticalRating')}</TableHead><TableHead className="px-5 text-start">Search ID</TableHead></TableRow></TableHeader>
            <TableBody>{adminLeads.map((lead) => <TableRow key={lead.id} className="cursor-pointer hover:bg-indigo-50/60" onClick={() => setInspectedLead({ lead, fallbackCity: adminSearchesById.get(lead.Search_id ?? -1)?.Ville })}><TableCell className="px-5 font-bold"><ProspectNameHover lead={lead} fallbackCity={adminSearchesById.get(lead.Search_id ?? -1)?.Ville}>{compactLeadName(lead.Entreprise)}</ProspectNameHover></TableCell><TableCell>{usersById.get(lead.User_id ?? '')?.Email || '—'}</TableCell><TableCell>{getLeadCityLabel(lead, adminSearchesById.get(lead.Search_id ?? -1)?.Ville)}</TableCell><TableCell dir="ltr">{lead.Telephone || '—'}</TableCell><TableCell>{isLeadValueAvailable(lead.Siteweb) ? <a href={safeWebsiteUrl(lead.Siteweb)} target="_blank" rel="noreferrer" className="text-indigo-600 underline" onClick={(event) => event.stopPropagation()}>{t('common.open')}</a> : t('common.notFound')}</TableCell><TableCell><ProspectEmailCell lead={lead} /></TableCell><TableCell>{lead.LeadScore ?? '—'}</TableCell><TableCell className="px-5 font-mono text-xs">{lead.Search_id ?? '—'}</TableCell></TableRow>)}</TableBody>
          </Table></div>}</CardContent>
        </Card>
      )}
      <LeadDetailsSheet
        lead={inspectedLead?.lead ?? null}
        fallbackCity={inspectedLead?.fallbackCity}
        open={Boolean(inspectedLead)}
        showInternalIdentifiers
        onOpenChange={(open) => {
          if (!open) setInspectedLead(null);
        }}
      />
    </div>
  );
}

function PlansPanel({
  email,
  userId,
  plan,
  loading,
  used,
  limit,
  options,
}: {
  email: string;
  userId: string;
  plan: UserPlan | null;
  loading: boolean;
  used: number;
  limit: number;
  options: PlanDefinition[];
}) {
  const [requests, setRequests] = useState<PlanUpgradeRequest[]>([]);
  const [requestingPlan, setRequestingPlan] = useState<string | null>(null);
  const [requestError, setRequestError] = useState<string | null>(null);

  const loadRequests = useCallback(async () => {
    const { data, error } = await supabase
      .from('Plan_Upgrade_Requests')
      .select('*')
      .eq('User_id', userId)
      .order('Created_at', { ascending: false })
      .limit(10);
    if (error) {
      setRequestError(t('account.upgradeLoadError'));
      return;
    }
    setRequests(data ?? []);
  }, [userId]);

  useEffect(() => {
    void loadRequests();
  }, [loadRequests]);

  async function requestUpgrade(requestedPlan: 'professional' | 'company') {
    setRequestingPlan(requestedPlan);
    setRequestError(null);
    const { error } = await supabase
      .from('Plan_Upgrade_Requests')
      .insert({ User_id: userId, Requested_plan: requestedPlan });
    if (error) {
      setRequestError(error.code === '23505' ? t('account.upgradeAlreadyPending') : t('account.upgradeRequestError'));
    } else {
      await loadRequests();
    }
    setRequestingPlan(null);
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-44 w-full rounded-3xl" />
        <div className="grid gap-4 lg:grid-cols-3">
          {[1, 2, 3].map((item) => (
            <Skeleton key={item} className="h-56 rounded-3xl" />
          ))}
        </div>
      </div>
    );
  }

  const currentPlan = plan?.Plan ?? 'starter';
  const currentName =
    planDisplayName(currentPlan, options.find((option) => option.id === currentPlan)?.Name);
  const remaining = Math.max(limit - used, 0);
  const percentage = limit > 0 ? Math.min(Math.round((used / limit) * 100), 100) : 0;
  const formatNumber = (value: number) => formatLocalizedNumber(value);
  const pendingRequest = requests.find((request) => request.Status === 'pending');

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border-0 bg-[#032e25] text-white shadow-[0_18px_55px_rgba(2,44,34,0.18)] ring-0">
        <CardContent className="grid gap-8 p-6 sm:p-8 lg:grid-cols-[1fr_1.2fr] lg:items-center">
          <div>
            <div className="mb-4 flex items-center gap-3">
              <div className="grid size-11 place-items-center rounded-2xl bg-indigo-500/20 text-indigo-300">
                <CircleUserRound className="size-6" />
              </div>
              <div>
                <p className="text-sm text-slate-400">{t('common.user')}</p>
                <p className="font-bold">{email}</p>
              </div>
            </div>
            <Badge className="border-indigo-400/30 bg-indigo-400/15 text-indigo-200">
              {currentName}
            </Badge>
          </div>

          <div>
            <div className="flex items-end justify-between gap-4">
              <div>
                <p className="text-sm text-slate-400">{t('account.monthlyUsage')}</p>
                <p className="mt-1 text-3xl font-black tabular-nums">
                  {formatNumber(used)}
                  <span className="text-base font-medium text-slate-400">
                    {' '}/ {formatNumber(limit)} {t('common.client')}
                  </span>
                </p>
              </div>
              <p className="text-sm font-bold text-indigo-300">{t('dashboard.remaining', { count: formatNumber(remaining) })}</p>
            </div>
            <div
              className="mt-5 h-3 overflow-hidden rounded-full bg-white/10"
              role="progressbar"
              aria-label={t('dashboard.monthlyUsage')}
              aria-valuemin={0}
              aria-valuemax={limit}
              aria-valuenow={used}
            >
              <div
                className="h-full rounded-full bg-gradient-to-l from-indigo-400 to-cyan-400 transition-[width]"
                style={{ width: `${percentage}%` }}
              />
            </div>
            <p className="mt-3 text-xs text-slate-400">
              {t('dashboard.resetMonthly')}
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        {options.map((option) => {
          const active = option.id === currentPlan;
          return (
            <Card
              key={option.id}
              className={
                active
                  ? 'border-indigo-300 bg-indigo-50/70 shadow-md ring-2 ring-indigo-500/20'
                  : 'border-slate-200 bg-white shadow-sm'
              }
            >
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <CardTitle className="text-lg font-black text-slate-950">
                    {planDisplayName(option.id, option.Name)}
                  </CardTitle>
                  {active && <Badge className="bg-indigo-600">{t('dashboard.currentPlanBadge')}</Badge>}
                </div>
                <CardDescription>{option.Description || t('dashboard.customPlan')}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-4xl font-black tabular-nums text-slate-950">
                  {formatNumber(option.Monthly_limit)}
                </p>
                <p className="mt-2 text-sm font-medium text-slate-500">{t('dashboard.clientsPerMonth', { count: formatNumber(option.Monthly_limit) })}</p>
                {!active && option.id !== 'starter' && option.Monthly_limit > limit && (
                  <Button
                    className="mt-5 w-full bg-[#059669] font-bold hover:bg-[#047857]"
                    disabled={Boolean(pendingRequest) || requestingPlan === option.id}
                    onClick={() => void requestUpgrade(option.id as 'professional' | 'company')}
                  >
                    {requestingPlan === option.id && <Spinner />}
                    {pendingRequest?.Requested_plan === option.id
                      ? t('account.upgradePending')
                      : pendingRequest
                        ? t('account.anotherUpgradePending')
                        : t('account.requestUpgrade')}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
      {requestError && <Alert variant="destructive"><AlertDescription>{requestError}</AlertDescription></Alert>}
      {pendingRequest && (
        <Alert className="border-amber-200 bg-amber-50 text-amber-900">
          <History />
          <AlertDescription>
            {t('account.pendingUpgradeDescription', {
              plan: planDisplayName(pendingRequest.Requested_plan, options.find((option) => option.id === pendingRequest.Requested_plan)?.Name),
            })}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}

function UserDashboardOverview({
  searches,
  loading,
  used,
  limit,
  totalLeads,
  successfulSearches,
  planName,
  onOpenSearch,
}: {
  searches: SearchRecord[];
  loading: boolean;
  used: number;
  limit: number;
  totalLeads: number;
  successfulSearches: number;
  planName: string;
  onOpenSearch: (id: number) => void;
}) {
  const percentage = limit > 0 ? Math.min(Math.round((used / limit) * 100), 100) : 0;
  const recentSearches = searches.slice(0, 4);

  if (loading) {
    return (
      <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
        <Skeleton className="h-56 rounded-3xl" />
        <Skeleton className="h-56 rounded-3xl" />
      </div>
    );
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]" aria-label={t('nav.dashboard')}>
      <Card className="overflow-hidden border-0 bg-[#032e25] text-white shadow-[0_18px_55px_rgba(2,44,34,0.16)] ring-0">
        <CardContent className="p-5 sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-indigo-200">{t('dashboard.monthlyUsage')}</p>
              <p className="mt-2 text-3xl font-black tabular-nums sm:text-4xl" dir="ltr">
                {formatLocalizedNumber(used)} / {formatLocalizedNumber(limit)}
              </p>
              <p className="mt-2 text-sm text-slate-400">{t('dashboard.usedClients', { count: formatLocalizedNumber(used) })}</p>
            </div>
            <Badge className="border-indigo-400/30 bg-indigo-400/15 px-3 py-1.5 text-indigo-100 hover:bg-indigo-400/15">
              {t('dashboard.usedPercent', { percent: formatLocalizedNumber(percentage) })}
            </Badge>
          </div>
          <Progress
            value={percentage}
            aria-label={t('dashboard.usedOfLimit', { used, limit })}
            className="mt-6 [&_[data-slot=progress-track]]:h-2.5 [&_[data-slot=progress-track]]:bg-white/10 [&_[data-slot=progress-indicator]]:bg-gradient-to-l [&_[data-slot=progress-indicator]]:from-indigo-400 [&_[data-slot=progress-indicator]]:to-cyan-400"
          />
          <div className="mt-6 grid grid-cols-3 gap-2">
            <DashboardMiniMetric icon={<Building2 />} label={t('dashboard.totalLeads')} value={formatLocalizedNumber(totalLeads)} />
            <DashboardMiniMetric icon={<CheckCircle2 />} label={t('dashboard.successfulSearches')} value={formatLocalizedNumber(successfulSearches)} />
            <DashboardMiniMetric icon={<Crown />} label={t('dashboard.currentPlan')} value={planName} />
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] ring-0">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-lg font-black text-slate-950">{t('dashboard.recentSearches')}</CardTitle>
              <CardDescription className="mt-1">{t('dashboard.recentDescription')}</CardDescription>
            </div>
            <span className="grid size-10 place-items-center rounded-xl bg-indigo-50 text-indigo-600">
              <History className="size-5" />
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {recentSearches.length === 0 ? (
            <div className="grid min-h-28 place-items-center rounded-2xl border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
              {t('dashboard.noSearches')}
            </div>
          ) : (
            recentSearches.map((search) => (
              <button
                key={search.id}
                type="button"
                aria-label={`${capitalizeFirst(search.Activité)} — ${capitalizeFirst(search.Ville)}`}
                onClick={() => onOpenSearch(search.id)}
                className="flex w-full items-center justify-between gap-3 rounded-2xl border border-slate-100 px-3 py-2.5 text-start transition hover:border-indigo-200 hover:bg-indigo-50/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              >
                <span className="min-w-0">
                  <span className="block truncate font-bold text-slate-900">{capitalizeFirst(search.Activité)}</span>
                  <span className="block truncate text-xs text-slate-500">
                    {[capitalizeFirst(search.Ville), capitalizeFirst(search.Pays)]
                      .filter((value) => value !== '—')
                      .join('، ')}
                  </span>
                </span>
                <span className="shrink-0 text-left">
                  <Badge
                    variant="outline"
                    className={isSuccessfulSearch(search) ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-amber-200 bg-amber-50 text-amber-700'}
                  >
                    {getSearchStatusLabel(search)}
                  </Badge>
                  <span className="mt-1 block text-xs tabular-nums text-slate-400">
                    {formatLocalizedNumber(search['Total de Clients'] ?? 0)} {t('common.client')}
                  </span>
                </span>
              </button>
            ))
          )}
        </CardContent>
      </Card>
    </section>
  );
}

function DashboardMiniMetric({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="min-w-0 rounded-2xl border border-white/10 bg-white/[0.06] p-3">
      <span className="text-indigo-300 [&_svg]:size-4">{icon}</span>
      <p className="mt-2 truncate text-lg font-black">{value}</p>
      <p className="mt-0.5 truncate text-xs text-slate-400">{label}</p>
    </div>
  );
}

function SearchForm({
  onSubmit,
  submitting,
}: {
  onSubmit: (input: SearchInput) => Promise<unknown>;
  submitting: boolean;
}) {
  const [activity, setActivity] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [count, setCount] = useState(25);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: SyntheticEvent<HTMLFormElement, SubmitEvent>) {
    event.preventDefault();
    if (!activity.trim() || !city.trim() || !country.trim()) {
      setError(t('search.fillRequired'));
      return;
    }
    setError(null);
    try {
      await onSubmit({
        activity: activity.trim(),
        city: city.trim(),
        country: country.trim(),
        count,
      });
    } catch (submissionError) {
      setError(
        submissionError instanceof Error
          ? submissionError.message
          : t('errors.startSearch'),
      );
    }
  }

  return (
    <Card className="border-0 bg-white shadow-[0_18px_55px_rgba(15,23,42,0.08)] ring-0">
      <CardHeader className="border-b border-slate-100 pb-5">
        <CardTitle className="flex items-center gap-2 text-lg font-black text-slate-950">
          <span className="grid size-9 place-items-center rounded-xl bg-indigo-50 text-indigo-600">
            <Search className="size-4" />
          </span>
          {t('search.newSearch')}
        </CardTitle>
        <CardDescription>
          {t('search.newDescription')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form
          className="grid gap-5 md:grid-cols-2 xl:grid-cols-[1.25fr_1fr_1fr_0.8fr_auto] xl:items-end"
          onSubmit={handleSubmit}
        >
          <Field label={t('common.activity')} htmlFor="activity">
            <Input
              id="activity"
              value={activity}
              onChange={(event) => setActivity(event.target.value)}
              className="h-11 bg-slate-50/70"
              placeholder={t('search.activityPlaceholder')}
              required
            />
          </Field>
          <Field label={t('common.city')} htmlFor="city">
            <div className="relative">
              <MapPin className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
              <Input
                id="city"
                value={city}
                onChange={(event) => setCity(event.target.value)}
                className="h-11 bg-slate-50/70 ps-9"
                placeholder={t('search.cityPlaceholder')}
                required
              />
            </div>
          </Field>
          <Field label={t('common.country')} htmlFor="country">
            <Input
              id="country"
              value={country}
              onChange={(event) => setCountry(event.target.value)}
              className="h-11 bg-slate-50/70"
              placeholder={t('search.countryPlaceholder')}
              required
            />
          </Field>
          <Field label={t('search.clientCount')} htmlFor="count">
            <Input
              id="count"
              type="number"
              min={1}
              max={500}
              value={count}
              onChange={(event) => setCount(Number(event.target.value))}
              className="h-11 bg-slate-50/70"
              required
            />
          </Field>
          <Button
            type="submit"
            size="lg"
            disabled={submitting}
            className="h-11 bg-[#059669] px-6 font-bold shadow-lg shadow-indigo-200 hover:bg-[#047857]"
          >
            {submitting ? <Spinner /> : <Search />}
            {submitting ? t('search.starting') : t('search.start')}
          </Button>
        </form>
        {error && <p className="mt-4 text-sm font-medium text-red-600">{error}</p>}
      </CardContent>
    </Card>
  );
}

function LeadsTable({
  search,
  leads,
  loading,
}: {
  search: SearchRecord | null;
  leads: Lead[];
  loading: boolean;
}) {
  const [availabilityFilter, setAvailabilityFilter] = useState('all');
  const [valueFilter, setValueFilter] = useState('');
  const [ratingFilter, setRatingFilter] = useState('all');
  const [qualityFilter, setQualityFilter] = useState('all');

  const ratingOptions = useMemo(
    () =>
      [...new Set(leads.map((lead) => lead.LeadScore).filter((value): value is number => value !== null))]
        .sort((a, b) => b - a),
    [leads],
  );
  const qualityOptions = useMemo(
    () =>
      [...new Set(leads.map((lead) => lead.LeadQuality?.trim()).filter((value): value is string => Boolean(value)))]
        .sort((a, b) => a.localeCompare(b)),
    [leads],
  );
  const activeFilterCount =
    Number(Boolean(valueFilter.trim())) +
    Number(availabilityFilter !== 'all') +
    Number(ratingFilter !== 'all') +
    Number(qualityFilter !== 'all');

  const filteredLeads = useMemo(() => {
    const query = valueFilter.trim().toLocaleLowerCase();
    return leads.filter((lead) => {
      const hasPhone = isLeadValueAvailable(lead.Telephone);
      const hasWebsite = isLeadValueAvailable(lead.Siteweb);
      const hasEmail = isLeadValueAvailable(lead.Email);
      const matchesAvailability =
        availabilityFilter === 'all' ||
        (availabilityFilter === 'phone' && hasPhone) ||
        (availabilityFilter === 'website' && hasWebsite) ||
        (availabilityFilter === 'email' && hasEmail) ||
        (availabilityFilter === 'complete' && hasPhone && hasWebsite && hasEmail) ||
        (availabilityFilter === 'missing' && (!hasPhone || !hasWebsite || !hasEmail));
      const matchesRating =
        ratingFilter === 'all' || String(lead.LeadScore ?? '') === ratingFilter;
      const matchesQuality =
        qualityFilter === 'all' || lead.LeadQuality?.trim() === qualityFilter;
      const searchableValues = [
        lead.Entreprise,
        lead.Activité,
        getLeadCityLabel(lead, search?.Ville),
        lead.Adresse,
        lead.Telephone,
        lead.Siteweb,
        lead.Email,
        lead.LeadQuality,
      ]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase();

      return matchesAvailability && matchesRating && matchesQuality && (!query || searchableValues.includes(query));
    });
  }, [availabilityFilter, leads, qualityFilter, ratingFilter, search?.Ville, valueFilter]);

  return (
    <>
    <Card className="border-0 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] ring-0">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-lg font-black text-slate-950">{t('search.resultsTitle')}</CardTitle>
        <CardDescription>
          {search
            ? `${search.Activité ? capitalizeFirst(search.Activité) : t('search.newSearch')} · ${capitalizeFirst(search.Ville)}، ${search.Pays ?? ''}`
            : t('search.firstPrompt')}
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        {loading ? (
          <div className="space-y-3 p-5">
            {[1, 2, 3].map((item) => (
              <Skeleton key={item} className="h-12 w-full" />
            ))}
          </div>
        ) : leads.length === 0 ? (
          <Empty className="min-h-64">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Building2 />
              </EmptyMedia>
              <EmptyTitle>
                {search ? t('search.waiting') : t('search.noResults')}
              </EmptyTitle>
              {search && <ResultsLoadingIndicator />}
              <EmptyDescription>
                {search
                  ? t('search.liveUpdate')
                  : t('search.fillForm')}
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <>
          <div className="border-b border-slate-100 bg-slate-50/70 p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-xl bg-white text-indigo-600 shadow-sm ring-1 ring-slate-200">
                  <SlidersHorizontal className="size-4" />
                </span>
                <div>
                  <h3 className="font-black text-slate-900">{t('search.filters')}</h3>
                  <p className="text-xs text-slate-500">{t('search.filtersDescription')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="h-8 bg-white px-3 text-slate-700">
                  {t('search.resultCount', { visible: filteredLeads.length, total: leads.length })}
                </Badge>
                {activeFilterCount > 0 && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="h-8 text-slate-600 hover:bg-white hover:text-slate-950"
                    onClick={() => {
                      setValueFilter('');
                      setAvailabilityFilter('all');
                      setRatingFilter('all');
                      setQualityFilter('all');
                    }}
                  >
                    <RotateCcw className="size-3.5" />
                    {t('search.clearFilters')}
                  </Button>
                )}
              </div>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-[1.7fr_1fr_0.8fr_1fr]">
              <Field label={t('search.searchResults')} htmlFor="lead-value-filter">
                <div className="relative">
                  <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    id="lead-value-filter"
                    value={valueFilter}
                    onChange={(event) => setValueFilter(event.target.value)}
                    placeholder={t('search.searchPlaceholder')}
                    className="h-11 border-slate-200 bg-white ps-9 shadow-sm"
                  />
                </div>
              </Field>
              <Field label={t('search.contactAvailability')} htmlFor="lead-availability-filter">
                <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
                  <SelectTrigger id="lead-availability-filter" className="h-11 border-slate-200 bg-white shadow-sm">
                    <SelectValue>{{ all: t('common.all'), phone: t('search.phoneAvailable'), website: t('search.websiteAvailable'), email: t('search.emailAvailable'), complete: t('search.allContactAvailable'), missing: t('search.incompleteData') }[availabilityFilter] ?? availabilityFilter}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('common.all')}</SelectItem>
                    <SelectItem value="phone">{t('search.phoneAvailable')}</SelectItem>
                    <SelectItem value="website">{t('search.websiteAvailable')}</SelectItem>
                    <SelectItem value="email">{t('search.emailAvailable')}</SelectItem>
                    <SelectItem value="complete">{t('search.allContactAvailable')}</SelectItem>
                    <SelectItem value="missing">{t('search.incompleteData')}</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t('common.rating')} htmlFor="lead-rating-filter">
                <Select value={ratingFilter} onValueChange={setRatingFilter}>
                  <SelectTrigger id="lead-rating-filter" className="h-11 border-slate-200 bg-white shadow-sm"><SelectValue>{ratingFilter === 'all' ? t('common.all') : ratingFilter}</SelectValue></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('common.all')}</SelectItem>
                    {ratingOptions.map((rating) => <SelectItem key={rating} value={String(rating)}>{rating}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t('common.quality')} htmlFor="lead-quality-filter">
                <Select value={qualityFilter} onValueChange={setQualityFilter}>
                  <SelectTrigger id="lead-quality-filter" className="h-11 border-slate-200 bg-white shadow-sm"><SelectValue>{qualityFilter === 'all' ? t('common.all') : leadQualityLabel(qualityFilter, t)}</SelectValue></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('common.all')}</SelectItem>
                    {qualityOptions.map((quality) => <SelectItem key={quality} value={quality}>{leadQualityLabel(quality, t)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
            </div>
          </div>
          <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80 hover:bg-slate-50/80">
                <TableHead className="px-5 text-start">{t('common.client')}</TableHead>
                <TableHead className="text-start">{t('common.activity')}</TableHead>
                <TableHead className="text-start">{t('common.city')}</TableHead>
                <TableHead className="text-start">{t('common.phone')}</TableHead>
                <TableHead className="text-start">{t('common.website')}</TableHead>
                <TableHead className="text-start">{t('common.email')}</TableHead>
                <TableHead className="text-start">{t('common.rating')}</TableHead>
                <TableHead className="px-5 text-start">{t('common.quality')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLeads.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-28 text-center text-slate-500">
                    {t('search.noFilterMatches')}
                  </TableCell>
                </TableRow>
              ) : filteredLeads.map((lead) => (
                <TableRow
                  key={lead.id}
                  role="button"
                  tabIndex={0}
                  aria-label={`${t('common.view')} ${lead.Entreprise || t('common.client')}`}
                  className="group h-16 cursor-pointer outline-none transition hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500"
                  onClick={() => window.location.assign(`/leads/${encodeURIComponent(lead.id)}`)}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      window.location.assign(`/leads/${encodeURIComponent(lead.id)}`);
                    }
                  }}
                >
                  <TableCell className="px-5 font-bold text-slate-900">
                    <ProspectNameHover lead={lead} fallbackCity={search?.Ville}>
                      <span className="transition group-hover:text-indigo-600">{compactLeadName(lead.Entreprise)}</span>
                    </ProspectNameHover>
                  </TableCell>
                  <TableCell className="text-slate-600">{capitalizeFirst(lead.Activité)}</TableCell>
                  <TableCell className="text-slate-500">{getLeadCityLabel(lead, search?.Ville)}</TableCell>
                  <TableCell className="whitespace-nowrap text-slate-600" dir="ltr">
                    {lead.Telephone ? (
                      <a
                        href={`tel:${lead.Telephone}`}
                        className="font-semibold hover:text-indigo-600"
                        onClick={(event) => event.stopPropagation()}
                      >
                        {lead.Telephone}
                      </a>
                    ) : (
                      '—'
                    )}
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    {isLeadValueAvailable(lead.Siteweb) ? (
                      <a
                        href={safeWebsiteUrl(lead.Siteweb)}
                        target="_blank"
                        rel="noreferrer"
                        className="font-semibold text-indigo-600 hover:text-indigo-800"
                        onClick={(event) => event.stopPropagation()}
                      >
                        {t('common.clickHere')}
                      </a>
                    ) : (
                      <span className="text-slate-400">{t('common.notFound')}</span>
                    )}
                  </TableCell>
                  <TableCell
                    className={
                      lead.Email_status?.toLowerCase() === 'found'
                        ? 'text-slate-600'
                        : 'text-amber-600'
                    }
                  >
                    <ProspectEmailCell lead={lead} />
                  </TableCell>
                  <TableCell className="font-bold text-slate-800">
                    {lead.LeadScore ?? 0}
                  </TableCell>
                  <TableCell className="px-5">
                    <QualityBadge quality={lead.LeadQuality} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
          </>
        )}
      </CardContent>
    </Card>
    </>
  );
}

function LeadDetailsSheet({
  lead,
  fallbackCity,
  open,
  onOpenChange,
  showInternalIdentifiers = false,
}: {
  lead: Lead | null;
  fallbackCity?: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  showInternalIdentifiers?: boolean;
}) {
  const { direction } = useI18n();
  if (!lead) return null;

  const emailStatus = (() => {
    const status = lead.Email_status?.trim().toLocaleLowerCase().replaceAll('_', ' ');
    if (status === 'found') return t('common.available');
    if (status === 'not found') return t('common.unavailable');
    if (!status || status === 'pending') return t('common.searching');
    return lead.Email_status;
  })();
  const phone = isLeadValueAvailable(lead.Telephone) ? lead.Telephone : t('common.unavailable');
  const websiteAvailable = isLeadValueAvailable(lead.Siteweb);
  const mapQuery =
    lead.Latitude !== null && lead.Longitude !== null
      ? `${lead.Latitude},${lead.Longitude}`
      : lead.Place_id
        ? `place_id:${lead.Place_id}`
        : [lead.Entreprise, lead.Adresse, lead.City].filter(Boolean).join(', ');

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="left"
        dir={direction}
        className="w-[94vw] overflow-y-auto border-r-0 bg-slate-50 p-0 sm:max-w-2xl"
      >
        <SheetHeader className="border-b border-slate-200 bg-white px-5 py-6 sm:px-7">
          <div className="flex items-start gap-3 pl-10">
            <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-indigo-50 text-indigo-600">
              <Building2 className="size-6" />
            </span>
            <div className="min-w-0">
              <SheetTitle className="text-xl font-black text-slate-950 sm:text-2xl">
                {lead.Entreprise || t('common.clientUnnamed')}
              </SheetTitle>
              <SheetDescription className="mt-1 text-sm text-slate-500">
                {capitalizeFirst(lead.Activité)} · {getLeadCityLabel(lead, fallbackCity)}
              </SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div className="space-y-5 p-4 sm:p-7">
          <div className="grid gap-3 sm:grid-cols-2">
            <LeadDetailItem label="Entreprise" value={lead.Entreprise || '—'} />
            <LeadDetailItem label="Adresse" value={lead.Adresse || '—'} wide />
            <LeadDetailItem
              label="Téléphone"
              value={
                isLeadValueAvailable(lead.Telephone) ? (
                  <a className="font-bold text-indigo-600 hover:underline" href={`tel:${lead.Telephone}`} dir="ltr">
                    {phone}
                  </a>
                ) : (
                  phone
                )
              }
            />
            <LeadDetailItem label="Email" value={<LeadEmailValue lead={lead} />} />
            <LeadDetailItem
              label="Siteweb"
              value={
                websiteAvailable ? (
                  <a className="font-bold text-indigo-600 hover:underline" href={safeWebsiteUrl(lead.Siteweb)} target="_blank" rel="noreferrer">
                    {t('common.clickHere')}
                  </a>
                ) : (
                  t('common.notFound')
                )
              }
            />
            <LeadDetailItem label="Email Status" value={emailStatus || '—'} />
          </div>

          <DetailSection title={t('lead.qualityAndRating')}>
            <LeadDetailItem label={t('search.theoreticalRating')} value={lead.LeadScore ?? '—'} />
            <LeadDetailItem label={t('lead.reputation')} value={<QualityBadge quality={lead.LeadQuality} />} />
            <LeadDetailItem label="Google Rating" value={lead.Rating ?? '—'} />
            <LeadDetailItem label="Reviews" value={lead.Reviews ?? '—'} />
          </DetailSection>

          <DetailSection title={t('lead.geography')}>
            {mapQuery ? (
              <div className="sm:col-span-2 overflow-hidden rounded-xl border border-slate-200 bg-slate-100">
                <iframe
                  title={`${t('lead.clientLocation')}: ${lead.Entreprise || t('common.client')}`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(mapQuery)}&z=16&output=embed`}
                  className="h-64 w-full border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
                <a
                  className="flex min-h-11 items-center justify-center gap-2 border-t border-slate-200 bg-white px-4 font-bold text-indigo-700 transition hover:bg-indigo-50"
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapQuery)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MapPinned className="size-4" />
                  {t('lead.openGoogleMaps')}
                </a>
              </div>
            ) : (
              <div className="sm:col-span-2 grid min-h-32 place-items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
                {t('lead.locationUnavailable')}
              </div>
            )}
          </DetailSection>

          <DetailSection title={t('lead.additionalData')}>
            <LeadDetailItem label="Activité" value={capitalizeFirst(lead.Activité)} />
            <LeadDetailItem label="City" value={getLeadCityLabel(lead, fallbackCity)} />
            <LeadDetailItem label="Claimed Business" value={lead.Claimed_Business === null ? '—' : lead.Claimed_Business ? t('common.yes') : t('common.no')} />
            <LeadDetailItem label="Client ID" value={lead.Client_id || '—'} mono />
            <LeadDetailItem label="Google Search ID" value={lead.searchgoogle_id || '—'} wide mono />
            <LeadDetailItem label="Record ID" value={lead.id} wide mono />
            {showInternalIdentifiers && (
              <>
                <LeadDetailItem label="Search ID" value={lead.Search_id ?? '—'} mono />
                <LeadDetailItem label="User ID" value={lead.User_id || '—'} mono />
              </>
            )}
          </DetailSection>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function DetailSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-3 font-black text-slate-950">{title}</h3>
      <div className="grid gap-3 sm:grid-cols-2">{children}</div>
    </section>
  );
}

function LeadDetailItem({
  label,
  value,
  wide = false,
  mono = false,
}: {
  label: string;
  value: ReactNode;
  wide?: boolean;
  mono?: boolean;
}) {
  return (
    <div className={`min-w-0 rounded-xl bg-slate-50 p-3 ${wide ? 'sm:col-span-2' : ''}`}>
      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">{label}</p>
      <div className={`mt-1 break-words text-sm font-semibold text-slate-800 ${mono ? 'font-mono text-xs' : ''}`}>
        {value}
      </div>
    </div>
  );
}

function SearchHistory({
  searches,
  loading,
  activeSearchId,
  userId,
  onOpen,
}: {
  searches: SearchRecord[];
  loading: boolean;
  activeSearchId: number | null;
  userId: string;
  onOpen: (id: number) => void;
}) {
  const [exporting, setExporting] = useState<string | null>(null);
  const [exportError, setExportError] = useState('');

  async function exportSearch(record: SearchRecord) {
    const exportKey = `${record.id}-excel`;
    setExporting(exportKey);
    setExportError('');
    const { data, error } = await supabase
      .from('Leads')
      .select('*')
      .eq('User_id', userId)
      .eq('Search_id', record.id)
      .order('LeadScore', { ascending: false });
    if (error) {
      setExportError(t('export.loadError'));
      setExporting(null);
      return;
    }
    const exportLeads = (data ?? []) as Lead[];
    if (exportLeads.length === 0) {
      setExportError(t('export.empty'));
      setExporting(null);
      return;
    }
    const context = {
      title: t('export.searchTitle', { activity: capitalizeFirst(record.Activité) }),
      city: capitalizeFirst(record.Ville),
      country: capitalizeFirst(record.Pays),
    };
    exportLeadsToExcel(exportLeads, context);
    setExporting(null);
  }

  return (
    <Card className="border-0 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] ring-0">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-lg font-black text-slate-950">{t('history.title')}</CardTitle>
        <CardDescription>{t('history.description')}</CardDescription>
        {exportError && <p className="mt-2 text-sm font-medium text-red-600">{exportError}</p>}
      </CardHeader>
      <CardContent className="px-0">
        {loading ? (
          <div className="space-y-3 p-5">
            {[1, 2, 3].map((item) => (
              <Skeleton key={item} className="h-14 w-full" />
            ))}
          </div>
        ) : searches.length === 0 ? (
          <Empty className="min-h-64">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <History />
              </EmptyMedia>
              <EmptyTitle>{t('history.emptyTitle')}</EmptyTitle>
              <EmptyDescription>{t('history.emptyDescription')}</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80 hover:bg-slate-50/80">
                <TableHead className="px-5 text-start">{t('common.activity')}</TableHead>
                <TableHead className="text-start">{t('common.location')}</TableHead>
                <TableHead className="text-start">{t('common.required')}</TableHead>
                <TableHead className="text-start">{t('common.status')}</TableHead>
                <TableHead className="px-5 text-start">{t('common.date')}</TableHead>
                <TableHead className="px-5 text-start">{t('export.download')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {searches.map((record) => (
                <TableRow
                  key={record.id}
                  role="button"
                  tabIndex={0}
                  aria-label={`${t('common.view')} ${capitalizeFirst(record.Activité)}`}
                  className={`cursor-pointer outline-none transition hover:bg-indigo-50/60 focus-visible:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-500 ${activeSearchId === record.id ? 'bg-indigo-50/50' : ''}`}
                  onClick={() => onOpen(record.id)}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      onOpen(record.id);
                    }
                  }}
                >
                  <TableCell className="px-5 font-bold">{capitalizeFirst(record.Activité)}</TableCell>
                  <TableCell className="text-slate-500">
                    {[capitalizeFirst(record.Ville), record.Pays].filter((value) => value && value !== '—').join('، ')}
                  </TableCell>
                  <TableCell>{record['Nombre de clients'] ?? 0}</TableCell>
                  <TableCell>
                    <StatusBadge search={record} />
                  </TableCell>
                  <TableCell className="px-5">
                    <Button
                      variant="ghost"
                      className="gap-2 text-indigo-600"
                      onClick={(event) => {
                        event.stopPropagation();
                        onOpen(record.id);
                      }}
                    >
                      {formatDate(record.Created_at, { dateStyle: 'medium', timeStyle: 'short' })}
                      <ChevronLeft className="rtl:rotate-0 ltr:rotate-180" />
                    </Button>
                  </TableCell>
                  <TableCell className="px-5">
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8"
                        disabled={exporting !== null}
                        onClick={(event) => {
                          event.stopPropagation();
                          void exportSearch(record);
                        }}
                      >
                        {exporting === `${record.id}-excel` ? <Spinner /> : <FileSpreadsheet className="size-3.5 text-emerald-600" />}
                        {t('export.excel')}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

function AuthScreen({ initialMode = 'login', onBack }: { initialMode?: 'login' | 'signup'; onBack?: () => void }) {
  const { direction } = useI18n();
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>(initialMode);
  const [confirmationEmail, setConfirmationEmail] = useState<string | null>(null);

  async function authenticate(mode: 'login' | 'signup', event: SyntheticEvent<HTMLFormElement, SubmitEvent>) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    const form = new FormData(event.currentTarget);
    const name = formText(form, 'name').trim();
    const email = formText(form, 'email').trim();
    const password = formText(form, 'password');
    const phone = formText(form, 'phone').trim();
    const selectedPlan = formText(form, 'requestedPlan', 'starter');
    const requestedPlan = ['professional', 'company'].includes(selectedPlan) ? selectedPlan : 'starter';
    const passwordConfirmation = formText(form, 'passwordConfirmation');

    if (mode === 'signup' && password.length < 8) {
      setSubmitting(false);
      setError(t('auth.passwordTooShort'));
      return;
    }
    if (mode === 'signup' && password !== passwordConfirmation) {
      setSubmitting(false);
      setError(t('auth.passwordMismatch'));
      return;
    }

    const result =
      mode === 'login'
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({
            email,
            password,
            options: {
              emailRedirectTo: `${window.location.origin}/`,
              data: { full_name: name, phone, requested_plan: requestedPlan },
            },
          });

    setSubmitting(false);
    if (result.error) {
      setError(result.error.message);
    } else if (mode === 'signup' && !result.data.session) {
      setConfirmationEmail(email);
    }
  }

  return (
    <main
      dir={direction}
      className="grid min-h-screen place-items-center bg-[radial-gradient(circle_at_top_right,rgba(163,230,53,0.20),transparent_32%),linear-gradient(145deg,#032e25_0%,#064e3b_58%,#022c22_100%)] p-5"
    >
      <div className="grid w-full max-w-5xl overflow-hidden rounded-[2rem] bg-white shadow-2xl shadow-slate-950/40 md:grid-cols-[1.05fr_0.95fr]">
        <section className="hidden min-h-[620px] flex-col justify-between bg-[linear-gradient(145deg,#059669,#047857_60%,#65a30d)] p-10 text-white md:flex">
          <Brand />
          <div>
            <Badge className="mb-5 bg-white/15 text-white hover:bg-white/15">
              <ShieldCheck />
              {t('auth.secure')}
            </Badge>
            <h1 className="max-w-md text-4xl font-black leading-tight">
              {t('auth.hero')}
            </h1>
            <p className="mt-5 max-w-md text-base leading-8 text-indigo-100">
              {t('auth.description')}
            </p>
          </div>
          <p className="text-sm font-bold tracking-wide text-indigo-200">LEADBOYACH</p>
        </section>

        <section className="flex min-h-[620px] flex-col justify-center p-6 sm:p-10">
          {onBack && <Button type="button" variant="ghost" className="mb-2 w-fit px-2 text-slate-500" onClick={onBack}><ArrowRight className="size-4 rtl:rotate-180" />{t('landing.backHome')}</Button>}
          <div className="mb-8 md:hidden">
            <Brand dark />
          </div>
          <div className="mb-5 flex justify-end"><LanguageSwitcher /></div>
          <h2 className="text-2xl font-black text-slate-950">{t('auth.welcome')}</h2>
          <p className="mt-2 text-sm text-slate-500">{t('auth.signInDescription')}</p>
          {confirmationEmail ? (
            <div className="mt-7 rounded-3xl border border-emerald-200 bg-emerald-50/80 p-6 text-center shadow-sm">
              <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/20">
                <Mail className="size-7" />
              </div>
              <h3 className="mt-5 text-xl font-black text-emerald-950">{t('auth.confirmationTitle')}</h3>
              <p className="mt-3 text-sm leading-7 text-emerald-900">
                {t('auth.confirmationDetails', { email: confirmationEmail })}
              </p>
              <p className="mt-2 text-xs leading-6 text-emerald-700">{t('auth.confirmationSpam')}</p>
              <Button
                type="button"
                variant="outline"
                className="mt-5 w-full border-emerald-300 bg-white text-emerald-800 hover:bg-emerald-100"
                onClick={() => {
                  setConfirmationEmail(null);
                  setAuthMode('login');
                  setError(null);
                }}
              >
                {t('auth.backToLogin')}
              </Button>
            </div>
          ) : (
            <Tabs
              className="mt-7"
              value={authMode}
              onValueChange={(value) => {
                setAuthMode(value === 'signup' ? 'signup' : 'login');
                setError(null);
              }}
            >
              <TabsList className="h-11 w-full">
                <TabsTrigger value="login">{t('auth.login')}</TabsTrigger>
                <TabsTrigger value="signup">{t('auth.signup')}</TabsTrigger>
              </TabsList>
              <TabsContent value="login">
                <AuthForm
                  mode="login"
                  submitting={submitting}
                  onSubmit={(event) => authenticate('login', event)}
                />
              </TabsContent>
              <TabsContent value="signup">
                <AuthForm
                  mode="signup"
                  submitting={submitting}
                  onSubmit={(event) => authenticate('signup', event)}
                />
              </TabsContent>
            </Tabs>
          )}
          {error && <p className="mt-4 text-sm font-medium text-red-600">{error}</p>}
        </section>
      </div>
    </main>
  );
}

function AuthForm({
  mode,
  submitting,
  onSubmit,
}: {
  mode: 'login' | 'signup';
  submitting: boolean;
  onSubmit: (event: SyntheticEvent<HTMLFormElement, SubmitEvent>) => void;
}) {
  return (
    <form className="mt-6 space-y-5" onSubmit={onSubmit}>
      {mode === 'signup' && (
        <>
        <Field label={t('auth.name')} htmlFor={`${mode}-name`}>
          <Input
            id={`${mode}-name`}
            name="name"
            type="text"
            autoComplete="name"
            className="h-11 bg-slate-50"
            placeholder={t('auth.fullName')}
            required
          />
        </Field>
        <Field label={t('auth.accountType')} htmlFor={`${mode}-requested-plan`}>
          <select id={`${mode}-requested-plan`} name="requestedPlan" defaultValue="starter" required className="h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm">
            <option value="starter">{t('auth.planStarter')}</option>
            <option value="professional">{t('auth.planProfessional')}</option>
            <option value="company">{t('auth.planCompany')}</option>
          </select>
          <p className="mt-2 text-sm leading-5 text-slate-500">{t('auth.accountTypeHelp')}</p>
        </Field>
        <Field label={t('common.phone')} htmlFor={`${mode}-phone`}>
          <Input
            id={`${mode}-phone`}
            name="phone"
            type="tel"
            autoComplete="tel"
            inputMode="tel"
            dir="ltr"
            minLength={6}
            maxLength={32}
            className="h-11 bg-slate-50 text-left"
            placeholder="+212 6 00 00 00 00"
            required
          />
        </Field>
        </>
      )}
      <Field label={t('common.email')} htmlFor={`${mode}-email`}>
        <Input
          id={`${mode}-email`}
          name="email"
          type="email"
          autoComplete="email"
          className="h-11 bg-slate-50"
          placeholder="name@example.com"
          required
        />
      </Field>
      {mode === 'signup' && (
        <Field label={t('auth.confirmPassword')} htmlFor={`${mode}-password-confirmation`}>
          <Input
            id={`${mode}-password-confirmation`}
            name="passwordConfirmation"
            type="password"
            autoComplete="new-password"
            minLength={8}
            className="h-11 bg-slate-50"
            required
          />
        </Field>
      )}
      <Field label={t('auth.password')} htmlFor={`${mode}-password`}>
        <Input
          id={`${mode}-password`}
          name="password"
          type="password"
          autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
          minLength={mode === 'signup' ? 8 : 6}
          className="h-11 bg-slate-50"
          required
        />
      </Field>
      <Button
        type="submit"
        size="lg"
        disabled={submitting}
        className="h-11 w-full bg-[#059669] font-bold hover:bg-[#047857]"
      >
        {submitting && <Spinner />}
        {mode === 'login' ? t('auth.enter') : t('auth.signup')}
      </Button>
    </form>
  );
}

function AppLoading() {
  const { direction } = useI18n();
  return (
    <main
      dir={direction}
      className="grid min-h-screen place-items-center bg-[#032e25] text-white"
    >
      <div className="flex items-center gap-3">
        <Spinner className="size-5" />
        <span className="text-sm font-semibold">{t('auth.creating')}</span>
      </div>
    </main>
  );
}

function Brand({ dark = false }: { dark?: boolean }) {
  return <button type="button" className="rounded-xl px-2 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400" onClick={() => window.location.assign('/landing')} aria-label={t('landing.home')}><ChayobLogo inverse={!dark} /></button>;
}

function NavButton({
  active,
  icon,
  onClick,
  children,
}: {
  active: boolean;
  icon: ReactNode;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <Button
      variant={active ? 'default' : 'ghost'}
      onClick={onClick}
      className={
        active
          ? 'h-11 w-full justify-start bg-white/10 px-3 text-white hover:bg-white/15'
          : 'h-11 w-full justify-start px-3 text-slate-300 hover:bg-white/10 hover:text-white'
      }
    >
      {icon}
      {children}
    </Button>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  tone,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  tone: 'indigo' | 'emerald' | 'cyan' | 'amber';
}) {
  const tones = {
    indigo: 'bg-indigo-50 text-indigo-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    cyan: 'bg-cyan-50 text-cyan-600',
    amber: 'bg-amber-50 text-amber-600',
  };

  return (
    <Card className="border-0 bg-white py-4 shadow-sm ring-1 ring-slate-200/70">
      <CardContent className="flex items-center gap-4">
        <div className={`grid size-11 place-items-center rounded-2xl [&_svg]:size-5 ${tones[tone]}`}>
          {icon}
        </div>
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="mt-1 text-2xl font-black tabular-nums text-slate-950">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ search }: { search: SearchRecord }) {
  const normalizedStatus = search.Status?.trim().toLocaleLowerCase() ?? '';
  const completed = isSuccessfulSearch(search);
  const failed = ['failed', 'error'].includes(normalizedStatus);
  return (
    <Badge
      variant="outline"
      className={
        completed
          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
          : failed
          ? 'border-red-200 bg-red-50 text-red-700'
          : 'border-amber-200 bg-amber-50 text-amber-700'
      }
    >
      {completed ? t('status.completed') : failed ? t('status.failed') : t('status.collecting')}
    </Badge>
  );
}

function QualityBadge({ quality }: { quality: string | null }) {
  const qualityTone = leadQualityTone(quality);
  const tone = qualityTone === 'positive'
    ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-50'
    : qualityTone === 'average'
      ? 'bg-amber-50 text-amber-700 hover:bg-amber-50'
      : qualityTone === 'negative'
        ? 'bg-red-50 text-red-700 hover:bg-red-50'
        : 'bg-slate-100 text-slate-700 hover:bg-slate-100';
  return (
    <Badge
      className={tone}
    >
      {leadQualityLabel(quality, t, t('quality.unclassified'))}
    </Badge>
  );
}
