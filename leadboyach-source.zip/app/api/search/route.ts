import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { apiMessage } from '@/lib/server-i18n';
import { readJsonObject } from '@/lib/request-security';

import type { Database } from '@/lib/database.types';

type SearchPayload = {
  activity?: string;
  city?: string;
  country?: string;
  count?: number;
  idempotencyKey?: string;
};

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const webhookUrl = process.env.N8N_WEBHOOK_URL;
  const webhookMethod = (process.env.N8N_WEBHOOK_METHOD || 'POST').toUpperCase();
  const authorization = request.headers.get('authorization');

  if (!supabaseUrl || !supabaseAnonKey || !webhookUrl) {
    return NextResponse.json({ error: apiMessage(request, 'إعدادات الربط غير مكتملة.') }, { status: 500 });
  }

  if (!authorization?.startsWith('Bearer ')) {
    return NextResponse.json({ error: apiMessage(request, 'يجب تسجيل الدخول أولًا.') }, { status: 401 });
  }

  const token = authorization.slice('Bearer '.length);
  const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization } },
  });

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser(token);

  if (userError || !user) {
    return NextResponse.json({ error: apiMessage(request, 'انتهت الجلسة. سجّل الدخول من جديد.') }, { status: 401 });
  }

  const { data: account, error: accountError } = await supabase
    .from('User_Plans')
    .select('*')
    .eq('User_id', user.id)
    .single();

  if (accountError || !account) {
    return NextResponse.json({ error: apiMessage(request, 'تعذر العثور على ملف حسابك.') }, { status: 403 });
  }

  if (account.Account_status !== 'active') {
    const messages = {
      pending: 'حسابك قيد المراجعة. لا يمكنك تشغيل البحث قبل تفعيله من الإدارة.',
      suspended: 'حسابك موقوف مؤقتًا. تواصل مع الإدارة لإعادة تفعيله.',
      disabled: 'هذا الحساب معطّل ولا يمكنه استخدام ميزات التطبيق.',
    } as const;
    return NextResponse.json(
      { error: apiMessage(request, messages[account.Account_status] || 'الحساب غير نشط.') },
      { status: 403 },
    );
  }

  let body: SearchPayload;
  try {
    body = await readJsonObject(request) as SearchPayload;
    if (['activity', 'city', 'country', 'idempotencyKey'].some(key => {
      const value = body[key as keyof SearchPayload];
      return value !== undefined && typeof value !== 'string';
    })) throw new Error('invalid_fields');
  } catch (error) {
    const message = error instanceof Error ? error.message : 'invalid_request';
    const translatedMessage = message === 'invalid_origin'
      ? apiMessage(request, 'تعذر التحقق من مصدر الطلب. أعد تحميل الصفحة وحاول مجددًا.')
      : apiMessage(request, 'تعذر قراءة طلب البحث. أعد تحميل الصفحة وحاول مجددًا.');
    return NextResponse.json({ error: translatedMessage }, { status: 400 });
  }
  const suppliedIdempotencyKey =
    body.idempotencyKey?.trim() || request.headers.get('idempotency-key')?.trim();

  if (suppliedIdempotencyKey && !UUID_PATTERN.test(suppliedIdempotencyKey)) {
    return NextResponse.json({ error: apiMessage(request, 'مفتاح منع التكرار غير صالح.') }, { status: 400 });
  }

  // Older cached clients may not send the new key yet. Keep those requests working
  // while current clients always provide a stable key for safe retries.
  const idempotencyKey = suppliedIdempotencyKey || crypto.randomUUID();
  const activity = body.activity?.trim();
  const city = body.city?.trim();
  const country = body.country?.trim();
  const count = Number(body.count);

  if (!activity || activity.length > 160 || !city || city.length > 120 || !country || country.length > 120 || !Number.isInteger(count) || count < 1 || count > 500) {
    return NextResponse.json({ error: apiMessage(request, 'تحقق من حقول البحث وعدد الزبائن.') }, { status: 400 });
  }

  const { data: search, error: searchError } = await supabase
    .from('Searches')
    .insert({
      User_id: user.id,
      Activité: activity,
      Ville: city,
      Pays: country,
      'Nombre de clients': count,
      Status: 'processing',
      'Total de Clients': 0,
      Idempotency_key: idempotencyKey,
    })
    .select('*')
    .single();

  if (searchError || !search) {
    if (searchError?.code === '23505') {
      const { data: existingSearch, error: existingSearchError } = await supabase
        .from('Searches')
        .select('*')
        .eq('User_id', user.id)
        .eq('Idempotency_key', idempotencyKey)
        .maybeSingle();

      if (!existingSearchError && existingSearch) {
        return NextResponse.json({ search: existingSearch, duplicate: true }, { status: 200 });
      }
    }

    if (searchError?.message.includes('MONTHLY_LIMIT_EXCEEDED')) {
      return NextResponse.json(
        { error: apiMessage(request, 'هذا البحث يتجاوز الحد الشهري لخطتك. اختر عددًا أقل أو قم بترقية الخطة.') },
        { status: 403 },
      );
    }

    if (searchError?.message.includes('ACCOUNT_NOT_ACTIVE')) {
      return NextResponse.json(
        { error: apiMessage(request, 'الحساب غير نشط ولا يمكنه تشغيل عمليات استخراج Leads.') },
        { status: 403 },
      );
    }

    return NextResponse.json(
      { error: apiMessage(request, 'تعذر إنشاء عملية البحث.') },
      { status: 500 },
    );
  }

  try {
    const workflowPayload = {
      Activite: activity,
      Ville: city,
      Pays: country,
      'Nombre de clients': String(count),
      user_id: user.id,
      search_id: String(search.id),
    };

    const targetUrl = new URL(webhookUrl);
    const requestInit: RequestInit = { method: webhookMethod, signal: AbortSignal.timeout(30000), redirect: 'error' };

    if (webhookMethod === 'GET') {
      Object.entries(workflowPayload).forEach(([key, value]) => {
        targetUrl.searchParams.set(key, value);
      });
    } else {
      requestInit.headers = { 'Content-Type': 'application/json' };
      requestInit.body = JSON.stringify(workflowPayload);
    }

    const workflowResponse = await fetch(targetUrl, requestInit);

    if (!workflowResponse.ok) {
      throw new Error(`n8n returned ${workflowResponse.status}`);
    }
  } catch {
    await supabase
      .from('Searches')
      .update({ Status: 'failed' })
      .eq('id', search.id)
      .eq('User_id', user.id);

    return NextResponse.json(
      { error: apiMessage(request, 'تم إنشاء البحث، لكن تعذر تشغيل جمع البيانات.') },
      { status: 502 },
    );
  }

  return NextResponse.json({ search, duplicate: false }, { status: 202 });
}
