import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { apiMessage } from '@/lib/server-i18n';
import { readJsonObject } from '@/lib/request-security';

import type { Database, UserPlan } from '@/lib/database.types';

const STATUSES = ['pending', 'active', 'suspended', 'disabled'] as const;
const ACTIVATION_MODES = ['automatic', 'manual'] as const;

type AccountStatus = (typeof STATUSES)[number];

function getServiceClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) return null;
  return createClient<Database>(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

function isPlanId(value: unknown): value is string {
  return typeof value === 'string' && /^[a-z0-9][a-z0-9_-]{1,31}$/.test(value);
}

function isPlanDefinition(name: unknown, monthlyLimit: unknown, description: unknown) {
  return (
    typeof name === 'string' &&
    name.trim().length >= 2 &&
    name.trim().length <= 80 &&
    Number.isInteger(Number(monthlyLimit)) &&
    Number(monthlyLimit) >= 1 &&
    Number(monthlyLimit) <= 1_000_000 &&
    (description === undefined || description === null ||
      (typeof description === 'string' && description.length <= 500))
  );
}

async function getAdmin(request: Request) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const authorization = request.headers.get('authorization');

  if (!supabaseUrl || !supabaseAnonKey) {
    return { error: NextResponse.json({ error: apiMessage(request, 'إعدادات Supabase غير مكتملة.') }, { status: 500 }) };
  }
  if (!authorization?.startsWith('Bearer ')) {
    return { error: NextResponse.json({ error: apiMessage(request, 'يجب تسجيل الدخول أولًا.') }, { status: 401 }) };
  }

  const token = authorization.slice('Bearer '.length);
  const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization } },
  });
  const { data: authData, error: authError } = await supabase.auth.getUser(token);

  if (authError || !authData.user) {
    return { error: NextResponse.json({ error: apiMessage(request, 'انتهت الجلسة. سجّل الدخول من جديد.') }, { status: 401 }) };
  }

  const { data: account, error: accountError } = await supabase
    .from('User_Plans')
    .select('*')
    .eq('User_id', authData.user.id)
    .single();

  if (accountError || account?.Role !== 'admin' || account.Account_status !== 'active') {
    return { error: NextResponse.json({ error: apiMessage(request, 'غير مصرح لك بالوصول إلى لوحة الإدارة.') }, { status: 403 }) };
  }

  return { supabase, user: authData.user, account: account as UserPlan };
}

export async function GET(request: Request) {
  const admin = await getAdmin(request);
  if ('error' in admin) return admin.error;

  const url = new URL(request.url);
  const userId = url.searchParams.get('user_id');
  const resource = url.searchParams.get('resource');

  if (resource === 'teams') {
    const [teams, members] = await Promise.all([
      admin.supabase.from('Teams').select('*').order('created_at', { ascending: false }),
      admin.supabase.from('Team_Members').select('*').order('joined_at', { ascending: true }),
    ]);
    if (teams.error || members.error) {
      return NextResponse.json(
        { error: teams.error?.message || members.error?.message || apiMessage(request, 'تعذر تحميل الفرق.') },
        { status: 500 },
      );
    }
    return NextResponse.json({ teams: teams.data ?? [], members: members.data ?? [] });
  }

  if (resource === 'searches') {
    const { data, error } = await admin.supabase
      .from('Searches')
      .select('*')
      .order('Created_at', { ascending: false })
      .limit(250);

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ searches: data ?? [] });
  }

  if (resource === 'leads') {
    const [leads, searches] = await Promise.all([
      admin.supabase
        .from('Leads')
        .select('*')
        .order('LeadScore', { ascending: false })
        .limit(500),
      admin.supabase
        .from('Searches')
        .select('*')
        .order('Created_at', { ascending: false })
        .limit(1000),
    ]);

    if (leads.error || searches.error) {
      return NextResponse.json(
        { error: leads.error?.message || searches.error?.message || apiMessage(request, 'تعذر تحميل البيانات.') },
        { status: 500 },
      );
    }
    return NextResponse.json({ leads: leads.data ?? [], searches: searches.data ?? [] });
  }

  if (userId) {
    const [searches, leads] = await Promise.all([
      admin.supabase
        .from('Searches')
        .select('*')
        .eq('User_id', userId)
        .order('Created_at', { ascending: false })
        .limit(50),
      admin.supabase
        .from('Leads')
        .select('*')
        .eq('User_id', userId)
        .order('LeadScore', { ascending: false })
        .limit(100),
    ]);

    if (searches.error || leads.error) {
      return NextResponse.json(
        { error: searches.error?.message || leads.error?.message || apiMessage(request, 'تعذر تحميل بيانات المستخدم.') },
        { status: 500 },
      );
    }
    return NextResponse.json({ searches: searches.data ?? [], leads: leads.data ?? [] });
  }

  const [users, settings, plans, upgradeRequests, searchesCount, leadsCount] = await Promise.all([
    admin.supabase
      .from('Admin_User_Overview')
      .select('*')
      .order('Created_at', { ascending: false }),
    admin.supabase.from('App_Settings').select('*').eq('id', true).single(),
    admin.supabase.from('Plans').select('*').order('Monthly_limit', { ascending: true }),
    admin.supabase.from('Plan_Upgrade_Requests').select('*').order('Created_at', { ascending: false }).limit(100),
    admin.supabase.from('Searches').select('id', { count: 'exact', head: true }),
    admin.supabase.from('Leads').select('id', { count: 'exact', head: true }),
  ]);

  if (users.error || settings.error || plans.error || upgradeRequests.error || searchesCount.error || leadsCount.error) {
    return NextResponse.json(
      {
        error:
          users.error?.message ||
          settings.error?.message ||
          plans.error?.message ||
          upgradeRequests.error?.message ||
          searchesCount.error?.message ||
          leadsCount.error?.message ||
          apiMessage(request, 'تعذر تحميل لوحة الإدارة.'),
      },
      { status: 500 },
    );
  }

  return NextResponse.json({
    users: users.data ?? [],
    settings: settings.data,
    plans: plans.data ?? [],
    upgradeRequests: upgradeRequests.data ?? [],
    summary: {
      searches: searchesCount.count ?? 0,
      leads: leadsCount.count ?? 0,
    },
  });
}

export async function PATCH(request: Request) {
  const admin = await getAdmin(request);
  if ('error' in admin) return admin.error;

  let parsed: Record<string, unknown>;
  try { parsed = await readJsonObject(request); }
  catch { return NextResponse.json({ error: 'invalid_request' }, { status: 400 }); }
  const body = parsed as {
    type?: 'user' | 'settings' | 'plan' | 'upgrade-request';
    userId?: string;
    plan?: string;
    status?: AccountStatus;
    activationMode?: (typeof ACTIVATION_MODES)[number];
    defaultPlan?: string;
    planId?: string;
    name?: string;
    monthlyLimit?: number;
    description?: string | null;
    requestId?: number;
    decision?: 'approved' | 'rejected';
  };

  if (body.type === 'upgrade-request') {
    if (!Number.isInteger(body.requestId) || !['approved', 'rejected'].includes(body.decision ?? '')) {
      return NextResponse.json({ error: apiMessage(request, 'قرار طلب الترقية غير صالح.') }, { status: 400 });
    }
    const { data, error } = await admin.supabase
      .from('Plan_Upgrade_Requests')
      .update({ Status: body.decision! })
      .eq('id', body.requestId!)
      .eq('Status', 'pending')
      .select('*')
      .single();
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ request: data });
  }

  if (body.type === 'settings') {
    if (
      !ACTIVATION_MODES.includes(body.activationMode as (typeof ACTIVATION_MODES)[number]) ||
      !isPlanId(body.defaultPlan)
    ) {
      return NextResponse.json({ error: apiMessage(request, 'إعدادات التفعيل أو الخطة غير صالحة.') }, { status: 400 });
    }

    const { data, error } = await admin.supabase
      .from('App_Settings')
      .update({ Activation_mode: body.activationMode, Default_plan: body.defaultPlan })
      .eq('id', true)
      .select('*')
      .single();

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ settings: data });
  }

  if (body.type === 'plan') {
    if (
      !isPlanId(body.planId) ||
      !isPlanDefinition(body.name, body.monthlyLimit, body.description)
    ) {
      return NextResponse.json({ error: apiMessage(request, 'بيانات الخطة غير صالحة.') }, { status: 400 });
    }

    const { data, error } = await admin.supabase
      .from('Plans')
      .update({
        Name: body.name!.trim(),
        Monthly_limit: Number(body.monthlyLimit),
        Description: body.description?.trim() || null,
      })
      .eq('id', body.planId)
      .select('*')
      .single();

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ plan: data });
  }

  if (
    body.type !== 'user' ||
    !body.userId ||
    !isPlanId(body.plan) ||
    !STATUSES.includes(body.status as AccountStatus)
  ) {
    return NextResponse.json({ error: apiMessage(request, 'بيانات المستخدم غير صالحة.') }, { status: 400 });
  }

  if (body.userId === admin.user.id && body.status !== 'active') {
    return NextResponse.json({ error: apiMessage(request, 'لا يمكنك تعطيل حساب الإدارة الذي تستخدمه الآن.') }, { status: 400 });
  }

  const { data, error } = await admin.supabase
    .from('User_Plans')
    .update({ Plan: body.plan, Account_status: body.status })
    .eq('User_id', body.userId)
    .select('*')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ user: data });
}

export async function POST(request: Request) {
  const admin = await getAdmin(request);
  if ('error' in admin) return admin.error;

  let parsed: Record<string, unknown>;
  try { parsed = await readJsonObject(request); }
  catch { return NextResponse.json({ error: 'invalid_request' }, { status: 400 }); }
  const body = parsed as {
    type?: 'plan' | 'team' | 'user';
    id?: string;
    name?: string;
    email?: string;
    password?: string;
    plan?: string;
    status?: AccountStatus;
    confirmEmail?: boolean;
    monthlyLimit?: number;
    description?: string | null;
    supervisorId?: string;
    memberIds?: string[];
  };

  if (body.type === 'user') {
    const email = body.email?.trim().toLocaleLowerCase();
    const name = body.name?.trim();
    if (
      !email || !/^\S+@\S+\.\S+$/.test(email) || !name || name.length < 2 || name.length > 100 ||
      typeof body.password !== 'string' || body.password.length < 8 || body.password.length > 128 ||
      !isPlanId(body.plan) || !STATUSES.includes(body.status as AccountStatus)
    ) {
      return NextResponse.json({ error: apiMessage(request, 'بيانات المستخدم الجديد غير صالحة.') }, { status: 400 });
    }

    const service = getServiceClient();
    if (!service) {
      return NextResponse.json({ error: apiMessage(request, 'أضف SUPABASE_SERVICE_ROLE_KEY إلى متغيرات الخادم لإدارة حسابات المستخدمين.') }, { status: 503 });
    }

    const { data: created, error: createError } = await service.auth.admin.createUser({
      email,
      password: body.password,
      email_confirm: body.confirmEmail !== false,
      user_metadata: { full_name: name },
    });
    if (createError || !created.user) {
      return NextResponse.json({ error: createError?.message || apiMessage(request, 'تعذر إنشاء المستخدم.') }, { status: 400 });
    }

    const { error: profileError } = await service
      .from('User_Plans')
      .update({ Name: name, Email: email, Plan: body.plan, Account_status: body.status })
      .eq('User_id', created.user.id);
    if (profileError) {
      await service.auth.admin.deleteUser(created.user.id);
      return NextResponse.json({ error: profileError.message }, { status: 400 });
    }
    return NextResponse.json({ userId: created.user.id }, { status: 201 });
  }

  if (body.type === 'team') {
    if (
      typeof body.name !== 'string' || body.name.trim().length < 2 || body.name.trim().length > 100 ||
      typeof body.supervisorId !== 'string' || !Array.isArray(body.memberIds) ||
      body.memberIds.some((id) => typeof id !== 'string')
    ) {
      return NextResponse.json({ error: apiMessage(request, 'بيانات الفريق غير صالحة.') }, { status: 400 });
    }

    const memberIds = Array.from(new Set([...body.memberIds, body.supervisorId]));
    const [accounts, assigned] = await Promise.all([
      admin.supabase.from('User_Plans').select('User_id, Account_status').in('User_id', memberIds),
      admin.supabase.from('Team_Members').select('*').in('user_id', memberIds),
    ]);
    if (accounts.error || assigned.error || accounts.data?.length !== memberIds.length || accounts.data.some((item) => item.Account_status !== 'active')) {
      return NextResponse.json({ error: apiMessage(request, 'يجب أن تكون حسابات جميع أعضاء الفريق نشطة.') }, { status: 400 });
    }
    if (assigned.data?.some((item) => !body.id || item.team_id !== body.id)) {
      return NextResponse.json({ error: apiMessage(request, 'أحد الأعضاء منضم إلى فريق آخر بالفعل.') }, { status: 409 });
    }

    let teamId = body.id;
    if (teamId) {
      const { data, error } = await admin.supabase.from('Teams').update({ name: body.name.trim(), supervisor_id: body.supervisorId }).eq('id', teamId).select('id').maybeSingle();
      if (error || !data) return NextResponse.json({ error: apiMessage(request, 'تعذر العثور على الفريق.') }, { status: 404 });
      const { error: deleteError } = await admin.supabase.from('Team_Members').delete().eq('team_id', teamId).not('user_id', 'in', `(${memberIds.join(',')})`);
      if (deleteError) return NextResponse.json({ error: apiMessage(request, 'تعذر حفظ الفريق.') }, { status: 400 });
    } else {
      const { data, error } = await admin.supabase.from('Teams').insert({ name: body.name.trim(), supervisor_id: body.supervisorId }).select('id').single();
      if (error) return NextResponse.json({ error: apiMessage(request, 'تعذر حفظ الفريق.') }, { status: 400 });
      teamId = data.id;
    }

    const { error: memberError } = await admin.supabase.from('Team_Members').upsert(memberIds.map((userId) => ({ team_id: teamId!, user_id: userId })), { onConflict: 'team_id,user_id' });
    if (memberError) {
      if (!body.id) await admin.supabase.from('Teams').delete().eq('id', teamId);
      return NextResponse.json({ error: apiMessage(request, 'تعذر حفظ الفريق.') }, { status: 400 });
    }
    return NextResponse.json({ teamId }, { status: body.id ? 200 : 201 });
  }

  if (!isPlanId(body.id) || !isPlanDefinition(body.name, body.monthlyLimit, body.description)) {
    return NextResponse.json(
      { error: apiMessage(request, 'استخدم رمزًا إنجليزيًا صغيرًا وحدًا شهريًا بين 1 و1,000,000.') },
      { status: 400 },
    );
  }

  const { data, error } = await admin.supabase
    .from('Plans')
    .insert({
      id: body.id,
      Name: body.name!.trim(),
      Monthly_limit: Number(body.monthlyLimit),
      Description: body.description?.trim() || null,
    })
    .select('*')
    .single();

  if (error) {
    const message = error.code === '23505' ? apiMessage(request, 'رمز الخطة مستخدم مسبقًا.') : error.message;
    return NextResponse.json({ error: message }, { status: 400 });
  }

  return NextResponse.json({ plan: data }, { status: 201 });
}

export async function DELETE(request: Request) {
  const admin = await getAdmin(request);
  if ('error' in admin) return admin.error;

  const url = new URL(request.url);
  const userId = url.searchParams.get('user_id');
  if (userId) {
    if (userId === admin.user.id) {
      return NextResponse.json({ error: apiMessage(request, 'لا يمكنك حذف حساب الإدارة الذي تستخدمه الآن.') }, { status: 400 });
    }
    const service = getServiceClient();
    if (!service) {
      return NextResponse.json({ error: apiMessage(request, 'أضف SUPABASE_SERVICE_ROLE_KEY إلى متغيرات الخادم لإدارة حسابات المستخدمين.') }, { status: 503 });
    }
    const { error } = await service.auth.admin.deleteUser(userId);
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ success: true });
  }

  const teamId = url.searchParams.get('team_id');
  if (!teamId) return NextResponse.json({ error: apiMessage(request, 'تعذر العثور على الفريق.') }, { status: 400 });

  const { error } = await admin.supabase.from('Teams').delete().eq('id', teamId);
  if (error) return NextResponse.json({ error: apiMessage(request, 'تعذر حذف الفريق.') }, { status: 400 });
  return NextResponse.json({ success: true });
}
