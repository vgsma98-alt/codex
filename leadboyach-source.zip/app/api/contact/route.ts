import { createClient } from '@supabase/supabase-js';
import { readJsonObject } from '@/lib/request-security';

const recipient = 'ayoubchachdi87@gmail.com';
const copyRecipient = 'contact@leadboyach.com';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function text(value: unknown, max: number) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

export async function POST(request: Request) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !supabaseKey) return Response.json({ error: 'service_unavailable' }, { status: 503 });
  let input: Record<string, unknown>;
  try {
    input = await readJsonObject(request);
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_request');
  } catch {
    return Response.json({ error: 'invalid_request' }, { status: 400 });
  }

  if (text(input.website, 200)) return Response.json({ ok: true }, { status: 201 });

  const payload = {
    name: text(input.name, 100),
    email: text(input.email, 254).toLowerCase(),
    phone: text(input.phone, 32) || null,
    company: text(input.company, 120) || null,
    subject: text(input.subject, 160),
    message: text(input.message, 4000),
    language: ['ar', 'fr', 'en'].includes(text(input.language, 2)) ? text(input.language, 2) : 'fr',
  };

  const headerText = payload.subject + payload.name;
  if (payload.name.length < 2 || !emailPattern.test(payload.email) || payload.subject.length < 2 || /[\r\n]/.test(headerText) || headerText.includes(String.fromCharCode(0)) || payload.message.length < 10 || (payload.phone && payload.phone.length < 6)) {
    return Response.json({ error: 'invalid_fields' }, { status: 422 });
  }

  // Reserve before sending. The database trigger limits even direct API inserts.
  const supabase = createClient(supabaseUrl, supabaseKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { error } = await supabase.from('Contact_Messages').insert({ ...payload, delivery_status: 'requested' });
  if (error) return Response.json({ error: 'submission_unavailable' }, { status: error.message.includes('CONTACT_RATE_LIMIT') ? 429 : 500 });

  let deliveryStatus: 'requested' | 'failed' = 'failed';
  try {
    const response = await fetch(`https://formsubmit.co/ajax/${recipient}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Referer: 'https://leadboyach.com/contact',
        Origin: 'https://leadboyach.com',
      },
      signal: AbortSignal.timeout(15000),
      body: JSON.stringify({
        name: payload.name,
        email: payload.email,
        phone: payload.phone ?? '—',
        company: payload.company ?? '—',
        subject: payload.subject,
        message: payload.message,
        _subject: `[LEADBOYACH] ${payload.subject}`,
        _cc: copyRecipient,
        _replyto: payload.email,
        _template: 'table',
        _captcha: 'false',
        _url: 'https://leadboyach.com/contact',
      }),
    });
    const result = await response.json() as { success?: boolean | string };
    deliveryStatus = response.ok && (result.success === true || result.success === 'true') ? 'requested' : 'failed';
  } catch {
    deliveryStatus = 'failed';
  }

  if (deliveryStatus === 'failed') return Response.json({ error: 'delivery_failed', saved: true }, { status: 502 });
  return Response.json({ ok: true }, { status: 201 });
}
