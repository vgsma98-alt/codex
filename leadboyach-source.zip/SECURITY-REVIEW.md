# Security review — 2026-09-16

## Implemented

- Patched React/RSC, Vite, esbuild, sharp, image-size, ws and undici; exact versions and lockfile committed. Full dependency audit reports zero known advisories at review time.
- Bounded JSON request streams (16 KiB), rejected malformed/non-object bodies and cross-origin browser JSON writes, validated search field types and lengths.
- HTTP(S)-only website links, excluding embedded credentials; unsafe scraped URL schemes no longer actionable.
- Security response headers: nosniff, conservative CSP (object/base restrictions), referrer and permissions policies; API responses configured no-store. CSP is intentionally partial to preserve existing runtime integrations.
- Contact submission reservation before email dispatch; database-enforced maximum 3 submissions per email per hour and 120 site-wide per hour. Database normalizes email and overrides client timestamps. These limits reduce abuse but do not replace a bot challenge/WAF; different-email distributed abuse remains possible.
- Revoked unnecessary execution rights on private privileged trigger functions. No authorization is derived from editable signup metadata.

## Verified

- Valid JSON accepted; null, arrays, malformed and oversized JSON rejected.
- javascript/data URLs and credential-bearing URLs rejected; HTTPS accepted.
- Database contact rate limit rejects the fourth same-email insertion; test rolled back.
- Authenticated unrecognized user cannot read Leads/Searches; ordinary user cannot self-promote or change plan; tests rolled back.
- All public tables have RLS enabled; reviewed owner/admin/team access policies.
- Signup plan requests retain Starter/user, 30 prospects; paid plan remains pending until admin approval.
- Build succeeds after updates. No service-role/private-key indicators found in app/components/lib/public scan.

## Requires owner action / remaining scope

- Supabase advisor still flags leaked-password protection disabled. Enable in Auth settings on the project owner's account. SMTP and confirmation-email branding remain separately pending from the earlier task.
- Configure Supabase signup/login rate limits and CAPTCHA, and administrator MFA through owner dashboard; not enabled or verified here.
- A full penetration test, infrastructure/WAF review, domain/email authentication (SPF/DKIM/DMARC), incident history and secret rotation assessment are outside this bounded code/database review.
- FormSubmit email destination must be activated by recipient. Contact delivery status `requested` means accepted/reserved submission, not proven email delivery; failures return `saved: true`.
- No claim that the application is free of all vulnerabilities. Re-run dependency/database checks after changes.
