export async function readJsonObject(request: Request, limit = 16384): Promise<Record<string, unknown>> {
  const origin = request.headers.get('origin');
  if (origin && !isAllowedOrigin(request, origin)) throw new Error('invalid_origin');
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new Error('invalid_request');
  const reader = request.body?.getReader();
  if (!reader) throw new Error('invalid_request');
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) { await reader.cancel(); throw new Error('request_too_large'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  const value = JSON.parse(new TextDecoder().decode(bytes));
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('invalid_request');
  return value;
}

function firstForwardedValue(value: string | null) {
  return value?.split(',')[0]?.trim().toLowerCase() || '';
}

function normalizeHost(value: string) {
  return value.trim().toLowerCase().replace(/\.$/, '');
}

function trustedProxyHosts() {
  return new Set(
    (process.env.VINEXT_TRUSTED_HOSTS || '')
      .split(',')
      .map(normalizeHost)
      .filter(Boolean),
  );
}

export function isAllowedOrigin(request: Request, origin: string) {
  let originUrl: URL;
  try {
    originUrl = new URL(origin);
  } catch {
    return false;
  }

  const requestUrl = new URL(request.url);
  if (originUrl.origin === requestUrl.origin) return true;

  const forwardedHost = normalizeHost(firstForwardedValue(request.headers.get('x-forwarded-host')));
  const forwardedProto = firstForwardedValue(request.headers.get('x-forwarded-proto'));
  if (!forwardedHost || !trustedProxyHosts().has(forwardedHost)) return false;
  if (originUrl.host.toLowerCase() !== forwardedHost) return false;

  return !forwardedProto || originUrl.protocol === `${forwardedProto}:`;
}
