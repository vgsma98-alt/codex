type ApiLanguage = 'ar' | 'fr' | 'en';

const translations: Record<string, { en: string; fr: string }> = {
  'إعدادات الربط غير مكتملة.': { en: 'Integration settings are incomplete.', fr: 'Les paramètres d’intégration sont incomplets.' },
  'إعدادات Supabase غير مكتملة.': { en: 'Supabase settings are incomplete.', fr: 'Les paramètres Supabase sont incomplets.' },
  'تعذر التحقق من مصدر الطلب. أعد تحميل الصفحة وحاول مجددًا.': { en: 'The request origin could not be verified. Reload the page and try again.', fr: 'L’origine de la requête n’a pas pu être vérifiée. Rechargez la page et réessayez.' },
  'تعذر قراءة طلب البحث. أعد تحميل الصفحة وحاول مجددًا.': { en: 'The search request could not be read. Reload the page and try again.', fr: 'La requête de recherche n’a pas pu être lue. Rechargez la page et réessayez.' },
  'يجب تسجيل الدخول أولًا.': { en: 'Please sign in first.', fr: 'Veuillez d’abord vous connecter.' },
  'انتهت الجلسة. سجّل الدخول من جديد.': { en: 'Your session has expired. Please sign in again.', fr: 'Votre session a expiré. Veuillez vous reconnecter.' },
  'تعذر العثور على ملف حسابك.': { en: 'Your account profile could not be found.', fr: 'Votre profil de compte est introuvable.' },
  'الحساب غير نشط.': { en: 'The account is not active.', fr: 'Le compte n’est pas actif.' },
  'حسابك قيد المراجعة. لا يمكنك تشغيل البحث قبل تفعيله من الإدارة.': { en: 'Your account is pending review. Search is unavailable until an administrator activates it.', fr: 'Votre compte est en attente de validation. La recherche sera disponible après activation par un administrateur.' },
  'حسابك موقوف مؤقتًا. تواصل مع الإدارة لإعادة تفعيله.': { en: 'Your account is temporarily suspended. Contact an administrator to reactivate it.', fr: 'Votre compte est temporairement suspendu. Contactez un administrateur pour le réactiver.' },
  'هذا الحساب معطّل ولا يمكنه استخدام ميزات التطبيق.': { en: 'This account is disabled and cannot use application features.', fr: 'Ce compte est désactivé et ne peut pas utiliser les fonctionnalités de l’application.' },
  'مفتاح منع التكرار غير صالح.': { en: 'The idempotency key is invalid.', fr: 'La clé d’idempotence est invalide.' },
  'تحقق من حقول البحث وعدد الزبائن.': { en: 'Check the search fields and lead count.', fr: 'Vérifiez les champs de recherche et le nombre de prospects.' },
  'هذا البحث يتجاوز الحد الشهري لخطتك. اختر عددًا أقل أو قم بترقية الخطة.': { en: 'This search exceeds your monthly plan limit. Choose a smaller number or upgrade your plan.', fr: 'Cette recherche dépasse le quota mensuel de votre forfait. Réduisez le nombre ou changez de forfait.' },
  'الحساب غير نشط ولا يمكنه تشغيل عمليات استخراج Leads.': { en: 'This account is not active and cannot run lead searches.', fr: 'Ce compte n’est pas actif et ne peut pas lancer de recherche de prospects.' },
  'تعذر إنشاء عملية البحث.': { en: 'Unable to create the search.', fr: 'Impossible de créer la recherche.' },
  'تم إنشاء البحث، لكن تعذر تشغيل جمع البيانات.': { en: 'The search was created, but data collection could not start.', fr: 'La recherche a été créée, mais la collecte des données n’a pas pu démarrer.' },
  'غير مصرح لك بالوصول إلى لوحة الإدارة.': { en: 'You are not authorized to access the admin dashboard.', fr: 'Vous n’êtes pas autorisé à accéder au tableau de bord administrateur.' },
  'تعذر تحميل البيانات.': { en: 'Unable to load data.', fr: 'Impossible de charger les données.' },
  'تعذر تحميل بيانات المستخدم.': { en: 'Unable to load user data.', fr: 'Impossible de charger les données de l’utilisateur.' },
  'تعذر تحميل لوحة الإدارة.': { en: 'Unable to load the admin dashboard.', fr: 'Impossible de charger le tableau de bord administrateur.' },
  'إعدادات التفعيل أو الخطة غير صالحة.': { en: 'The activation or default plan settings are invalid.', fr: 'Les paramètres d’activation ou du forfait par défaut sont invalides.' },
  'بيانات الخطة غير صالحة.': { en: 'The plan data is invalid.', fr: 'Les données du forfait sont invalides.' },
  'بيانات المستخدم غير صالحة.': { en: 'The user data is invalid.', fr: 'Les données de l’utilisateur sont invalides.' },
  'لا يمكنك تعطيل حساب الإدارة الذي تستخدمه الآن.': { en: 'You cannot disable the administrator account you are currently using.', fr: 'Vous ne pouvez pas désactiver le compte administrateur que vous utilisez.' },
  'استخدم رمزًا إنجليزيًا صغيرًا وحدًا شهريًا بين 1 و1,000,000.': { en: 'Use a lowercase ASCII code and a monthly limit between 1 and 1,000,000.', fr: 'Utilisez un code ASCII en minuscules et un quota mensuel compris entre 1 et 1 000 000.' },
  'رمز الخطة مستخدم مسبقًا.': { en: 'This plan code is already in use.', fr: 'Ce code de forfait est déjà utilisé.' },
  'تعذر تحميل الفرق.': { en: 'Unable to load teams.', fr: 'Impossible de charger les équipes.' },
  'بيانات الفريق غير صالحة.': { en: 'The team data is invalid.', fr: 'Les données de l’équipe sont invalides.' },
  'أحد الأعضاء منضم إلى فريق آخر بالفعل.': { en: 'One of the selected members already belongs to another team.', fr: 'Un des membres sélectionnés appartient déjà à une autre équipe.' },
  'يجب أن تكون حسابات جميع أعضاء الفريق نشطة.': { en: 'All team member accounts must be active.', fr: 'Tous les comptes des membres doivent être actifs.' },
  'تعذر العثور على الفريق.': { en: 'The team could not be found.', fr: 'L’équipe est introuvable.' },
  'تعذر حفظ الفريق.': { en: 'Unable to save the team.', fr: 'Impossible d’enregistrer l’équipe.' },
  'تعذر حذف الفريق.': { en: 'Unable to delete the team.', fr: 'Impossible de supprimer l’équipe.' },
};

export function apiMessage(request: Request, arabicMessage: string) {
  const requested = request.headers.get('x-app-language');
  const language: ApiLanguage = requested === 'en' || requested === 'ar' ? requested : 'fr';
  return language === 'ar' ? arabicMessage : translations[arabicMessage]?.[language] ?? arabicMessage;
}
