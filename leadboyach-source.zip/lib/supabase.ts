import { createClient } from '@supabase/supabase-js';

import type { Database } from './database.types';

const supabaseUrl =
  import.meta.env.NEXT_PUBLIC_SUPABASE_URL ||
  'https://qsrxsddxffyjwgrxbqru.supabase.co';
const supabaseAnonKey =
  import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFzcnhzZGR4ZmZ5andncnhicXJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgzMzczMTMsImV4cCI6MjEwMzkxMzMxM30.v_C_lvdVWJnzF8yTFgN12W3FgkIfkysKIBFWbXwbv-U';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase public configuration is missing.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
