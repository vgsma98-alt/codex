'use client';

import type { Lead } from '@/lib/database.types';
import { t } from '@/lib/i18n';
import { leadQualityLabel } from '@/lib/lead-quality';

type ExportContext = {
  title: string;
  city?: string | null;
  country?: string | null;
};

const columns: Array<{ label: string; value: (lead: Lead) => string | number }> = [
  { label: 'common.client', value: (lead) => lead.Entreprise?.trim() || '—' },
  { label: 'common.activity', value: (lead) => lead.Activité?.trim() || '—' },
  { label: 'common.city', value: (lead) => lead.City?.trim() || '—' },
  { label: 'common.address', value: (lead) => lead.Adresse?.trim() || '—' },
  { label: 'common.phone', value: (lead) => lead.Telephone?.trim() || '—' },
  { label: 'common.email', value: (lead) => lead.Email?.trim() || '—' },
  { label: 'common.website', value: (lead) => lead.Siteweb?.trim() || '—' },
  { label: 'search.theoreticalRating', value: (lead) => lead.LeadScore ?? '—' },
  { label: 'search.clientReputation', value: (lead) => leadQualityLabel(lead.LeadQuality, t) },
  { label: 'lead.googleRating', value: (lead) => lead.Rating ?? '—' },
  { label: 'common.reviews', value: (lead) => lead.Reviews ?? '—' },
];

function safeFileName(value: string) {
  const normalized = value.trim().replace(/[<>:"/\\|?*\p{Cc}]+/gu, '-').replace(/\s+/g, '-');
  return normalized.slice(0, 80) || 'prospects';
}

function escapeXml(value: string | number) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportLeadsToExcel(leads: Lead[], context: ExportContext) {
  const headerCells = columns.map((column) => `<Cell ss:StyleID="Header"><Data ss:Type="String">${escapeXml(t(column.label))}</Data></Cell>`).join('');
  const dataRows = leads.map((lead) => `<Row>${columns.map((column) => {
    const value = column.value(lead);
    const isNumber = typeof value === 'number';
    return `<Cell><Data ss:Type="${isNumber ? 'Number' : 'String'}">${escapeXml(value)}</Data></Cell>`;
  }).join('')}</Row>`).join('');
  const metadata = [context.city, context.country].filter(Boolean).join(' - ');
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles><Style ss:ID="Default"><Alignment ss:Vertical="Center"/><Font ss:FontName="Arial" ss:Size="11"/></Style><Style ss:ID="Title"><Font ss:Bold="1" ss:Size="16" ss:Color="#FFFFFF"/><Interior ss:Color="#4F46E5" ss:Pattern="Solid"/></Style><Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#111827" ss:Pattern="Solid"/></Style></Styles>
  <Worksheet ss:Name="Prospects"><Table>
    <Column ss:Width="220"/><Column ss:Width="120"/><Column ss:Width="100"/><Column ss:Width="260"/><Column ss:Width="115"/><Column ss:Width="190"/><Column ss:Width="190"/><Column ss:Width="100"/><Column ss:Width="120"/><Column ss:Width="90"/><Column ss:Width="80"/>
    <Row ss:Height="28"><Cell ss:StyleID="Title" ss:MergeAcross="10"><Data ss:Type="String">${escapeXml(context.title)}</Data></Cell></Row>
    ${metadata ? `<Row><Cell ss:MergeAcross="10"><Data ss:Type="String">${escapeXml(metadata)}</Data></Cell></Row>` : ''}
    <Row><Cell ss:MergeAcross="10"><Data ss:Type="String">${escapeXml(t('export.generatedCount', { count: leads.length }))}</Data></Cell></Row>
    <Row>${headerCells}</Row>${dataRows}
  </Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>4</SplitHorizontal><TopRowBottomPane>4</TopRowBottomPane><ActivePane>2</ActivePane></WorksheetOptions></Worksheet>
</Workbook>`;
  downloadBlob(new Blob([`\uFEFF${xml}`], { type: 'application/vnd.ms-excel;charset=utf-8' }), `${safeFileName(context.title)}.xls`);
}
