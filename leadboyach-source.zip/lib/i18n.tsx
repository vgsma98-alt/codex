'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import ar from '@/locales/ar/common';
import en from '@/locales/en/common';
import fr from '@/locales/fr/common';
import landingAr from '@/locales/ar/landing';
import landingEn from '@/locales/en/landing';
import landingFr from '@/locales/fr/landing';
import { supabase } from '@/lib/supabase';

export type Language = 'ar' | 'fr' | 'en';
export type Direction = 'rtl' | 'ltr';
type Variables = Record<string, string | number>;

const dictionaries: Record<Language, Record<string, string>> = {
  ar: { ...ar, ...landingAr },
  fr: { ...fr, ...landingFr },
  en: { ...en, ...landingEn },
};
const localeByLanguage: Record<Language, string> = { ar: 'ar-MA', fr: 'fr-FR', en: 'en-GB' };
let activeLanguage: Language = 'fr';

function isLanguage(value: unknown): value is Language {
  return value === 'ar' || value === 'fr' || value === 'en';
}

export function t(key: string, variables: Variables = {}) {
  const template = dictionaries[activeLanguage][key] ?? dictionaries.fr[key] ?? key;
  return template.replace(/\{\{(\w+)\}\}/g, (_, name: string) => String(variables[name] ?? ''));
}

export function getLocale() {
  return localeByLanguage[activeLanguage];
}

export function getLanguage() { return activeLanguage; }

export function formatNumber(value: number, options?: Intl.NumberFormatOptions) {
  return new Intl.NumberFormat(getLocale(), options).format(value);
}

export function formatDate(value: string | number | Date, options?: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat(getLocale(), options ?? { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

type I18nValue = {
  language: Language;
  direction: Direction;
  locale: string;
  setLanguage: (language: Language) => Promise<void>;
};

const I18nContext = createContext<I18nValue | null>(null);

function applyDocumentLanguage(language: Language) {
  activeLanguage = language;
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('fr');

  useEffect(() => {
    let cancelled = false;

    async function loadAccountPreference() {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      const { data: profile } = await supabase
        .from('User_Plans')
        .select('Preferred_language')
        .eq('User_id', data.user.id)
        .maybeSingle();
      if (!cancelled && isLanguage(profile?.Preferred_language)) {
        window.localStorage.setItem('preferred_language', profile.Preferred_language);
        applyDocumentLanguage(profile.Preferred_language);
        setLanguageState(profile.Preferred_language);
      }
    }

    async function loadPreference() {
      const stored = window.localStorage.getItem('preferred_language');
      const localLanguage = isLanguage(stored) ? stored : 'fr';
      applyDocumentLanguage(localLanguage);
      if (!cancelled) setLanguageState(localLanguage);
      await loadAccountPreference();
    }

    void loadPreference();
    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        window.setTimeout(() => void loadAccountPreference(), 0);
      }
    });
    return () => { cancelled = true; listener.subscription.unsubscribe(); };
  }, []);

  const setLanguage = useCallback(async (nextLanguage: Language) => {
    window.localStorage.setItem('preferred_language', nextLanguage);
    applyDocumentLanguage(nextLanguage);
    setLanguageState(nextLanguage);

    const { data } = await supabase.auth.getUser();
    if (data.user) {
      await supabase
        .from('User_Plans')
        .update({ Preferred_language: nextLanguage })
        .eq('User_id', data.user.id);
    }
  }, []);

  const value = useMemo<I18nValue>(() => ({
    language,
    direction: language === 'ar' ? 'rtl' : 'ltr',
    locale: localeByLanguage[language],
    setLanguage,
  }), [language, setLanguage]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used inside I18nProvider');
  return { ...context, t, formatNumber, formatDate };
}
