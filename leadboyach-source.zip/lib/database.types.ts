export type Lead = {
  Activité: string | null;
  Adresse: string | null;
  City: string | null;
  Claimed_Business: boolean | null;
  Client_id: string | null;
  Email: string | null;
  Email_status: string | null;
  Entreprise: string | null;
  id: string;
  Latitude: number | null;
  LeadQuality: string | null;
  LeadScore: number | null;
  Longitude: number | null;
  Place_id: string | null;
  Rating: number | null;
  Reviews: number | null;
  Search_id: number | null;
  searchgoogle_id: string | null;
  Siteweb: string | null;
  Telephone: string | null;
  User_id: string | null;
  pipeline_stage_id: string | null;
  pipeline_version: number;
  estimated_value: number;
  pipeline_updated_at: string | null;
  pipeline_updated_by: string | null;
  created_at: string;
  lead_source: string;
  commercial_id: string | null;
  stage_entered_at: string;
  final_deal_amount: number | null;
  deal_closed_at: string | null;
  loss_reason: string | null;
};

export type PipelineStage = {
  id: string;
  user_id: string;
  slug: string;
  name: string;
  position: number;
  color: string;
  is_terminal: boolean;
  created_at: string;
  updated_at: string;
};

export type LeadAuditLog = {
  id: number;
  lead_id: string;
  search_id: number | null;
  user_id: string | null;
  event_type: 'created' | 'stage_changed' | 'owner_changed' | 'lead_updated';
  previous_stage: string | null;
  new_stage: string | null;
  previous_stage_id: string | null;
  new_stage_id: string | null;
  changed_fields: string[];
  old_values: Record<string, unknown>;
  new_values: Record<string, unknown>;
  changed_by: string | null;
  changed_at: string;
  version: number;
};

export type Team = {
  id: string;
  name: string;
  supervisor_id: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export type TeamMember = {
  team_id: string;
  user_id: string;
  added_by: string | null;
  joined_at: string;
};

export type SearchRecord = {
  Activité: string | null;
  Created_at: string;
  id: number;
  Idempotency_key: string | null;
  'Nombre de clients': number | null;
  Pays: string | null;
  Status: string | null;
  'Total de Clients': number | null;
  User_id: string | null;
  Ville: string | null;
};

export type UserPlan = {
  User_id: string;
  Name: string | null;
  Email: string | null;
  Phone: string | null;
  Plan: string;
  Role: 'user' | 'admin';
  Account_status: 'pending' | 'active' | 'suspended' | 'disabled';
  Monthly_limit: number;
  Created_at: string;
  Updated_at: string;
  Last_activity: string | null;
  Preferred_language: 'fr' | 'en' | 'ar';
};

export type PlanUpgradeRequest = {
  id: number;
  User_id: string;
  Requested_plan: 'professional' | 'company';
  Status: 'pending' | 'approved' | 'rejected';
  Reviewed_by: string | null;
  Reviewed_at: string | null;
  Created_at: string;
  Updated_at: string;
};

export type AppSettings = {
  id: boolean;
  Activation_mode: 'automatic' | 'manual';
  Default_plan: string;
  Updated_at: string;
  Updated_by: string | null;
};

export type PlanDefinition = {
  id: string;
  Name: string;
  Monthly_limit: number;
  Description: string | null;
  Created_at: string;
  Updated_at: string;
};

export type AdminUserOverview = {
  User_id: string;
  Name: string | null;
  Email: string | null;
  Plan: UserPlan['Plan'];
  Account_status: UserPlan['Account_status'];
  Monthly_limit: number;
  Monthly_usage: number;
  Created_at: string;
  Last_activity: string | null;
};

export type Database = {
  public: {
    Tables: {
      Leads: {
        Row: Lead;
        Insert: Partial<Lead>;
        Update: Partial<Lead>;
        Relationships: [];
      };
      Searches: {
        Row: SearchRecord;
        Insert: Partial<SearchRecord>;
        Update: Partial<SearchRecord>;
        Relationships: [];
      };
      User_Plans: {
        Row: UserPlan;
        Insert: Partial<UserPlan>;
        Update: Partial<UserPlan>;
        Relationships: [];
      };
      App_Settings: {
        Row: AppSettings;
        Insert: Partial<AppSettings>;
        Update: Partial<AppSettings>;
        Relationships: [];
      };
      Plans: {
        Row: PlanDefinition;
        Insert: Partial<PlanDefinition>;
        Update: Partial<PlanDefinition>;
        Relationships: [];
      };
      Plan_Upgrade_Requests: {
        Row: PlanUpgradeRequest;
        Insert: Pick<PlanUpgradeRequest, 'User_id' | 'Requested_plan'> & Partial<PlanUpgradeRequest>;
        Update: Pick<PlanUpgradeRequest, 'Status'> & Partial<PlanUpgradeRequest>;
        Relationships: [];
      };
      Pipeline_Stages: {
        Row: PipelineStage;
        Insert: Partial<PipelineStage> & Pick<PipelineStage, 'user_id' | 'slug' | 'name' | 'position'>;
        Update: Partial<PipelineStage>;
        Relationships: [];
      };
      Lead_Audit_Log: {
        Row: LeadAuditLog;
        Insert: Partial<LeadAuditLog>;
        Update: Partial<LeadAuditLog>;
        Relationships: [];
      };
      Teams: {
        Row: Team;
        Insert: Partial<Team> & Pick<Team, 'name' | 'supervisor_id'>;
        Update: Partial<Team>;
        Relationships: [];
      };
      Team_Members: {
        Row: TeamMember;
        Insert: Partial<TeamMember> & Pick<TeamMember, 'team_id' | 'user_id'>;
        Update: Partial<TeamMember>;
        Relationships: [];
      };
    };
    Views: {
      Admin_User_Overview: {
        Row: AdminUserOverview;
        Relationships: [];
      };
    };
    Functions: {
      get_sales_analytics: {
        Args: {
          p_period?: string;
          p_stage_id?: string | null;
          p_source?: string | null;
          p_city?: string | null;
          p_commercial_id?: string | null;
          p_custom_start?: string | null;
          p_custom_end?: string | null;
          p_granularity?: string;
        };
        Returns: Record<string, unknown>;
      };
    };
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};
