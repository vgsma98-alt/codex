type Translate = (key: string, variables?: Record<string, string | number>) => string;

const QUALITY_KEYS: Record<string, string> = {
  excellent: 'quality.excellent',
  ممتاز: 'quality.excellent',
  'very good': 'quality.veryGood',
  'très bon': 'quality.veryGood',
  'tres bon': 'quality.veryGood',
  'جيد جدا': 'quality.veryGood',
  good: 'quality.good',
  bon: 'quality.good',
  جيد: 'quality.good',
  average: 'quality.average',
  medium: 'quality.average',
  moyen: 'quality.average',
  متوسط: 'quality.average',
  poor: 'quality.poor',
  bad: 'quality.poor',
  faible: 'quality.poor',
  ضعيف: 'quality.poor',
};

export function normalizeLeadQuality(value?: string | null) {
  return value
    ?.trim()
    .toLocaleLowerCase()
    .replaceAll('_', ' ')
    .replaceAll('-', ' ')
    .replace(/[ًٌٍَُِّْ]/g, '')
    .replace(/\s+/g, ' ');
}

export function leadQualityLabel(value: string | null | undefined, translate: Translate, emptyLabel = '—') {
  const normalized = normalizeLeadQuality(value);
  if (!normalized) return emptyLabel;
  const key = QUALITY_KEYS[normalized];
  return key ? translate(key) : value!.trim();
}

export function leadQualityTone(value?: string | null) {
  const key = QUALITY_KEYS[normalizeLeadQuality(value) ?? ''];
  if (key === 'quality.excellent' || key === 'quality.veryGood' || key === 'quality.good') return 'positive' as const;
  if (key === 'quality.average') return 'average' as const;
  if (key === 'quality.poor') return 'negative' as const;
  return 'neutral' as const;
}
