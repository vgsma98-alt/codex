$ErrorActionPreference = 'Stop'
$vpsRoot = Split-Path -Parent $PSScriptRoot
$vpsRootPrefix = ([System.IO.Path]::GetFullPath($vpsRoot)).TrimEnd('\') + '\'
$vpsOutput = Join-Path $vpsRoot 'outputs'
New-Item -ItemType Directory -Path $vpsOutput -Force | Out-Null
$vpsArchive = Join-Path $vpsOutput ('LEADBOYACH-VPS-source-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.zip')
$vpsPaths = @('app','components','hooks','lib','locales','public','supabase','scripts','deploy',
  'package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.json','next-env.d.ts',
  'vite-env.d.ts','next.config.ts','proxy.ts','vite.config.ts','Dockerfile','.dockerignore',
  'compose.yaml','README.md','SECURITY-REVIEW.md','.openai/hosting.json')
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$vpsZip = [System.IO.Compression.ZipFile]::Open($vpsArchive, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($vpsRelative in $vpsPaths) {
    $vpsPath = Join-Path $vpsRoot $vpsRelative
    if (!(Test-Path -LiteralPath $vpsPath)) { continue }
    $vpsFiles = if (Test-Path -LiteralPath $vpsPath -PathType Container) {
      Get-ChildItem -LiteralPath $vpsPath -Recurse -File
    } else { Get-Item -LiteralPath $vpsPath }
    foreach ($vpsFile in $vpsFiles) {
      if ($vpsFile.Name -like '.env*' -or $vpsFile.Extension -in @('.pem','.key','.log')) { continue }
      $vpsFilePath = [System.IO.Path]::GetFullPath($vpsFile.FullName)
      if (!$vpsFilePath.StartsWith($vpsRootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to package a file outside the project root: $vpsFilePath"
      }
      $vpsEntry = $vpsFilePath.Substring($vpsRootPrefix.Length).Replace('\','/')
      [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($vpsZip, $vpsFile.FullName, $vpsEntry) | Out-Null
    }
  }
} finally { $vpsZip.Dispose() }
Write-Output $vpsArchive
