import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
const action = process.argv[2];
if (!['build', 'start'].includes(action)) throw new Error('Use build or start');
if (action === 'start' && !existsSync('dist/standalone/server.js')) {
  throw new Error('Run pnpm build:vps before pnpm start:vps');
}
const entry = action === 'build'
  ? join(dirname(fileURLToPath(import.meta.resolve('vinext'))), 'cli.js')
  : 'dist/standalone/server.js';
const child = spawn(process.execPath, [entry, ...(action === 'build' ? ['build'] : [])], {
  stdio: 'inherit',
  env: { ...process.env, DEPLOY_TARGET: 'vps' },
});
child.on('error', (error) => { console.error(error.message); process.exitCode = 1; });
child.on('exit', (code) => { process.exitCode = code ?? 1; });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => child.kill(signal));
