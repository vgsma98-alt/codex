create index if not exists "Plan_Upgrade_Requests_Reviewed_by_idx"
  on public."Plan_Upgrade_Requests" ("Reviewed_by")
  where "Reviewed_by" is not null;

drop policy if exists "Admins can manage user accounts" on public."User_Plans";
drop policy if exists "Users can update own preferred language" on public."User_Plans";

create policy "Users or admins can update accounts"
on public."User_Plans"
for update
to authenticated
using (
  (select private.is_admin())
  or "User_id" = (select auth.uid())
)
with check (
  (
    (select private.is_admin())
    and (
      "User_id" <> (select auth.uid())
      or ("Role" = 'admin' and "Account_status" = 'active')
    )
  )
  or "User_id" = (select auth.uid())
);
