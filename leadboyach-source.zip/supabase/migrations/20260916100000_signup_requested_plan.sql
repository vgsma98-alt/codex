create or replace function private.handle_new_user_plan()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  configured_mode text;
begin
  select s."Activation_mode"
  into configured_mode
  from public."App_Settings" s
  where s.id = true;

  insert into public."User_Plans" (
    "User_id", "Name", "Email", "Phone", "Plan", "Role", "Account_status", "Created_at"
  )
  values (
    new.id,
    coalesce(
      nullif(new.raw_user_meta_data ->> 'full_name', ''),
      nullif(new.raw_user_meta_data ->> 'name', ''),
      split_part(coalesce(new.email, ''), '@', 1)
    ),
    new.email,
    nullif(btrim(new.raw_user_meta_data ->> 'phone'), ''),
    'starter',
    'user',
    case when coalesce(configured_mode, 'automatic') = 'manual'
      then 'pending' else 'active' end,
    coalesce(new.created_at, now())
  )
  on conflict ("User_id") do update
  set
    "Name" = excluded."Name",
    "Email" = excluded."Email",
    "Phone" = excluded."Phone";

  -- A requested paid plan is only a pending request, never an entitlement.
  if new.raw_user_meta_data ->> 'requested_plan' in ('professional', 'company') then
    insert into public."Plan_Upgrade_Requests" ("User_id", "Requested_plan", "Status")
    values (new.id, new.raw_user_meta_data ->> 'requested_plan', 'pending')
    on conflict ("User_id") where "Status" = 'pending' do nothing;
  end if;

  return new;
end;
$$;
