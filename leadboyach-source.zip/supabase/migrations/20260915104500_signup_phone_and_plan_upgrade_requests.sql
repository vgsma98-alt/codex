alter table public."User_Plans"
  add column if not exists "Phone" text;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'User_Plans_Phone_length_check'
      and conrelid = 'public."User_Plans"'::regclass
  ) then
    alter table public."User_Plans"
      add constraint "User_Plans_Phone_length_check"
      check ("Phone" is null or char_length(btrim("Phone")) between 6 and 32);
  end if;
end $$;

update public."Plans"
set "Monthly_limit" = 30
where id = 'starter' and "Monthly_limit" <> 30;

update public."App_Settings"
set "Default_plan" = 'starter'
where id = true and "Default_plan" <> 'starter';

create or replace function private.handle_new_user_plan()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  configured_mode text;
begin
  select s."Activation_mode"
  into configured_mode
  from public."App_Settings" s
  where s.id = true;

  insert into public."User_Plans" (
    "User_id", "Name", "Email", "Phone", "Plan", "Role", "Account_status", "Created_at"
  )
  values (
    new.id,
    coalesce(
      nullif(new.raw_user_meta_data ->> 'full_name', ''),
      nullif(new.raw_user_meta_data ->> 'name', ''),
      split_part(coalesce(new.email, ''), '@', 1)
    ),
    new.email,
    nullif(btrim(new.raw_user_meta_data ->> 'phone'), ''),
    'starter',
    'user',
    case when coalesce(configured_mode, 'automatic') = 'manual'
      then 'pending' else 'active' end,
    coalesce(new.created_at, now())
  )
  on conflict ("User_id") do update
  set
    "Name" = excluded."Name",
    "Email" = excluded."Email",
    "Phone" = excluded."Phone";

  return new;
end;
$$;

create table if not exists public."Plan_Upgrade_Requests" (
  id bigint generated always as identity primary key,
  "User_id" uuid not null references auth.users(id) on delete cascade,
  "Requested_plan" text not null references public."Plans"(id),
  "Status" text not null default 'pending',
  "Reviewed_by" uuid references auth.users(id) on delete set null,
  "Reviewed_at" timestamp with time zone,
  "Created_at" timestamp with time zone not null default now(),
  "Updated_at" timestamp with time zone not null default now(),
  constraint "Plan_Upgrade_Requests_plan_check"
    check ("Requested_plan" in ('professional', 'company')),
  constraint "Plan_Upgrade_Requests_status_check"
    check ("Status" in ('pending', 'approved', 'rejected'))
);

create index if not exists "Plan_Upgrade_Requests_User_id_idx"
  on public."Plan_Upgrade_Requests" ("User_id");

create index if not exists "Plan_Upgrade_Requests_Requested_plan_idx"
  on public."Plan_Upgrade_Requests" ("Requested_plan");

create unique index if not exists "Plan_Upgrade_Requests_one_pending_per_user_idx"
  on public."Plan_Upgrade_Requests" ("User_id")
  where "Status" = 'pending';

alter table public."Plan_Upgrade_Requests" enable row level security;

drop policy if exists "Users can read own upgrade requests" on public."Plan_Upgrade_Requests";
create policy "Users can read own upgrade requests"
on public."Plan_Upgrade_Requests"
for select
to authenticated
using (
  "User_id" = (select auth.uid())
  or (select private.is_admin())
);

drop policy if exists "Users can request a plan upgrade" on public."Plan_Upgrade_Requests";
create policy "Users can request a plan upgrade"
on public."Plan_Upgrade_Requests"
for insert
to authenticated
with check (
  "User_id" = (select auth.uid())
  and "Requested_plan" in ('professional', 'company')
  and "Status" = 'pending'
  and "Reviewed_by" is null
  and "Reviewed_at" is null
  and exists (
    select 1
    from public."User_Plans" up
    where up."User_id" = (select auth.uid())
      and up."Account_status" = 'active'
      and up."Plan" <> "Requested_plan"
  )
);

drop policy if exists "Admins can review upgrade requests" on public."Plan_Upgrade_Requests";
create policy "Admins can review upgrade requests"
on public."Plan_Upgrade_Requests"
for update
to authenticated
using ((select private.is_admin()))
with check ((select private.is_admin()));

grant select, insert, update on table public."Plan_Upgrade_Requests" to authenticated;
grant usage, select on sequence public."Plan_Upgrade_Requests_id_seq" to authenticated;
revoke delete, truncate, references, trigger on table public."Plan_Upgrade_Requests" from anon, authenticated;

create or replace function private.review_plan_upgrade_request()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not private.is_admin((select auth.uid())) then
    raise exception using errcode = '42501', message = 'ADMIN_REQUIRED';
  end if;

  if old."Status" <> 'pending' then
    raise exception using errcode = '23514', message = 'REQUEST_ALREADY_REVIEWED';
  end if;

  if new."User_id" is distinct from old."User_id"
     or new."Requested_plan" is distinct from old."Requested_plan"
     or new."Created_at" is distinct from old."Created_at" then
    raise exception using errcode = '42501', message = 'IMMUTABLE_REQUEST_FIELDS';
  end if;

  if new."Status" not in ('approved', 'rejected') then
    raise exception using errcode = '23514', message = 'INVALID_REVIEW_STATUS';
  end if;

  new."Reviewed_by" := (select auth.uid());
  new."Reviewed_at" := now();
  new."Updated_at" := now();

  if new."Status" = 'approved' then
    update public."User_Plans"
    set "Plan" = new."Requested_plan"
    where "User_id" = new."User_id";

    if not found then
      raise exception using errcode = '23503', message = 'USER_PLAN_NOT_FOUND';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists review_plan_upgrade_request on public."Plan_Upgrade_Requests";
create trigger review_plan_upgrade_request
before update on public."Plan_Upgrade_Requests"
for each row execute function private.review_plan_upgrade_request();

create or replace function private.protect_user_plan_fields()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null
     and not private.is_admin((select auth.uid()))
     and (
       new."User_id" is distinct from old."User_id"
       or new."Plan" is distinct from old."Plan"
       or new."Monthly_limit" is distinct from old."Monthly_limit"
       or new."Role" is distinct from old."Role"
       or new."Account_status" is distinct from old."Account_status"
     ) then
    raise exception using errcode = '42501', message = 'PROTECTED_ACCOUNT_FIELDS';
  end if;

  return new;
end;
$$;

drop trigger if exists protect_user_plan_fields on public."User_Plans";
create trigger protect_user_plan_fields
before update on public."User_Plans"
for each row execute function private.protect_user_plan_fields();

