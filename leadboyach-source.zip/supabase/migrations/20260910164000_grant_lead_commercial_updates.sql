-- Commercial outcome fields are intentionally editable from the authenticated UI.
-- Row ownership and administrator access remain enforced by the existing RLS policy.
grant update (final_deal_amount, loss_reason, commercial_id)
on table public."Leads"
to authenticated;

notify pgrst, 'reload schema';
