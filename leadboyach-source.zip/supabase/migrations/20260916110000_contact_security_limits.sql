create or replace function private.limit_contact_submissions()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.email := lower(btrim(new.email));
  new.created_at := now();
  if new.email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' then
    raise exception using errcode = '23514', message = 'INVALID_CONTACT_EMAIL';
  end if;
  perform pg_advisory_xact_lock(91744001);
  if (select count(*) from public."Contact_Messages" where created_at > now() - interval '1 hour') >= 120
    or (select count(*) from public."Contact_Messages" where email = new.email and created_at > now() - interval '1 hour') >= 3 then
    raise exception using errcode = 'P0001', message = 'CONTACT_RATE_LIMIT';
  end if;
  return new;
end;
$$;
revoke all on function private.limit_contact_submissions() from public, anon, authenticated;
create trigger limit_contact_submissions before insert on public."Contact_Messages"
for each row execute function private.limit_contact_submissions();
revoke all on function private.touch_app_settings() from public, anon, authenticated;
revoke all on function private.review_plan_upgrade_request() from public, anon, authenticated;
