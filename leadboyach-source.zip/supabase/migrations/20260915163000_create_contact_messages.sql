create table if not exists public."Contact_Messages" (
  id bigint generated always as identity primary key,
  name text not null check (char_length(btrim(name)) between 2 and 100),
  email text not null check (char_length(btrim(email)) between 5 and 254),
  phone text check (phone is null or char_length(btrim(phone)) between 6 and 32),
  company text check (company is null or char_length(btrim(company)) <= 120),
  subject text not null check (char_length(btrim(subject)) between 2 and 160),
  message text not null check (char_length(btrim(message)) between 10 and 4000),
  language text not null default 'fr' check (language in ('ar', 'fr', 'en')),
  delivery_status text not null default 'pending' check (delivery_status in ('pending', 'requested', 'failed')),
  created_at timestamptz not null default now()
);

alter table public."Contact_Messages" enable row level security;
revoke all on table public."Contact_Messages" from anon, authenticated;
grant insert on table public."Contact_Messages" to anon, authenticated;
grant usage, select on sequence public."Contact_Messages_id_seq" to anon, authenticated;

drop policy if exists "contact_messages_public_insert" on public."Contact_Messages";
create policy "contact_messages_public_insert"
on public."Contact_Messages"
for insert
to anon, authenticated
with check (
  delivery_status in ('requested', 'failed')
  and char_length(btrim(name)) between 2 and 100
  and char_length(btrim(email)) between 5 and 254
  and char_length(btrim(subject)) between 2 and 160
  and char_length(btrim(message)) between 10 and 4000
);

create index if not exists contact_messages_created_at_idx
on public."Contact_Messages" (created_at desc);

comment on table public."Contact_Messages" is
  'Public contact requests submitted from the LEADBOYACH landing page.';
