alter table public."Leads"
  add column if not exists created_at timestamptz,
  add column if not exists lead_source text,
  add column if not exists commercial_id uuid,
  add column if not exists stage_entered_at timestamptz,
  add column if not exists final_deal_amount numeric,
  add column if not exists deal_closed_at timestamptz,
  add column if not exists loss_reason text;

update public."Leads" l
set created_at = coalesce(
  l.created_at,
  (select s."Created_at" from public."Searches" s where s.id = l."Search_id"),
  (select min(a.changed_at) from public."Lead_Audit_Log" a where a.lead_id = l.id and a.event_type = 'created'),
  l.pipeline_updated_at,
  now()
),
lead_source = coalesce(nullif(trim(l.lead_source), ''), 'search'),
commercial_id = coalesce(l.commercial_id, l."User_id"),
stage_entered_at = coalesce(
  l.stage_entered_at,
  (select max(a.changed_at) from public."Lead_Audit_Log" a where a.lead_id = l.id and a.event_type in ('created', 'stage_changed') and a.new_stage_id = l.pipeline_stage_id),
  l.pipeline_updated_at,
  l.created_at,
  now()
);

alter table public."Leads"
  alter column created_at set default now(),
  alter column created_at set not null,
  alter column lead_source set default 'search',
  alter column lead_source set not null,
  alter column stage_entered_at set default now(),
  alter column stage_entered_at set not null;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'Leads_estimated_value_nonnegative') then
    alter table public."Leads" add constraint "Leads_estimated_value_nonnegative" check (estimated_value >= 0);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'Leads_final_deal_amount_nonnegative') then
    alter table public."Leads" add constraint "Leads_final_deal_amount_nonnegative" check (final_deal_amount is null or final_deal_amount >= 0);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'Leads_loss_reason_allowed') then
    alter table public."Leads" add constraint "Leads_loss_reason_allowed" check (
      loss_reason is null or loss_reason in ('price_too_high','not_interested','competitor_chosen','insufficient_budget','no_response','project_cancelled','bad_timing','other')
    );
  end if;
end $$;

create index if not exists "Leads_user_created_idx" on public."Leads" ("User_id", created_at desc);
create index if not exists "Leads_user_source_idx" on public."Leads" ("User_id", lead_source);
create index if not exists "Leads_user_city_idx" on public."Leads" ("User_id", "City");
create index if not exists "Leads_user_commercial_idx" on public."Leads" ("User_id", commercial_id);
create index if not exists "Leads_user_stage_entered_idx" on public."Leads" ("User_id", pipeline_stage_id, stage_entered_at);
create index if not exists "Lead_Audit_Log_user_event_changed_idx" on public."Lead_Audit_Log" (user_id, event_type, changed_at desc);

create or replace function private.prepare_lead_pipeline()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_slug text;
begin
  if tg_op = 'INSERT' then
    if new.pipeline_stage_id is null and new."User_id" is not null then
      select ps.id into new.pipeline_stage_id from public."Pipeline_Stages" ps
      where ps.user_id = new."User_id" order by ps.position, ps.id limit 1;
    end if;
    new.pipeline_version := coalesce(new.pipeline_version, 1);
    new.estimated_value := coalesce(new.estimated_value, 0);
    new.pipeline_updated_at := coalesce(new.pipeline_updated_at, now());
    new.created_at := coalesce(new.created_at, now());
    new.lead_source := coalesce(nullif(trim(new.lead_source), ''), 'search');
    new.commercial_id := coalesce(new.commercial_id, new."User_id");
    new.stage_entered_at := coalesce(new.stage_entered_at, now());
    return new;
  end if;

  if new.pipeline_stage_id is distinct from old.pipeline_stage_id then
    new.stage_entered_at := now();
    select ps.slug into next_slug from public."Pipeline_Stages" ps where ps.id = new.pipeline_stage_id;
    if next_slug in ('won', 'lost') then new.deal_closed_at := now(); else new.deal_closed_at := null; end if;
    if next_slug <> 'lost' then new.loss_reason := null; end if;
  else
    new.stage_entered_at := old.stage_entered_at;
    new.deal_closed_at := old.deal_closed_at;
  end if;

  if new.pipeline_stage_id is distinct from old.pipeline_stage_id
     or new.estimated_value is distinct from old.estimated_value
     or new.final_deal_amount is distinct from old.final_deal_amount
     or new.loss_reason is distinct from old.loss_reason
     or new.commercial_id is distinct from old.commercial_id then
    new.pipeline_version := old.pipeline_version + 1;
    new.pipeline_updated_at := now();
    new.pipeline_updated_by := (select auth.uid());
  else
    new.pipeline_version := old.pipeline_version;
    new.pipeline_updated_at := old.pipeline_updated_at;
    new.pipeline_updated_by := old.pipeline_updated_by;
  end if;
  return new;
end;
$$;

create or replace function private.audit_lead_changes()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  changed text[] := '{}'::text[];
  old_stage_name text;
  new_stage_name text;
  event_name text := 'lead_updated';
begin
  if tg_op = 'INSERT' then
    select ps.name into new_stage_name from public."Pipeline_Stages" ps where ps.id = new.pipeline_stage_id;
    insert into public."Lead_Audit_Log" (lead_id, search_id, user_id, event_type, previous_stage, new_stage, previous_stage_id, new_stage_id, changed_fields, old_values, new_values, changed_by, version)
    values (new.id, new."Search_id", new."User_id", 'created', null, new_stage_name, null, new.pipeline_stage_id, array['created'], '{}'::jsonb,
      jsonb_build_object('Entreprise',new."Entreprise",'pipeline_stage_id',new.pipeline_stage_id,'estimated_value',new.estimated_value,'final_deal_amount',new.final_deal_amount,'loss_reason',new.loss_reason),
      (select auth.uid()), new.pipeline_version);
    return new;
  end if;

  if new.pipeline_stage_id is distinct from old.pipeline_stage_id then changed := array_append(changed, 'pipeline_stage'); event_name := 'stage_changed'; end if;
  if new.estimated_value is distinct from old.estimated_value then changed := array_append(changed, 'estimated_value'); end if;
  if new.final_deal_amount is distinct from old.final_deal_amount then changed := array_append(changed, 'final_deal_amount'); end if;
  if new.loss_reason is distinct from old.loss_reason then changed := array_append(changed, 'loss_reason'); end if;
  if new.commercial_id is distinct from old.commercial_id then changed := array_append(changed, 'commercial_id'); end if;
  if new."User_id" is distinct from old."User_id" then changed := array_append(changed, 'owner'); event_name := 'owner_changed'; end if;
  if new."Entreprise" is distinct from old."Entreprise" then changed := array_append(changed, 'Entreprise'); end if;
  if new."Adresse" is distinct from old."Adresse" then changed := array_append(changed, 'Adresse'); end if;
  if new."Telephone" is distinct from old."Telephone" then changed := array_append(changed, 'Telephone'); end if;
  if new."Email" is distinct from old."Email" then changed := array_append(changed, 'Email'); end if;
  if new."Siteweb" is distinct from old."Siteweb" then changed := array_append(changed, 'Siteweb'); end if;
  if new."City" is distinct from old."City" then changed := array_append(changed, 'City'); end if;
  if cardinality(changed) = 0 then return new; end if;

  select ps.name into old_stage_name from public."Pipeline_Stages" ps where ps.id = old.pipeline_stage_id;
  select ps.name into new_stage_name from public."Pipeline_Stages" ps where ps.id = new.pipeline_stage_id;
  insert into public."Lead_Audit_Log" (lead_id, search_id, user_id, event_type, previous_stage, new_stage, previous_stage_id, new_stage_id, changed_fields, old_values, new_values, changed_by, version)
  values (new.id, new."Search_id", new."User_id", event_name, old_stage_name, new_stage_name, old.pipeline_stage_id, new.pipeline_stage_id, changed,
    jsonb_build_object('Entreprise',old."Entreprise",'Adresse',old."Adresse",'Telephone',old."Telephone",'Email',old."Email",'Siteweb',old."Siteweb",'City',old."City",'owner',old."User_id",'pipeline_stage_id',old.pipeline_stage_id,'estimated_value',old.estimated_value,'final_deal_amount',old.final_deal_amount,'loss_reason',old.loss_reason,'commercial_id',old.commercial_id),
    jsonb_build_object('Entreprise',new."Entreprise",'Adresse',new."Adresse",'Telephone',new."Telephone",'Email',new."Email",'Siteweb',new."Siteweb",'City',new."City",'owner',new."User_id",'pipeline_stage_id',new.pipeline_stage_id,'estimated_value',new.estimated_value,'final_deal_amount',new.final_deal_amount,'loss_reason',new.loss_reason,'commercial_id',new.commercial_id),
    (select auth.uid()), new.pipeline_version);
  return new;
end;
$$;

create or replace function public.get_sales_analytics(
  p_period text default '30d',
  p_stage_id uuid default null,
  p_source text default null,
  p_city text default null,
  p_commercial_id uuid default null,
  p_custom_start timestamptz default null,
  p_custom_end timestamptz default null,
  p_granularity text default 'day'
)
returns jsonb
language plpgsql
stable
security invoker
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_start timestamptz;
  v_end timestamptz := now();
  v_prev_start timestamptz;
  v_prev_end timestamptz;
  v_step interval;
  v_trunc text;
  result jsonb;
begin
  if v_uid is null then raise exception 'authentication required' using errcode = '42501'; end if;
  case p_period
    when 'today' then v_start := date_trunc('day', now());
    when '7d' then v_start := now() - interval '7 days';
    when '30d' then v_start := now() - interval '30 days';
    when 'month' then v_start := date_trunc('month', now());
    when 'previous_month' then v_start := date_trunc('month', now()) - interval '1 month'; v_end := date_trunc('month', now());
    when '3m' then v_start := now() - interval '3 months';
    when 'year' then v_start := date_trunc('year', now());
    when 'custom' then v_start := coalesce(p_custom_start, now() - interval '30 days'); v_end := least(coalesce(p_custom_end, now()), now());
    else v_start := now() - interval '30 days';
  end case;
  if v_end <= v_start then raise exception 'invalid analytics period'; end if;
  v_prev_end := v_start;
  v_prev_start := v_start - (v_end - v_start);
  v_trunc := case when p_granularity in ('day','week','month') then p_granularity else 'day' end;
  v_step := case v_trunc when 'month' then interval '1 month' when 'week' then interval '1 week' else interval '1 day' end;

  with stage_order as (
    select ps.*, lead(ps.id) over (order by ps.position) as next_stage_id
    from public."Pipeline_Stages" ps where ps.user_id = v_uid
  ), all_user_leads as (
    select l.*, ps.slug as current_slug, ps.position as current_position, ps.is_terminal,
      coalesce(q.position, 2147483647) as qualified_position
    from public."Leads" l
    left join stage_order ps on ps.id = l.pipeline_stage_id
    left join stage_order q on q.slug = 'qualified'
    where l."User_id" = v_uid
      and (p_stage_id is null or l.pipeline_stage_id = p_stage_id)
      and (p_source is null or l.lead_source = p_source)
      and (p_city is null or l."City" = p_city)
      and (p_commercial_id is null or l.commercial_id = p_commercial_id)
  ), current_leads as (
    select * from all_user_leads where created_at >= v_start and created_at < v_end
  ), previous_leads as (
    select * from all_user_leads where created_at >= v_prev_start and created_at < v_prev_end
  ), relevant_history as (
    select a.*, lead(a.changed_at) over (partition by a.lead_id order by a.changed_at, a.id) as next_changed_at
    from public."Lead_Audit_Log" a join current_leads l on l.id = a.lead_id
    where a.user_id = v_uid and a.event_type in ('created','stage_changed')
  ), reached as (
    select new_stage_id as stage_id, count(distinct lead_id)::int as reached_count from relevant_history where new_stage_id is not null group by new_stage_id
  ), duration_stats as (
    select h.new_stage_id as stage_id,
      avg(extract(epoch from (case when h.next_changed_at is null and l.pipeline_stage_id = h.new_stage_id then now() else h.next_changed_at end - h.changed_at)) / 86400.0) as average_days
    from relevant_history h join current_leads l on l.id = h.lead_id
    where h.new_stage_id is not null and (h.next_changed_at is not null or l.pipeline_stage_id = h.new_stage_id)
    group by h.new_stage_id
  ), stage_metrics as (
    select s.id, s.slug, s.name, s.position, s.color, s.is_terminal, s.next_stage_id,
      (select count(*)::int from current_leads l where l.pipeline_stage_id=s.id) as current_count,
      case when (select count(*) from current_leads) > 0 then round((select count(*) from current_leads l where l.pipeline_stage_id=s.id) * 100.0 / (select count(*) from current_leads), 1) else 0 end as share,
      coalesce(r.reached_count,(select count(*)::int from current_leads l where l.pipeline_stage_id=s.id)) as reached_count,
      coalesce(ds.average_days,(select avg(extract(epoch from (now()-l.stage_entered_at))/86400.0) from current_leads l where l.pipeline_stage_id=s.id)) as average_days,
      (select count(distinct h.lead_id)::int from relevant_history h where h.previous_stage_id=s.id and h.new_stage_id=s.next_stage_id) as passed_count,
      (select count(distinct h.lead_id)::int from relevant_history h where h.previous_stage_id=s.id and h.new_stage_id in (select id from stage_order where slug='lost')) as lost_from_count,
      (select coalesce(sum(l.estimated_value) filter (where l.estimated_value>0),0) from current_leads l where l.pipeline_stage_id=s.id) as estimated_value,
      (select coalesce(sum(l.final_deal_amount) filter (where l.final_deal_amount is not null),0) from current_leads l where l.pipeline_stage_id=s.id and s.slug='won') as final_value,
      (select coalesce(sum(l.estimated_value) filter (where l.estimated_value>0),0) from current_leads l where l.pipeline_stage_id=s.id and s.slug='lost') as lost_value,
      (select count(*)::int from current_leads l where l.pipeline_stage_id=s.id and not s.is_terminal and l.stage_entered_at < now() - (case when s.slug='negotiation' then interval '15 days' else interval '7 days' end)) as blocked_count
    from stage_order s
    left join reached r on r.stage_id=s.id
    left join duration_stats ds on ds.stage_id=s.id
  ), current_kpi as (
    select count(*)::int total,
      count(*) filter (where current_slug='won')::int won,
      count(*) filter (where current_slug='lost')::int lost,
      coalesce(sum(final_deal_amount) filter (where current_slug='won' and final_deal_amount is not null),0) generated_revenue,
      coalesce(sum(estimated_value) filter (where not coalesce(is_terminal,false) and current_position >= qualified_position and estimated_value>0),0) potential_revenue,
      coalesce(sum(estimated_value) filter (where current_slug='lost' and estimated_value>0),0) lost_revenue
    from current_leads
  ), previous_kpi as (
    select count(*)::int total,
      count(*) filter (where current_slug='won')::int won,
      coalesce(sum(final_deal_amount) filter (where current_slug='won' and final_deal_amount is not null),0) generated_revenue,
      coalesce(sum(estimated_value) filter (where not coalesce(is_terminal,false) and current_position >= qualified_position and estimated_value>0),0) potential_revenue
    from previous_leads
  ), buckets as (
    select generate_series(date_trunc(v_trunc,v_start), date_trunc(v_trunc,v_end - interval '1 microsecond'), v_step) as bucket
  ), trend as (
    select b.bucket,
      (select count(*)::int from current_leads l where date_trunc(v_trunc,l.created_at)=b.bucket) as new_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='contacted') as contacted_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='qualified') as qualified_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='proposal') as proposal_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='negotiation') as negotiation_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='won') as won_count,
      (select count(distinct h.lead_id)::int from relevant_history h join stage_order s on s.id=h.new_stage_id where date_trunc(v_trunc,h.changed_at)=b.bucket and s.slug='lost') as lost_count,
      (select coalesce(sum(l.final_deal_amount),0) from current_leads l where l.current_slug='won' and l.deal_closed_at is not null and date_trunc(v_trunc,l.deal_closed_at)=b.bucket) as generated_revenue
    from buckets b
    order by b.bucket
  )
  select jsonb_build_object(
    'period',jsonb_build_object('start',v_start,'end',v_end,'previous_start',v_prev_start,'previous_end',v_prev_end,'granularity',v_trunc),
    'kpis',jsonb_build_object(
      'total',c.total,'won',c.won,'lost',c.lost,'conversion_rate',case when c.total>0 then round(c.won*100.0/c.total,1) else 0 end,
      'generated_revenue',c.generated_revenue,'potential_revenue',c.potential_revenue,'lost_revenue',c.lost_revenue,
      'average_won_value',case when c.won>0 then round(c.generated_revenue/c.won,2) else null end,
      'previous',jsonb_build_object('total',p.total,'won',p.won,'conversion_rate',case when p.total>0 then round(p.won*100.0/p.total,1) else null end,'generated_revenue',p.generated_revenue,'potential_revenue',p.potential_revenue)
    ),
    'stages',(select coalesce(jsonb_agg(jsonb_build_object(
      'id',m.id,'slug',m.slug,'name',m.name,'position',m.position,'color',m.color,'is_terminal',m.is_terminal,
      'current_count',m.current_count,'share',m.share,'reached_count',m.reached_count,'average_days',round(m.average_days::numeric,1),
      'passage_rate',case when m.reached_count>0 then round(m.passed_count*100.0/m.reached_count,1) else null end,
      'dropoff_rate',case when m.reached_count>0 then round(m.lost_from_count*100.0/m.reached_count,1) else null end,
      'passed_count',m.passed_count,'lost_from_count',m.lost_from_count,'estimated_value',m.estimated_value,'final_value',m.final_value,'lost_value',m.lost_value,'blocked_count',m.blocked_count
    ) order by m.position),'[]'::jsonb) from stage_metrics m),
    'trend',(select coalesce(jsonb_agg(jsonb_build_object('bucket',bucket,'new',new_count,'contacted',contacted_count,'qualified',qualified_count,'proposal',proposal_count,'negotiation',negotiation_count,'won',won_count,'lost',lost_count,'generated_revenue',generated_revenue) order by bucket),'[]'::jsonb) from trend),
    'loss_reasons',(select coalesce(jsonb_agg(jsonb_build_object('reason',loss_reason,'count',cnt,'value',value) order by cnt desc),'[]'::jsonb) from (select coalesce(loss_reason,'unspecified') loss_reason,count(*)::int cnt,coalesce(sum(estimated_value),0) value from current_leads where current_slug='lost' group by coalesce(loss_reason,'unspecified')) x),
    'blocked',(select coalesce(jsonb_agg(jsonb_build_object('stage_id',m.id,'slug',m.slug,'name',m.name,'color',m.color,'count',m.blocked_count,'threshold_days',case when m.slug='negotiation' then 15 else 7 end) order by m.blocked_count desc),'[]'::jsonb) from stage_metrics m where m.blocked_count>0),
    'filters',jsonb_build_object(
      'sources',(select coalesce(jsonb_agg(distinct lead_source),'[]'::jsonb) from all_user_leads where lead_source is not null),
      'cities',(select coalesce(jsonb_agg(city order by city),'[]'::jsonb) from (select distinct "City" city from all_user_leads where "City" is not null and trim("City")<>'') q),
      'commercials',(select coalesce(jsonb_agg(commercial_id),'[]'::jsonb) from (select distinct commercial_id from all_user_leads where commercial_id is not null) q)
    )
  ) into result from current_kpi c cross join previous_kpi p;
  return result;
end;
$$;

revoke execute on function public.get_sales_analytics(text,uuid,text,text,uuid,timestamptz,timestamptz,text) from public, anon;
grant execute on function public.get_sales_analytics(text,uuid,text,text,uuid,timestamptz,timestamptz,text) to authenticated;
